package com.assurant.test.inc.sox.domain.ar;

import java.util.List;

import com.assurant.inc.sox.ar.dto.ApplicationDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;
import com.assurant.inc.sox.ar.dto.CostCenterDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.EnvironmentDTO;
import com.assurant.inc.sox.ar.dto.IndividualDTO;
import com.assurant.inc.sox.ar.dto.ManagerDTO;
import com.assurant.inc.sox.ar.dto.PrivDescriptionDTO;
import com.assurant.inc.sox.ar.dto.PrivValueDTO;
import com.assurant.inc.sox.ar.dto.SourceNameDTO;
import com.assurant.inc.sox.ar.dto.SoxConcernDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.UserTypeDTO;
import com.assurant.inc.sox.ar.service.IMetaDataService;
import com.assurant.inc.sox.domain.ar.FilterType;


public class MetaDataServiceMock implements IMetaDataService {

	public FilterType getFilterTypeByValue(String value) {
		FilterType ft = new FilterType();
		return ft;
	}

	public List<ConflictDTO> retreiveConflicts(Long conflictTypeId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ApplicationDTO> retrieveApplications(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictTypeDTO> retrieveConflictTypes() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<CostCenterDTO> retrieveCostCenters(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DepartmentDTO> retrieveDepartments(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DivisionDTO> retrieveDivisions(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<EnvironmentDTO> retrieveEnvironments() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<IndividualDTO> retrieveIndividuals(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ManagerDTO> retrieveManagers(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PrivDescriptionDTO> retrievePrivDescriptions(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PrivValueDTO> retrievePrivValues(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SourceNameDTO> retrieveSourceNames(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SoxConcernDTO> retrieveSoxConcerns() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserStatusDTO> retrieveUserStatuses() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserTypeDTO> retrieveUserTypes() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
