package com.assurant.test.inc.sox.domain.ar;

import com.assurant.inc.sox.dao.ar.IReviewQueueDao;
import com.assurant.inc.sox.domain.ar.ReviewQueue;

public class ReviewQueueDaoMock implements IReviewQueueDao {

	public ReviewQueue save(ReviewQueue queue) {
		ReviewQueue rq = new ReviewQueue();
		return rq;
	}
	
}
