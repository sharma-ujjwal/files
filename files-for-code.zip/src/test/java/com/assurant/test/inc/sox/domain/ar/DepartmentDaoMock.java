package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IDepartmentDao;
import com.assurant.inc.sox.domain.ar.Department;


public class DepartmentDaoMock implements IDepartmentDao {

	@SuppressWarnings("unchecked")
	public List<Department> findByName(String searchString) {
		if (searchString.equals("ACC")) { 
			List<Department> result = new ArrayList<Department>();
			Department dept1 = new Department();
			dept1.setId(-2L);
			dept1.setName("ACCOUNTS");
			dept1.setCreatedBy("juCr");
			dept1.setCreatedDate(new Date());
			dept1.setDeleteFlag(IFlags.NOT_DELETED);
			result.add(dept1);
			
			Department dept2 = new Department();
			dept2.setId(-3L);
			dept2.setName("ACCOUNTS1");
			dept2.setCreatedBy("juCr");
			dept2.setCreatedDate(new Date());
			dept2.setDeleteFlag(IFlags.NOT_DELETED);
			result.add(dept2);
			return result;
		}
		return Collections.EMPTY_LIST;
	}

	public List<Department> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Department department) {
		// TODO Auto-generated method stub
		// return '';
	}

	public List<Department> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Department findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean findNameExist(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Department> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findUnassignedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Department findDuplicate(String name, String costCenterNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findAllByDepartmentNameCostCenter(String searchText) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findDeletedByDepartmentNameCostCenter(String searchText) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> findUnassignedByDepartmentNameCostCenter(String searchText) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean canDepartmentBeDeleted(Long id) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
