package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IReviewWorkOrderDao;
import com.assurant.inc.sox.domain.ar.ReviewApplicationWO;
import com.assurant.inc.sox.domain.ar.ReviewApplicationWOPk;
import com.assurant.inc.sox.domain.ar.ReviewUserAccessWO;
import com.assurant.inc.sox.domain.ar.ReviewUserAccessWOPk;
import com.assurant.inc.sox.domain.ar.ReviewUserWO;
import com.assurant.inc.sox.domain.ar.ReviewUserWOPk;
import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;


public class ReviewWorkOrderDaoMock implements IReviewWorkOrderDao {

	public List<ReviewApplicationWO> findByReviewApplicationId(
			Long reviewApplicationId) {
		if (reviewApplicationId.equals((67890L))) {
			// UserActionRequiredServiceTest.testRetrieveActionItems
			List<ReviewApplicationWO> appWOList = new ArrayList<ReviewApplicationWO>();
			ReviewApplicationWO appWO = new ReviewApplicationWO();
			ReviewApplicationWOPk pk = new ReviewApplicationWOPk();
			pk.setReviewApplicationId(reviewApplicationId);
			ReviewWorkOrder wo = new ReviewWorkOrder();
			wo.setReasonCode("TERM");
			pk.setWorkOrder(wo);
			appWO.setPk(pk);
			appWOList.add(appWO);
			return appWOList;
		} else {
			throw new AssertionError("Invalid Review application Id: " + reviewApplicationId);
		}
	}

	public List<ReviewUserAccessWO> findByReviewUserAccessId(
			Long reviewUserAccessId) {
		if (reviewUserAccessId.equals((42342L))) {
			// UserActionRequiredServiceTest.testRetrieveActionItems
			List<ReviewUserAccessWO> accessWOList = new ArrayList<ReviewUserAccessWO>();
			ReviewUserAccessWO accessWO = new ReviewUserAccessWO();
			ReviewUserAccessWOPk pk = new ReviewUserAccessWOPk();
			pk.setReviewUserAccessId(reviewUserAccessId);
			ReviewWorkOrder wo = new ReviewWorkOrder();
			wo.setReasonCode("TERM");
			pk.setWorkOrder(wo);
			accessWO.setPk(pk);
			accessWOList.add(accessWO);
			return accessWOList;
		} else {
			throw new AssertionError("Invalid Review User Access Id: " + reviewUserAccessId);
		}
		
	}

	public List<ReviewUserWO> findByReviewUserId(Long reviewUserId) {
		if (reviewUserId.equals((44444L))) {
			// UserActionRequiredServiceTest.testRetrieveWorkOrdersByReviewUser
			List<ReviewUserWO> woList = new ArrayList<ReviewUserWO>();
			ReviewUserWO userWO = new ReviewUserWO();
			ReviewUserWOPk pk = new ReviewUserWOPk();
			pk.setReviewUserId(reviewUserId);
			ReviewWorkOrder wo = new ReviewWorkOrder();
			wo.setReasonCode("TERM");
			pk.setWorkOrder(wo);
			userWO.setPk(pk);
			woList.add(userWO);
			return woList;
		} else {
			throw new AssertionError("Invalid Review User Id: " + reviewUserId);
		}
		
	}

	public List<ReviewWorkOrder> findBySavvionId(String savvionId) {
		
		if (savvionId.equals("SoxSummary_V1#20755")) {
			// MyTaskListServiceTest.testRetrieveActionRequiredTasks
			List<ReviewWorkOrder> woList = new ArrayList<ReviewWorkOrder>();
			ReviewWorkOrder wo = new ReviewWorkOrder();
			wo.setWorkOrderNo((32234L));
			woList.add(wo);
			return woList;
		} else {
			throw new AssertionError("Invalid savvion Id: " + savvionId);
		}
		
	}

	public ReviewWorkOrder save(ReviewWorkOrder workOrder) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewUserAccessWO saveAccessWO(ReviewUserAccessWO accessWorkOrder) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewApplicationWO saveApplicationWO(
			ReviewApplicationWO appWorkOrder) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewUserWO saveReviewUserWO(ReviewUserWO userWorkOrder) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
