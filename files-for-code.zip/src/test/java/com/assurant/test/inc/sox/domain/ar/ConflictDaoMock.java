package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IConflictDao;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.Division;

public class ConflictDaoMock implements IConflictDao {

	@SuppressWarnings("unchecked")
	public List<Conflict> findByConflictTypeId(Long id) {
		if(id.equals((23234L))){
			List<Conflict> result = new ArrayList<Conflict>();
			Conflict conf = new Conflict();
			conf.setId(-3L);
			conf.setLeftConflictName("ACCOUNTING");
			conf.setLeftConflictId(682L);
			conf.setRightConflictId(683L);
			conf.setRightConflictName("AUTOCODER");
			result.add(conf);
			return result;
		}
		return Collections.EMPTY_LIST;
	}

	public Conflict findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findConflictByDivisionId(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findConflictsByConflictTypeIdList(
			List<Long> distinctLeftConflictIdList) {
		// TODO Auto-generated method stub
		return null;
	}

	public Conflict findDistinctConflictTypeLeftConflictIds(Conflict conflict) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Long> findDistinctLeftConflictIds(Long conflictTypeId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Conflict findOnlyFirstConflictRecord(Long distinctLeftConflictId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Conflict getById(Long conflictId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Long save(Conflict conflict) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findConflictByDivisionId(Division division) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findAllByName(String leftConflictSearchText,
			String rightConflictSearchText) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findAllConflictsByCode(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Conflict> findDeletedByName(String leftConflictSearchText,
			String rightConflictSearchText) {
		// TODO Auto-generated method stub
		return null;
	}

}
