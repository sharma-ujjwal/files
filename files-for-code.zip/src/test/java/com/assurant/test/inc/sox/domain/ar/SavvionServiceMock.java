/*package com.assurant.test.inc.sox.domain.ar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;

import com.assurant.inc.sox.ar.service.ISavvionService;
import com.assurant.inc.sox.ar.service.impl.TestHelper;
import com.assurant.inc.sox.ar.utils.exceptions.SavvionException;
import com.assurant.inc.sox.consts.ISavvionValues;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.dto.SavvionDTO;

public class SavvionServiceMock implements ISavvionService {

	public void completeProcess(String processId) throws SavvionException {
		// TODO Auto-generated method stub

	}

	public void createBulkProcess(DataSlotsTemplateCode processTemplate, String processInstanceNamePrefix, String priority,
	    List<HashMap<String, Object>> savvionReviewers) throws SavvionException {

		Assert.assertEquals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY, processTemplate);
		Assert.assertEquals(ISavvionValues.PROCESS_INSTANCE_NAME_PREFIX_VERIFY, processInstanceNamePrefix);
		Assert.assertEquals(ISavvionValues.PRIORITY_LOW, priority);

		HashMap<String, Object> dataSlots = savvionReviewers.get(0);
		Assert.assertEquals("juEmail", dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_TO));
		Assert.assertEquals("junitFrom", dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_FROM));
		Assert.assertNotNull(dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_SUBJECT));
		Assert.assertEquals("Bob reviewer", dataSlots.get(ISavvionValues.DATASLOTS_REVIEWER_NAME));
		Assert.assertEquals("34460", dataSlots.get(ISavvionValues.DATASLOTS_REVIEWER_ID));
		Assert.assertEquals("appUrl", dataSlots.get(ISavvionValues.DATASLOTS_URL));
		Assert.assertEquals(new SimpleDateFormat("EEE, MMM dd yyyy").format(TestHelper.buildTimelessDate(2004, 2, 1)), dataSlots
		    .get(ISavvionValues.DATASLOTS_TARGET_DUE_DATE));
		Assert.assertEquals("Instructions", dataSlots.get(ISavvionValues.DATASLOTS_INSTRUCTIONS));
		Assert.assertEquals(ISavvionValues.REASSIGNED_FALSE, dataSlots.get(ISavvionValues.DATASLOTS_REASSIGNED));
		Assert.assertEquals("JU34460", dataSlots.get(ISavvionValues.DATASLOTS_ASSIGNEE));

		// TODO Auto-generated method stub

	}

	public String createProcess(DataSlotsTemplateCode processTemplate, String processInstanceNamePrefix, String priority,
	    String assignedTo, HashMap<String, Object> dataSlots) throws SavvionException {
		if (processTemplate.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_SUMMARY)) {
			// ReviewBundleServiceTest.testCreateReviewBundle
			return "SoxSummary_V1#20755";
		} else if(processTemplate.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_REJECT_USER)) {
			// ReviewUserServiceTest.testRejectReviewUsers
			return "SoxSummary_V1#23453";
		} else {
			throw new AssertionError("Invalid savvion template found " + processTemplate);
		}

	}

	public List<SavvionDTO> retrieveProcessesByAssignedTo(String userId) throws SavvionException {
		if (userId.equals("TestSavvionITComplianceUserId")) {
			// MyTaskListServiceTest.testCreateReviewBundle
			List<SavvionDTO> dtos = new ArrayList<SavvionDTO>();
			SavvionDTO dto = new SavvionDTO();
			dto.setAssignedTo(userId);
			dto.setTaskCode(TaskTypeCode.VALIDATE_ACTION_REQUIERED);
			dto.setSavvionProcessId("SoxSummary_V1#20755");
			Map<String, Object> dataSlots = new HashMap<String, Object>();
			dataSlots.put(ISavvionValues.DATASLOTS_VALIDATE_APPLICATION_ID, "12543");
			dataSlots.put(ISavvionValues.DATASLOTS_VALIDATE_REVIEWER_ID, "23234");
			dto.setDataSlots(dataSlots);
			dtos.add(dto);
			return dtos;
		}  else {
			throw new AssertionError("Invalid user Id: " + userId);
		}
	}

	public List<SavvionDTO> retrieveProcessesByTemplateName(DataSlotsTemplateCode templateName) throws SavvionException {
		List<SavvionDTO> dtos = new ArrayList<SavvionDTO>();
	       if(templateName.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_REJECT_USER)) {
	    	// ReviewServiceTest.testCloseReview
	    	   Map<String, Object> dataSlots = new  HashMap<String, Object>();
	    	   dataSlots.put(ISavvionValues.DATASLOTS_VALIDATE_REJECTED_USER_ID, "12345");
	    	   SavvionDTO dto = new SavvionDTO();
	    	   dto.setDataSlots(dataSlots);
	    	   dtos.add(dto);
	    	   return dtos;
			} else if(templateName.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VALIDATE_ACCESS)) {
			// ReviewServiceTest.testCloseReview
		       Map<String, Object> dataSlots = new  HashMap<String, Object>();
		       dataSlots.put(ISavvionValues.DATASLOTS_VALIDATE_REVIEWER_ID, "88888");
		       SavvionDTO dto = new SavvionDTO();
		       dto.setDataSlots(dataSlots);
		       dtos.add(dto);
			   return dtos;
			} else if (templateName.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY)) {
			// ReviewerTaskListServiceTest.testRetrieveTaskListForAllReviewers
			   Map<String, Object> dataSlots = new  HashMap<String, Object>();
			   dataSlots.put(ISavvionValues.DATASLOTS_VALIDATE_REVIEWER_ID, "88888");
			   SavvionDTO dto = new SavvionDTO();
			   dto.setTaskCode(TaskTypeCode.REVIEW_DETAILS);
			   dto.setDataSlots(dataSlots);
			   dtos.add(dto);
			   return dtos;			
			} else {
				throw new SavvionException("Invalid template name :" + templateName);
			}
	
	}

	public void updateProcessDataSlots(String processId, Map<String, Object> dataSlots) throws SavvionException {

		if("SoxSummary_V1#20755".equals(processId)) {
		Assert.assertNotNull(processId);
		Assert.assertNotNull(dataSlots);
		Assert.assertEquals("SoxSummary_V1#20755", processId);
		}
		else if("Savvion#558948".equals(processId)) {
		// ReviewerServiceTest.testReassignReleasedReviewer
			Assert.assertEquals("email@emailAddr", dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_TO));
			Assert.assertEquals("junitFrom", dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_FROM));
			Assert.assertEquals("testReassignReleasedReviewer", dataSlots.get(ISavvionValues.DATASLOTS_EMAIL_SUBJECT));
			Assert.assertEquals("userName", dataSlots.get(ISavvionValues.DATASLOTS_REVIEWER_NAME));
			Assert.assertEquals(new Long(5577383).toString(), dataSlots.get(ISavvionValues.DATASLOTS_REVIEWER_ID));
			Assert.assertEquals("appUrl", dataSlots.get(ISavvionValues.DATASLOTS_URL));
			Assert.assertEquals(new SimpleDateFormat("EEE, MMM dd yyyy").format(TestHelper.buildTimelessDate(2004, 4, 3)), dataSlots.get(ISavvionValues.DATASLOTS_TARGET_DUE_DATE));
			Assert.assertEquals("drist instructions blah", dataSlots.get(ISavvionValues.DATASLOTS_INSTRUCTIONS));
			Assert.assertEquals(ISavvionValues.REASSIGNED_TRUE, dataSlots.get(ISavvionValues.DATASLOTS_REASSIGNED));
			Assert.assertEquals("JU7733", dataSlots.get(ISavvionValues.DATASLOTS_ASSIGNEE));
			
			
		}
		else {
			throw new AssertionError("Invalid process id: " + processId);
		}

	}

}
*/