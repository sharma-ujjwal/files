package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.dao.ar.IReviewDao;
import com.assurant.inc.sox.domain.ar.Review;

public class ReviewDaoMock implements IReviewDao {

	public List<Review> findAll() {
		List<Review> reviews = new ArrayList<Review>();
		Review review = new Review();
		review.setId((12344L));
		review.setReviewName("Manager101");
		reviews.add(review);
		return reviews;
	}

	public Review findById(Long id) {

		Review review;
		if (12342L == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			review = new Review();
			review.setId(id);
			review.setReviewTypeCd(ReviewTypeCode.DATA_OWNER.getCode());
		} else if ((12343) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
			review = new Review();
			review.setId(id);
			review.setReviewTypeCd(ReviewTypeCode.MANAGER.getCode());
		} else if ((12344) == (id)) {
			// ReviewBundleServiceTest.testRetrieveReviewName
			// ReviewServiceTest.testRetrieveReviewById
			review = new Review();
			review.setId(id);
			review.setReviewName("Manager101");
			review.setReviewTypeCd("MNGR");
			review.setReviewStatus("PEND");
			return review;
		} else if((88776) == (id)) {
			review = new Review();
			review.setId((34488L));
			review.setReviewTypeCd(ReviewTypeCode.MANAGER.getCode());
		} else if((12345) == (id)) {
		 // ReviewServiceTest.testCloseReview
			review = new Review();
			review.setId((34488L));
			
		} else {
		
			throw new AssertionError("Invalid review id found: " + id);
		}

		return review;
	}

	public Review findByName(String reviewName) {
		return null;
	}

	public List<Review> findByStatus(String status) {
		List<Review> reviews = new ArrayList<Review>();
		if(status.equals(ReviewStatusCode.OUTSTANDING.getCode())) {
			// ReviewServiceTest.testRetrieveReviewsByStatus
			Review review = new Review();
			review.setId((12343L));
			review.setReviewStatus("OTST");
			review.setReviewTypeCd(ReviewTypeCode.MANAGER.getCode());
			reviews.add(review);
			return reviews;
		} else if(status.equals(ReviewStatusCode.COMPLETED.getCode())) {
			// ReviewServiceTest.testRetrieveCompletedDashboardReviews
			Review review = new Review();
			review.setId((12343L));
			review.setReviewStatus("CMPD");
			review.setReviewTypeCd(ReviewTypeCode.MANAGER.getCode());
			reviews.add(review);
			return reviews;
		} else {
			throw new AssertionError("Invalid review Status" + status);
		}
		
	}

	public Review save(Review review) {
		review.setId((12345L));
		review.setReviewTypeCd("MNGR");
		review.setReviewStatus("PEND");
		return review;
	}

}
