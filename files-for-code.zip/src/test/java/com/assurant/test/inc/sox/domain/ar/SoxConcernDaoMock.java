package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.ISoxConcernDao;
import com.assurant.inc.sox.domain.ar.SoxConcern;

public class SoxConcernDaoMock implements ISoxConcernDao {

	public List<SoxConcern> findAll() {
		List<SoxConcern> result =  new ArrayList<SoxConcern>();
		SoxConcern s = new SoxConcern();
		s.setId((-2L));
		s.setSoxConcernCode("D");
		result.add(s);
		return result;
	}

	public List<SoxConcern> findByValue(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SoxConcern> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SoxConcern> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean doesNameExist(String nameExists) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<SoxConcern> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SoxConcern> findUnassignedByName(String soxConcerntNameLike) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(SoxConcern soxConcern) {
		// TODO Auto-generated method stub
		
	}

	public SoxConcern findDuplicate(String codeExists) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean canSoxConcernBeDeleted(String soxConcernCode) {
		// TODO Auto-generated method stub
		return false;
	}	
}
