package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IFilterTypeDao;
import com.assurant.inc.sox.domain.ar.FilterType;

public class FilterTypeDaoMock implements IFilterTypeDao {

	public List<FilterType> findAll() {
		List<FilterType> result = new ArrayList<FilterType>(2);
		FilterType filter = new FilterType();
		filter.setId(-2L);
		filter.setCreatedBy("juCr");
		filter.setCreatedDate(new Date());
		filter.setDeleteFlag("N");
		filter.setFilterTypeValue("Department");
		result.add(filter);
		return result;
	}
}
