/*package com.assurant.test.inc.sox.domain.ar;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang.math.RandomUtils;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.richfaces.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.impl.TestHelper;
import com.assurant.inc.sox.ar.service.impl.WorkflowService;
import com.assurant.inc.sox.ar.service.util.WorkflowUtil;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.ISavvionValues;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.dto.TaskDTO;

public class WorkflowServiceMock {
	
protected static final Logger logger = LoggerFactory.getLogger(WorkflowServiceMock.class);

	@Autowired
	WorkflowService workflowService;

	String taskId = null;
    
    public static final Logger getLogger() {
        return logger;
    }

	public void createProcess() {
		WorkflowService workflowService = new WorkflowService();
		Map<String, Object> dataSlots = getMockDataSlots(null);
		String processId = workflowService.createProcess(WorkflowTemplateCode.createProcess, ISavvionValues.ALL_INSTANCE_NAME_PREFIX_VERIFY, ISavvionValues.PRIORITY_LOW, WorkflowUtil.username, dataSlots);
		taskId = processId;
		getLogger().debug("processId: " + processId);
		Assert.assertNotNull(processId);
	}

	@Test
	public void updateProcessDataSlots() {
		createProcess();
		Map<String, Object> dataSlots = new HashMap<String, Object>();
		dataSlots.put(ISavvionValues.DATASLOTS_REVIEWER_NAME, "Ray Tester");
		dataSlots.put(ISavvionValues.DATASLOTS_REVIEWER_ID, "15360");
		dataSlots.put(ISavvionValues.DATASLOTS_REASSIGNED, ISavvionValues.REASSIGNED_TRUE);
		WorkflowService workflowService = new WorkflowService();
		workflowService.updateProcessDataSlots(taskId,  getMockDataSlots(dataSlots));
		completeProcess();
	}

//	@Test
	public void retrieveProcessesByAssignedTo() throws JSONException {
		WorkflowService workflowService = new WorkflowService();
		List<TaskDTO> retriveProcessesBy = workflowService.retrieveProcessesByAssignedTo("rz7830");//retriveProcessesBy("rz7830", "assignedTo");
		getLogger().debug("TaskDTO List: " + retriveProcessesBy);
	}

//	@Test
	public void retrieveProcessesByTemplateName() {
		WorkflowService workflowService = new WorkflowService();
		List<TaskDTO> retriveProcessesBy = workflowService.retrieveProcessesByTemplateName(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_SUMMARY);
		getLogger().debug("TaskDTO List: " + retriveProcessesBy);
	}

	public void completeProcess() {
		WorkflowService workflowService = new WorkflowService();
		workflowService.completeProcess(taskId);
	}

	public void createBulkProcess() {
	}
	
	private static final Map<String, Object> getMockDataSlots(Map<String, Object> modify){
		Map<String, Object> dataSlots = new HashMap<String, Object>();
		dataSlots.put(ISavvionValues.DATASLOTS_EMAIL_TO, "juEmail");
		dataSlots.put(ISavvionValues.DATASLOTS_EMAIL_FROM, "junitFrom");
		dataSlots.put(ISavvionValues.DATASLOTS_EMAIL_SUBJECT, "juEmail");
		dataSlots.put(ISavvionValues.DATASLOTS_REVIEWER_NAME, "Bob reviewer");
		dataSlots.put(ISavvionValues.DATASLOTS_REVIEWER_ID, "34460");
		dataSlots.put(ISavvionValues.DATASLOTS_URL, "appUrl");
		dataSlots.put(ISavvionValues.DATASLOTS_TARGET_DUE_DATE, new SimpleDateFormat("EEE, MMM dd yyyy").format(TestHelper.buildTimelessDate(2004, 2, 1)));
		dataSlots.put(ISavvionValues.DATASLOTS_INSTRUCTIONS, "Instructions");
		dataSlots.put(ISavvionValues.DATASLOTS_REASSIGNED, ISavvionValues.REASSIGNED_FALSE);
		dataSlots.put(ISavvionValues.DATASLOTS_ASSIGNEE, WorkflowUtil.username);
		if(modify != null){
			dataSlots.putAll(modify);
		}
		return dataSlots;
	}

	public DataSlotsTemplateCode getRandomDataSlot(){
		int val = RandomUtils.nextInt(4);
		getLogger().debug("random val: " + val + " value: " + DataSlotsTemplateCode.values()[val]);
		return DataSlotsTemplateCode.values()[val];
	}

}
*/