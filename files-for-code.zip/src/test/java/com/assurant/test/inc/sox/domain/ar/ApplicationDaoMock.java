package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IApplicationDao;
import com.assurant.inc.sox.domain.ar.Application;


public class ApplicationDaoMock implements IApplicationDao {

	public List<Application> findAll() {
		return null;
	}

	public Application findById(Long id) {
		return null;
	}
   
	@SuppressWarnings("unchecked")
	public List<Application> findByName(String searchString) {
		if(searchString.equals("APP")){
			List<Application> apps = new ArrayList<Application>(2);
			Application app1 = new Application();
			app1.setName("APP1");
			app1.setId(-2L);
			app1.setCreatedBy("juCr");
			app1.setCreatedDate(new Date());
			app1.setDeleteFlag(IFlags.NOT_DELETED);
			apps.add(app1);
			
			Application app2 = new Application();
			app2.setName("APP2");
			app2.setId(-3L);
			app2.setCreatedBy("juCr");
			app2.setCreatedDate(new Date());
			app2.setDeleteFlag(IFlags.NOT_DELETED);
			apps.add(app2);
	        
			return apps;
		}
		
		return Collections.EMPTY_LIST;
	}

	public List<Application> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Application> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Application> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Application findDuplicate(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Application> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Application> findUnassignedByName(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Application application) {
		// TODO Auto-generated method stub
		
	}

	public boolean canBeDeleted(String applicationName) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
