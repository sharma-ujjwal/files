package com.assurant.test.inc.sox.domain.ar;

import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.utils.exceptions.DuplicateReviewNameException;
import com.assurant.inc.sox.ar.utils.exceptions.NonClosableReview;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;
import com.assurant.inc.sox.domain.ar.Review;


public class ReviewServiceMock implements IReviewService {

	public void calculateStatistics(ReviewDashboardDTO reviewDashboardDTO) {
		// TODO Auto-generated method stub
		
	}

	public void closeReview(Long reviewId) throws NonClosableReview {
		// TODO Auto-generated method stub
		
	}

	public ReviewDTO createReview(String name, ReviewTypeCode typeCode,
			String comments, Date targetDate, boolean adHoc)
			throws DuplicateReviewNameException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewDashboardDTO> retrieveCompletedDashboardReviews() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewDashboardDTO> retrieveOutstandingDashboardReviews() {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewDTO retrieveReviewById(Long reviewId) {
		Review review;
		CodeDTO codeDTO;
		if(reviewId.equals((12344L))) {
			// ReviewBundleServiceTest.testCreateReviewBundle
			Code code = new Code();
			CodePk pk = new CodePk();
			pk.setColumnName("reviewtypecode");
			pk.setTableName("review");
			pk.setValue("MNGR");
			code.setPk(pk);
			codeDTO = new CodeDTO(code);
			review = new Review();
			review.setId((12344L));
		} else {
			throw new AssertionError("Invalid review id: " + reviewId);
		}
		return new ReviewDTO(review, codeDTO, codeDTO);
	}

	public List<ReviewDTO> retrieveReviewsByStatus(ReviewStatusCode status) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewDTO updateReview(ReviewDTO reviewDto) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
