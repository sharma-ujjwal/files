/*package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.dao.savvion.ISavvionDao;

import com.assurant.inc.sox.dto.SavvionDTO;


public class SavvionDaoMock implements ISavvionDao {

	public List<SavvionDTO> findByAssignedTo(String assignedTo) {
		if (assignedTo.equals("TestAssignedTo")) {
			List<SavvionDTO> dtos = new ArrayList<SavvionDTO>();
			SavvionDTO dto = new SavvionDTO();
			dto.setAssignedTo(assignedTo);
			dtos.add(dto);
			return dtos;
		} else {
			throw new AssertionError("Invalid assigned to: " + assignedTo);
		}
		
	}

	public List<SavvionDTO> findByAssignedToProcessTemplate(String assignedTo,
			DataSlotsTemplateCode processTemplate) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<SavvionDTO> findByProcesTemplate(
			DataSlotsTemplateCode processTemplate) {
		if (processTemplate.equals(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY)) {
			List<SavvionDTO> dtos = new ArrayList<SavvionDTO>();
			SavvionDTO dto = new SavvionDTO();
			dtos.add(dto);
			return dtos;
		} else {
			throw new AssertionError("Invalid assigned to: " + processTemplate);
		}
	}
	
}
*/