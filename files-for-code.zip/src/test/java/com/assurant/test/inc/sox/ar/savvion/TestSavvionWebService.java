/*package com.assurant.test.inc.sox.ar.savvion;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.rmi.RemoteException;

import org.junit.Before;
import org.junit.Test;

public class TestSavvionWebService {
	private String webServiceEndPoint = "http://lkcmvwasdev2:9070/sbm/services/BizLogic";
	//private String webServiceEndPoint = "http://lkcmvwasstg5:9070/sbm/services/BizLogic";
	
	
	private String userId = "EBMS";
	
	private String password = "develop";
	//private String password = "staging";
	
	private String schedulePtName = "SoxSummary_V1";
	private String schedulePiNamePrefix = "SoxSummary_V1";
	
	private String verifyPtName = "SoxVerifyReviews_V1";
	private String verifyPiNamePrefix = "SoxVerifyReviews_V1";
	
	private String rejectUserPtName = "SoxRejectUser_V1";
	private String rejectUserPiNamePrefix = "SoxRejectUser_V1";
	
	private String rejectAccess_CommentPtName = "SoxRejectAccessComment_V1";
	private String rejectAccess_CommentPiNamePrefix = "SoxRejectAccessComment_V1";	
	
	private String piName = null;
	
	String sessionId = null;
	
	@Before
	public void setUp() throws Exception {
		proxy = new BizLogicProxy(webServiceEndPoint);
	}
	
	@Test 
	public void testInitProxy() {
		assertNotNull(proxy);
	}
	
	@Test
	public void testConnect(){
		sessionId = connect();
		assertNotNull(sessionId);
	}
	
	private String connect(){
		try {
			sessionId = proxy.connect(userId, password);
		} catch (RemoteException e){ 
			e.printStackTrace();
			assertTrue(false);
		}
		return sessionId;
	}
	
	private void disconnect(){
		try {
			proxy.disconnect(sessionId);
		} catch (RemoteException e) {
			e.printStackTrace();
			assertTrue(false);
		}		
	}	
	
//	@Test
//	public void testScheduleReviewTask(){
//		connect();
//		assertNotNull(createScheduleReviewTask());
//		disconnect();
//	}	
//	
//	@SuppressWarnings("unchecked")
//	@Test
//	public void testRetrieveAllProcessesForTemplateName(){
//		try{
//			sessionId = connect();
//			createScheduleReviewTask();
//			String[] test = proxy.getProcessInstanceNameList_02(sessionId, SavvionTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY.getCode());
//			for (String string : test) {
//				PAKClientWorkitem[] workitems = proxy.getProcessInstanceWorkitem(sessionId, string);
//				assertNotNull(workitems);
//			}
//			assertNotNull(test);
//			
////			for (Map.Entry pair : processInstances.entrySet()) {
////				
////				Map<String, String> test = (HashMap)pair.getValue();
////				System.out.println("Number of processes found " + test.size());
////				for (Map.Entry pair2 : test.entrySet()) {
////					System.out.println("key = " + pair2.getKey());
////					System.out.println("value = " + pair2.getValue());
////				} 				
////			} 		
////			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}
//	}	
//	
//	@Test
//	public void testRetrieveProcessInfoForId(){
//		
//		try{
//			sessionId = connect();
//			createScheduleReviewTask();
//			String test = proxy.getProcessInstanceID(sessionId, piName);
//			System.out.println("ProcessInstanceID: " + test);
//			
//			HashMap<String, Object> map = proxy.getProcessInstanceInfo(sessionId, piName);
//			System.out.println("InstanceInfo: " + map);
//
//			test = proxy.getProcessInstanceStartTime(sessionId, piName);
//			System.out.println("StartTime: " + test);	
//			 
//			test = proxy.getProcessInstanceStatus(sessionId, piName);
//			System.out.println("Status: " + test);				
//			
//			test = (String)proxy.getDataslotValue(sessionId, piName, "Assignee");
//			System.out.println("DataslotValue: " + test);	
//			
//			test = proxy.getProcessInstanceCategory(sessionId, piName);
//			System.out.println("category: " + test);	
//			
//			test = proxy.getProcessInstanceDescription(sessionId, piName);
//			System.out.println("desc: " + test);
//			
//			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}		
//	}		
//	
//	@Test
//	public void testUpdateProcessDataSlots(){
//		
//		try{
//			sessionId = connect();
//			
//			piName = createScheduleReviewTask();
//
//			HashMap<String, Object> dataSlots = new HashMap<String, Object>();
//			
//			dataSlots.put(ISavvionValues.DATASLOTS_SUMMARY_APPROVED, true);			
//			
//			updateDataSlots(piName, dataSlots);
//			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}		
//	}	
//	
//	@Test
//	public void testCompleteWorkflowStep(){
//		
//		try{
//			sessionId = connect();
//			
//			piName = createScheduleReviewTask();
//
//			HashMap<String, Object> dataSlots = new HashMap<String, Object>();
//			
//			dataSlots.put(ISavvionValues.DATASLOTS_SUMMARY_APPROVED, true);	
//			
//			PAKClientWorkitem[] workitem = proxy.getProcessInstanceWorkitem(sessionId, piName);
//			
//			proxy.completeWorkitem_02(sessionId, workitem[0].getName());		
//			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}		
//	}		
//	
//	@Test
//	public void testAssignedTo(){
//		
//		try{
//			sessionId = connect();
//			String myPiName = createScheduleReviewTask();
//			
//			HashMap<String, String> map = proxy.getProcessInstanceInfo(sessionId, piName);
//			
//			for (Map.Entry pair : map.entrySet()) {
//				System.out.println("key = " + pair.getKey());
//				System.out.println("value = " + pair.getValue());
//				System.out.println("----------------------------------------------------");
//			}		
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}		
//	}	
//	
//	@Test
//	public void testRetrieveAssignedTo(){
//		
//		try{
//			sessionId = connect();
//			piName = createScheduleReviewTask();
//
//			HashMap<String, Object> dataSlots = new HashMap<String, Object>();
//			
//			dataSlots.put(ISavvionValues.DATASLOTS_SUMMARY_APPROVED, true);				
//			
//			updateDataSlots(piName, dataSlots);
//			
//			PAKClientWorkitem[] workitems = proxy.getWorkitemList_02(sessionId, "ITCompliance");
//			//PAKClientWorkitem[] workitems = proxy.getWorkitemList_01(session);
//			
//			if(workitems != null){
//				for (PAKClientWorkitem workitem : workitems) {
//					System.out.println("piName = " + workitem.getPiName());
//					System.out.println("ptName = " + workitem.getPtName());
//					System.out.println("status = " + workitem.getStatus());
//					System.out.println("name = " + workitem.getName());				
//				}
//			}else
//				System.out.println("workitems is null");
//			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}finally{
//			disconnect();
//		}		
//	}	
//	
////	@Test
////	public void testReassignedTo(){
////		try{
////			sessionId = connect();
////			String myPiName = createScheduleReviewTask();
////			
////			//proxy.setWorkstepPerformer_01(sessionId, myPiName,TaskTypeCode.REVIEW_SUMMARY.getCode(), "ITCompliance");
////			String[] perfs = proxy.getProcessInstanceWorkstepPerformers(sessionId, myPiName);
////			assertTrue("ITCompliance".equals(perfs[0]));
////			for (String string : perfs) {
////				System.out.println("performer 1= " + string);
////			}
////			//proxy.setWorkstepPerformer_01(sessionId, myPiName, TaskTypeCode.REVIEW_SUMMARY.getCode(), "ITCompliance");	
////			
////			String[] perfs2 = proxy.getProcessInstanceWorkstepPerformers(sessionId, myPiName);
////			assertTrue("ITCompliance".equals(perfs2[0]));
////			for (String string : perfs2) {
////				System.out.println("performer 2= " + string);
////			}					
////			
////		} catch(Exception e){
////			e.printStackTrace();
////			assertTrue(false);
////		}finally{
////			disconnect();
////		}		
////	}	
//	
//	private String createScheduleReviewTask() {
//		
//		String priority = "low"; // high, low
//
//		try {
//			HashMap<String, Object> dataSlots = new HashMap<String, Object>();
//			
//			dataSlots.put(ISavvionValues.DATASLOTS_SUMMARY_CREATED, true);
//			dataSlots.put("Assignee", "bb68602");
//			piName = proxy.createProcessInstance_03(sessionId, schedulePtName,schedulePiNamePrefix, priority, dataSlots);
//
//			System.out.println("piName: " + piName);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return piName;
//	}
//	
//	
//	
//	private void updateDataSlots(String processId, HashMap<String, Object> dataSlots){
//		try{
//
//			for (Map.Entry pair : dataSlots.entrySet()) {
//				pair.getKey();
//				pair.getValue();
//				if(pair.getValue() instanceof String){
//					proxy.setDataslotValue_02(sessionId, processId, (String)pair.getKey(), (String)pair.getValue());
//				}else if(pair.getValue() instanceof Boolean){
//					proxy.setDataslotValue_01(sessionId, processId, (String)pair.getKey(), (Boolean)pair.getValue());
//				}
//			} 					
//			
//		} catch(Exception e){
//			e.printStackTrace();
//			assertTrue(false);
//		}
//	}
//
//	
//	@Test
//	public void testVeriftyUserAccessWorkStep() {
//		try {
//			connect();
//			piName = createVerifyAccessTask();
//
//			System.out.println("piName: " + piName);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	@Test
//	public void testReassignVeriftyUserAccessWorkStep() {
//
//		try {
//			connect();
//			piName = "SoxVerifyReviews_V1#14794";
//			
//			HashMap<String, Object> map =buildVerifyAccessDataSlots("brandon.beckley@assurant.com", "brandon.beckley@assurant.com",
//					"Q1 All Manager Review - Reassigned", "Jeff Shaw", "2", "http://google.com", "1/1/2009", "These are your instructions, please log in and complete your review", true, "ITCompliance");			
//			
//			updateDataSlots(piName, map);
//			
//			PAKClientWorkitem[] workitem = proxy.getProcessInstanceWorkitem(sessionId, piName);
//			
//			proxy.completeWorkitem_02(sessionId, workitem[0].getName());			
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	private String createVerifyAccessTask() {
//		
//		String priority = "low"; // high, low
//		try {
//
//			HashMap<String, Object> map =buildVerifyAccessDataSlots("brandon.beckley@assurant.com", "do.Not.Reply@assurant.com",
//					"Q1 All Manager Review", "Tim Bachta", "1", "http://google.com", "1/1/2009", "These are your instructions, please log in and complete your review", false, "bb68602");			
//						
//			
//			piName = proxy.createProcessInstance_03(sessionId, verifyPtName,verifyPtName, priority, map);
//
//			PAKClientWorkitem[] workitem = proxy.getProcessInstanceWorkitem(sessionId, piName);
//			proxy.completeWorkitem_02(sessionId, workitem[0].getName());	
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return piName;
//	}	
//	
//	private HashMap<String, Object> buildVerifyAccessDataSlots(String emailTo, String emailFrom,
//			String emailSubject, String reviewerName, String reviewerId, String url,
//			String targetDueDate, String instructions, boolean reAssigned, String assignee) {
//				
//		HashMap<String, Object> map = new HashMap<String, Object>();
//		map.put("emailTo", emailTo);
//		map.put("emailFrom", emailFrom);
//		map.put("emailSubject", emailSubject);
//		map.put("ReviewerName", reviewerName);
//		map.put("primaryReviewerId", reviewerId);
//		map.put("url", url);
//		map.put("targetDueDate", targetDueDate);
//		map.put("instructions", instructions);
//		map.put("reAssigned", reAssigned);	
//		map.put("Assignee", assignee);
//			
//		return map;
//	}	
//	
//	@Test
//	public void testRejectUsersTask() {
//
//		try {
//			connect();
//			piName = createRejectUserTask();
//
//			System.out.println("piName: " + piName);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	private String createRejectUserTask() {
//		
//		String priority = "low"; // high, low
//		try {
//
//			HashMap<String, Object> map = new HashMap<String, Object>();
//			String[] list = {"abc", "b"};
//			
//			map.put("ListRejectedUsers", list);
//			map.put("Assignee", "bb68602");
//			piName = proxy.createProcessInstance_03(sessionId, rejectUserPiNamePrefix,rejectUserPtName, priority, map);
//
//			//PAKClientWorkitem[] workitem = proxy.getProcessInstanceWorkitem(sessionId, piName);
//			//proxy.completeWorkitem_02(sessionId, workitem[0].getName());	
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return piName;
//	}	
//	
//	@Test
//	public void testRejectAccessCommentTask() {
//
//		try {
//			connect();
//			piName = createRejectAccessCommentsTask();
//
//			System.out.println("piName: " + piName);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}	
//	
//	private String createRejectAccessCommentsTask() {
//		
//		String priority = "low"; // high, low
//		try {
//
//			HashMap<String, Object> map = new HashMap<String, Object>();
//			String[] list1 = {"abc", "b"};
//			String[] list2 = {"def", "c"};
//			
//			map.put("ListRejectedAccess", list1);
//			map.put("ListRejectedApplicationComment", list2);
//			map.put("Assignee", "bb68602");
//			piName = proxy.createProcessInstance_03(sessionId, rejectAccess_CommentPiNamePrefix,rejectAccess_CommentPtName, priority, map);
//
//			//PAKClientWorkitem[] workitem = proxy.getProcessInstanceWorkitem(sessionId, piName);
//			//proxy.completeWorkitem_02(sessionId, workitem[0].getName());	
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return piName;
//	}		
}
*/