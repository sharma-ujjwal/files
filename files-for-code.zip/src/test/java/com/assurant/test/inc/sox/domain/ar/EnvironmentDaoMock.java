package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IEnvironmentDao;
import com.assurant.inc.sox.domain.ar.Environment;

public class EnvironmentDaoMock implements IEnvironmentDao {

	public List<Environment> findAll() {
		List<Environment> result = new ArrayList<Environment>(2);
		Environment env1 = new Environment();
		env1.setId((-1L));
		env1.setCreatedBy("test");
		env1.setCreatedDate(new Date());
		env1.setDeleteFlag("N");
		result.add(env1);
		
		Environment env2 = new Environment();
		env2.setId((-3L));
		env2.setCreatedBy("test");
		env2.setCreatedDate(new Date());
		env2.setDeleteFlag("N");
		result.add(env2);
		
		return result;
	}

	public List<Environment> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Environment findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Environment> findByName(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Environment> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Environment> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Environment findDuplicate(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Environment> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(Environment environment) {
		// TODO Auto-generated method stub
	}

	public List<Environment> findUnassignedByName(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
