package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;

import com.assurant.inc.sox.ar.service.impl.TestHelper;
import com.assurant.inc.sox.dao.ar.IReviewerReassignmentDao;
import com.assurant.inc.sox.domain.ar.ReviewerReassignment;

public class ReviewerReassignmentDaoMock implements IReviewerReassignmentDao {

	public List<ReviewerReassignment> findByReviewerId(Long reviewerId) {
		List<ReviewerReassignment> results = new ArrayList<ReviewerReassignment>(3);
		if ((5577383L) == (reviewerId)) {
			ReviewerReassignment reassign = new ReviewerReassignment();
			reassign.setReviewReassignSeqNumber(2);
			reassign.setReviewReassignEndDate(TestHelper.buildTimelessDate(1999, 7, 3));
			reassign.setReviewReassignNewUserId((3L));
			results.add(reassign);
		} else {
			throw new AssertionError("Invalid reviewer id: " + reviewerId);
		}
		// TODO Auto-generated method stub
		return results;
	}

	public ReviewerReassignment save(ReviewerReassignment reviewReassignment) {
		if((5577383) == (reviewReassignment.getReviewerId())) {
			TestHelper.assertTimelessDateEquals(TestHelper.buildTimelessDate(1999, 7, 3), reviewReassignment.getReviewReassignBeginDate());
			Assert.assertEquals(Optional.of(3L).get(), reviewReassignment.getReviewReassignPrevUserId());
			Assert.assertEquals(Optional.of(43L).get(), reviewReassignment.getReviewReassignNewUserId());
			Assert.assertEquals("REAS", reviewReassignment.getReassignmentCode());
			Assert.assertEquals("reassign comment", reviewReassignment.getReassignmentText());
			Assert.assertEquals(3, reviewReassignment.getReviewReassignSeqNumber());
		}
		else {
			throw new AssertionError("Invalid reviewer id: " + reviewReassignment.getReviewerId());
		}
		// TODO Auto-generated method stub
		return reviewReassignment;
	}

}
