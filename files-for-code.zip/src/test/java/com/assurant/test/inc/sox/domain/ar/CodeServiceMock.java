package com.assurant.test.inc.sox.domain.ar;

import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;

public class CodeServiceMock implements ICodeService {

	public List<CodeDTO> retrieveAllCodesByType(CodeSet codeSet) {
		// TODO Auto-generated method stub
		return null;
	}

	public CodeDTO retrieveCodeByValueFromCache(CodeSet codeSet, String value) {
		CodeDTO code;
		if (CodeSet.REVIEWER_REJECT_REASON.equals(codeSet)
				||CodeSet.REVIEWER_STATUS.equals(codeSet)
				||CodeSet.REVIEW_BUNDLE_STATUS.equals(codeSet)
				||CodeSet.REVIEW_TYPE.equals(codeSet)
				||CodeSet.REVIEW_STATUS.equals(codeSet)
				||CodeSet.REVIEW_USER_ACCESS_STATUS.equals(codeSet)
				||CodeSet.REVIEW_USER_REJECT_REASON.equals(codeSet)
				||CodeSet.REVIEW_USER_COMPLETE.equals(codeSet)
				||CodeSet.WORK_ORDER_REASON.equals(codeSet)) {
			code = buildCode(codeSet, value);
		} else {
			throw new AssertionError("Invalid code set: " + codeSet.getTableName() + " " + codeSet.getColumnName());
		}
		return code;
	}

	private CodeDTO buildCode(CodeSet codeSet, String value) {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName(codeSet.getColumnName());
		pk.setTableName(codeSet.getTableName());
		pk.setValue(value);
		code.setPk(pk);
		CodeDTO codeDto = new CodeDTO(code);
		return codeDto;
	}

}
