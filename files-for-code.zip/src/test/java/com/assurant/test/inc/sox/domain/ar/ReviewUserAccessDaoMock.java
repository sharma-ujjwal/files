package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessStatusCode;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ApplicationSystem;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;


public class ReviewUserAccessDaoMock implements IReviewUserAccessDao {

	public ReviewUserAccess findById(Long reviewUserAccessId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewUserAccess> findByIds(List<Long> reviewUserAccessIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewUserAccess> findByReviewUserId(Long reviewUserid) {
		List<ReviewUserAccess> userAccesses = new ArrayList<ReviewUserAccess>();
		if(reviewUserid.equals(22222L)) {
			ReviewUserAccess access = new ReviewUserAccess();
			Application app = new Application();
			app.setName("JUnitTestName");
			ApplicationSystem appSystem = new ApplicationSystem();
			appSystem.setApplication(app);
			access.setApplicationSystem(appSystem);
			access.setUserId("ABC1001");
			access.setReviewUserId(555333L);
			access.setValidationStatusCode(ReviewUserAccessStatusCode.ACTIVE.getCode());
			userAccesses.add(access);
			return userAccesses;
		} else {
			throw new AssertionError("Invalid review user id: " + reviewUserid);
		}
	}

	public List<String> findDistinctSoxValuesByReviewerId(Long reviewerId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewUserAccess> findRejectedByReviewUserIds(
			List<Long> reviewUserIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewUserAccess> findRejectedByReviewerAndApplication(
			Long reviewerId, Long applicationId) {
		if (reviewerId.equals(12345L) && applicationId.equals(67890L)) {
			//UserActionRequiredServiceTest.testRetrieveActionItems
			List<ReviewUserAccess> accesses = new ArrayList<ReviewUserAccess>();
			ReviewUserAccess access = new ReviewUserAccess();
			access.setId(42342L);
			access.setReviewUserId(64546L);
			access.setValidationStatusCode("TEST");
			accesses.add(access);
			return accesses;
		} else {
			throw new AssertionError("Invalid reviewerId :" + reviewerId +"and applicationId: " + applicationId);
		}
		
	}

	public ReviewUserAccess save(ReviewUserAccess reviewUserAccess) {
		
		return reviewUserAccess;
	}

	public List<ReviewUserAccess> save(List<ReviewUserAccess> reviewUserAccesses) {
		// TODO Auto-generated method stub
		return null;
	}


}
