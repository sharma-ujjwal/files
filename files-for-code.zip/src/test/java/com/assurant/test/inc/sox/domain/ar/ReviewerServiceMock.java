package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.utils.exceptions.UnReassignableException;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;
import com.assurant.inc.sox.domain.ar.Reviewer;

public class ReviewerServiceMock implements IReviewerService {

	public void approveReviewers(List<ReviewerDTO> reviewers) {
		// TODO Auto-generated method stub
		
	}

	public void attestReview(ReviewerDTO reviewer, String savvionProcessId,
			List<ReviewUserDTO> reviewUserDTOs) {
		// TODO Auto-generated method stub
		
	}

	public void completeSavvionProcess(Set<Long> reviewBundleIds) {
		// TODO Auto-generated method stub
		
	}

	public List<ReviewerDTO> distributeReviewers(List<ReviewerDTO> reviewers,
			Date targetCompleteDate, String instructions) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserDataDTO> getDataOwnerReviewAvailableReassignReviewers(
			Long applicationId, Long currentAssignedUserId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserDataDTO> getManagerReviewAvailableReassignReviewers(
			Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserDataDTO> getSODAvailableReassignReviewers(
			ConflictDTO conflictType, Long currentAssignedUserId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isReviewDetailCompleted(Long reviewBundleId) {
		// TODO Auto-generated method stub
		return false;
	}

	public void populateHasManagerAccessToApplication(
			List<ReviewerDTO> reviewers) {
		// TODO Auto-generated method stub
		
	}

	public void reassignReleasedReviewer(ReviewerDTO reviewerDTO,
			String reasonCode, String comments, UserDataDTO newUser,
			String savvionProcessId) throws UnReassignableException {
		// TODO Auto-generated method stub
		
	}

	public void reassignReviewer(ReviewerDTO reviewer, String reasonCode,
			String comments, UserDataDTO newUser) {
		// TODO Auto-generated method stub
		
	}

	public void reassignReviewers(List<ReviewerDTO> reviewerDTOs,
			String reasonCode, String comments, UserDataDTO newUser) {
		// TODO Auto-generated method stub
		
	}

	public void rejectReviewers(List<ReviewerDTO> reviewers, String reasonCode,
			String comments) {
		// TODO Auto-generated method stub
		
	}

	public List<ReviewerDTO> retrieveByBundleId(Long reviewBundleId) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewerDTO retrieveById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewerDTO> retrieveByReviewIdForDashboard(Long reviewId) {
		List<ReviewerDTO> dtos = new ArrayList<ReviewerDTO>();
		Reviewer  reviewer = new Reviewer();
		reviewer.setNumberOfDirectReports((2L));
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("ReviewStatusCode");
		pk.setTableName("Review");
		pk.setValue("PEND");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		dtos.add(new ReviewerDTO(reviewer, null, codeDTO, null));
		return dtos;
	}

	public List<ReviewerDTO> retrieveByStatus(Long reviewBundleId,
			ReviewerStatusCode status) {
		// TODO Auto-generated method stub
		return null;
	}

	public int retrieveNumberOfReviewers(List<Long> reviewBundleIds) {
		if((12345L) == (reviewBundleIds.get(0))) {
			// ReviewBundleServiceTest.testRetrieveNumberOfReports
			return 1;
		} else {
			return 0;
		}
	}

	public ReviewerDTO retrieveByIdWithSlim(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void populateReviewerNumberOfDepts(ReviewerDTO dto) {
		// TODO Auto-generated method stub
		
	}

	public void populateReviewerDataOwnerName(ReviewerDTO dto) {
		// TODO Auto-generated method stub
		
	}

	public void populateReviewerEscalationMgrName(ReviewerDTO dto) {
		// TODO Auto-generated method stub
		
	}

	public void populateReviewerSODValues(ReviewerDTO dto) {
		// TODO Auto-generated method stub
		
	}

	public void populateReviewerDistinctEnvName(ReviewerDTO reviewer) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
