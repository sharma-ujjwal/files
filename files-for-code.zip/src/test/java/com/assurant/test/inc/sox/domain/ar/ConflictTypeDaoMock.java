package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IConflictTypeDao;
import com.assurant.inc.sox.domain.ar.ConflictType;

public class ConflictTypeDaoMock implements IConflictTypeDao {

	public List<ConflictType> findAll() {
		List<ConflictType> types = new ArrayList<ConflictType>();
		ConflictType type1 = new ConflictType();
		type1.setId(-2L);
		types.add(type1);
		return types;
	}

	public List<ConflictType> findAllConflictTypeByCode(
			String conflictCodeSelect) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictType> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictType> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictType> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictType> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConflictType> findUnassignedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Long save(ConflictType conflictType) {
		// TODO Auto-generated method stub
		return null;
	}

	public ConflictType getById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
