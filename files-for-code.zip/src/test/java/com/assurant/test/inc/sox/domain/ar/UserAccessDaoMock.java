package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.assurant.inc.sox.dao.luad.IUserAccessDao;
import com.assurant.inc.sox.domain.luad.UserAccess;

public class UserAccessDaoMock implements IUserAccessDao {

	public List<String> checkManagerAccessToSoxApp(String userId) {
		List<String> results = new ArrayList<String>(2);
		if ("JU112233".equals(userId)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			results.add(UserAccess.SOX_APP_PRIV_VALUE_APP);
			results.add(UserAccess.SOX_APP_PRIV_VALUE_MANAGER);
		} else if ("JU112234".equals(userId)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			results.add(UserAccess.SOX_APP_PRIV_VALUE_APP);
		} else if ("JU112235".equals(userId)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			// don't add any privs.
		} else if ("JU112236".equals(userId)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			results.add(UserAccess.SOX_APP_PRIV_VALUE_MANAGER);
		} else {
			throw new AssertionError("Invalid user key id: " + userId);
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<String> findBySourceName(String searchString) {
		if (searchString.equals("FP3a")) {
			List<String> result = new ArrayList<String>(2);
			result.add(new String("FP3aSP1"));
			result.add(new String("FP3aSP2"));

			return result;
		}
		return Collections.EMPTY_LIST;
	}

	public boolean isAccessActive(String userKeyId, String userId, String sourceName, String privValue, String privDescription) {
       if(userKeyId.equals("TestUserKeyId")) {
    	   return true;
       } else {
    	   return false;
       }
		
	}

	public boolean isPrivCommentAccessActive(String privValue,
			String privDescription) {
		// TODO Auto-generated method stub
		return false;
	}

}
