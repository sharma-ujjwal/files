package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IUserStatusDao;
import com.assurant.inc.sox.domain.ar.UserStatus;

public class UserStatusDaoMock implements IUserStatusDao {

	public List<UserStatus> findAll() {
		List<UserStatus> result =  new ArrayList<UserStatus>();
		UserStatus status = new UserStatus();
		status.setId((-2L));
		status.setCreatedBy("juCr");
		status.setCreatedDate(new Date());
		status.setDeleteFlag("N");
		
		result.add(status
				);
		
		return result;
		
	}

	public List<UserStatus> findByValue(String searchString) {
		return null;
	}

	public List<UserStatus> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserStatus> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public UserStatus findDuplicate(String nameExists) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserStatus> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserStatus> findUnassignedByName(String userStatustNameLike) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(UserStatus userStatus) {
		// TODO Auto-generated method stub
		
	}

	public UserStatus findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean canUserStatusBeDeleted(Long id) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
