package com.assurant.test.inc.sox.domain.ar;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.luad.IPrivilegeCommentDao;
import com.assurant.inc.sox.domain.ar.ExtractSystem;
import com.assurant.inc.sox.domain.luad.PrivilegeComment;


public class PrivilegeCommentDaoMock implements IPrivilegeCommentDao {

	@SuppressWarnings("unchecked")
	public List<String> findDescriptions(String searchString) {
		if(searchString.equals("O")){
			List<String> list = new ArrayList<String>();
			list.add("ORACLE OBJECT PRIVILEGE");
			list.add("ORACLE VIEW PRIVILEGE");
			return list;
		}
		return Collections.EMPTY_LIST;
	}

	@SuppressWarnings("unchecked")
	public List<String> findValues(String searchString) {
		if(searchString.equals("O")){
			List<String> list = new ArrayList<String>();
			list.add("UPDATE ON DHAVCPC.ANNFE_NWFEE_ELIG");
			list.add("SELECT ON COMPASS.CALL_LOGS");
			return list;
		}
		return Collections.EMPTY_LIST;
	}

	public List<PrivilegeComment> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PrivilegeComment> findByValue(String soxConcern,
			String privDescription, String privValue, Long functionDutyId,
			String applicationName, String comment, Long extractSystemId,
			boolean searchForDuplicate) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> findDistinctApplicationNames() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Long> findDistinctFunctionDuties() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> findDistinctSOXConcerns() {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(PrivilegeComment privilegeComment) {
		// TODO Auto-generated method stub
		
	}

	public List<PrivilegeComment> findAllActive() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean doesPrivCommentExists(String privDescription,
			String privValue, boolean searchInDelete) {
		// TODO Auto-generated method stub
		return false;
	}

	public void saveAll(List<PrivilegeComment> privilegeCommentList) {
		// TODO Auto-generated method stub
		
	}

	public void update(PrivilegeComment privilegeComment) {
		// TODO Auto-generated method stub
		
	}

	public List<PrivilegeComment> findByFilters(boolean isActive,
			String soxConcern, String applicationName, String privDescription,
			String privValue, Long functionDutyId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PrivilegeComment> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}


	public List<PrivilegeComment> findByFilters(boolean isActive,
			List soxConcernList, String applicationName,
			String privDescription, String privValue, Long functionDutyId,
			Long extractSystemId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updatePrivComment(String privValue, String privDesc,
			String privComment, Long functionDutyId, String soxConcern,
			String applicationName, String lastChangedBy) {
		// TODO Auto-generated method stub
		
	}

	public void markAsDelete(PrivilegeComment privilegeComment) {
		// TODO Auto-generated method stub
		
	}

	public List<PrivilegeComment> findByFilters(boolean isActive,
			String soxConcern, String applicationName, String privDescription,
			String privValue, Long functionDutyId, Long extractSystemId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updatePrivComment(String privValue, String privDesc,
			String privComment, Long functionDutyId, String soxConcern,
			String applicationName, String lastChangedBy, Date activeFrom,
			Date activeTo) {
		// TODO Auto-generated method stub
		
	}

	public boolean isActivePrivilegeComment(PrivilegeComment privComment) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
