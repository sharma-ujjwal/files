package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IFilterCriteriaDao;
import com.assurant.inc.sox.domain.ar.FilterCriteria;

public class FilterCriteriaDaoMock implements IFilterCriteriaDao {

	public List<FilterCriteria> findByReviewBundleId(Long reviewBundleId) {
		List<FilterCriteria> filterCriteriaList = new ArrayList<FilterCriteria>();
		if(reviewBundleId.equals((12345L))) {
			// ReviewBundleServiceTest.testRetrieveFilterCriteria
			FilterCriteria ft = new FilterCriteria();
			ft.setReviewBundleId((12345L));
			filterCriteriaList.add(ft);
			return filterCriteriaList;
		} else{
			throw new AssertionError("Invalid bundle id was found " + reviewBundleId);
		}
		
	}

	public FilterCriteria save(FilterCriteria filterCriteria) {
		
		return null;
	}

	public List<FilterCriteria> save(List<FilterCriteria> filterCriterias) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
