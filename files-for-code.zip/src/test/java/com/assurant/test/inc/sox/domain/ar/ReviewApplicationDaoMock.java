package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IReviewApplicationDao;
import com.assurant.inc.sox.domain.ar.Application;

import com.assurant.inc.sox.domain.ar.ReviewApplication;



public class ReviewApplicationDaoMock implements IReviewApplicationDao {

	public List<ReviewApplication> findBy(Long reviewUserId,
			Application application, String accessUserId) {
		List<ReviewApplication> reviewApps = new ArrayList<ReviewApplication>();
		if(reviewUserId.equals((555333L))) {
			// UserActionrequiredServiceTest.testRetrieveActionItems
			ReviewApplication app = new ReviewApplication();
			app.setId((76543L));
			reviewApps.add(app);
			return reviewApps;
		} else {
			throw new AssertionError("Invalid review user id: " + reviewUserId);
		}
	}

	public ReviewApplication findById(Long reviewApplicationId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewApplication> findByIds(List<Long> reviewApplicationIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewApplication> findRejectedByReviewUserIds(
			List<Long> reviewUserIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewApplication> findRejectedByReviewerAndApplication(
			Long reviewerId, Long applicationId) {
		List<ReviewApplication> reviewApps = new ArrayList<ReviewApplication>();
		if(reviewerId.equals((12345))) {
			// UserActionrequiredServiceTest.testRetrieveActionItems
			ReviewApplication app = new ReviewApplication();
			app.setId(applicationId);
			app.setReviewUserId((66666L));
			reviewApps.add(app);
			return reviewApps;
		} else {
			throw new AssertionError("Invalid reviewer id: " + reviewerId);
		}
	}

	public ReviewApplication save(ReviewApplication reviewApplication) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
