package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.assurant.inc.sox.dao.luad.IUserDao;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewOwner;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.luad.User;
import com.assurant.inc.sox.domain.luad.UserPk;

public class UserDaoMock implements IUserDao {

	@SuppressWarnings("unchecked")
	public List<User> findActiveUsers(String searchName) {
		if (searchName.equals("CHA")) {
			List<User> list = new ArrayList<User>();
			User user1 = new User();
			user1.setUserId((-2L));
			user1.setLastName("CHAMPION");
			user1.setFirstName("CLEOPATRA");
			list.add(user1);
			return list;
		}
		return Collections.EMPTY_LIST;

	}
	public List<User> findByMgrUserIds(List<Long> ids) {
		return null;
	}

	public User findByMgrUserId(Long id) {
		User user;
		if ((3445) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			user = new User();
			user.setLastName("Smith");
			user.setFirstName("John");
			user.setMiddleName("Q");
		}else {
			throw new AssertionError("Invalid user id: " + id);
		}
		return user;
	}

	public User findByUserId(Long id) {
		User user;
		if ((3445) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			user = new User();
			user.setLastName("Smith");
			user.setFirstName("John");
			user.setMiddleName("Q");
		} else if ((334388) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			user = new User();
			user.setLastName("James");
			user.setFirstName("Sally");
		} else if ((4430) == (id)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU112233");
			user.setPk(pk);
		} else if ((4431) == (id)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU112234");
			user.setPk(pk);
		} else if ((4432) == (id)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU112235");
			user.setPk(pk);
		} else if ((4433) == (id)) {
			// ReviewerServiceTest.testPopulateHasManagerAccessToApplication
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU112236");
			user.setPk(pk);
		} else if ((6475675) == (id)) {
			// ReviewerServiceTest.testDistributeReviewers
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU34460");
			user.setPk(pk);
		} else if ((6475676) == (id)) {
			// ReviewerServiceTest.testDistributeReviewers
			user = new User();
		} else if ((6475677) == (id)) {
			// ReviewerServiceTest.testDistributeReviewers
			user = null;
		} else if ((6475678) == (id)) {
			// ReviewerServiceTest.testDistributeReviewers
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU34461");
			user.setPk(pk);
		} else if ((8773) == (id)) {
			// ReviewerServiceTest.testReassignReleasedReviewer
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU7733");
			user.setPk(pk);
		} else if ((45678) == (id)) {
			// ReviewUserServiceTest.testRetrieveByReviewerIdNonRejected
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU34440");
			user.setPk(pk);
			user.setFirstName("JUnitFirstName");
			user.setLastName("JUnitLastName");
			user.setMiddleName("JUnitMiddleName");
		} else if ((88888) == (id)) {
			// ReviewUserServiceTest.testRetrieveByReviewerIdNonRejected
			user = new User();
			UserPk pk = new UserPk();
			pk.setKeyId("JU34440");
			user.setPk(pk);
			user.setFirstName("JUnitFirstName");
			user.setLastName("JUnitLastName");
			user.setMiddleName("JUnitMiddleName");
		} else if ((34) == (id)) {
			// ReviewUserServiceTest.testGetManagerReviewAvailableReassignReviewersNoItComp
			user = new User();

			Department dept = new Department();
			dept.setId((64L));
			user.setDepartment(dept);

			user.setEmailAddress("itComUsr");

			UserStatus userStatus = new UserStatus();
			userStatus.setId((84L));
			user.setUserStatus(userStatus);

			user.setUserId((884L));
			user.setLastName("blair");
			user.setFirstName("linda");
			user.setMiddleName("r");

		} else if ((8098) == (id)) {
			// ReviewUserServiceTest.testGetDataOwnerReviewAvailableReassignReviewers
			user = new User();

			Department dept = new Department();
			dept.setId((5566L));
			user.setDepartment(dept);

			user.setEmailAddress("dataOwnerReviewer");

			UserStatus userStatus = new UserStatus();
			userStatus.setId((665L));
			user.setUserStatus(userStatus);

			user.setUserId((7898L));
			user.setLastName("Johnson");
			user.setFirstName("John");
			user.setMiddleName("J");

		} 
		else if((8099) == (id)) {
			user = null;
		}
		else {
			throw new AssertionError("Invalid user id: " + id);
		}
		return user;
	}

	public List<User> findByUserIds(List<Long> ids) {
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<String> findCostCenters(String searchString) {
		if (searchString.equals("517")) {
			List<String> list = new ArrayList<String>();
			list.add("51713");
			return list;
		}
		return Collections.EMPTY_LIST;
	}

	public List<User> findUsersForSupervisor(Long supervisorId) {
		return null;
	}

	public User findUsersSupervisor(Long userId) {
		User result;
		if ((8423) == (userId) || (8425) == (userId)) {
			// ReviewUserServiceTest.testGetManagerReviewAvailableReassignReviewers
			result = new User();

			Department dept = new Department();
			dept.setId((6L));
			result.setDepartment(dept);

			result.setEmailAddress("superEmailAddr");

			UserStatus userStatus = new UserStatus();
			userStatus.setId((8L));
			result.setUserStatus(userStatus);

			result.setUserId((88L));
			result.setLastName("smith");
			result.setFirstName("john");
			result.setMiddleName("joe");
		} else if ((8424) == (userId)) {
			// ReviewUserServiceTest.testGetManagerReviewAvailableReassignReviewersNoSuper
			result = null;
		} else {
			throw new AssertionError("Invalid supervisor id: " + userId);
		}
		return result;
	}

	public User findByUserIdInactive(Long id) {
		User user;
		if ((8099) == (id)) {
			// ReviewUserServiceTest.testGetDataOwnerReviewAvailableReassignReviewers
			user = new User();

			Department dept = new Department();
			dept.setId((5567L));
			user.setDepartment(dept);

			user.setEmailAddress("inactiveReviewer");

			UserStatus userStatus = new UserStatus();
			userStatus.setId((668L));
			user.setUserStatus(userStatus);

			user.setUserId((7899L));
			user.setLastName("JohnsonI");
			user.setFirstName("JohnI");
			user.setMiddleName("JI");

		}
		else {
			throw new AssertionError("Invalid user id: " + id);
		}
		return user;
	}
	public User findActiveUserByUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}
	public Long findActiveUserIdByKeyId(String keyId) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findActiveUsers() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findAllActiveUsers() {
		// TODO Auto-generated method stub
		return null;
	}
	public User findByUserKeyId(UserPk userPk) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findByUserName(String searchFirstName,
			String searchLastName) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findByValue(boolean isActive, String searchKeyIdOrAltId,
			Long searchSupervisor, String searchFirstNm, String searchLastNm,
			List searchUserType, List searchStatus, List searchDprtmntId,
			List searchDivisionId, List<String> searchCostCenter,
			List<String> searchBsnssSgmnt) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findDeletedByName(String userNameSearchText) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findDistinctBusinessSegment() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findDistinctCostCenter() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findPotentialSupervisors(String keyId, String firstName,
			String lastName) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findSupDistinctBusinessSegment(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findSupDistinctCostCenter(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Department> findSupDistinctDepartments(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Division> findSupDistinctDivision(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findSupDistinctJobTitle(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<String> findSupDistinctLocation(Long supervisorID) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findUnassignedByName(String userNameSearchText) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<User> findUserExist(String searchKeyId, String satMFId,
			String satGFId, String satCFId, String satLCSId, String satFDMSId,
			String satSiteminderId, String searchSatAltId1,
			String searchSatAltId2, String searchSatAltId3) {
		// TODO Auto-generated method stub
		return null;
	}
	public List<ReviewOwner> findUserExistInReviewOwner(Long searchUserId) {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean isActiveReviewOwner(Long userId) {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean isActiveUser(Long userId) {
		// TODO Auto-generated method stub
		return false;
	}
	public void markAsDelete(Long userId, String deletedBy) {
		// TODO Auto-generated method stub
		
	}
	public List<User> populateSupevisorData(Long searchSupervisor) {
		// TODO Auto-generated method stub
		return null;
	}
	public void save(User transientInstance) {
		// TODO Auto-generated method stub
		
	}
	public List<User> searchAssociatedUser(String searchFirstNm,
			String searchLastNm, String keyId, Long supervisorId,
			List userStatuses, List userTypes, List departments,
			List divisions, String location) {
		// TODO Auto-generated method stub
		return null;
	}
	public void updateAltIds(Long userId, String lastChangedBy, String satMFId,
			String satGFId, String satCFId, String satLCSId, String satFDMSId,
			String satSiteminderId, String satAltId1, String satAltId2,
			String satAltId3) {
		// TODO Auto-generated method stub
		
	}
	public void updateRejectedUser(Long userId, String firstNm, String mddlNm,
			String lastNm, Long userStatusId, String userStatus,
			Long userTypeId, String userType, Long supervisorId,
			String supervisorName, Long departmentId, String departmentName,
			String cstCntr, String bsnssSgmnt, Long divisionId,
			String divisionName, String jobTitle, String location,
			String phone, String emailAddress, String satStatus,
			String satJobRole, String satComment, String lastChangedBy) {
		// TODO Auto-generated method stub
		
	}
	public void updateSupervisorOnUserDelete(Long userId, String lastChangedBy) {
		// TODO Auto-generated method stub
		
	}
	public void updateUser(Long userId, String keyId, String firstNm,
			String mddlNm, String lastNm, Long userStatusId, String userStatus,
			Long userTypeId, String userType, Long supervisorId,
			String supervisorName, Long departmentId, String departmentName,
			String cstCntr, String bsnssSgmnt, Long divisionId,
			String divisionName, String jobTitle, String location,
			String phone, String emailAddress, String satStatus,
			String satJobRole, String satComment, String satMFId,
			String satGFId, String satCFId, String satLCSId, String satFDMSId,
			String satSiteminderId, String satAltId1, String satAltId2,
			String satAltId3, String lastChangedBy) {
		// TODO Auto-generated method stub
		
	}
	public void updateUsers(List<User> persistentInstances) {
		// TODO Auto-generated method stub
		
	}
	public List<Review> outstandingReviewsForUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
