package com.assurant.test.inc.sox.domain.ar;

import org.junit.Assert;

import com.assurant.inc.sox.ar.service.impl.TestHelper;
import com.assurant.inc.sox.dao.ar.IProcessLockDao;
import com.assurant.inc.sox.domain.ar.ProcessLock;

public class ProcessLockDaoMock implements IProcessLockDao {

	public ProcessLock findByProcessId(String savvionId) {

		if ("GetSavIdNF".equals(savvionId)) {
			return null;
		}

		ProcessLock lock = new ProcessLock();
		lock.setId(savvionId);
		if ("GetSavId".equals(savvionId)) {
			lock.setLockedDate(TestHelper.buildTimelessDate(2000, 2, 4));
			lock.setHolderId("JUNITUSR");
		}
		return lock;
	}

	public ProcessLock insert(ProcessLock lock) {
		
		Assert.assertEquals(ProcessLock.NOT_DELETED, lock.getDeleteFlag());
		Assert.assertEquals("JUNITUSR", lock.getHolderId());
		Assert.assertEquals("LockSavId", lock.getId());

		//assert that the lock date is with in a 1 second threshold of the current date.
		long lockTime = lock.getLockedDate().getTime();
		long currTime = System.currentTimeMillis();
		Assert.assertTrue(Math.abs(currTime - lockTime) < 1000);
		return lock;
	}

	public ProcessLock update(ProcessLock lock) {
		Assert.assertEquals("BreakSavId", lock.getId());
		Assert.assertEquals("JUNITUSR", lock.getHolderId());
		return null;
	}

}
