/*package com.assurant.test.inc.sox.domain.ar;

import java.util.List;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.RejectSodBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.utils.exceptions.SavvionException;

public class ReviewBundleServiceMock implements IReviewBundleService {

	public void acceptBundleSummary(Long reviewBundleId) throws SavvionException {
		// TODO Auto-generated method stub

	}

	public ReviewBundleDTO createReviewBundle(Long reviewId, List<FilterCriteriaDTO> filterCriteriaDtos) throws SavvionException {
		// TODO Auto-generated method stub
		return null;
	}

	public void rejectBundleSummary(Long reviewBundleId) throws SavvionException {
		// TODO Auto-generated method stub

	}

	public String retrieveBundleName(Long reviewBundleId) {
		String name;
		if (new Long(44338).equals(reviewBundleId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			name = "JunitBundleName";
		} else if (new Long(44339).equals(reviewBundleId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
			name = "JunitBundleNameNoDept";
		} else if (new Long(44341).equals(reviewBundleId)) {
			name = "NAME";
		} else if (new Long(56465).equals(reviewBundleId)) {
			// ReviewServiceTest.testCloseReview
			name = "TestName";
		} else if (new Long(44566).equals(reviewBundleId)) {
			// ReviewerServiceTest.testDistributeReviewers
			name = "ReviewName";
		} else {
			throw new AssertionError("Invalid review bundle id: " + reviewBundleId);
		}
		return name;
	}

	public ReviewBundleDTO retrieveById(Long reviewBundleSummaryId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewBundleDTO> retrieveByReviewId(Long reviewId) {
		// TODO Auto-generated method stub
		return null;
	}

	public ReviewBundleDTO retrieveBySavvionId(String savvionId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<FilterCriteriaDTO> retrieveFilterCriteria(Long reviewBundleId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer retrieveNumberOfReports(List<Long> reviewBundleIds) {
		// TODO Auto-generated method stub
		return null;
	}

	public String retrieveReviewName(Long reviewBundleId) {
		String result;
		if (new Long(44566).equals(reviewBundleId)) {
			// ReviewerServiceTest.testDistributeReviewers
			result = "ReviewName";
		} else if (new Long(774324).equals(reviewBundleId)) {
			// ReviewerServiceTest.testReassignReleasedReviewer
			result = "testReassignReleasedReviewer";
		} else {
			throw new AssertionError("Invalid bundle id: " + reviewBundleId);
		}
		return result;
	}

	public void rejectSODBundleSummaryWithNoConflict(Long reviewBundleId)
			throws SavvionException {
		// TODO Auto-generated method stub
		
	}

	public List<RejectSodBundleDTO> retrieveRejectedWithNoConflictsByReviewId(
			Long reviewId) {
		// TODO Auto-generated method stub
		return null;
	}

}
*/