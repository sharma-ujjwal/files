package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.domain.ar.ReviewUser;

public class ReviewUserDaoMock implements IReviewUserDao {

	public ReviewUser findById(Long reviewUserId) {
		if(reviewUserId  == (12345)) {
			// ReviewServiceTest.testCloseReview
			ReviewUser user = new ReviewUser();
			user.setReviewerId((45678L));
			return user;
		} else if (reviewUserId  == (64546)) {
			// ReviewUserServiceTest.testRetrieveByIdResultNotNull
			ReviewUser user = new ReviewUser();
			user.setReviewerId((54353L));
			user.setId(reviewUserId);
			user.setReviewUserStatusCd("TERM");
			user.setReviewCompletedFlag("Y");
			return user;
		} else if(reviewUserId  == (66666)) {
			// ReviewUserServiceTest.testRetrieveByIdResultNull
			return null;
		} else {
			throw new AssertionError("Invalid review user Id" + reviewUserId);
		}
	}

	public List<ReviewUser> findByReviewerId(Long id) {
		List<ReviewUser> users = new ArrayList<ReviewUser>();
		if(id  == (45454)) {
			// ReviewUserServiceTest.testRetrieveByReviewerId
			ReviewUser user = new ReviewUser();
			user.setReviewUserStatusCd("TERM");
			user.setReviewCompletedFlag("Y");
			user.setUserId((45678L));
			user.setId((22222L));
			user.setManagerId((88888L));
			users.add(user);
		} else {
			throw new AssertionError("Invalid id : " + id);
		}
		return users;
	}

	public List<ReviewUser> findByReviewerIdNonRejected(Long id) {
		List<ReviewUser> users = new ArrayList<ReviewUser>();
		if(id  == (12345)) {
			// ReviewUserServiceTest.testRetrieveByReviewerIdNonRejected
			ReviewUser user = new ReviewUser();
			user.setReviewUserStatusCd("TERM");
			user.setReviewCompletedFlag("Y");
			user.setUserId((45678L));
			user.setManagerId((88888L));
			users.add(user);
		} else {
			throw new AssertionError("Invalid id : " + id);
		}
		return users;
	}

	public List<String> findDistinctUserStatusesByReviewerId(Long reviewerId) {
		List<String> result;
		if ((5433)  == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = new ArrayList<String>(1);
			result.add("ACTIVE");
		} else if ((5432)  == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = new ArrayList<String>(1);
			result.add("ACTIVE");
			result.add("INACTIVE");
		}
		else if((5437) == (reviewerId)) {
			result = new ArrayList<String>(0);
		}
		else {
			throw new AssertionError("Invalid reviewer id: " + reviewerId);
		}
		return result;
	}

	public int findUserCountForReviewer(Long reviewerId) {
		int result;
		if ((5433) == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = 2;
		} else if ((5432) == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = 1;
		} else if ((5437) == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
			result = 23;
		} else {
			throw new AssertionError("Invalid reviewer id: " + reviewerId);
		}
		return result;
	}

	public ReviewUser save(ReviewUser reviewUser) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewUser> save(List<ReviewUser> reviewUsers) {
		// TODO Auto-generated method stub
		return null;
	}

}
