package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IDivisionDao;
import com.assurant.inc.sox.domain.ar.Division;

public class DivisionDaoMock implements IDivisionDao {
	
	public List<Division> findAll() {
		List<Division> result = new ArrayList<Division>(2);
		Division div1 = new Division();
		div1.setId(-2L);
		div1.setCreatedBy("juCr");
		div1.setCreatedDate(new Date());
		div1.setDeleteFlag("N");
		result.add(div1);
		
		Division div2= new Division();
		div2.setId(-3L);
		div2.setCreatedBy("juCr");
		div2.setCreatedDate(new Date());
		div2.setDeleteFlag("N");
		result.add(div2);
		return result;
	}

	public List<Division> findByName(String searchString) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void save(Division division) {
		// TODO Auto-generated method stub

	}

	public List<Division> findAllByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Division findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Division> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Division> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Division findDuplicate(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Division> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Division> findUnassignedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean canDivisionBeDeleted(Long id) {
		// TODO Auto-generated method stub
		return false;
	}

}
