package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IUserTypeDao;
import com.assurant.inc.sox.domain.ar.UserType;

public class UserTypeDaoMock implements IUserTypeDao {

	public List<UserType> findAll() {
		List<UserType> result = new ArrayList<UserType>(2);
		UserType user = new UserType();
		user.setId((-2L));
		user.setCreatedBy("juCr");
		user.setCreatedDate(new Date());
		user.setDeleteFlag("N");
		result.add(user);
		return result;
	}

	public List<UserType> findByValue(String searchString) {
		
		return null;
	}

	public List<UserType> findDeleted() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserType> findDeletedByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	public UserType findDuplicate(String nameExists) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserType> findUnassigned() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<UserType> findUnassignedByName(String NameLike) {
		// TODO Auto-generated method stub
		return null;
	}

	public void save(UserType userType) {
		// TODO Auto-generated method stub
		
	}

	public UserType findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean canUserTypeBeDeleted(Long id) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
