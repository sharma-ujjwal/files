package com.assurant.test.inc.sox.domain.ar;

import java.util.List;

import com.assurant.inc.sox.dao.security.ISecurityFunctionAccessDao;



public class SecurityFunctionAccessDaoMock implements ISecurityFunctionAccessDao {

	public List<String> listAuthorizedRolesByFunctionCode(String functionCode) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> listFunctionCodeByRoles(List<String> roles) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
