package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;

import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.impl.TestHelper;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.Reviewer;

public class ReviewerDaoMock implements IReviewerDao {

	public Reviewer findById(Long id) {
		if (id.equals((88888L))) {
			// ReviewServiceTest.testCloseReview
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId((45678L));
			return reviewer;
		} else if (id.equals((23234L))) {
			// MyTaskListServiceTest.testRetrieveActionRequiredTasks
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId((44338L));
			reviewer.setRejectCode("TRMD");
			return reviewer;
		} else {
			return null;
		}

	}

	public List<Reviewer> findByReviewBundleId(Long id) {
		List<Reviewer> reviewers = new ArrayList<Reviewer>(2);
		if ((44338) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setRejectCode("TERM");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.PENDING.getCode());
			reviewer.setId((5433L));
			reviewer.setEscalationMgrId((334388L));

			Application app = new Application();
			app.setId((23L));
			reviewer.setApplication(app);

			Conflict conflict = new Conflict();
			conflict.setId((3224L));
			reviewer.setConflict(conflict);

			reviewers.add(reviewer);

			reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setRejectCode("RCHG");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.APPROVED.getCode());
			reviewer.setId((5432L));
			reviewers.add(reviewer);

		} else if ((44339) == (id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setRejectCode("RJCT");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.REJECTED.getCode());
			reviewer.setNumberOfDirectReports((3L));
			reviewer.setReviewerUserStatusValues("NOTACTIVE, ACTIVE");
			reviewer.setEscalationMgrId((-1L));
			reviewer.setId((5436L));

			Application app = new Application();
			app.setId((-1L));
			reviewer.setApplication(app);

			reviewers.add(reviewer);

			reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setRejectCode("NOEV");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.RELEASED.getCode());
			reviewer.setId((5437L));

			app = new Application();
			app.setId(223L);
			reviewer.setApplication(app);

			reviewers.add(reviewer);
		} else if (44340L == id) {
			// ReviewerServiceTest.testRetrieveByBundleIdNoReviewers
			reviewers = new ArrayList<Reviewer>(0);
		} else if (56465L == id) {
			// ReviewServiceTest.testCloseReview
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setRejectCode("RJCT");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.REJECTED.getCode());
			reviewer.setNumberOfDirectReports(3L);
			reviewer.setReviewerUserStatusValues("NOTACTIVE, ACTIVE");
			reviewer.setEscalationMgrId(-1L);
			reviewer.setId(45678L);

			Application app = new Application();
			app.setId(-1L);
			reviewer.setApplication(app);

			reviewers.add(reviewer);
		} else if (34343L == id) {
			// ReviewServiceTest.testCloseReviewReviewerNonClosablereview
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId(id);
			reviewer.setReviewerName("JUnitName");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.PENDING.getCode());
			reviewer.setNumberOfDirectReports((3L));
			reviewer.setId((45678L));

			Application app = new Application();
			app.setId((-1L));
			reviewer.setApplication(app);

			reviewers.add(reviewer);
		} else {
			throw new AssertionError("Invalid bundle id found " + id);
		}

		return reviewers;

	}

	public List<Reviewer> findByStatus(Long reviewBundleId, String status) {
		List<Reviewer> reviewers = new ArrayList<Reviewer>(2);
		if ((44341) == (reviewBundleId)) {
			// ReviewerServiceTest.testRetrieveByStatus
			Assert.assertEquals(ReviewerStatusCode.APPROVED.getCode(), status);
			Reviewer reviewer = new Reviewer();
			reviewer.setReviewBundleId(reviewBundleId);
			reviewer.setRejectCode("RCHG");
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.APPROVED.getCode());
			reviewer.setId((5440L));
			reviewer.setNumberOfDirectReports((1L));
			reviewer.setReviewerUserStatusValues("Statuses");
			reviewers.add(reviewer);
		} else if ((843348) == (reviewBundleId)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotComplePendAppr
			if (ReviewerStatusCode.APPROVED.getCode().equals(status) || ReviewerStatusCode.PENDING.getCode().equals(status)) {
				reviewers.add(new Reviewer());
			} else {
				throw new AssertionError("Invalid status code: " + status);
			}
		} else if ((843349) == (reviewBundleId)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotComplePend
			if (ReviewerStatusCode.APPROVED.getCode().equals(status)) {
				// leave results empty
			} else if (ReviewerStatusCode.PENDING.getCode().equals(status)) {
				reviewers.add(new Reviewer());
			} else {
				throw new AssertionError("Invalid status code: " + status);
			}
		} else if ((843350) == (reviewBundleId)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotCompleAppr
			if (ReviewerStatusCode.APPROVED.getCode().equals(status)) {
				reviewers.add(new Reviewer());
			} else if (ReviewerStatusCode.PENDING.getCode().equals(status)) {
				// leave results empty
			} else {
				throw new AssertionError("Invalid status code: " + status);
			}
		} else if ((843351) == (reviewBundleId)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotCompNoBundle
			Assert.assertTrue(ReviewerStatusCode.APPROVED.getCode().equals(status)
			    || ReviewerStatusCode.PENDING.getCode().equals(status));
		} else if ((843352) ==(reviewBundleId)) {
			// ReviewerServiceTest.testCompleteSavvionProcessComp
		} else {
			throw new AssertionError("Invalid bundle id: " + reviewBundleId);
		}
		// TODO Auto-generated method stub
		return reviewers;
	}

	public List<String> findDistinctApplicationNames(Long reviewrId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> findDistinctDepartments(Long reviewerId) {
		List<String> result;
		if ((5433) == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = new ArrayList<String>(1);
			result.add("SALES");
		} else if ((5432) == (reviewerId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			result = new ArrayList<String>(1);
			result.add("SALES");
			result.add("IT");
		} else {
			throw new AssertionError("Invalid reviewer id: " + reviewerId);
		}
		return result;
	}

	public List<String> findDistinctEnvironments(Long reviewerId) {
		List<String> results = new ArrayList<String>();
		if ((5450) == (reviewerId)) {
			results.add("PROD");
			results.add("DEV");
		}
		return results;
	}

	public int findReviewerCountForBundle(Long reviewBundleId) {
		int result;
		if((38849) == (reviewBundleId)) {
			result = 4;
		}
		else {
			throw new AssertionError("Invalid bundle id: " + reviewBundleId);
		}
		// TODO Auto-generated method stub
		return result;
	}

	public Reviewer save(Reviewer reviewer) {
		if ((5577383) == (reviewer.getId())) {
			// ReviewerServiceTest.testReassignReleasedReviewer
			Assert.assertEquals(Optional.of(8773L).get(), reviewer.getUserId());
			Assert.assertEquals("userName", reviewer.getReviewerName());
			Assert.assertEquals(Optional.of((443L)).get(), reviewer.getUserStatus().getId());
			Assert.assertEquals(Optional.of((53434L)).get(), reviewer.getDepartment().getId());
			Assert.assertEquals("email@emailAddr", reviewer.getReviewerEmailAddress());
			Assert.assertEquals("drist instructions blah", reviewer.getDistributionInstructions());
			TestHelper.assertTimelessDateEquals(TestHelper.buildTimelessDate(2004, 4, 3), reviewer.getDistributionTargetCompleteDate());
		} else if ((5433) == (reviewer.getId()) || (5432) == (reviewer.getId())
		    || (5437) == (reviewer.getId()) || reviewer.getId() == null) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
		} else if ((5322423) == (reviewer.getId())) {
			TestHelper.assertTimelessDateEquals(new Date(), reviewer.getReviewerRejectDate());
			Assert.assertEquals(ReviewerStatusCode.REJECTED.getCode(), reviewer.getReviewerLastStatusCd());
			Assert.assertEquals("JU11228", reviewer.getReviewerRejectBy());
			Assert.assertEquals("RJCT", reviewer.getRejectCode());
			Assert.assertEquals("reject reason comments", reviewer.getRejectText());
		} else if ((5460) == (reviewer.getId())) {
			Assert.assertEquals(ReviewerStatusCode.APPROVED.getCode(), reviewer.getReviewerLastStatusCd());
			TestHelper.assertTimelessDateEquals(new Date(), reviewer.getReviewerApprovedDate());
			Assert.assertEquals("JU11228", reviewer.getReviewerApprovedBy());
		} else if ((34460) == (reviewer.getId()) || (34461) == (reviewer.getId())
		    || (34462) == (reviewer.getId()) || (34463) == (reviewer.getId())) {
			Assert.assertEquals(ReviewerStatusCode.RELEASED.getCode(), reviewer.getReviewerLastStatusCd());
			TestHelper.assertTimelessDateEquals(new Date(), reviewer.getReviewerReleaseDate());
			Assert.assertEquals("JU11228", reviewer.getReviewerReleaseBy());
			Assert.assertEquals("Instructions", reviewer.getDistributionInstructions());
			TestHelper.assertTimelessDateEquals(TestHelper.buildTimelessDate(2004, 2, 1), reviewer.getDistributionTargetCompleteDate());
		} else {
			throw new AssertionError("Invalid reviewer id: " + reviewer.getId());
		}
		return reviewer;
	}

	public List<Reviewer> save(List<Reviewer> reviewers) {

		for (Reviewer reviewer : reviewers) {
			save(reviewer);
		}
		return reviewers;
	}

}
