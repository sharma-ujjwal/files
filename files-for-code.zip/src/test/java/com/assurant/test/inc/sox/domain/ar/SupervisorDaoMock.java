package com.assurant.test.inc.sox.domain.ar;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.assurant.inc.sox.dao.ar.ISupervisorDao;
import com.assurant.inc.sox.domain.ar.Supervisor;


public class SupervisorDaoMock implements ISupervisorDao {

	@SuppressWarnings("unchecked")
	public List<Supervisor> findByName(String searchString) {
		if(searchString.equals("sHAw Je")){
			List<Supervisor> list = new ArrayList<Supervisor>();
			Supervisor supervisor = new Supervisor();
			supervisor.setUserId((-2L));
			supervisor.setLastName("SHAW");
			supervisor.setFirstName("JEFF");
			
			list.add(supervisor);
			return list;
		}
		return Collections.EMPTY_LIST;
	}
	
	public Supervisor findByKeyId(String keyId) {
		return null;
	}

	public List<Supervisor> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
}
