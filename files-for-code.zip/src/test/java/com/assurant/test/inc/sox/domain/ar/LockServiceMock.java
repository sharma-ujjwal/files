package com.assurant.test.inc.sox.domain.ar;

import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.service.ILockService;


public class LockServiceMock implements ILockService {

	public void breakLock(String savvionId) {
		// TODO Auto-generated method stub
		
	}

	public LockDTO getLock(String savvionId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void lock(String savvionId) {
		// TODO Auto-generated method stub
		
	}

	public void unlock(String savvionId) {
		// TODO Auto-generated method stub
		
	}
	
}
