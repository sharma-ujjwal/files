package com.assurant.test.inc.sox.domain.ar;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;

public class SystemUserDTOMock extends SystemUserDTO {
	
	public String getUserId() {
		return "TEST123";
	}
}
