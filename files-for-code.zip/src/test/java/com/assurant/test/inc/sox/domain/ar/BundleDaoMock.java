/*package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;

import com.assurant.inc.sox.ar.dto.enums.ReviewBundleStatusCode;
import com.assurant.inc.sox.dao.ar.IReviewBundleDao;
import com.assurant.inc.sox.domain.ar.ReviewBundle;

public class BundleDaoMock implements IReviewBundleDao {

	public ReviewBundle findById(Long id) {
		ReviewBundle bundle;
		if (new Long(44338).equals(id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			bundle = new ReviewBundle();
			bundle.setId(id);
			bundle.setReviewId(new Long(12342));
		} else if (new Long(44339).equals(id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithOutDepts
			bundle = new ReviewBundle();
			bundle.setId(id);
			bundle.setReviewId(new Long(12343));
		} else if (new Long(44333).equals(id)) {
			// ReviewBundleServiceTest.testRetrieveByIdBundleFound
			// ReviewBundleServiceTest.testRetrieveReviewName
			bundle = new ReviewBundle();
			bundle.setId(id);
			bundle.setReviewId(new Long(12344));
			bundle.setBundleStatusCode("PEND");
			bundle.setCreatedDate(new Date());
			bundle.setSavvionProcessId("SoxSummary_V1#20755");
		} else if (new Long(44340).equals(id)) {
			// ReviewerServiceTest.testRetrieveByBundleIdNoReviewers
			bundle = null;
		} else if (new Long(44341).equals(id)) {
			// ReviewerServiceTest.testRetrieveByStatus
			bundle = new ReviewBundle();
			bundle.setId(id);
			bundle.setReviewId(new Long(88776));
		} else if (new Long(843351).equals(id)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotCompNoBundle
			bundle = null;
		} else if (new Long(843352).equals(id)) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotCompNoBundle
			bundle = new ReviewBundle();
			bundle.setId(id);
		} else {
			throw new AssertionError("Invalid bundle id was found " + id);
		}
		return bundle;
	}

	public List<ReviewBundle> findByReviewId(Long id) {
		List<ReviewBundle> bundles = new ArrayList<ReviewBundle>();
		if (id.equals(new Long(32232))) {
			// ReviewBundleServiceTest.testRetrieveByReviewId
			ReviewBundle bundle = new ReviewBundle();
			bundle.setId(new Long(56465));
			bundle.setReviewId(id);
			bundles.add(bundle);
		} else if (id.equals(new Long(12345))) {
			// ReviewServiceTest.testCloseReview
			ReviewBundle bundle = new ReviewBundle();
			bundle.setId(new Long(56465));
			bundle.setReviewId(id);
			bundle.setBundleStatusCode(ReviewBundleStatusCode.COMPLETED.getCode());
			bundles.add(bundle);
		} else if (id.equals(new Long(33333))) {
			// ReviewServiceTest.testCloseReviewNonClosableReview
			ReviewBundle bundle = new ReviewBundle();
			bundle.setId(new Long(44566));
			bundle.setReviewId(id);
			bundle.setBundleStatusCode(ReviewBundleStatusCode.IN_PROCESS.getCode());
			bundles.add(bundle);
		} else if (id.equals(new Long(55555))) {
			// ReviewServiceTest.testCloseReviewReviewerNonClosablereview
			ReviewBundle bundle = new ReviewBundle();
			bundle.setId(new Long(34343));
			bundle.setReviewId(id);
			bundle.setBundleStatusCode(ReviewBundleStatusCode.COMPLETED.getCode());
			bundles.add(bundle);
		} else {
			throw new AssertionError("Invalid review id was found " + id);
		}
		return bundles;
	}

	public ReviewBundle findBySavvionId(String id) {
		if (id.equals("SoxSummary_V1#20755")) {
			// ReviewBundleServiceTest.testRetrieveBySavvionId
			ReviewBundle bundle = new ReviewBundle();
			bundle.setId(new Long(12345));
			bundle.setSavvionProcessId("SoxSummary_V1#20755");
			return bundle;
		}
		return null;
	}

	public ReviewBundle save(ReviewBundle reviewBundle) {
		if (reviewBundle.getId() == null) {
			reviewBundle.setId(new Long(12345));
			reviewBundle.setCreatedDate(new Date());
		} else if (new Long(843352).equals(reviewBundle.getId())) {
			// ReviewerServiceTest.testCompleteSavvionProcessNotCompNoBundle
			Assert.assertEquals(ReviewBundleStatusCode.COMPLETED.getCode(), reviewBundle.getBundleStatusCode());
		} else if (new Long(44333).equals(reviewBundle.getId())) {
			// ReviewBundleServiceTest.testAcceptBundleSummary
			// ReviewBundleServiceTest.testRejectBundleSummary
		} else if (new Long(12345).equals(reviewBundle.getId())) {
			Assert.assertNotNull(reviewBundle);
			Assert.assertEquals("SoxSummary_V1#20755", reviewBundle.getSavvionProcessId());
			reviewBundle.setId(new Long(12345));
			reviewBundle.setCreatedDate(new Date());
		} else {
			throw new AssertionError("Invalid bundle id: " + reviewBundle.getId());
		}
		return reviewBundle;
	}

	public List<ReviewBundle> findByStatus(Long reviewId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
*/