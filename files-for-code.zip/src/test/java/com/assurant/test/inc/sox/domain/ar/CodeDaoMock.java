package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;

import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.dao.ar.ICodeDao;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;

public class CodeDaoMock implements ICodeDao {

	@SuppressWarnings("unchecked")
	public List<Code> findAllCodesByType(String tableName, String columnName) {
		if (tableName.equals(CodeSet.REVIEW_TYPE.getTableName())) {
			Assert.assertEquals(CodeSet.REVIEW_TYPE.getTableName(), tableName);
			Assert.assertEquals(CodeSet.REVIEW_TYPE.getColumnName(), columnName);
			List<Code> codes = new ArrayList<Code>(2);

			Code code = new Code();
			CodePk pk = new CodePk();
			pk.setColumnName(columnName);
			pk.setTableName(tableName);
			pk.setValue("CODE1");
			code.setPk(pk);
			codes.add(code);

			code = new Code();
			pk = new CodePk();
			pk.setColumnName(columnName);
			pk.setTableName(tableName);
			pk.setValue("CODE2");
			code.setPk(pk);
			codes.add(code);

			return codes;
		}

		return Collections.EMPTY_LIST;
	}

	public Code findCodeByValue(String tableName, String columnName, String value) {
		Assert.assertEquals(CodeSet.REVIEW_BUNDLE_STATUS.getTableName(), tableName);
		Assert.assertEquals(CodeSet.REVIEW_BUNDLE_STATUS.getColumnName(), columnName);
		if (value.equals("VAL")) {
			Code code = new Code();
			CodePk pk = new CodePk();
			pk.setColumnName(columnName);
			pk.setTableName(tableName);
			pk.setValue(value);
			code.setPk(pk);
			return code;
		}
		return null;
	}

}
