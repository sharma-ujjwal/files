package com.assurant.test.inc.sox.domain.ar;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.dao.ar.IReviewOwnerDao;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.ReviewOwner;

public class ReviewOwnerDaoMock implements IReviewOwnerDao {

	private boolean nullItCompUser;

	public List<ReviewOwner> findDataOwnerOwnersByApplicationId(Long applicationId) {
		List<ReviewOwner> results;
		if (23L ==(applicationId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			results = new ArrayList<ReviewOwner>(1);
			ReviewOwner owner = new ReviewOwner();
			owner.setId((54L));
			owner.setUserId((3445L));
			results.add(owner);
		} else if ((223) == (applicationId)) {
			results = new ArrayList<ReviewOwner>(0);
		} else {
			throw new AssertionError("Invalid application id: " + applicationId);
		}
		return results;
	}

	public List<ReviewOwner> findDataOwnerReviewersByApplicationId(Long applicationId) {
		List<ReviewOwner> results = new ArrayList<ReviewOwner>(3);
		if ((563533) == (applicationId)) {
			// ReviewerServiceTest.testGetDataOwnerReviewAvailableReassignReviewers
			ReviewOwner owner = new ReviewOwner();
			owner.setUserId((8098L));
			results.add(owner);
		} 
		else if ((563534) == (applicationId)) {
			// ReviewerServiceTest.testGetDataOwnerReviewAvailableReassignReviewers
			ReviewOwner owner = new ReviewOwner();
			owner.setUserId((8098L));
			results.add(owner);
		}
		else if ((563535) == (applicationId)) {
			// ReviewerServiceTest.testGetDataOwnerReviewAvailableReassignReviewers
			ReviewOwner owner = new ReviewOwner();
			owner.setUserId((8099L));
			results.add(owner);
		} else if ((12345) == (applicationId)) {
			// ReviewerServiceTest.testGetSodAvailableReassignReviewers
			results = new ArrayList<ReviewOwner>(0);
		} else {
			throw new AssertionError("Invalid application id: " + applicationId);
		}
		return results;
	}

	public List<ReviewOwner> findSODOwnersByConflictTypeId(Long conflictTypeId) {
		List<ReviewOwner> results = new ArrayList<ReviewOwner>(3);
		if ((3224) == (conflictTypeId)) {
			// ReviewerServiceTest.testRetrieveByBundleIdWithDepts
			results = new ArrayList<ReviewOwner>(0);
		} else {
			throw new AssertionError("Invalid conflictType id: " + conflictTypeId);
		}
		return results;
	}

	public List<ReviewOwner> findSODReviewersByConflictTypeId(Long conflictTypeId) {
		List<ReviewOwner> results = new ArrayList<ReviewOwner>(2);
		if((88932) == (conflictTypeId)) {
			// ReviewerServiceTest.testGetSodAvailableReassignReviewers
			results = new ArrayList<ReviewOwner>(0);
		}
		else {
			throw new AssertionError("Invalid conflict type id: " + conflictTypeId);
		}
		return results;
	}

	public ReviewOwner retrieveITComplianceManager() {
		if (this.nullItCompUser) {
			return null;
		}
		ReviewOwner owner = new ReviewOwner();
		owner.setUserId((34L));
		return owner;
	}

	public boolean isNullItCompUser() {
		return nullItCompUser;
	}

	public void setNullItCompUser(boolean nullItCompUser) {
		this.nullItCompUser = nullItCompUser;
	}

	public List<ReviewOwner> retrieveITComplianceManagers() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewOwner> findReviewOwnerByConflictId(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewOwner> findReviewOwnerListByConflict(Conflict conflict) {
		// TODO Auto-generated method stub
		return null;
	}

	public Long save(ReviewOwner reviewOwner) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReviewOwner> findActiveSodOwners() {
		// TODO Auto-generated method stub
		return null;
	}

}
