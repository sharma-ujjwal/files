/*package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.impl.tasklist.ReviewerTaskListService;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.test.inc.sox.domain.ar.ReviewBundleServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerServiceMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;
import com.assurant.test.inc.sox.domain.ar.SupervisorDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserDaoMock;


public class ReviewerTaskListServiceTest {
		
	@Test
	public void testRetrieveTaskListForReviewer() {
		List<ReviewerTaskListDTO> result = buildReviewerTaskListService().retrieveTaskListForReviewer();
		Assert.assertNotNull(result);
		
	}
	      
	@Test
	public void testRetrieveTaskListForAllReviewers() {
		List<ReviewerTaskListDTO> result = buildReviewerTaskListService().retrieveTaskListForAllReviewers();
		Assert.assertNotNull(result);
	}
	
	@Test
	public void testRetrieveTaskListForReviewersTeam() {
		List<ReviewerTaskListDTO> result = buildReviewerTaskListService().retrieveTaskListForReviewersTeam();
		Assert.assertNotNull(result);
	}
	
	private ReviewerTaskListService buildReviewerTaskListService() {
		ReviewerTaskListService service = new ReviewerTaskListService();
		service.setSavvionService(new SavvionServiceMock());
		service.setReviewBundleService(new ReviewBundleServiceMock());
		service.setReviewerService(new ReviewerServiceMock());
		service.setReviewService(new ReviewServiceMock());
		SystemUserDTO systemUser = new SystemUserDTO();
		systemUser.setUserId("TestSavvionITComplianceUserId");
		service.setSessionSystemUser(systemUser);
		service.setUserDao(new UserDaoMock());
		service.setSupervisorDao(new SupervisorDaoMock());
		return service;
	}
	
}
*/