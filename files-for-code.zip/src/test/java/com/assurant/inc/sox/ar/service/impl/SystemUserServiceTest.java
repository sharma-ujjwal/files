package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.test.inc.sox.domain.ar.SecurityFunctionAccessDaoMock;

public class SystemUserServiceTest {
	
	@Test
	public void testGetSystemUserAccessesWithRolesNotNull() {
		List<String> ldapRoles = new ArrayList<String>();
		ldapRoles.add("EBSOXSA");
		ldapRoles.add("EBSOXITC");
		SystemUserDTO result = buildSystemUserService().getSystemUserAccesses(ldapRoles);	
		Assert.assertNotNull(result);
		Assert.assertEquals("TestUserId", result.getUserId());
	}
	
	@Test
	public void testGetSystemUserAccessesWithRolesNull() {
		SystemUserDTO result = buildSystemUserService().getSystemUserAccesses(null);	
		Assert.assertNotNull(result);
		Assert.assertEquals("TestUserId", result.getUserId());
	}
	
	private SystemUserService buildSystemUserService() {
		SystemUserService service = new SystemUserService();
		SystemUserDTO user = new SystemUserDTO();
		user.setUserId("TestUserId");
		service.setSessionSystemUser(user);
		service.setSecurityFunctionAccessDao(new SecurityFunctionAccessDaoMock());
	   	return service;
	}
	
}
