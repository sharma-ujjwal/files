package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.ApplicationByUserIdDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserApplicationAccessesDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessKeepRemoveFlag;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ApplicationSystem;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewApplicationDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerDaoMock;


public class ReviewUserAccessServiceTest {
		
	@Test
	public void testRetrieveByReviewUserId() {
		List<ReviewUserApplicationAccessesDTO> result = buildReviewUserAccessService()
		.retrieveByReviewUserId((22222L));
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		Assert.assertNotNull(result.get(0));
		Assert.assertNotNull(result.get(0).getApplicationUserId());
		Assert.assertEquals("ABC1001", result.get(0).getApplicationUserId());
		Assert.assertNotNull(result.get(0).getApplicationName());
		Assert.assertEquals("JUnitTestName",  result.get(0).getApplicationName());
		Assert.assertNotNull(result.get(0).getAccesses().get(0));
	}
	
	@Test
	public void testSave() {
		List<ReviewUserAccessDTO> reviewUserAccessDTOs = new ArrayList<ReviewUserAccessDTO>();
		ReviewUserAccess access = new ReviewUserAccess();
		Application app = new Application();
		app.setName("JUnitTestName");
		ApplicationSystem appSystem = new ApplicationSystem();
		appSystem.setApplication(app);
		access.setApplicationSystem(appSystem);
		ReviewUserAccessDTO accessDTO = new ReviewUserAccessDTO(access, null);
		accessDTO.setKeepRemoveString("KEEP");
		reviewUserAccessDTOs.add(accessDTO);
		ReviewUserApplicationAccessesDTO dto = new ReviewUserApplicationAccessesDTO(
				new ApplicationByUserIdDTO("JUnitTestName", "ABC1001"), reviewUserAccessDTOs);
		dto.getReviewApplicationDTO().setComment("JUnitComment");
		List<ReviewUserApplicationAccessesDTO> dtos = new ArrayList<ReviewUserApplicationAccessesDTO>();
		dtos.add(dto);
		buildReviewUserAccessService().save(dtos, new ReviewerDTO(new Reviewer(), null, null, null));
	}
	
	@Test
	public void testSaveNoComment() {
		List<ReviewUserAccessDTO> reviewUserAccessDTOs = new ArrayList<ReviewUserAccessDTO>();
		ReviewUserAccess access = new ReviewUserAccess();
		Application app = new Application();
		app.setName("JUnitTestName");
		ApplicationSystem appSystem = new ApplicationSystem();
		appSystem.setApplication(app);
		access.setApplicationSystem(appSystem);
		ReviewUserAccessDTO accessDTO = new ReviewUserAccessDTO(access, null);
		accessDTO.setKeepRemoveString("KEEP");
		reviewUserAccessDTOs.add(accessDTO);
		ReviewUserApplicationAccessesDTO dto = new ReviewUserApplicationAccessesDTO(
				new ApplicationByUserIdDTO("JUnitTestName", "ABC1001"), reviewUserAccessDTOs);
		List<ReviewUserApplicationAccessesDTO> dtos = new ArrayList<ReviewUserApplicationAccessesDTO>();
		dtos.add(dto);
		buildReviewUserAccessService().save(dtos, new ReviewerDTO(new Reviewer(), null, null, null));
	}
	@Test
	public void testSaveNoAccessesChanged() {
		List<ReviewUserAccessDTO> reviewUserAccessDTOs = new ArrayList<ReviewUserAccessDTO>();
		ReviewUserAccess access = new ReviewUserAccess();
		access.setKeepRemoveFlg(ReviewUserAccessKeepRemoveFlag.KEEP.getFlagValue());
		Application app = new Application();
		app.setName("JUnitTestName");
		ApplicationSystem appSystem = new ApplicationSystem();
		appSystem.setApplication(app);
		access.setApplicationSystem(appSystem);
		ReviewUserAccessDTO accessDTO = new ReviewUserAccessDTO(access, null);
		accessDTO.setKeepRemoveString(ReviewUserAccessKeepRemoveFlag.KEEP.getFlagValue());
		reviewUserAccessDTOs.add(accessDTO);
		ReviewUserApplicationAccessesDTO dto = new ReviewUserApplicationAccessesDTO(
				new ApplicationByUserIdDTO("JUnitTestName", "ABC1001"), reviewUserAccessDTOs);
		List<ReviewUserApplicationAccessesDTO> dtos = new ArrayList<ReviewUserApplicationAccessesDTO>();
		dtos.add(dto);
		buildReviewUserAccessService().save(dtos, new ReviewerDTO(new Reviewer(), null, null, null));
	}
	private ReviewUserAccessService buildReviewUserAccessService() {
		ReviewUserAccessService service = new ReviewUserAccessService();
		service.setReviewerDao(new ReviewerDaoMock());
		service.setReviewUserAccessDao(new ReviewUserAccessDaoMock());
		service.setCodeService(new CodeServiceMock());
		service.setReviewApplicationDao(new ReviewApplicationDaoMock());
	   	return service;
	}
	
}
