package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.test.inc.sox.domain.ar.CodeDaoMock;

public class CodeServiceTest {

	@Test
	public void testRetrieveCodeByValueNoResult() {
		Assert.assertNull(buildCodeService().retrieveCodeByValueFromCache(CodeSet.REVIEW_BUNDLE_STATUS, "NONE"));
	}
	
	@Test
	public void testRetrieveCodeByValueFoundResult() {
		Assert.assertNotNull(buildCodeService().retrieveCodeByValueFromCache(CodeSet.REVIEW_BUNDLE_STATUS, "VAL"));
	}
	
	@Test
	public void testRetrieveAllCodesByTypeFoundResult() {
		CodeService codeService = buildCodeService();
		List<CodeDTO> codes = codeService.retrieveAllCodesByType(CodeSet.REVIEW_TYPE);
		Assert.assertNotNull(codes);
		Assert.assertEquals(2, codes.size());
		Assert.assertNotNull(getCodeByValue("CODE1", codes));
		Assert.assertNotNull(getCodeByValue("CODE2", codes));
		
	}
	
	@Test
	public void testRetrieveAllCodesByTypeNoResult() {
		CodeService codeService = buildCodeService();
		List<CodeDTO> codes = codeService.retrieveAllCodesByType(CodeSet.REVIEW_USER_ACCESS_KEEP_REMOVE);
		Assert.assertNotNull(codes);
		Assert.assertEquals(0, codes.size());
	}
	
	private CodeDTO getCodeByValue(String value, List<CodeDTO> codes) {
		CodeDTO result = null;
		for(CodeDTO code : codes) {
			if(value.equals(code.getValue())) {
				result =  code;
				break;
			}
		}
		return result;
	}
	
	private CodeService buildCodeService() {
		CodeService codeService = new CodeService();
		codeService.setCodeDao(new CodeDaoMock());
		return codeService;
	}
}
