package com.assurant.inc.sox.ar.service.impl;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.test.inc.sox.domain.ar.ProcessLockDaoMock;

public class LockServiceTest {

	@Test
	public void testBreakLock() {
		LockService lockService = buildLockService();
		lockService.breakLock("BreakSavId");
	}

	@Test
	public void testGetLockFound() {
		LockService service = buildLockService();
		LockDTO lock = service.getLock("GetSavId");
		Assert.assertEquals("JUNITUSR", lock.getHolder());
		Assert.assertEquals(TestHelper.buildTimelessDate(2000, 2, 4), lock.getCreated());
	}

	@Test
	public void testGetLockNotFound() {
		LockService service = buildLockService();
		LockDTO lock = service.getLock("GetSavIdNF");
		Assert.assertNull(lock);
	}
	
	@Test
	public void testLock() {
		LockService service = buildLockService();
		service.lock("LockSavId");
	}

	private LockService buildLockService() {
		LockService lockService = new LockService();
		lockService.setLockDao(new ProcessLockDaoMock());
		SystemUserDTO user = new SystemUserDTO();
		user.setUserId("JUNITUSR");
		lockService.setSessionSystemUser(user);
		return lockService;
	}

}
