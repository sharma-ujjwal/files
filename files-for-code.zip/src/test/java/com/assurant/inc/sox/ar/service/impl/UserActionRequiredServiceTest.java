/*package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewApplicationDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.UserActionRequiredDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;
import com.assurant.inc.sox.domain.ar.ReviewApplication;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewApplicationDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewWorkOrderDaoMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;
import com.assurant.test.inc.sox.domain.ar.UserAccessDaoMock;



public class UserActionRequiredServiceTest {
		
	@Test
	public void testRetrieveActionItems() {
		List<UserActionRequiredDTO> result = buildUserActionRequiredService()
		.retrieveActionItems(new Long(12345), new Long(67890));
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		Assert.assertEquals(new Long(42342), result.get(0).getReviewUserAccessId());
	}
	
	@Test
	public void testRetrieveWorkOrdersByReviewUser() {
		List<WorkOrderDTO> result = buildUserActionRequiredService()
		.retrieveWorkOrdersByReviewUser(new Long(44444));
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		Assert.assertEquals("TERM", result.get(0).getReasonCode().getValue());
	}
	
	@Test
	public void testAddWorkOrderList() {
		List<UserActionRequiredDTO> userActionRequiredDTOs = new ArrayList<UserActionRequiredDTO>();
		UserActionRequiredDTO accessdto = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		accessdto.setReviewUserAccessDTO(new ReviewUserAccessDTO(new ReviewUserAccess(), null));
		userActionRequiredDTOs.add(accessdto);
		
		UserActionRequiredDTO appdto = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		appdto.setReviewApplicationDTO(new ReviewApplicationDTO());
		userActionRequiredDTOs.add(accessdto);
		
		buildUserActionRequiredService()
		.addWorkOrder(userActionRequiredDTOs, "TERM", "TestSavvionId", new Long(32342), "TestComment");
	}
	
	@Test
	public void testAddWorkOrder() {
		ReviewUser user = new ReviewUser();
		user.setId(new Long(34234));
		ReviewUserDTO userDTO = new ReviewUserDTO(user, null, null);
		buildUserActionRequiredService()
		.addWorkOrder(userDTO, "TERM", "TestSavvionId", new Long(32342), "TestComment");
	}
	

	@Test
	public void testCompleteActionItemApplicationNull() {
		UserActionRequiredDTO accessDTO = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		ReviewUserAccessDTO dto = new ReviewUserAccessDTO(new ReviewUserAccess(), null);
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("statuscode");
		pk.setTableName("ReviewUserAccess");
		pk.setValue("PEND");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		dto.setStatus(codeDTO);
		accessDTO.setReviewUserAccessDTO(dto);
	
		buildUserActionRequiredService().completeActionItem(accessDTO, new Date());
		
	}
	

	@Test
	public void testCompleteActionItemAccessNull() {
		UserActionRequiredDTO appDTO = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		ReviewApplicationDTO dto = new ReviewApplicationDTO(new ReviewApplication());
		appDTO.setReviewApplicationDTO(dto);
		buildUserActionRequiredService().completeActionItem(appDTO, new Date());
		
	}
	
	@Test
	public void testCompleteActionRequiredTask() {
		buildUserActionRequiredService().completeActionRequiredTask("TestSavvionId");
	}
	
	@Test
	public void testValidateUsersAccessesWithAccessNotNull() {
		List<UserActionRequiredDTO> userActionRequiredDTOs = new ArrayList<UserActionRequiredDTO>();
		
		UserActionRequiredDTO accessDTO = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		ReviewUserAccessDTO dto = new ReviewUserAccessDTO(new ReviewUserAccess(), null);
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("statuscode");
		pk.setTableName("ReviewUserAccess");
		pk.setValue("PEND");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		dto.setStatus(codeDTO);
		dto.setUserKeyId("TestUserKeyId");
		accessDTO.setReviewUserAccessDTO(dto);
		userActionRequiredDTOs.add(accessDTO);
		buildUserActionRequiredService().validateUsersAccesses(userActionRequiredDTOs);
		
	}
	
	@Test
	public void testValidateUsersAccessesWithAccessNull() {
		List<UserActionRequiredDTO> userActionRequiredDTOs = new ArrayList<UserActionRequiredDTO>();
		
		UserActionRequiredDTO accessDTO = new UserActionRequiredDTO(new ArrayList<WorkOrderDTO>()
				, new ReviewUserDTO(new ReviewUser(), null, null));
		userActionRequiredDTOs.add(accessDTO);
		buildUserActionRequiredService().validateUsersAccesses(userActionRequiredDTOs);
		
	}
	
	private UserActionRequiredService buildUserActionRequiredService() {
		UserActionRequiredService service = new UserActionRequiredService();
		service.setReviewApplicationDao(new ReviewApplicationDaoMock());
		service.setReviewUserAccessDao(new ReviewUserAccessDaoMock());
		service.setReviewUserDao(new ReviewUserDaoMock());
		service.setWorkOrderDao(new ReviewWorkOrderDaoMock());
		service.setCodeService(new CodeServiceMock());
		service.setSavvionService(new SavvionServiceMock());
		service.setUserAccessDao(new UserAccessDaoMock());
		return service;
	}
	
}
*/