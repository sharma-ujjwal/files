/*package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDashboardDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerDaoMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;
import com.assurant.test.inc.sox.domain.ar.UserDaoMock;


public class ReviewUserServiceTest {
		
	@Test
	public void testRetrieveByReviewerIdNonRejected() {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("reviewtypecode");
		pk.setTableName("review");
		pk.setValue("MNGR");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		List<ReviewUserDTO> userDTOs = buildReviewUserService()
		 .retrieveByReviewerIdNonRejected(new Long(12345), codeDTO);
		Assert.assertNotNull(userDTOs);
		Assert.assertTrue(!userDTOs.isEmpty());
		Assert.assertNotNull(userDTOs.get(0).getReviewUser());
		Assert.assertEquals(new Long(45678), userDTOs.get(0).getUserId());
	}
	
	@Test
	public void testRetrieveByReviewerIdNonRejectedNonManager() {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("reviewtypecode");
		pk.setTableName("review");
		pk.setValue("DTOW");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		List<ReviewUserDTO> userDTOs = buildReviewUserService()
		 .retrieveByReviewerIdNonRejected(new Long(12345), codeDTO);
		Assert.assertNotNull(userDTOs);
		Assert.assertTrue(!userDTOs.isEmpty());
		Assert.assertEquals(new Long(45678), userDTOs.get(0).getUserId());
		Assert.assertNotNull(userDTOs.get(0).getReviewUser());
	}
	

	@Test
	public void testRejectReviewUsers() {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("rejectcode");
		pk.setTableName("reviewer");
		pk.setValue("TERM");
		code.setPk(pk);
		CodeDTO rejectcodeDTO = new CodeDTO(code);
		
		ReviewUser user = new ReviewUser();
		user.setId(new Long(757575));
		List<ReviewUserDTO> reviewUsers = new ArrayList<ReviewUserDTO>();
		reviewUsers.add(new ReviewUserDTO(user, null, null));
		
		ReviewerDTO reviewer = new ReviewerDTO(new Reviewer(), rejectcodeDTO, rejectcodeDTO, "TestBundleName");
		
		buildReviewUserService().rejectReviewUsers(reviewUsers, reviewer, "TERM", "TestComment");
	}
	
	@Test
	public void testCompleteReviewUser() {
		ReviewUser user = new ReviewUser();
		ReviewUserDTO dto = new ReviewUserDTO(user, null, null);
		buildReviewUserService().completeReviewUser(dto);
	}
	
	@Test
	public void testRetrieveByReviewerIdDashboard() {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("reviewtypecode");
		pk.setTableName("review");
		pk.setValue("DTOW");
		code.setPk(pk);
		CodeDTO reviewTypeCode = new CodeDTO(code);
		List<ReviewUserDashboardDTO> dashboardsDtos = buildReviewUserService()
		 .retrieveByReviewerIdDashboard(new Long(45454), reviewTypeCode);
		Assert.assertNotNull(dashboardsDtos);
		Assert.assertTrue(!dashboardsDtos.isEmpty());
		Assert.assertEquals(new Long(45678), dashboardsDtos.get(0).getUserId());
	}
	
	@Test
	public void testRetrieveByReviewerIdNonManager() {
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("reviewtypecode");
		pk.setTableName("review");
		pk.setValue("DTOW");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		List<ReviewUserDTO> userDTOs = buildReviewUserService()
		 .retrieveByReviewerId(new Long(45454), codeDTO);
		Assert.assertNotNull(userDTOs);
		Assert.assertTrue(!userDTOs.isEmpty());
		Assert.assertEquals(new Long(45678), userDTOs.get(0).getUserId());
	}
	
	@Test
	public void testRetrieveByIdResultNotNull() {
		ReviewUserDTO userDTO = buildReviewUserService().retrieveById(new Long(64546));
		Assert.assertNotNull(userDTO);
		Assert.assertNotNull(userDTO.getReviewUser());
		Assert.assertEquals(new Long(64546), userDTO.getReviewUserId());
	}
	
	@Test
	public void testRetrieveByIdResultNull() {
		ReviewUserDTO userDTO = buildReviewUserService().retrieveById(new Long(66666));
		Assert.assertNull(userDTO);
		
	}
	private ReviewUserService buildReviewUserService() {
		ReviewUserService service = new ReviewUserService();
		service.setReviewerDao(new ReviewerDaoMock());
		service.setReviewUserDao(new ReviewUserDaoMock());
		service.setCodeService(new CodeServiceMock());
		service.setUserDao(new UserDaoMock());		
		service.setSavvionService(new SavvionServiceMock());
		service.setSavvionITComplianceUserId("TestUserId101");
		service.setReviewUserAccessDao(new ReviewUserAccessDaoMock());
	   	return service;
	}
	
}
*/