/*package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.consts.ISavvionValues;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.dto.SavvionDTO;
import com.assurant.test.inc.sox.domain.ar.SavvionDaoMock;

public class SavvionServiceTest {
	
	@Test
	public void testCompleteProcessWithSavvionException() {
		try{
		  buildSavvionService().completeProcess("TestSavvionProcessId");
		} catch (Exception e) {
			
		}
	}
	
	@Test
	public void testCreateProcessWithSavvionException() {
		try{
		String processId = buildSavvionService().createProcess(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_SUMMARY
				, ISavvionValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY
				, ISavvionValues.PRIORITY_LOW
				, "TestAssignedTo", new HashMap<String, Object>());
		Assert.assertNull(processId);
		} catch (Exception e) {
			
		}

	}
	
	@Test
	public void testRetrieveProcessesByAssignedTo() {
		List<SavvionDTO> dtos = buildSavvionService().retrieveProcessesByAssignedTo("TestAssignedTo");
		Assert.assertNotNull(dtos);
		Assert.assertTrue(!dtos.isEmpty());
		Assert.assertEquals("TestAssignedTo", dtos.get(0).getAssignedTo());
	}
	
	@Test
	public void testRetrieveProcessesByTemplateName() {
		List<SavvionDTO> dtos = buildSavvionService().retrieveProcessesByTemplateName
		(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY);
		Assert.assertNotNull(dtos);
		Assert.assertTrue(!dtos.isEmpty());
	}
	
	@Test
	public void testUpdateProcessDataSlotsWithSavvionException() {
		try{
			buildSavvionService().updateProcessDataSlots("TestProcessId", new HashMap<String, Object>());
		} catch(Exception e) {
			
		}
		
	}
	
	@Test
	public void testCreateBulkProcessWithSavvionException() {
		try{
			buildSavvionService().createBulkProcess(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY
				    ,ISavvionValues.PROCESS_INSTANCE_NAME_PREFIX_VERIFY
				    , ISavvionValues.PRIORITY_LOW
				    , new ArrayList<HashMap<String, Object>>());
		} catch(Exception e) {
			
		}		
	}
	
	private SavvionService buildSavvionService() {
		SavvionService service = new SavvionService();
		service.setSavvionPassword("TESTPWD");
		service.setSavvionUserName("TestuserName");
		service.setWebServiceEndPoint("TestWSEndPoint");
		service.setSavvionDao(new SavvionDaoMock());
	   	return service;
	}
	
}
*/