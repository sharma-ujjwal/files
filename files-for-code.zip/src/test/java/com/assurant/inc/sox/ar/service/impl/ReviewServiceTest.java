/*package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.utils.exceptions.DuplicateReviewNameException;
import com.assurant.inc.sox.ar.utils.exceptions.NonClosableReview;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.CodePk;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.test.inc.sox.domain.ar.BundleDaoMock;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewBundleServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerServiceMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;
import com.assurant.test.inc.sox.domain.ar.SystemUserDTOMock;

public class ReviewServiceTest {
		
	@Test
	public void testRetrieveReviewById() {
		ReviewDTO review = buildReviewService().retrieveReviewById(new Long(12344));
		Assert.assertNotNull(review);
		Assert.assertEquals(new Long(12344), review.getReviewId());
	}
	
	@Test
	public void testRetrieveReviews() {
		List<ReviewDTO> reviews = buildReviewService().retrieveReviews();
		Assert.assertNotNull(reviews);
		Assert.assertTrue(!reviews.isEmpty());
	}
	
	@Test
	public void testRetrieveReviewsByStatus() {
		List<ReviewDTO> reviewDTOs = buildReviewService().retrieveReviewsByStatus(ReviewStatusCode.OUTSTANDING);
		Assert.assertNotNull(reviewDTOs);
		Assert.assertTrue(!reviewDTOs.isEmpty());
		Assert.assertEquals("OTST", reviewDTOs.get(0).getReviewStatusCd().getValue());
	}
	
	@Test
	public void testUpdateReview (){
		Code code = new Code();
		CodePk pk = new CodePk();
		pk.setColumnName("reviewtypecode");
		pk.setTableName("review");
		pk.setValue("MNGR");
		code.setPk(pk);
		CodeDTO codeDTO = new CodeDTO(code);
		Review review = new Review();
		review.setId(new Long(12344));
		ReviewDTO result = buildReviewService().updateReview(new ReviewDTO(review, codeDTO, codeDTO));
		Assert.assertNotNull(result);
		Assert.assertEquals("MNGR", result.getReviewTypeCd().getValue());
	}
	
	@Test
	public void testRetrieveCompletedDashboardReviews() {
		List<ReviewDashboardDTO> result = buildReviewService().retrieveCompletedDashboardReviews();
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		Assert.assertEquals("CMPD", result.get(0).getReviewStatusCd().getValue());
	}
	
	@Test
	public void testRetrieveOutstandingDashboardReviews() {
		List<ReviewDashboardDTO> result = buildReviewService().retrieveOutstandingDashboardReviews();
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		Assert.assertEquals("OTST", result.get(0).getReviewStatusCd().getValue());
	}
	
	@Test
	public void testCreateReview() {
		try {
			ReviewDTO result = buildReviewService().createReview("TestReview"
					, ReviewTypeCode.MANAGER, "TestComment", new Date(), true);
			Assert.assertNotNull(result);
			Assert.assertNotNull(result.getReview());
			Assert.assertEquals("TestReview", result.getReviewName());
			Assert.assertEquals("TestComment", result.getReviewComments());
			Assert.assertEquals(ReviewTypeCode.MANAGER.getCode(), result.getReviewTypeCd().getValue());
       		Assert.assertEquals("PEND", result.getReviewStatusCd().getValue());
			} catch (DuplicateReviewNameException e) {
				
			}
		
	}
	
	@Test
	public void testCalculateStatistics() {
		Review review = new Review();
		review.setId(new Long(12345));
		buildReviewService().calculateStatistics(new ReviewDashboardDTO(review, null, null));
	}
	
	@Test
	public void testCloseReview() {
		try {
			buildReviewService().closeReview(new Long(12345));
		} catch (NonClosableReview e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testCloseReviewBundleNonClosablereview() {
		try {
			buildReviewService().closeReview(new Long(33333));
		} catch (NonClosableReview e) {
			// TODO Auto-generated catch block
			
		}
	}
	
	@Test
	public void testCloseReviewReviewerNonClosablereview() {
		try {
			buildReviewService().closeReview(new Long(55555));
		} catch (NonClosableReview e) {
			// TODO Auto-generated catch block
			
		}
	}
	
	private ReviewService buildReviewService() {
		ReviewService service = new ReviewService();
		service.setReviewDao(new ReviewDaoMock());
		service.setCodeService(new CodeServiceMock());
		service.setReviewerService(new ReviewerServiceMock());
		service.setSessionSystemUser(new SystemUserDTOMock());
		service.setReviewBundleDao(new BundleDaoMock());
		service.setReviewDao(new ReviewDaoMock());
		service.setReviewerDao(new ReviewerDaoMock());
		service.setSavvionService(new SavvionServiceMock());
		service.setReviewUserDao(new ReviewUserDaoMock());
		service.setReviewBundleService(new ReviewBundleServiceMock());
	   	return service;
	}
	
}
*/