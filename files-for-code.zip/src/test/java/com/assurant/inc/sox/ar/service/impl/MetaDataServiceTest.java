package com.assurant.inc.sox.ar.service.impl;


import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.ApplicationDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;
import com.assurant.inc.sox.ar.dto.CostCenterDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.EnvironmentDTO;
import com.assurant.inc.sox.ar.dto.IndividualDTO;
import com.assurant.inc.sox.ar.dto.ManagerDTO;
import com.assurant.inc.sox.ar.dto.PrivDescriptionDTO;
import com.assurant.inc.sox.ar.dto.PrivValueDTO;
import com.assurant.inc.sox.ar.dto.SourceNameDTO;
import com.assurant.inc.sox.ar.dto.SoxConcernDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.UserTypeDTO;
import com.assurant.inc.sox.domain.ar.FilterType;
import com.assurant.test.inc.sox.domain.ar.ApplicationDaoMock;
import com.assurant.test.inc.sox.domain.ar.ConflictDaoMock;
import com.assurant.test.inc.sox.domain.ar.ConflictTypeDaoMock;
import com.assurant.test.inc.sox.domain.ar.DepartmentDaoMock;
import com.assurant.test.inc.sox.domain.ar.DivisionDaoMock;
import com.assurant.test.inc.sox.domain.ar.EnvironmentDaoMock;
import com.assurant.test.inc.sox.domain.ar.FilterTypeDaoMock;
import com.assurant.test.inc.sox.domain.ar.PrivilegeCommentDaoMock;
import com.assurant.test.inc.sox.domain.ar.SoxConcernDaoMock;
import com.assurant.test.inc.sox.domain.ar.SupervisorDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserStatusDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserTypeDaoMock;


public class MetaDataServiceTest {
	
	@Test
	public void testGetFilterTypeByValue(){
		FilterType filterType = buildMetaDataService().getFilterTypeByValue("Department");
		Assert.assertNotNull(filterType);
		Assert.assertEquals("Department", filterType.getFilterTypeValue());
		
	}
	
	@Test
	public void testRetrieveApplications() {
		 List<ApplicationDTO> result = buildMetaDataService().retrieveApplications("APP");
		 Assert.assertNotNull(result);
		 assertTrue(!result.isEmpty());
		            
	 }
	
	@Test
	public void testRetrieveSourceNames() {
		 List<SourceNameDTO> sourceNames =  buildMetaDataService().retrieveSourceNames("FP3a");
		 Assert.assertNotNull(sourceNames);
		 assertTrue(!sourceNames.isEmpty());
	}
	
	@Test
	public void testRetrieveDivisions() {
		 List<DivisionDTO> results = buildMetaDataService().retrieveDivisions("A");
		 Assert.assertNotNull(results);
		 assertTrue(!results.isEmpty());
		              
	 }
	
	@Test
	public void testRetrieveDepartments() {
		 List<DepartmentDTO> results = buildMetaDataService().retrieveDepartments("ACC");
		 Assert.assertNotNull(results);
		 assertTrue(!results.isEmpty());
		              
	 }
	
	@Test
	public void testRetrieveEnvironments() {
		 List<EnvironmentDTO> results = buildMetaDataService().retrieveEnvironments();
		 Assert.assertNotNull(results);
		 assertTrue(!results.isEmpty());
		 
		              
	 }
	
	@Test
	public void testRetrieveManagers() {
		 List<ManagerDTO> managers = buildMetaDataService().retrieveManagers("sHAw Je");
		 assertNotNull(managers);
	     assertTrue(!managers.isEmpty());
	}
	
	@Test
	public void testRetrieveIndividuals() {
		 List<IndividualDTO> users = buildMetaDataService().retrieveIndividuals("CHA");
		 assertNotNull(users);
		 assertTrue(!users.isEmpty());
		 
	}
	
	@Test
	public void testRetrieveCostCenters() {
		 List<CostCenterDTO> costCenters = buildMetaDataService().retrieveCostCenters("517");
		 assertNotNull(costCenters);
		 assertTrue(!costCenters.isEmpty());
	}
	
	@Test
	public void testRetrievePrivDescriptions(){
		List<PrivDescriptionDTO> privs = buildMetaDataService().retrievePrivDescriptions("O");
		assertNotNull(privs);
		assertTrue(!privs.isEmpty());
	}
	
	@Test
	public void testRetrievePrivValues(){
		List<PrivValueDTO> values = buildMetaDataService().retrievePrivValues("O");
		assertNotNull(values);
		assertTrue(!values.isEmpty());
	}
	
	@Test
	public void testRetrieveSoxConcerns(){
		List<SoxConcernDTO> soxConcerns = buildMetaDataService().retrieveSoxConcerns();
		assertNotNull(soxConcerns);
		assertTrue(!soxConcerns.isEmpty());
	}
	
	@Test
	public void testRetrieveUserStatuses(){
		List<UserStatusDTO> userStatuses = buildMetaDataService().retrieveUserStatuses();
		assertNotNull(userStatuses);
		assertTrue(!userStatuses.isEmpty());
	}
	
	@Test
	public void testRetrieveUserTypes(){
		List<UserTypeDTO> userTypes = buildMetaDataService().retrieveUserTypes();
		assertNotNull(userTypes);
		assertTrue(!userTypes.isEmpty());
	}
	
	@Test
	public void testRetrieveConflicts(){
		List<ConflictDTO> conflicts = buildMetaDataService().retreiveConflicts(23234L);
		assertNotNull(conflicts);
		assertTrue(!conflicts.isEmpty());
	}
	
	@Test
	public void testRetrieveConflictTypes(){
		List<ConflictTypeDTO> conflictTypes = buildMetaDataService().retrieveConflictTypes();
		assertNotNull(conflictTypes);
		assertTrue(!conflictTypes.isEmpty());
	}
	private MetaDataService buildMetaDataService() {
		 MetaDataService service = new MetaDataService();
		 service.setFilterTypeDao(new FilterTypeDaoMock());
		 service.setApplicationDao(new ApplicationDaoMock());
		 service.setUserAccessDao(new UserAccessDaoMock());
		 service.setDivisionDao(new DivisionDaoMock());
		 service.setDepartmentDao(new DepartmentDaoMock());
		 service.setEnvironmentDao(new EnvironmentDaoMock());
		 service.setSupervisorDao(new SupervisorDaoMock());
		 service.setUserDao(new UserDaoMock());
		 service.setPrivilegeCommentDao(new PrivilegeCommentDaoMock());
		 service.setSoxConcernDao(new SoxConcernDaoMock());
		 service.setUserStatusDao(new UserStatusDaoMock());
		 service.setUserTypeDao(new UserTypeDaoMock());
		 service.setConflictDao(new ConflictDaoMock());
		 service .setConflictTypeDao(new ConflictTypeDaoMock());
		 return service;
	}
	
	
}
