/*package com.assurant.inc.sox.ar.service.impl;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import com.assurant.test.inc.sox.domain.ar.BundleDaoMock;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.FilterCriteriaDaoMock;
import com.assurant.test.inc.sox.domain.ar.LockServiceMock;
import com.assurant.test.inc.sox.domain.ar.MetaDataServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewQueueDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerServiceMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;

public class ReviewBundleServiceTest {
		
	@Test
	public void testCreateReviewBundle() {
		List<FilterCriteriaDTO> filterCriteriaDtos = new ArrayList<FilterCriteriaDTO>();
		FilterCriteriaDTO dto = new FilterCriteriaDTO();
		dto.setFilterCriteriaType(FilterCriteriaType.DEPARTMENT);
		filterCriteriaDtos.add(dto);
		ReviewBundleDTO bundleDTO = buildReviewBundleService().createReviewBundle(new Long(12344), filterCriteriaDtos);
		Assert.assertNotNull(bundleDTO);
		Assert.assertEquals(new Long(12344), bundleDTO.getReviewId());
		Assert.assertEquals(new Long(12345), bundleDTO.getReviewBundleId());
		Assert.assertEquals("SoxSummary_V1#20755", bundleDTO.getSavvionProcessId());
		Assert.assertNotNull(bundleDTO.getReviewBundle());
	}
	
	@Test
	public void testRetrieveByIdBundleFound() {
		ReviewBundleDTO bundle = buildReviewBundleService().retrieveById(new Long(44333));
		Assert.assertNotNull(bundle);
		Assert.assertEquals(new Long(44333), bundle.getReviewBundleId());
		Assert.assertEquals(new Long(12344), bundle.getReviewId());    
	 }
	
	@Test
	public void testRetrieveByReviewId() {
		List<ReviewBundleDTO> bundles = buildReviewBundleService().retrieveByReviewId(new Long(32232));
		Assert.assertNotNull(bundles);
		assertTrue(!bundles.isEmpty());
		Assert.assertEquals(new Long(32232), bundles.get(0).getReviewId());
		Assert.assertNotNull(bundles.get(0).getReviewBundle());
		Assert.assertEquals(new Long(56465), bundles.get(0).getReviewBundleId());
		    
	 }

	@Test
	public void testRetrieveBySavvionId() {
		ReviewBundleDTO bundle = buildReviewBundleService().retrieveBySavvionId("SoxSummary_V1#20755");
		Assert.assertNotNull(bundle);
		Assert.assertEquals("SoxSummary_V1#20755", bundle.getSavvionProcessId());
		Assert.assertEquals(new Long(12345), bundle.getReviewBundleId());
	}
	
	@Test
	public void testRetrieveReviewName() {
		String reviewName = buildReviewBundleService().retrieveReviewName(new Long(44333));
		Assert.assertNotNull(reviewName);
		Assert.assertEquals("Manager101", reviewName);
	}
	
	@Test
	public void testRetrieveBundleName() {
		String bundleName = buildReviewBundleService().retrieveBundleName(new Long(44333));
		Assert.assertNotNull(bundleName);
			
	}
	
	@Test
	public void testRetrieveFilterCriteria() {
		List<FilterCriteriaDTO> filterCriteriaDTOs= 
			buildReviewBundleService().retrieveFilterCriteria(new Long(12345));
		Assert.assertNotNull(filterCriteriaDTOs);
		assertTrue(!filterCriteriaDTOs.isEmpty());
		Assert.assertEquals(new Long(12345), new Long(filterCriteriaDTOs.get(0).getReviewBundleId()));
	}
	
	@Test
	public void testAcceptBundleSummary() {
		buildReviewBundleService().acceptBundleSummary(new Long(44333));
	}
	
	@Test
	public void testRejectBundleSummary() {
		buildReviewBundleService().rejectBundleSummary(new Long(44333));
	}
	
	@Test
	public void testRetrieveNumberOfReports() {
		List<Long> reviewBundleIds = new ArrayList<Long>();
		reviewBundleIds.add(new Long(12345));
		Integer result = buildReviewBundleService().retrieveNumberOfReports(reviewBundleIds);
		Assert.assertNotNull(result);
		Assert.assertEquals(new Integer(1), result);
	}
	
	private ReviewBundleService buildReviewBundleService() {
		ReviewBundleService service = new ReviewBundleService();
		service.setReviewBundleDao(new BundleDaoMock());
		service.setCodeService(new CodeServiceMock());
		service.setReviewDao(new ReviewDaoMock());
		service.setReviewService(new ReviewServiceMock());
		service.setSavvionService(new SavvionServiceMock());
		service.setMetaDataService(new MetaDataServiceMock());
		service.setFilterCriteriaDao(new FilterCriteriaDaoMock());
		service.setReviewQueueDao(new ReviewQueueDaoMock());
		service.setReviewerService(new ReviewerServiceMock());
		service.setLockService(new LockServiceMock());
		return service;
	}
	
}
*/