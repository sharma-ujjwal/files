/*package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.utils.exceptions.UnReassignableException;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.ConflictType;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.test.inc.sox.domain.ar.BundleDaoMock;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewBundleServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewOwnerDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerReassignmentDaoMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;
import com.assurant.test.inc.sox.domain.ar.UserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.UserDaoMock;

public class ReviewerServiceTest {

	@Test
	public void testRetrieveByBundleIdWithDepts() {
		ReviewerService service = buildReviewerService();
		List<ReviewerDTO> reviewers = service.retrieveByBundleId(new Long(44338));
		Assert.assertNotNull(reviewers);
		Assert.assertEquals(2, reviewers.size());
		ReviewerDTO reviewer = reviewers.get(0);
		Assert.assertEquals(new Long(5433), reviewer.getReviewerId());
		Assert.assertNotNull(reviewer.getBundleName());
		Assert.assertEquals("TERM", reviewer.getRejectCode().getValue());
		Assert.assertEquals(ReviewerStatusCode.PENDING.getCode(), reviewer.getStatusCode().getValue());
		Assert.assertEquals(new Long(2), reviewer.getNumberOfReviewedUsers());
		Assert.assertEquals("ACTIVE", reviewer.getDistinctEmployeeStatuses());
		Assert.assertEquals(1, reviewer.getNumberOfDepartments());
		Assert.assertEquals(new Long(23), reviewer.getApplicationId());
		Assert.assertEquals("Smith, John Q", reviewer.getOwnerName());
		Assert.assertEquals(new Long(3224), reviewer.getConflict().getId());
		Assert.assertEquals("James, Sally", reviewer.getEscalationMgrName());

		reviewer = reviewers.get(1);
		Assert.assertEquals(new Long(5432), reviewer.getReviewerId());
		Assert.assertNotNull(reviewer.getBundleName());
		Assert.assertEquals("RCHG", reviewer.getRejectCode().getValue());
		Assert.assertEquals(ReviewerStatusCode.APPROVED.getCode(), reviewer.getStatusCode().getValue());
		Assert.assertEquals(new Long(1), reviewer.getNumberOfReviewedUsers());
		Assert.assertEquals("ACTIVE, INACTIVE", reviewer.getDistinctEmployeeStatuses());
		Assert.assertEquals(2, reviewer.getNumberOfDepartments());
		Assert.assertNull(reviewer.getApplicationId());
		Assert.assertNull(reviewer.getOwnerName());
		Assert.assertNull(reviewer.getConflict());
		Assert.assertNull(reviewer.getEscalationMgrName());
	}

	@Test
	public void testRetrieveByBundleIdWithOutDepts() {
		ReviewerService service = buildReviewerService();
		List<ReviewerDTO> reviewers = service.retrieveByBundleId(new Long(44339));

		ReviewerDTO reviewer = reviewers.get(0);
		Assert.assertEquals(new Long(5436), reviewer.getReviewerId());
		Assert.assertNotNull(reviewer.getBundleName());
		Assert.assertEquals("RJCT", reviewer.getRejectCode().getValue());
		Assert.assertEquals(ReviewerStatusCode.REJECTED.getCode(), reviewer.getStatusCode().getValue());
		Assert.assertEquals(new Long(3), reviewer.getNumberOfReviewedUsers());
		Assert.assertEquals("NOTACTIVE, ACTIVE", reviewer.getDistinctEmployeeStatuses());
		Assert.assertEquals(0, reviewer.getNumberOfDepartments());
		Assert.assertEquals(new Long(-1), reviewer.getApplicationId());
		Assert.assertNull(reviewer.getOwnerName());
		Assert.assertNull(reviewer.getConflict());
		Assert.assertEquals(new Long(-1), reviewer.getEscalationMgrId());
		Assert.assertNull(reviewer.getEscalationMgrName());

		reviewer = reviewers.get(1);
		Assert.assertEquals(new Long(5437), reviewer.getReviewerId());
		Assert.assertNotNull(reviewer.getBundleName());
		Assert.assertEquals("NOEV", reviewer.getRejectCode().getValue());
		Assert.assertEquals(ReviewerStatusCode.RELEASED.getCode(), reviewer.getStatusCode().getValue());
		Assert.assertEquals(new Long(23), reviewer.getNumberOfReviewedUsers());
		Assert.assertEquals("", reviewer.getDistinctEmployeeStatuses());
		Assert.assertEquals(0, reviewer.getNumberOfDepartments());
		Assert.assertEquals(new Long(223), reviewer.getApplicationId());
		Assert.assertNull(reviewer.getOwnerName());
		Assert.assertNull(reviewer.getConflict());
		Assert.assertNull(reviewer.getEscalationMgrName());
	}

	@Test
	public void testRetrieveByBundleIdNoReviewers() {
		ReviewerService service = buildReviewerService();
		List<ReviewerDTO> reviewers = service.retrieveByBundleId(new Long(44340));
		Assert.assertNotNull(reviewers);
		Assert.assertEquals(0, reviewers.size());
	}

	@Test
	public void testRetrieveByStatus() {
		ReviewerService service = buildReviewerService();
		List<ReviewerDTO> reviewers = service.retrieveByStatus(new Long(44341), ReviewerStatusCode.APPROVED);
		Assert.assertNotNull(reviewers);
		Assert.assertEquals(1, reviewers.size());
		ReviewerDTO reviewer = reviewers.get(0);
		Assert.assertEquals(new Long(5440), reviewer.getReviewerId());
		Assert.assertEquals(ReviewerStatusCode.APPROVED.getCode(), reviewer.getStatusCode().getValue());
	}

	@Test
	public void testPopulateReviewerAdditionalDetails() {
		ReviewerService service = buildReviewerService();
		Reviewer reviewer = new Reviewer();
		reviewer.setId(new Long(5450));
		ReviewerDTO dto = new ReviewerDTO(reviewer, null, null, null);
		service.populateReviewerDistinctEnvName(dto);
		Assert.assertEquals("PROD, DEV", dto.getDistinctEnvName());
	}

	@Test
	public void testPopulateHasManagerAccessToApplication() {
		List<ReviewerDTO> reviewers = new ArrayList<ReviewerDTO>(2);

		Reviewer reviewer = new Reviewer();
		reviewer.setId(new Long(5460));
		reviewer.setUserId(new Long(4430));
		ReviewerDTO dto1 = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(dto1);

		reviewer = new Reviewer();
		reviewer.setId(new Long(5461));
		reviewer.setUserId(new Long(4431));
		ReviewerDTO dto2 = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(dto2);

		reviewer = new Reviewer();
		reviewer.setId(new Long(5462));
		reviewer.setUserId(new Long(4432));
		ReviewerDTO dto3 = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(dto3);

		reviewer = new Reviewer();
		reviewer.setId(new Long(5463));
		reviewer.setUserId(new Long(4433));
		ReviewerDTO dto4 = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(dto4);

		buildReviewerService().populateHasManagerAccessToApplication(reviewers);

		Assert.assertTrue(dto1.isHasAccessToApplication());
		Assert.assertFalse(dto2.isHasAccessToApplication());
		Assert.assertFalse(dto3.isHasAccessToApplication());
		Assert.assertFalse(dto4.isHasAccessToApplication());
	}

	@Test
	public void testApproveReviewers() {
		List<ReviewerDTO> reviewers = new ArrayList<ReviewerDTO>(2);

		Reviewer reviewer = new Reviewer();
		reviewer.setId(new Long(5460));
		reviewer.setReviewerLastStatusCd(ReviewerStatusCode.PENDING.getCode());
		ReviewerDTO dto1 = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(dto1);

		buildReviewerService().approveReviewers(reviewers);

		Assert.assertEquals(ReviewerStatusCode.APPROVED.getCode(), reviewer.getReviewerLastStatusCd());
		TestHelper.assertTimelessDateEquals(new Date(), reviewer.getReviewerApprovedDate());
		Assert.assertEquals("JU11228", reviewer.getReviewerApprovedBy());
	}

	@Test
	public void testDistributeReviewers() {
		List<ReviewerDTO> reviewers = new ArrayList<ReviewerDTO>(1);
		Reviewer reviewer = new Reviewer();
		reviewer.setId(new Long(34460));
		reviewer.setReviewerName("Bob reviewer");
		reviewer.setReviewerEmailAddress("juEmail");
		reviewer.setReviewBundleId(new Long(44566));
		reviewer.setUserId(new Long(6475675));
		ReviewerDTO reviewerDTO = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(reviewerDTO);

		reviewer = new Reviewer();
		reviewer.setId(new Long(34461));
		reviewer.setReviewerName("John reviewer");
		reviewer.setReviewerEmailAddress("juEmail2");
		reviewer.setReviewBundleId(new Long(44566));
		reviewer.setUserId(new Long(6475676));
		reviewerDTO = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(reviewerDTO);

		reviewer = new Reviewer();
		reviewer.setId(new Long(34462));
		reviewer.setReviewerName("Sally reviewer");
		reviewer.setReviewerEmailAddress("juEmail3");
		reviewer.setReviewBundleId(new Long(44566));
		reviewer.setUserId(new Long(6475677));
		reviewerDTO = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(reviewerDTO);

		reviewer = new Reviewer();
		reviewer.setId(new Long(34463));
		reviewer.setReviewerName("Sally reviewer");
		reviewer.setReviewerEmailAddress("-1");
		reviewer.setReviewBundleId(new Long(44566));
		reviewer.setUserId(new Long(6475678));
		reviewerDTO = new ReviewerDTO(reviewer, null, null, null);
		reviewers.add(reviewerDTO);

		Date targetDate = TestHelper.buildTimelessDate(2004, 2, 1);
		String instructions = "Instructions";

		buildReviewerService().distributeReviewers(reviewers, targetDate, instructions);

	}

	@Test
	public void testCompleteSavvionProcessNotComplePendAppr() {
		Set<Long> bundleIds = Collections.singleton(new Long(843348));
		buildReviewerService().completeSavvionProcess(bundleIds);
	}

	@Test
	public void testCompleteSavvionProcessNotComplePend() {
		Set<Long> bundleIds = Collections.singleton(new Long(843349));
		buildReviewerService().completeSavvionProcess(bundleIds);
	}

	@Test
	public void testCompleteSavvionProcessNotCompleAppr() {
		Set<Long> bundleIds = Collections.singleton(new Long(843350));
		buildReviewerService().completeSavvionProcess(bundleIds);
	}

	@Test
	public void testCompleteSavvionProcessNotCompNoBundle() {
		Set<Long> bundleIds = Collections.singleton(new Long(843351));
		buildReviewerService().completeSavvionProcess(bundleIds);
	}

	@Test
	public void testCompleteSavvionProcessComp() {
		Set<Long> bundleIds = Collections.singleton(new Long(843352));
		buildReviewerService().completeSavvionProcess(bundleIds);
	}

	@Test
	public void testReassignReleasedReviewer() {
		UserDataDTO newUser = new UserDataDTO();
		newUser.setEmailAddress("email@emailAddr");
		newUser.setUserId(8773);
		newUser.setName("userName");
		newUser.setReassignedInstructions("drist instructions blah");
		Date targetDate = TestHelper.buildTimelessDate(2004, 4, 3);
		newUser.setReassignedTargetCompleteDate(targetDate);

		UserStatus statusDomain = new UserStatus();
		statusDomain.setId(new Long(443));
		UserStatusDTO status = new UserStatusDTO(statusDomain);
		newUser.setStatus(status);

		Department deptDomain = new Department();
		deptDomain.setId(new Long(53434));
		DepartmentDTO dept = new DepartmentDTO(deptDomain);
		newUser.setDepartment(dept);

		Reviewer reviewerDomain = new Reviewer();
		reviewerDomain.setId(new Long(5577383));
		reviewerDomain.setUserId(new Long(43));
		reviewerDomain.setReviewerName("junitName");
		reviewerDomain.setReviewBundleId(new Long(774324));
		ReviewerDTO reviewer = new ReviewerDTO(reviewerDomain, null, null, null);

		try {
			buildReviewerService().reassignReleasedReviewer(reviewer, "REAS", "reassign comment", newUser, "Savvion#558948");
		} catch (UnReassignableException e) {
			Assert.fail();
		}

	}

	@Test
	public void testReassignReleasedReviewerUnreassignable() {
		UserDataDTO newUser = new UserDataDTO();
		newUser.setEmailAddress("-1");

		try {
			buildReviewerService().reassignReleasedReviewer(null, "REAS", "reassign comment", newUser, "Savvion#558948");
			Assert.fail("should have thrown unreassignable exception");
		} catch (UnReassignableException e) {
			//
		}
	}

	@Test
	public void testReassignReviewer() {
		UserDataDTO newUser = new UserDataDTO();
		newUser.setEmailAddress("email@emailAddr");
		newUser.setUserId(8773);
		newUser.setName("userName");
		newUser.setReassignedInstructions("drist instructions blah");
		Date targetDate = TestHelper.buildTimelessDate(2004, 4, 3);
		newUser.setReassignedTargetCompleteDate(targetDate);

		UserStatus statusDomain = new UserStatus();
		statusDomain.setId(new Long(443));
		UserStatusDTO status = new UserStatusDTO(statusDomain);
		newUser.setStatus(status);

		Department deptDomain = new Department();
		deptDomain.setId(new Long(53434));
		DepartmentDTO dept = new DepartmentDTO(deptDomain);
		newUser.setDepartment(dept);

		Reviewer reviewerDomain = new Reviewer();
		reviewerDomain.setId(new Long(5577383));
		reviewerDomain.setUserId(new Long(43));
		reviewerDomain.setReviewerName("junitName");
		reviewerDomain.setReviewBundleId(new Long(774324));
		ReviewerDTO reviewer = new ReviewerDTO(reviewerDomain, null, null, null);

		buildReviewerService().reassignReviewers(Collections.singletonList(reviewer), "REAS", "reassign comment", newUser);

	}

	@Test
	public void testRejectReviewers() {
		Reviewer reviewer = new Reviewer();
		reviewer.setId(new Long(5322423));
		ReviewerDTO reviewerDTO = new ReviewerDTO(reviewer, null, null, null);

		buildReviewerService().rejectReviewers(Collections.singletonList(reviewerDTO), "RJCT", "reject reason comments");

	}

	@Test
	public void testRetrieveNumberOfReviewers() {
		List<Long> reviewBundleIds = Collections.singletonList(new Long(38849));
		Assert.assertEquals(4, buildReviewerService().retrieveNumberOfReviewers(reviewBundleIds));
	}

	@Test
	public void testGetManagerReviewAvailableReassignReviewers() {
		List<UserDataDTO> results = buildReviewerService().getManagerReviewAvailableReassignReviewers(new Long(8423));
		Assert.assertNotNull(results);
		Assert.assertEquals(2, results.size());
		UserDataDTO result = results.get(0);
		Assert.assertEquals(new Long(6), new Long(result.getDepartment().getId()));
		Assert.assertEquals(new Long(8), result.getStatus().getUserStatus().getId());
		Assert.assertEquals("superEmailAddr", result.getEmailAddress());
		Assert.assertEquals(new Long(88), new Long(result.getUserId()));
		Assert.assertEquals("smith, john joe", result.getName());

		result = results.get(1);
		Assert.assertEquals(new Long(64), new Long(result.getDepartment().getId()));
		Assert.assertEquals(new Long(84), result.getStatus().getUserStatus().getId());
		Assert.assertEquals("itComUsr", result.getEmailAddress());
		Assert.assertEquals(new Long(884), new Long(result.getUserId()));
		Assert.assertEquals("blair, linda r", result.getName());

	}

	@Test
	public void testGetManagerReviewAvailableReassignReviewersNoSuper() {
		List<UserDataDTO> results = buildReviewerService().getManagerReviewAvailableReassignReviewers(new Long(8424));
		Assert.assertNotNull(results);
		Assert.assertEquals(1, results.size());
		UserDataDTO result = results.get(0);
		Assert.assertEquals(new Long(64), new Long(result.getDepartment().getId()));
		Assert.assertEquals(new Long(84), result.getStatus().getUserStatus().getId());
		Assert.assertEquals("itComUsr", result.getEmailAddress());
		Assert.assertEquals(new Long(884), new Long(result.getUserId()));
		Assert.assertEquals("blair, linda r", result.getName());
	}

	@Test
	public void testGetManagerReviewAvailableReassignReviewersNoItComp() {
		ReviewerService service = buildReviewerService();
		ReviewOwnerDaoMock ownerDao = (ReviewOwnerDaoMock) service.getReviewOwnerDao();
		ownerDao.setNullItCompUser(true);
		List<UserDataDTO> results = service.getManagerReviewAvailableReassignReviewers(new Long(8425));
		Assert.assertNotNull(results);
		Assert.assertEquals(1, results.size());
		UserDataDTO result = results.get(0);
		Assert.assertEquals(new Long(6), new Long(result.getDepartment().getId()));
		Assert.assertEquals(new Long(8), result.getStatus().getUserStatus().getId());
		Assert.assertEquals("superEmailAddr", result.getEmailAddress());
		Assert.assertEquals(new Long(88), new Long(result.getUserId()));
		Assert.assertEquals("smith, john joe", result.getName());
	}

	@Test
	public void testGetDataOwnerReviewAvailableReassignReviewers() {
		try {
			List<UserDataDTO> results = buildReviewerService().getDataOwnerReviewAvailableReassignReviewers(new Long(563533),
			    new Long(6643));

			Assert.assertNotNull(results);
			Assert.assertEquals(2, results.size());
			UserDataDTO result = results.get(0);
			Assert.assertEquals(new Long(5566), new Long(result.getDepartment().getId()));
			Assert.assertEquals(new Long(665), result.getStatus().getUserStatus().getId());
			Assert.assertEquals("dataOwnerReviewer", result.getEmailAddress());
			Assert.assertEquals(new Long(7898), new Long(result.getUserId()));
			Assert.assertEquals("Johnson, John J", result.getName());

			result = results.get(1);
			Assert.assertEquals(new Long(64), new Long(result.getDepartment().getId()));
			Assert.assertEquals(new Long(84), result.getStatus().getUserStatus().getId());
			Assert.assertEquals("itComUsr", result.getEmailAddress());
			Assert.assertEquals(new Long(884), new Long(result.getUserId()));
			Assert.assertEquals("blair, linda r", result.getName());

		} catch (InactiveReassignReviewerException e) {
			Assert.fail();
		}
	}

	@Test
	public void testGetDataOwnerReviewAvailableReassignReviewersCurrentUser() {
		try {
			List<UserDataDTO> results = buildReviewerService().getDataOwnerReviewAvailableReassignReviewers(new Long(563534),
			    new Long(7898));

			Assert.assertNotNull(results);
			Assert.assertEquals(1, results.size());

			UserDataDTO result = results.get(0);
			Assert.assertEquals(new Long(64), new Long(result.getDepartment().getId()));
			Assert.assertEquals(new Long(84), result.getStatus().getUserStatus().getId());
			Assert.assertEquals("itComUsr", result.getEmailAddress());
			Assert.assertEquals(new Long(884), new Long(result.getUserId()));
			Assert.assertEquals("blair, linda r", result.getName());

		} catch (InactiveReassignReviewerException e) {
			Assert.fail();
		}
	}

	@Test
	public void testGetDataOwnerReviewAvailableReassignReviewersInactive() {
		try {
			buildReviewerService().getDataOwnerReviewAvailableReassignReviewers(new Long(563535), new Long(7898));
			Assert.fail();
		} catch (InactiveReassignReviewerException e) {
			List<UserDataDTO> results = e.getInactiveUsers();
			Assert.assertNotNull(results);
			Assert.assertEquals(1, results.size());

			UserDataDTO result = results.get(0);
			Assert.assertEquals(new Long(5567), new Long(result.getDepartment().getId()));
			Assert.assertEquals(new Long(668), result.getStatus().getUserStatus().getId());
			Assert.assertEquals("inactiveReviewer", result.getEmailAddress());
			Assert.assertEquals(new Long(7899), new Long(result.getUserId()));
			Assert.assertEquals("JohnsonI, JohnI JI", result.getName());
		}
	}

	@Test
	public void testGetSodAvailableReassignReviewers() {
		Conflict conf = new Conflict();
		conf.setId(new Long(88932));
		conf.setLeftConflictId(new Long(12345));
		conf.setConflictType(new ConflictType());
		ConflictDTO confDTO = new ConflictDTO(conf);
		try {
			buildReviewerService().getSODAvailableReassignReviewers(confDTO, new Long(22888));
		} catch (InactiveReassignReviewerException e) {
			Assert.fail();
		}
	}

	private ReviewerService buildReviewerService() {
		ReviewerService service = new ReviewerService();
		service.setReviewBundleDao(new BundleDaoMock());
		service.setReviewDao(new ReviewDaoMock());
		service.setReviewerDao(new ReviewerDaoMock());
		service.setReviewBundleService(new ReviewBundleServiceMock());
		service.setCodeService(new CodeServiceMock());
		service.setReviewUserDao(new ReviewUserDaoMock());
		service.setReviewOwnerDao(new ReviewOwnerDaoMock());
		service.setUserDao(new UserDaoMock());
		service.setUserAccessDao(new UserAccessDaoMock());
		SystemUserDTO user = new SystemUserDTO();
		user.setUserId("JU11228");
		service.setSessionSystemUser(user);
		service.setSavvionService(new SavvionServiceMock());
		service.setFromEmailAddress("junitFrom");
		service.setAppURL("appUrl");
		service.setReviewReassignmentDao(new ReviewerReassignmentDaoMock());
		return service;
	}
}
*/