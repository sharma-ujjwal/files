package com.assurant.inc.sox.ar.service.impl;

import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;

public class TestHelper {
	public static Date buildTimelessDate(int year, int month, int day) {
		Calendar cal = Calendar.getInstance();
		cal.set(year, month, day, 0, 0, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	public static void assertTimelessDateEquals(Date expected, Date actual) {
		long expectedTime = expected.getTime();
		long actualTime = actual.getTime();
		String message = "expected:<" + expected + "> but was:<" + actual + ">";
		Assert.assertTrue(message, Math.abs((expectedTime - actualTime)) <= 1000);
	}

}
