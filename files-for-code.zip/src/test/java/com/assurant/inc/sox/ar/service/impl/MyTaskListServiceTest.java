/*package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.service.impl.tasklist.MyTaskListService;
import com.assurant.test.inc.sox.domain.ar.ApplicationDaoMock;
import com.assurant.test.inc.sox.domain.ar.BundleDaoMock;
import com.assurant.test.inc.sox.domain.ar.CodeServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewApplicationDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewBundleServiceMock;
import com.assurant.test.inc.sox.domain.ar.ReviewDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserAccessDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewUserDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewWorkOrderDaoMock;
import com.assurant.test.inc.sox.domain.ar.ReviewerDaoMock;
import com.assurant.test.inc.sox.domain.ar.SavvionServiceMock;


public class MyTaskListServiceTest {
		
	@Test
	public void testRetrieveActionRequiredTasks() {
		List<ActionRequiredTasklistDTO> result = buildMyTaskListService().retrieveActionRequiredTasks();
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		
	}
	@Test
	public void testRetrieveItComplianceTasks() {
		List<AbstractTaskListDTO> result = buildMyTaskListService().retrieveItComplianceTasks();
		Assert.assertNotNull(result);
		Assert.assertTrue(!result.isEmpty());
		
	}
	
	private MyTaskListService buildMyTaskListService() {
		MyTaskListService service = new MyTaskListService();
		service.setSavvionService(new SavvionServiceMock());
		service.setSavvionITComplianceUserId("TestSavvionITComplianceUserId");
		service.setReviewUserDao(new ReviewUserDaoMock());
		service.setApplicationDao(new ApplicationDaoMock());
		service.setReviewApplicationDao(new ReviewApplicationDaoMock());
		service.setReviewDao(new ReviewDaoMock());
		service.setReviewUserAccessDao(new ReviewUserAccessDaoMock());
		service.setReviewerDao(new ReviewerDaoMock());
		service.setReviewBundleDao(new BundleDaoMock());
		service.setReviewBundleService(new ReviewBundleServiceMock());
		service.setCodeService(new CodeServiceMock());
		service.setWorkOrderDao(new ReviewWorkOrderDaoMock());
		return service;
	}
	
}
*/