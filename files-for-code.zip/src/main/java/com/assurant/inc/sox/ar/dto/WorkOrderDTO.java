package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;

public class WorkOrderDTO {

	private final ReviewWorkOrder workOrder;
	private final CodeDTO reasonCode;
	

	public WorkOrderDTO(ReviewWorkOrder workOrder, CodeDTO reasonCode) {
		this.workOrder = workOrder;
		this.reasonCode = reasonCode;
	}

	public Date getCreateDate() {
		return this.workOrder.getCreatedDate();
	}

	public void setCreateDate(Date createDate) {
		this.workOrder.setCreatedDate(createDate);
	}

	public Long getWorkOrderNumber() {
		if (this.workOrder.getWorkOrderNo() == null) {
			return null;
		}
		return this.workOrder.getWorkOrderNo();
	}

	public void setWorkOrderNumber(Long workOrderNumber) {
		this.workOrder.setWorkOrderNo(workOrderNumber);
	}

	public CodeDTO getReasonCode() {

		return this.reasonCode;
	}

	public String getComments() {
		return this.workOrder.getWorkOrderComment();
	}

	public void setComments(String comments) {
		this.workOrder.setWorkOrderComment(comments);
	}

	public Long getWorkOrderId() {
		return this.workOrder.getId();
	}

	public void setWorkOrderId(Long workOrderId) {
		this.workOrder.setId(workOrderId);
	}

	public ReviewWorkOrder getWorkOrder() {
		return workOrder;
	}

	public String getSavvionProcessId() {
		return this.workOrder.getTaskProcessId();
	}

	public void setTaskProcessId(String taskProcessId) {
		this.workOrder.setTaskProcessId(taskProcessId);
	}
}
