package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.assurant.inc.sox.ar.client.admin.ui.DepartmentUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IDepartmentService;
import com.assurant.inc.sox.domain.ar.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
public class DepartmentSummaryBean {
	private static final Logger logger = LoggerFactory.getLogger(DepartmentSummaryBean.class);
	private List<DepartmentUI> departmentList;
	private List<DepartmentUI> deletedDepartmentList = new ArrayList<DepartmentUI>();
	@Autowired
	@Qualifier("departmentService")
	private IDepartmentService departmentService;
	private Integer displayAmount = 10;
	private String oldSortColumn;
	private String departmentName;
	private String costCenterNumber;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String departmentSearchText;
	private boolean renderAddDepartmentModalPanel;
	private boolean renderDeleteDepartmentModalPanel;
	private SessionDataBean sessionDataBean;
	private boolean allChecked;
	private String  pageNumber = "1";
	private String 	lastPageNumber= "1";
	
	public List<DepartmentUI> getDepartmentList() {
		if (departmentList == null) {
			refreshList();
		}
		return departmentList;
	}

	// ******* Refresh the List RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.departmentList = new ArrayList<>();
		List<Department> departmentsRetrieved = new ArrayList<>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.departmentSearchText)) {
				departmentsRetrieved = this.departmentService
						.retrieveAllDepartmentsByDepartmentNameCostCenter(this.departmentSearchText);
			} else {
				departmentsRetrieved = this.departmentService
						.retrieveAllDepartments();
			}

		} else if (FilterTableCode.DELETED_ROWS.name()
				.equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.departmentSearchText)) {
				departmentsRetrieved = this.departmentService
						.retrieveDeletedDepartmentsByDepartmentNameCostCenter(this.departmentSearchText);
			} else {
				departmentsRetrieved = this.departmentService
						.retrieveDeletedDepartments();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.departmentSearchText)) {
				departmentsRetrieved = this.departmentService
						.retrieveUnassignedDepartmentsByDepartmentNameCostCenter(this.departmentSearchText);
			} else {
				departmentsRetrieved = this.departmentService
						.retrieveUnassignedDepartments(); 
			}
		}
		for (Department department : departmentsRetrieved) {
			this.departmentList.add(new DepartmentUI(department));
		}

		this.doSort();
	}

	// ******* GO button *******
	public String goSearch() {
		refreshList();
		return "";
	}

	// ******* RESET button *******
	public String resetSearch() {
		this.departmentList = null;
		this.departmentSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// ******* Filter ListBox *******
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		this.clearSelections();
		
		return "";
	}

	// ******* List Headers *******
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "name";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(departmentList, column, this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}

	// ******* Add Department Panel *******
	public String showAddDepartmentPanel() {
		this.renderAddDepartmentModalPanel = true;
		this.departmentName = "";
		this.costCenterNumber = "";
		this.clearSelections();
		return null;
	}

	// ******* Add Department Panel CANCEL *******
	public String doCancelAdd() {
		logger.debug("doCancelAddDepartmentPanel() --> being executed.");
		this.renderAddDepartmentModalPanel = false;
		this.clearSelections();
		return null;
	}

	// ******* Add Department Panel SAVE *******
	public String doAddDepartment() {
		logger.debug("doAddDepartment() --> being executed.");
		// Displays error message if Department not provided

		if (!validDepartmentName()) {
			String message = "Department name is required.";
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}
		if (!validCostCenter()) {
			String message = "Cost Center is required.";
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		this.departmentName   = this.departmentName.toUpperCase(); 
		this.costCenterNumber = this.costCenterNumber.toUpperCase(); 
		
		Department duplicate = this.departmentService.findDuplicate(departmentName, 
				costCenterNumber);
		if (duplicate != null) {
			String message = "Department " + departmentName + "-"
					+ this.costCenterNumber + " already exists with ID "
					+ duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		departmentService.add(this.departmentName, this.costCenterNumber);

		// Display Message.
		String message = "Added Department " + this.departmentName + "-" + this.costCenterNumber;
		JSFUtils.addFacesMessage(message);
		this.refreshList();

		this.renderAddDepartmentModalPanel = false;
		return "";
	}

	// ******* Delete Department Panel *******
	public String showDeleteDepartmentPanel() {
		populateDeletedDepartmentList();
		if (this.deletedDepartmentList.isEmpty()) {
			String message = "Please select at least one department.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteDepartmentModalPanel = true;
		}

		return null;
	}

	private void populateDeletedDepartmentList() {
		deletedDepartmentList = new ArrayList<DepartmentUI>();
		
		for (DepartmentUI ui : this.departmentList) {
			if (ui.isChecked()) {
				this.deletedDepartmentList.add(ui);
			}
		}
	}

	public void doDisplayRowListener() {
		logger.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = displayAmount;
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)departmentList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), departmentList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				departmentList.get(currRow).setChecked(true);
			}
		} else {
			for (DepartmentUI departmentUI : this.departmentList) {
				departmentUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (DepartmentUI departmentUI : this.departmentList) {
			departmentUI.setChecked(false);
		}
	}

	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (DepartmentUI ui : this.deletedDepartmentList) {
			// first perform a check to ensure that no one user record has the
			// curren department assigned
			if (this.departmentService.canDepartmentBeDeleted(ui.getId())) {
				this.departmentService.delete(ui.getDepartment()); 
			} else {
				unableToDelete.add(ui.getDepartmentNameCostCenter());
			}
		}

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected departments were deleted " +
					"except for the following, which are assigned to at least one " +
					"user record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected departments");
		}

		this.refreshList();

		this.deletedDepartmentList = new ArrayList<DepartmentUI>();
		this.renderDeleteDepartmentModalPanel = false;
		return null;
	}

	public String doCancelDelete() {
		this.deletedDepartmentList = new ArrayList<DepartmentUI>();
		this.renderDeleteDepartmentModalPanel = false;
		return null;
	}

	public boolean validDepartmentName() {
		return (StringUtils.isNotEmpty(departmentName));
	}

	public boolean validCostCenter() {
		return (StringUtils.isNotEmpty(costCenterNumber));
	}

	public boolean isRenderAddDepartmentModalPanel() {
		return renderAddDepartmentModalPanel;
	}

	public void setRenderAddDepartmentModalPanel(
			boolean renderAddDepartmentModalPanel) {
		this.renderAddDepartmentModalPanel = renderAddDepartmentModalPanel;
	}

	public boolean isRenderDeleteDepartmentModalPanel() {
		return renderDeleteDepartmentModalPanel;
	}

	public void setRenderDeleteDepartmentModalPanel(
			boolean renderDeleteDepartmentModalPanel) {
		this.renderDeleteDepartmentModalPanel = renderDeleteDepartmentModalPanel;
	}

	public List<DepartmentUI> getDeletedDepartmentList() {
		return deletedDepartmentList;
	}

	public void setDeletedDepartmentList(
			List<DepartmentUI> deletedDepartmentList) {
		this.deletedDepartmentList = deletedDepartmentList;
	}

	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}

	public String getDepartmentName() {
		return this.departmentName;
	}

	public void setDepartmentName(String name) {
		this.departmentName = name;
	}

	public Integer getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getDepartmentSearchText() {
		return departmentSearchText;
	}

	public void setDepartmentSearchText(String departmentSearchText) {
		this.departmentSearchText = departmentSearchText;
	}

	public void setDepartmentList(List<DepartmentUI> departmentList) {
		this.departmentList = departmentList;
	}

	public IDepartmentService getDepartmentService() {
		return departmentService;
	}

	public void setDepartmentService(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public String getCostCenterNumber() {
		return costCenterNumber;
	}

	public void setCostCenterNumber(String costCenterNumber) {
		this.costCenterNumber = costCenterNumber;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.departmentList = null;
		this.deletedDepartmentList = null;
		this.departmentSearchText = null;
		this.oldSortColumn = null;
		this.allChecked = false;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = 10;
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}
}
