package com.assurant.inc.sox.ar.client.bean;

import com.assurant.inc.sox.ar.client.bean.admin.AdminConsoleBean;
import com.assurant.inc.sox.ar.client.bean.dashboard.ReviewManagementDashboardBean;
import com.assurant.inc.sox.ar.client.bean.review.CreateBundleBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * JSF bean that defines the logic for globally available methods. The normal case is for these methods to be used by the
 * main.xhtml template. Any session scoped JSF beans that must be reset on page exit must be registered (injected into) this bean
 * so that it can be reset when a global action is executed.
 */
@Component("globalActionBean")
@Scope("request")
public class GlobalActionBean {
	private static final Logger log = LoggerFactory.getLogger(GlobalActionBean.class);

	/**
	 * Resets all registered session beans and navigates the user to "dashboard".
	 * 
	 * @return the navigation "dashboard".
	 */
	public String doShowDashboard() {
		log.debug("doShowDashboard() -- enter.");
		ReviewManagementDashboardBean bean = (ReviewManagementDashboardBean) JSFUtils.lookupBean("reviewManagementDashboardBean");
		bean.clear();
		// currently disabled action navigation
		return "dashboard"; 
	}

	/**
	 * Resets all registered session beans and navigates the user to "taskList".
	 * 
	 * @return the navigation "taskList".
	 */
	public String doShowTaskList() {
		log.debug("doShowTaskList() -- enter.");
		
		SessionDataBean bean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
		bean.initSelectedTasklistBean();
		
		return "taskList";
	}

	/**
	 * Resets all registered session beans and navigates the user to "createReview".
	 * 
	 * @return the navigation "createReview".
	 */
	public String doShowCreateReview() {
		log.debug("doShowCreateReview() -- enter.");
		// no bean init is needed for a create review.
		return "createReview";
	}

	/**
	 * Resets all registered session beans and navigates the user to "createBundle".
	 * 
	 * @return the navigation "createBundle".
	 */
	public String doShowCreateBundle() {
		log.debug("doShowCreateBundle() -- enter.");
		CreateBundleBean bean = (CreateBundleBean) JSFUtils.lookupBean("createBundleBean");
		// need to explicitly set these to null to clear out prev session data. Global action will go to page without a
		// preselected review.
		bean.receive(null, null);
		return "createBundle";
	}

	public String doShowAdminConsole() {
		AdminConsoleBean bean = (AdminConsoleBean) JSFUtils.lookupBean("adminConsoleBean");
		return bean.switchToTableMaintenance();
	}
	
	/**
	 * Destroys the current http session.
	 * 
	 * @param context
	 *            the context to destroy the session for.
	 */
	public void destroySession(FacesContext context) {
		HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
		session.invalidate();
	}

	/**
	 * Logs the user out, destorys the current session and navigates the user to the generic log out screen.
	 */
	public void logout() {
		log.debug("logout -- enter.");
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext ec = context.getExternalContext();
		destroySession(context);

		try{
			//log.info("Redirecting to logout : " +ec.getRequestContextPath() + "/logout/logout.html" );
            HttpServletRequest request = (HttpServletRequest) ec.getRequest();
            String url = request.getRequestURL().toString();
            String baseURL = url.substring(0, url.length() - request.getRequestURI().length())+"/logout/logout.html";
			log.debug("Redirecting to Logout url "  + baseURL);

            ec.redirect(baseURL);
		}catch(Exception e){
			log.error("LogOut redirect error: ", e);
		}

		context.responseComplete();
	}

	/**
	 * Navigates the user to the AEB app selection screen with out logging the user out of the system.
	 */
	public void toAEB() {
		log.debug("toAEB -- enter.");
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext ec = context.getExternalContext();

		try{
			ec.redirect("/wps/myportal/ForAEB");
		}catch(IOException e){
			log.debug("toAEB -- an IOException occured.  Eating the error.", e);
		}

		context.responseComplete();
	}
}
