package com.assurant.inc.sox.ar.client.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;

public class WorkOrderUI {

	private final WorkOrderDTO workOrder;
	//Displays the row index numbers of rejected accesses with the given work order number.
	private List<String> accessLineNos;

	public WorkOrderUI() {
		this.workOrder = new WorkOrderDTO(new ReviewWorkOrder(), new CodeDTO(new Code()));
		this.accessLineNos = new ArrayList<>();
	}

	public WorkOrderUI(WorkOrderDTO workOrder) {
		this.workOrder = workOrder;
	}

	public WorkOrderDTO getWorkOrder() {
		return this.workOrder;
	}

	public String getComments() {
		return workOrder.getComments();
	}

	public Date getCreateDate() {
		return workOrder.getCreateDate();
	}

	public String getReasonCode() {
		if(this.workOrder.getReasonCode() != null){
			return this.workOrder.getReasonCode().getDisplay();
		}
		return null;
	}

	public void setComments(String comments) {
		workOrder.setComments(comments);
	}

	public void setCreateDate(Date createDate) {
		workOrder.setCreateDate(createDate);
	}

	
	public void setWorkOrderNumber(Long workOrderNumber) {
		workOrder.setWorkOrderNumber(workOrderNumber);
	}

	public Long getWorkOrderNumber() {
		if(workOrder.getWorkOrderNumber()== null){
			return null;
		}
	  	return workOrder.getWorkOrderNumber();
	  }
	public void setAccessLineNos(List<String> accessLineNos) {
		this.accessLineNos = accessLineNos;
	}

	public List<String> getAccessLineNos() {
		DisplayStringBuilder.buildCommaDelimitedList(this.accessLineNos);
		return accessLineNos;
	}
	public String getDisplayAccessLineNos(){
		return DisplayStringBuilder.buildCommaDelimitedList(this.accessLineNos);
	}
	public Long getWorkOrderId() {
		return workOrder.getWorkOrderId();
	}
	public String getSavvionProcessId() {
		return this.workOrder.getSavvionProcessId();
	}
	public void setSavvionProcessId(String savvionProcessId) {
		this.workOrder.setTaskProcessId(savvionProcessId);
	}
}
