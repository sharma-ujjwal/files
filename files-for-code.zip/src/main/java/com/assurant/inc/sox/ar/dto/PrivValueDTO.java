package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.luad.PrivilegeComment;

public class PrivValueDTO {
    
	private PrivilegeComment privilege = null;
	
	public PrivValueDTO(PrivilegeComment privilege) {
		this.privilege = privilege;
	}	
	
	public PrivValueDTO() {
		this.privilege = new PrivilegeComment();
		
	}
	
	private String name;
    private String id;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }


}
