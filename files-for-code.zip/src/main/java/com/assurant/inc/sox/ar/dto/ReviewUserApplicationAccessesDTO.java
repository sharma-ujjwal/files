package com.assurant.inc.sox.ar.dto;

import java.util.List;

public class ReviewUserApplicationAccessesDTO {

	private ApplicationByUserIdDTO applicationUserIdDTO;
	private List<ReviewUserAccessDTO> accesses;
	private ReviewApplicationDTO reviewApplicationDTO;

	public ReviewUserApplicationAccessesDTO(ApplicationByUserIdDTO applicationUserIdDTO, List<ReviewUserAccessDTO> accesses) {
		this.applicationUserIdDTO = applicationUserIdDTO;
		this.accesses = accesses;
		this.reviewApplicationDTO = createReviewApplicationDTO(accesses);
		
	}

	public ReviewUserApplicationAccessesDTO(ApplicationByUserIdDTO applicationUserIdDTO, List<ReviewUserAccessDTO> accesses,
			ReviewApplicationDTO reviewApplicationDTO) {
		this.applicationUserIdDTO = applicationUserIdDTO;
		this.accesses = accesses;
		this.reviewApplicationDTO = reviewApplicationDTO;
	}

	public List<ReviewUserAccessDTO> getAccesses() {
		return this.accesses;
	}

	public String getApplicationName() {
		return this.applicationUserIdDTO.getApplicationName();
	}

	public ReviewApplicationDTO createReviewApplicationDTO(List<ReviewUserAccessDTO> accessesDomain) {
		ReviewApplicationDTO dto = new ReviewApplicationDTO();
		dto.setComment("");
		ReviewUserAccessDTO reviewUserAccessDTO = accessesDomain.get(0);
		dto.setApplication(reviewUserAccessDTO.getReviewUserAccess().getApplicationSystem().getApplication());
		dto.setReviewUserId(reviewUserAccessDTO.getReviewUserId());
		return dto;
	}

	public String getComment() {
		return reviewApplicationDTO.getComment();
	}

	public void setComment(String comment) {
		reviewApplicationDTO.setComment(comment);
	}

	public ReviewApplicationDTO getReviewApplicationDTO() {
		return reviewApplicationDTO;
	}

	public void setReviewApplicationDTO(ReviewApplicationDTO reviewApplicationDTO) {
		this.reviewApplicationDTO = reviewApplicationDTO;
	}
	
	public String getApplicationUserId(){
		return this.applicationUserIdDTO.getApplicationUserId();
	}	
}
