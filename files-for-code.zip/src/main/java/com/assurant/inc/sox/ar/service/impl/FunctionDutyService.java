/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IFunctionDutyService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IFunctionDutyDao;
import com.assurant.inc.sox.domain.ar.FunctionDuty;

 /**
 * @author RuthSchmalz
 * 
 */
@Service
public class FunctionDutyService implements IFunctionDutyService {

	@Autowired
	private IFunctionDutyDao functionDutyDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public List<FunctionDuty> retrieveAll() {
		return this.functionDutyDao.findAll();
	}
	
	public List<FunctionDuty> retrieveAllByDescription(String description) {
		return this.functionDutyDao.findAllByDescription(description);
	}
	
	public List<FunctionDuty> retrieveDeleted() {
		return this.functionDutyDao.findDeleted();
	}

	public List<FunctionDuty> retrieveDeletedByDescription(String description) {
		return this.functionDutyDao.findDeletedByDescription(description);
	}

	public List<FunctionDuty> retrieveUnassigned() {
		return this.functionDutyDao.findUnassigned();
	}

	public List<FunctionDuty> retrieveUnassignedByDescription(String description) {
		return this.functionDutyDao.findUnassignedByDescription(description);
	}
	public FunctionDuty findDuplicate(String description) {
		return this.functionDutyDao.findDuplicate(description);
	}

	public void add(String functionDutyDescription) {
		Date currentDate = new Date();

		//Create a Function Duty record.
		FunctionDuty functionDuty = new FunctionDuty();
		
		functionDuty.setDescription(functionDutyDescription);
		functionDuty.setDeleteFlag(IFlags.NOT_DELETED);
		functionDuty.setCreatedBy(this.systemUser.getUserId());
		functionDuty.setCreatedDate(currentDate);

		functionDuty.setActiveFromDate(currentDate);
		functionDuty.setActiveToDate(DateUtil.END_OF_TIME); 
		
		this.functionDutyDao.save(functionDuty);
	}

	@Transactional
	public void delete(FunctionDuty functionDuty) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		FunctionDuty currentFunctionDuty = new FunctionDuty();
		currentFunctionDuty.setDescription(functionDuty.getDescription());
		currentFunctionDuty.setDeleteFlag(IFlags.NOT_DELETED);
		currentFunctionDuty.setCreatedBy(functionDuty.getCreatedBy());
		currentFunctionDuty.setCreatedDate(functionDuty.getCreatedDate());
		currentFunctionDuty.setLastChangedBy(this.systemUser.getUserId());
		currentFunctionDuty.setLastChangedDate(currentDate);
		
		currentFunctionDuty.setActiveFromDate(functionDuty.getActiveFromDate());
	 	currentFunctionDuty.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.functionDutyDao.save(currentFunctionDuty);
		
		//Create a Deleted Function Duty record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		functionDuty.setDeleteFlag(IFlags.DELETED);
		functionDuty.setActiveFromDate(currentDate);
		functionDuty.setActiveToDate(currentDate);
		this.functionDutyDao.save(functionDuty);
	}

	public boolean canFunctionDutyBeDeleted(Long id) {
		return this.functionDutyDao.canFunctionDutyBeDeleted(id);
	}
}
