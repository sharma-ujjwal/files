package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import com.assurant.inc.sox.domain.ar.FilterCriteria;

public class FilterCriteriaDTO {

    private final FilterCriteria filterCriteria;
    private FilterCriteriaType filterCriteriaType;

    // private String filterValueDisplay;

    public FilterCriteriaDTO() {
        this(new FilterCriteria());
        
    }

    public FilterCriteriaDTO(FilterCriteria filterCriteria) {
        this.filterCriteria = filterCriteria;
    }

    public FilterCriteria getFilterCriteria() {
        return this.filterCriteria;
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#getFilterCriteriaId()
     */
    public long getFilterCriteriaId() {
        Long id = this.filterCriteria.getId();
        return (id == null) ? 0 : id.longValue();
    }

    public FilterCriteriaType getFilterCriteriaType() {
        return filterCriteriaType;
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#getFilterSeqNumber()
     */
    public long getFilterSeqNumber() {
        return this.filterCriteria.getFilterSeqNumber();
    }

    public String getFilterValueName() {
        return this.filterCriteria.getFilterValueName();
    }

    public void setFilterValueName(String fltrValNm) {
        filterCriteria.setFilterValueName(fltrValNm);
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#getFilterValue()
     */
    public String getFilterValueKey() {
        return this.filterCriteria.getFilterValueKey();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#getReviewBundleId()
     */
    public long getReviewBundleId() {
        Long reviewBundleId = this.filterCriteria.getReviewBundleId();
        return (reviewBundleId == null) ? 0 : reviewBundleId.longValue();
    }

    public void setFilterCriteriaType(FilterCriteriaType filterCriteriaType) {
        this.filterCriteriaType = filterCriteriaType;
    }

    public String getFilterCriteriaTypeValue() {
        if (this.filterCriteriaType == null) {
            this.filterCriteriaType = FilterCriteriaType
                    .getByCodeValue(filterCriteria.getFilterType().getFilterTypeValue());
        }
        return (this.filterCriteriaType == null) ? null : this.filterCriteriaType.getValue();
    }

    /**
     * @param filterSeqNumber
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#setFilterSeqNumber(long)
     */
    public void setFilterSeqNumber(long filterSeqNumber) {
        this.filterCriteria.setFilterSeqNumber(filterSeqNumber);
    }

    /**
     * @param filterValue
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#setFilterValue(java.lang.String)
     */
    public void setFilterValueKey(String filterValueKey) {
        this.filterCriteria.setFilterValueKey(filterValueKey);
    }

    /**
     * @param reviewBundleId
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#setReviewBundleId(long)
     */
    public void setReviewBundleId(long reviewBundleId) {
        this.filterCriteria.setReviewBundleId((reviewBundleId == 0) ? null : (
                reviewBundleId));
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterCriteria#toString()
     */
    @Override
    public String toString() {
        return this.filterCriteria.toString();
    }
}
