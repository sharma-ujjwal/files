package com.assurant.inc.sox.ar.service.base;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.impl.CodeService;
import com.assurant.inc.sox.dao.ar.ICodeDao;
import org.springframework.stereotype.Component;

@Component
public class CodeServiceBase {
	protected static final Logger logger = LoggerFactory.getLogger(CodeService.class);

	@Autowired
	protected ICodeDao codeDao;
	private CacheManager singletonManager = null;

	private Cache soxRefTableCache = null;

	private static final String SOX_REF_TABLE_CACHE_NM = "SoxRefTableCache";
	
	public ICodeDao getCodeDao() {
		return codeDao;
	}

	public void setCodeDao(ICodeDao codeDao) {
		this.codeDao = codeDao;
	}

	/*
	 *  Cache in memory is created
	 *  to hold 5000 elements and with this
	 *  attributes
	 *  name - the name of the cache. "SolarCoveragesCache"
	 *	maxElementsInMemory - the maximum number of elements in memory, before they are evicted
	 *	overflowToDisk - whether to use the disk store - we have set to false
	 *	eternal - whether the elements in the cache are eternal, i.e. never expire - set to false
	 *	timeToLiveSeconds - the default amount of time to live for an element from its creation date, in seconds
	 * 	timeToIdleSeconds - the default amount of time to live for an element from its last accessed or modified date, in seconds
	 *  Also Shutdown Hook is enabled, so when application
	 *  is stopped ,cache elements are cleared and removed
	 */
	@PostConstruct
	public void init() {
		logger.debug("Creating Cache");
		singletonManager = CacheManager.create();
		System.setProperty(CacheManager.ENABLE_SHUTDOWN_HOOK_PROPERTY, Boolean.TRUE.toString());
		soxRefTableCache = new Cache(SOX_REF_TABLE_CACHE_NM, 100, false, false,	86400, 86400);
		singletonManager.addCache(soxRefTableCache);
		logger.debug("Created Cache");
	}

	/*
	 * called as part of spring
	 * destruction cycle, removes
	 * the cache element and
	 * destroys the cache manager.
	 */
	@PreDestroy
	public void destroy() throws Exception {
		logger.debug("Shutting down Cache");
		singletonManager.removeCache(SOX_REF_TABLE_CACHE_NM);
		singletonManager.shutdown();
		logger.debug("Shut down cache complete");
	}

	public Cache getSoxRefTableCache() {
		return soxRefTableCache;
	}

	public void setSoxRefTableCache(Cache soxRefTableCache) {
		this.soxRefTableCache = soxRefTableCache;
	}

}
