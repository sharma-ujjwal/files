package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.ar.ReviewUser;

public class ReviewUserDashboardDTO extends ReviewUserDTO {

	private int accessesCount;
	private int acceptedCount;
	private int rejectedCount;

	public ReviewUserDashboardDTO(ReviewUser reviewUser, CodeDTO rejectCode, CodeDTO completeFlag) {
		super(reviewUser, rejectCode, completeFlag);
	}

	public int getAccessesCount() {
		return accessesCount;
		
	}

	public void setAccessesCount(int accessesCount) {
		this.accessesCount = accessesCount;
	}

	public int getAcceptedCount() {
		return acceptedCount;
	}

	public void setAcceptedCount(int acceptedCount) {
		this.acceptedCount = acceptedCount;
	}

	public int getRejectedCount() {
		return rejectedCount;
	}

	public void setRejectedCount(int rejectedCount) {
		this.rejectedCount = rejectedCount;
	}

	public boolean isUserRejected() {
		return (this.getRejectDate() != null);
	}
}
