package com.assurant.inc.sox.ar.client.bean.tasklist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.component.html.HtmlOutputText;


import com.assurant.inc.sox.ar.client.bean.UserActionRequiredBean;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.tasklist.ActionRequiredTasklistUI;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListField;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListFilterType;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.IUserActionRequiredService;
import com.assurant.inc.sox.ar.service.impl.tasklist.MyTaskListService;
import org.primefaces.component.column.Column;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("rejectedAccessesTaskListBean")
@Scope("session")
public class RejectedAccessesTaskListBean extends
		AbstractLockableTaskListBean<ActionRequiredTasklistUI, ActionRequiredTasklistDTO> implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(RejectedAccessesTaskListBean.class);
	@Autowired
	@Qualifier("myTaskListService")
	private MyTaskListService myTaskListService;
	@Autowired
	@Qualifier("userActionRequiredService")
	private IUserActionRequiredService userActionRequiredService;
	private boolean itCompUser;
	private List<ActionRequiredTasklistDTO> tempList = new ArrayList<ActionRequiredTasklistDTO>();

	public List<ActionRequiredTasklistDTO> myRejectedAccessTaskListBeanResults;

	public List<ActionRequiredTasklistDTO> getMyRejectedAccessTaskListBeanResults() {
		return myRejectedAccessTaskListBeanResults;
	}

	public void setMyRejectedAccessTaskListBeanResults(List<ActionRequiredTasklistDTO> myRejectedAccessTaskListBeanResults) {
		this.myRejectedAccessTaskListBeanResults = myRejectedAccessTaskListBeanResults;
	}

	public RejectedAccessesTaskListBean() {
		super(TaskListFilterType.REVIEW_TYPE, "rejectedAccessesTaskListBean", "rejectedAccessesTaskList");
	}

	// ----------------------------- faces injected properties start ----------------

	public IUserActionRequiredService getUserActionRequiredService() {
		return userActionRequiredService;
	}

	public void setUserActionRequiredService(IUserActionRequiredService userActionRequiredService) {
		this.userActionRequiredService = userActionRequiredService;
	}

	public MyTaskListService getMyTaskListService() {
		return myTaskListService;
	}

	public void setMyTaskListService(MyTaskListService myTaskListService) {
		this.myTaskListService = myTaskListService;
	}

	// ----------------------------- faces injected properties end----------------
	/**
	 * Initializes the user action required bean when an action required task is selected from the list.
	 * @return string navigate to the action required page.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String doWorkTask() {
		logger.debug("doWorkTask() --> being executed.");
		String taskId = JSFUtils.getParameter(WORK_TASK_ACTION_PARAM_NAME);

		String result;
		LockDTO taskLock = this.lockService.getLock(taskId);
		if (taskLock == null) {
			this.lockService.lock(taskId);
			result = this.processTask(null, taskId, null);
		} else if (this.isUserHolder(taskLock)) {
			result = this.processTask(null, taskId, null);
		} else {
			this.prepareLockModalPanel(taskLock, null, taskId);
			result = null;
		}
		return result;
	}

	@Override
	protected String processTask(@SuppressWarnings("unused")
								 String typeCode, String taskId, AbstractTaskListDTO abstractTaskListDTO) {
		// Get the selected action required task.
		ActionRequiredTasklistDTO selectedActionTask = (ActionRequiredTasklistDTO) this.extractSelectedTaskListDTO(taskId, abstractTaskListDTO);
		// Load the user action required bean.
		UserActionRequiredBean bean = (UserActionRequiredBean) JSFUtils.lookupBean("userActionRequiredBean");
		bean.initActionRequired(selectedActionTask, taskId);
		// Navigate to the action required page.
		unloadBean();
		return "actionRequired";
	}

	// -----------------------------Helper Methods Start---------------------------
	/**
	 * Adds column to the task list table.
	 * @param table the task list table.
	 */
	@Override
	@SuppressWarnings("unchecked")
	protected void addTableColumns(DataTable table) {
		logger.debug("addTableColumns() --> being executed.");
		List tableChildren = table.getChildren();
		tableChildren.add(this.buildLockColumn());
		tableChildren.add(this.buildReviewTypeColumn());
		tableChildren.add(this.buildReviewNameColumn());
		tableChildren.add(this.buildTaskCreateDateColumn());
		tableChildren.add(this.buildTaskNameColumn());
		tableChildren.add(this.buildReviewerNameColumn());
		tableChildren.add(this.buildApplicationNameColumn());
		tableChildren.add(this.buildWorkOrderNumbersColumn());
		tableChildren.add(this.buildAssignedToColumn());
	}

	protected Column buildReviewerNameColumn() {
		String fieldName = TaskListField.REVIEWER_NM.getFieldName();
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Reviewer", fieldName, "SortByReviewerLink"),
				HtmlTableBuilderUtil.buildOutputText(this.buildFieldBinding(fieldName)));
	}

	protected Column buildApplicationNameColumn() {
		String fieldName = TaskListField.APP_NAME.getFieldName();
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Application", fieldName, "SortByApplicationLink"),
				HtmlTableBuilderUtil.buildOutputText(this.buildFieldBinding(fieldName)));
	}

	protected Column buildWorkOrderNumbersColumn() {
		String fieldName = TaskListField.WORKORDER_NUMS.getFieldName();
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Work Orders", fieldName, "SortByWorkOrderNumLink"),
				buildOutputText(this.buildFieldBinding(fieldName)));
	}

	private HtmlOutputText buildOutputText(String valueBinding) {
		HtmlOutputText text = new HtmlOutputText();
		text.setEscape(false);
		JSFUtils.setValueBinding(text, "value", valueBinding);
		return text;
	}

	@Override
	protected ActionRequiredTasklistUI buildClientObject(ActionRequiredTasklistDTO dto) {
		dto.setLock(this.lockService.getLock(dto.getTaskId()));
		return new ActionRequiredTasklistUI(dto);
	}

	/**
	 * Populates the rejected accesses task list.
	 * @param values the action required tasks.
	 */
	public void prePopTable(List<ActionRequiredTasklistUI> values) {
		logger.debug("prePopTable() --> being executed.");
		synchronized (this.tempList) {
			List<ActionRequiredTasklistDTO> dtos = new ArrayList<ActionRequiredTasklistDTO>(values.size());
			for (ActionRequiredTasklistUI value : values) {
				dtos.add((ActionRequiredTasklistDTO) value.getTaskList());
			}

			this.tempList.clear();
			this.tempList.addAll(dtos);
		}
	}

	/**
	 * Retrieves the action required tasks on selecting the rejected accesses tab.
	 * @return List<ActionRequiredTasklistDTO> list of action required tasks.
	 */
	@Override
	protected List<ActionRequiredTasklistDTO> retrieveTaskListDTOs() {
		logger.debug("retrieveTaskListDTOs() --> being executed.");
		List<ActionRequiredTasklistDTO> results;
		if (this.sessionDataBean.getSelectedTabId().equals(this.sessionDataBean.getRejectedAccessesTaskTabId())) {
			results = new ArrayList<ActionRequiredTasklistDTO>();
			if (this.itCompUser) {
				synchronized (this.tempList) {
					if (this.tempList.isEmpty()) {
						results.addAll(this.myTaskListService.retrieveActionRequiredTasks());
					} else {
						results.addAll(this.tempList);
						this.tempList.clear();
					}
				}
			}

		} else {
			results = new ArrayList<ActionRequiredTasklistDTO>();
		}

		for (ActionRequiredTasklistDTO result : results) {
			buildClientObject(result);
		}

		String sortField = TaskListField.CREATE_DATE.getFieldName();
		Collections.sort(results, new GenericComparator(sortField, false));
		this.previousSortFieldCodeValue = sortField;

		myRejectedAccessTaskListBeanResults = results;
		return results;
	}

	@Override
	protected void loadBean() {
		logger.debug("loadBean() --> being executed.");
		this.itCompUser = this.sessionDataBean.getSystemUser().isItComplianceUser();
		super.loadBean();
	}

	public void setItCompUser(boolean itCompUser) {
		this.itCompUser = itCompUser;
	}

	/**
	 * Checks if the user is IT compliance user
	 * @return boolean true if it is IT compliance user.
	 */
	public boolean isItCompUser() {
		logger.debug("isItCompUser() --> being executed.");
		synchronized (this.lock) {
			if (!(this.beanLoaded)) {
				this.loadBean();
			}
		}
		return itCompUser;
	}
}
