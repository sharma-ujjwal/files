package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Application;

public class ApplicationDTO {
	

    private final Application application;

    public ApplicationDTO() {
        this(new Application());
    }

    public ApplicationDTO(Application application) {
        this.application = application;
    }

    public Application getApplication() {
        return this.application;
    }

    public Date getActiveFromDate() {
        return this.application.getActiveFromDate();
    }

    public Date getActiveToDate() {
        return this.application.getActiveToDate();
    }

    public Long getId() {
        return this.application.getId();
    }

    public String getName() {
        return this.application.getName();
    }

    public void setActiveFromDate(Date activeFromDate) {
        this.application.setActiveFromDate(activeFromDate);
    }

    public void setActiveToDate(Date activeToDate) {
        this.application.setActiveToDate(activeToDate);
    }

    public void setId(Long id) {
        this.application.setId(id);
    }

    public void setName(String name) {
        this.application.setName(name);
    }

    @Override
    public String toString() {
        return this.application.toString();
    }

}
