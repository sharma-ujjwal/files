package com.assurant.inc.sox.ar.service.tasklist;

import java.util.List;

import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;

public interface IMyTaskListService {
	public List<AbstractTaskListDTO> retrieveItComplianceTasks();
}
