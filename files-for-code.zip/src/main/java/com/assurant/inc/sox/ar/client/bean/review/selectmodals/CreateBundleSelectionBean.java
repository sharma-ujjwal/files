package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import com.assurant.inc.sox.ar.client.bean.review.CreateBundleBean;
import com.assurant.inc.sox.ar.client.bean.review.SelectionBean;
import com.assurant.inc.sox.ar.service.IMetaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * This class is to provide common services and beans to the selection
 * beans for the create bundle page.
 *
 */

@Component
@Scope("session")
public abstract class CreateBundleSelectionBean extends SelectionBean {
    @Autowired
    @Qualifier("metaDataService")
    protected IMetaDataService metaDataService;

    @Autowired
    @Qualifier("createBundleBean")
    protected CreateBundleBean createBundleBean;

    public CreateBundleSelectionBean() {
        super();
    }

    public CreateBundleBean getCreateBundleBean() {
        return createBundleBean;
    }

    public IMetaDataService getMetaDataService() {
        return metaDataService;
    }

    public void setCreateBundleBean(CreateBundleBean createBundleBean) {
        this.createBundleBean = createBundleBean;
    }

    public void setMetaDataService(IMetaDataService metaDataService) {
        this.metaDataService = metaDataService;
    }
}