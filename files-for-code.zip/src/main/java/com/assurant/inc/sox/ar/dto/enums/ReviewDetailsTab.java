package com.assurant.inc.sox.ar.dto.enums;

public enum ReviewDetailsTab {

	PENDING_TAB("pendingTab"), APPROVED_TAB("approvedTab"), DISTRIBUTED_TAB("distributedTab"), REJECTED_TAB("rejectedTab");
	
	private final String tabId;
	
	private ReviewDetailsTab(String tabId){
		this.tabId = tabId;
	}
	
	public String getTabId(){
		return this.tabId;
	}
}
