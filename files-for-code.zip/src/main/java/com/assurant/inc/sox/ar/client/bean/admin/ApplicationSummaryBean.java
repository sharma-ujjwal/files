package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.assurant.inc.sox.ar.client.admin.ui.ApplicationUI;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.domain.ar.Application;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("applicationSummaryBean")
@Scope("session")
public class ApplicationSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(ApplicationSummaryBean.class);
	private List<ApplicationUI> applicationList;
	private List<ApplicationUI> deletedApplicationList = new ArrayList<ApplicationUI>();
	@Autowired
	@Qualifier("applicationService")
	private IApplicationService applicationService;
	private String displayAmount = "10";
	private String oldSortColumn;
	private String applicationName;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String applicationNameSearchText;
	private boolean renderAddApplicationModalPanel;
	private boolean renderDeleteApplicationModalPanel;
	private boolean allChecked;
	private String pageNumber = "1";
	private String lastPageNumber = "1";
	DataScroller dataScroller;

	public List<ApplicationUI> getApplicationList() {
		if (applicationList == null) {
			refreshList();
		}
		return applicationList;
	}

	// ******* Refresh the List RESET button *******
	public void refreshList() {
		this.allChecked = false;

		this.applicationList = new ArrayList<ApplicationUI>();
		List<Application> applicationsRetrieved = new ArrayList<Application>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.applicationNameSearchText)) {
				applicationsRetrieved = this.applicationService
						.retrieveAllApplicationsByName(this.applicationNameSearchText);
			} else {
				applicationsRetrieved = this.applicationService
						.retrieveAllApplications();
			}

		} else if (FilterTableCode.DELETED_ROWS.name()
				.equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.applicationNameSearchText)) {
				applicationsRetrieved = this.applicationService
						.retrieveDeletedApplicationsByName(this.applicationNameSearchText);
			} else {
				applicationsRetrieved = this.applicationService
						.retrieveDeletedApplications();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.applicationNameSearchText)) {
				applicationsRetrieved = this.applicationService
						.retrieveUnassignedByName(this.applicationNameSearchText);
			} else {
				applicationsRetrieved = this.applicationService
						.retrieveUnassignedApplications(); // constructor JSF call
			}

		}
		
		for (Application application : applicationsRetrieved) {
			this.applicationList.add(new ApplicationUI(application));
		}

		this.doSort();
	}

	// ******* GO button *******
	public String goSearch() {
		refreshList();
		return "";
	}

	// ******* RESET button *******
	public String resetSearch() {
		this.applicationList = null;
		this.applicationNameSearchText = null;
		this.applicationNameSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// ******* Filter ListBox *******
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		this.clearSelections();		
		return "";
	}

	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "name";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(applicationList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}

	// ******* Add Application Panel *******
	public String showAddApplicationPanel() {
		this.renderAddApplicationModalPanel = true;
		this.applicationName = "";
		this.clearSelections();
		return null;
	}

	// ******* Add Application Panel CANCEL *******
	public String doCancelSave() {
		logger.debug("doCancelAddApplicationPanel() --> being executed.");
		this.renderAddApplicationModalPanel = false;
		this.clearSelections();
		return null;
	}

	// ******* Add Application Panel SAVE *******
	public String doSave() {
		logger.debug("doSaveAddApplicationPanel() --> being executed.");
		// Displays error message if reason not provided

		if (!validApplicationName()) {
			String message = "Application name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddApplicationModalPanel = true;
			return null;
		}

		this.applicationName = this.applicationName.toUpperCase();

		Application duplicate = this.applicationService.findDuplicate(applicationName);
		if (duplicate != null) {
			String message = "Application name " + applicationName
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		// Add record on the Application table
		applicationService.add(applicationName);

		// Display Message.
		String message = "Added Application " + applicationName;
		JSFUtils.addFacesMessage(message);

		this.renderAddApplicationModalPanel = false;
		return null;
	}

	// ******* Delete Application Panel *******
	public String showDeleteApplicationPanel() {
		this.deletedApplicationList = new ArrayList<ApplicationUI>();
		
		// populate the deleted list with all checked values
		for (ApplicationUI ui : this.applicationList) {
			if (ui.isChecked()) {
				this.deletedApplicationList.add(ui);
			}
		}

		if (this.deletedApplicationList.isEmpty()) {
			JSFUtils.addFacesErrorMessage("Please select at least one application.");
		} else {
			this.renderDeleteApplicationModalPanel = true;
		}

		return null;
	}

	public void doScrollerListener(PageEvent event) {
		logger
				.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked; // toggle true & false

		if (allChecked) {
			int pageSize = Integer.parseInt(displayAmount);
			int intLastPageNumber = Integer.parseInt(lastPageNumber);

			int pageNum;

			//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
			if ("first".equals(pageNumber))
				pageNum = 1;
			else if ("last".equals(pageNumber))
				pageNum = (int) (Math.ceil((double) applicationList.size() / pageSize));
			else if ("next".equals(pageNumber))
				pageNum = intLastPageNumber + 1;
			else if ("previous".equals(pageNumber))
				pageNum = intLastPageNumber - 1;
			else if ("fastforward".equals(pageNumber))
				pageNum = intLastPageNumber + 1;
			else if ("fastrewind".equals(pageNumber))
				pageNum = intLastPageNumber - 1;
			else
				// user pressed a real number
				pageNum = Integer.parseInt(this.pageNumber);

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math.min((firstRow + pageSize), applicationList
					.size());

			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				applicationList.get(currRow).setChecked(true);
			}
		} else {
			for (ApplicationUI applicationUI : this.applicationList) {
				applicationUI.setChecked(false);
			}
		}
	}

	private void clearSelections() {
		this.allChecked = false;
		for (ApplicationUI applicationUI : this.applicationList) {
			applicationUI.setChecked(false);
		}
	}

	public void doDisplayRowListener() {
		logger
				.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	// ******* Delete Application Panel DELETE *******
	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (ApplicationUI ui : this.deletedApplicationList) {
			// first perform a check to ensure that no priv comment record 
			// has the current application assigned before deleting
			if (this.applicationService.canApplicationBeDeleted(ui.getName())) {
				this.applicationService.delete(ui.getApplication());
			} else {
				unableToDelete.add(ui.getName() + " (" + ui.getId() + ")");
			}
		}

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected applications were deleted " +
					"except for the following, which are assigned to at least one " +
					"priv comment record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected applications");
		}

		this.refreshList();
		this.deletedApplicationList = new ArrayList<ApplicationUI>();
		this.renderDeleteApplicationModalPanel = false;
		return null;
	}

	// ******* Delete Application Panel CANCEL *******
	public String doCancelDelete() {
		this.deletedApplicationList = new ArrayList<ApplicationUI>();
		this.renderDeleteApplicationModalPanel = false;
		return null;
	}

	// ******* gets & setters *******
	public boolean validApplicationName() {
		return (StringUtils.isNotEmpty(applicationName));
	}

	public boolean isRenderAddApplicationModalPanel() {
		return renderAddApplicationModalPanel;
	}

	public void setRenderAddApplicationModalPanel(
			boolean renderAddApplicationModalPanel) {
		this.renderAddApplicationModalPanel = renderAddApplicationModalPanel;
	}

	public boolean isRenderDeleteApplicationModalPanel() {
		return renderDeleteApplicationModalPanel;
	}

	public void setRenderDeleteApplicationModalPanel(
			boolean renderDeleteApplicationModalPanel) {
		this.renderDeleteApplicationModalPanel = renderDeleteApplicationModalPanel;
	}

	public List<ApplicationUI> getDeletedApplicationList() {
		return deletedApplicationList;
	}

	public void setDeletedApplicationList(
			List<ApplicationUI> deletedApplicationList) {
		this.deletedApplicationList = deletedApplicationList;
	}

	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}

	public String getApplicationName() {
		return this.applicationName;
	}

	public void setApplicationName(String name) {
		this.applicationName = name;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getApplicationNameSearchText() {
		return applicationNameSearchText;
	}

	public void setApplicationNameSearchText(String applicationNameSearchText) {
		this.applicationNameSearchText = applicationNameSearchText;
	}

	public void setApplicationList(List<ApplicationUI> applicationList) {
		this.applicationList = applicationList;
	}

	public IApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(IApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.applicationList = null;
		this.deletedApplicationList = null;
		this.applicationNameSearchText = null;
		this.oldSortColumn = null;
		this.allChecked = false;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}
