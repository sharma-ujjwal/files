package com.assurant.inc.sox.ar.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.RejectSodBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.enums.ReviewBundleStatusCode;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.base.ReviewBundleServiceBase;
import com.assurant.inc.sox.ar.utils.exceptions.TaskException;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.FilterCriteria;
import com.assurant.inc.sox.domain.ar.FilterType;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.ReviewQueue;

/**
 * Service to perform all business logic associated with the creating, updating, and viewing of the a review bundle
 * 
 * @author BB68602
 * 
 */
@Service
public class ReviewBundleService extends ReviewBundleServiceBase implements IReviewBundleService {

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#createReviewBundle(com.assurant.inc.sox.ar.dto.ReviewBundleDTO, java.util.List)
	 */
	public ReviewBundleDTO createReviewBundle(Long reviewId, List<FilterCriteriaDTO> filterCriteriaDtos) throws TaskException {
		getLogger().debug("createReviewBundle(ReviewBundleDTO, List<FilterCriteria>) --> being executed.");

		ReviewBundle reviewBundle = new ReviewBundle();
		reviewBundle.setReviewId(reviewId);
		reviewBundle.setBundleStatusCode(ReviewBundleStatusCode.SUBMITTED.getCode());

		HashMap<String, Object> dataSlots = new HashMap<String, Object>(3);
		dataSlots.put(ITaskValues.DATASLOTS_SUMMARY_CREATED, Boolean.TRUE);
		String processInstance = getWorkflowService().createProcess(WorkflowTemplateCode.createProcess,
				DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_SUMMARY,
		    ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY, 
		    ITaskValues.PRIORITY_LOW,
		    getSavvionITComplianceUserId(),
		    dataSlots); 
		reviewBundle.setTaskProcessId(processInstance);

		reviewBundle = getReviewBundleDao().save(reviewBundle);

		// add the filter criteria
		Long reviewBundleId = reviewBundle.getId();
		for (FilterCriteriaDTO criteriaDTO : filterCriteriaDtos) {
			FilterCriteria filterCriteria = criteriaDTO.getFilterCriteria();
			final FilterType ft = metaDataService.getFilterTypeByValue(criteriaDTO.getFilterCriteriaType().getValue());
			filterCriteria.setFilterType(ft);
			filterCriteria.setReviewBundleId(reviewBundleId);
			getFilterCriteriaDao().save(filterCriteria);
		}

		ReviewQueue reviewQueue = new ReviewQueue();
		reviewQueue.setReviewBundleId(reviewBundleId);
		ReviewDTO reviewDTO = getReviewService().retrieveReviewById(reviewBundle.getReviewId());
		reviewQueue.setReviewTypeCode(reviewDTO.getReviewTypeCd().getValue());
		reviewQueue.setStatusCode(ReviewQueue.OUTSTANDING_STATUS_CODE);
		getReviewQueueDao().save(reviewQueue);

		return buildDTO(reviewBundle);
	}

	/**
	 * Converts a review bundle into its corresponding DTO.
	 * @param reviewBundle the review bundle to convert.
	 * @return the resulting ReviewBundleDTO.
	 */
	private ReviewBundleDTO buildDTO(ReviewBundle reviewBundle) {
		return new ReviewBundleDTO(reviewBundle, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_BUNDLE_STATUS, reviewBundle
		    .getBundleStatusCode()));
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveById(long)
	 */
	public ReviewBundleDTO retrieveById(Long id) {
		getLogger().debug("retrieveById(long) --> being executed.");
		ReviewBundle bundleFound = getReviewBundleDao().findById(id);
		return (bundleFound == null) ? null : this.buildDTO(bundleFound);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveByReviewId(long)
	 */
	public List<ReviewBundleDTO> retrieveByReviewId(Long reviewId) {
		getLogger().debug("retrieveByReviewId(reviewId) --> being executed.");

		return buildReviewBundleDTOList(getReviewBundleDao().findByReviewId(reviewId));
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveBySavvionId(java.lang.String)
	 */
	public ReviewBundleDTO retrieveBySavvionId(String taskId) {
		getLogger().debug("retrieveBySavvionId(taskId) --> being executed.");

		ReviewBundle bundleFound = getReviewBundleDao().findBySavvionId(taskId);
		return (bundleFound == null) ? null : this.buildDTO(bundleFound);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveFilterCriteria(long)
	 */
	public List<FilterCriteriaDTO> retrieveFilterCriteria(Long reviewBundleId) {
		getLogger().debug("retrieveFilterCriteria(long) --> being executed.");

		return buildFilterCriteriaDTOList(getFilterCriteriaDao().findByReviewBundleId(reviewBundleId));
	}

	/**
	 * Converts a list of review bundles into their corresponding dto. Any bundles marked as rejected will not be converted or added
	 * to the resulting list.
	 * @param reviewBundles the review bundles to convert.
	 * @return the resulting list of review bundle dtos.
	 */
	private List<ReviewBundleDTO> buildReviewBundleDTOList(List<ReviewBundle> reviewBundles) {
		getLogger().debug("buildReviewBundleDTOList(List<ReviewBundle>) --> being executed.");

		List<ReviewBundleDTO> dtos = new ArrayList<ReviewBundleDTO>(reviewBundles.size());
		for (ReviewBundle bundle : reviewBundles) {
			if (!(ReviewBundleStatusCode.REJECTED.getCode().equalsIgnoreCase(bundle.getBundleStatusCode()))) {
				dtos.add(this.buildDTO(bundle));
			}
		}
		return dtos;
	}

	/**
	 * Build a filter criteria dto list
	 * 
	 * @param filterCriterias
	 * @return List<FilterCriteriaDTO>
	 */
	private List<FilterCriteriaDTO> buildFilterCriteriaDTOList(List<FilterCriteria> filterCriterias) {
		getLogger().debug("buildFilterCriteriaDTOList(List<FilterCriteria>) --> being executed.");

		List<FilterCriteriaDTO> dtos = new ArrayList<FilterCriteriaDTO>(filterCriterias.size());
		for (FilterCriteria filterCriteria : filterCriterias) {
			dtos.add(new FilterCriteriaDTO(filterCriteria));
		}
		return dtos;
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#acceptBundleSummary(long)
	 */
	public void acceptBundleSummary(Long reviewBundleId) throws TaskException {
		getLogger().debug("acceptBundleSummary(Long reviewBundleId)--> being executed.");
		ReviewBundle reviewBundle = getReviewBundleDao().findById(reviewBundleId);
		Map<String, Object> dataSlots = new HashMap<String, Object>(3);
		// AEB workflow changes Start 
		dataSlots.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX,ITaskValues.ALL_INSTANCE_NAME_PREFIX_VERIFY);
		String taskProcessId = reviewBundle.getTaskProcessId();
		getWorkflowService().updateProcessDataSlots(taskProcessId, dataSlots);
		
		HashMap<String, Object> newDataSlots = new HashMap<String, Object>(3);
		newDataSlots.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, Boolean.TRUE);
		// AEB workflow changes Start 
		newDataSlots.put("templateCode", TaskTypeCode.getTaskTypeCodeByDataSlotsTemplateCode(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY));
		newDataSlots.put(ITaskValues.PRIORITY, ITaskValues.PRIORITY_HIGH);		
		String processInstance = getWorkflowService().createProcess(WorkflowTemplateCode.createProcess,
				DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_SUMMARY,
		    ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY, 
		    ITaskValues.PRIORITY_LOW,
		    getSavvionITComplianceUserId(),
		    newDataSlots); 
		reviewBundle.setTaskProcessId(processInstance);
		// AEB workflow changes End 
		reviewBundle.setBundleStatusCode(ReviewBundleStatusCode.APPROVED.getCode());
		getReviewBundleDao().save(reviewBundle);
		
		//unlock the task
		this.lockService.unlock(taskProcessId);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#rejectBundleSummary(long)
	 */
	public void rejectBundleSummary(Long reviewBundleId) throws TaskException {
		getLogger().debug("rejectBundleSummary(Long reviewBundleId)--> being executed.");
		rejectBundleSummary(reviewBundleId, ReviewBundleStatusCode.REJECTED.getCode());
	}

	private void rejectBundleSummary(Long reviewBundleId, String rejectStatusCode){
		ReviewBundle reviewBundle = getReviewBundleDao().findById(reviewBundleId);
		Map<String, Object> dataSlots = new HashMap<String, Object>(3);
		dataSlots.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, Boolean.FALSE);
		
		// AEB workflow changes Start
		dataSlots.put(ITaskValues.PRIORITY, ITaskValues.PRIORITY_HIGH);
		dataSlots.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX,ITaskValues.ALL_INSTANCE_NAME_PREFIX_VERIFY);
		// AEB workflow changes  End 
		String taskProcessId = reviewBundle.getTaskProcessId();
		getWorkflowService().updateProcessDataSlots(taskProcessId, dataSlots);
		reviewBundle.setBundleStatusCode(rejectStatusCode);
		getReviewBundleDao().save(reviewBundle);		
	}
	
	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#rejectBundleSummary(long)
	 */
	public void rejectSODBundleSummaryWithNoConflict(Long reviewBundleId) throws TaskException {
		getLogger().debug("rejectSODBundleSummaryWithNoConflict(Long reviewBundleId)--> being executed.");
		rejectBundleSummary(reviewBundleId, ReviewBundleStatusCode.REJECTED_W_NO_CONFLICTS.getCode());
	}	
	
	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveNumberOfReports(java.util.List)
	 */
	public Integer retrieveNumberOfReports(List<Long> reviewBundleIds) {
		getLogger().debug("retrieveNumberOfReports(List<Long> reviewBundleIds) --> being executed.");
		return (getReviewerService().retrieveNumberOfReviewers(reviewBundleIds));
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveBundleName(java.lang.Long)
	 */
	public String retrieveBundleName(Long reviewBundleId) {
		getLogger().debug("retrieveBundleName(Long reviewBundleId)--> being executed.");
		return buildBundleName(reviewBundleId);
	}

	/**
	 * Combines the required fields to build the bundle name.
	 * @param reviewBundleId
	 * @return the bundle name.
	 */
	private String buildBundleName(Long reviewBundleId) {
		getLogger().debug("buildBundleName(reviewBundleId) --> being executed.");

		ReviewBundle bundle = this.reviewBundleDao.findById(reviewBundleId);
		ReviewDTO review = reviewService.retrieveReviewById(bundle.getReviewId());
		return buildBundleName(review.getReviewTypeCd(), bundle.getCreatedDate());
	}

	/**
	 * Builds the bundle name using review type code and create date.
	 * @param reviewTypeCode the type code of the review.
	 * @param bundleCreateDate the create date of the bundle.
	 * @return
	 */
	public static String buildBundleName(CodeDTO reviewTypeCode, Date bundleCreateDate) {
		getLogger().debug("String buildBundleName(ReviewTypeCode reviewTypeCode, Date bundleCreateDate)--> being executed.");
		return reviewTypeCode.getDisplay() + " " + new SimpleDateFormat("yyMMdd-HHmmss").format(bundleCreateDate);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveReviewName(java.lang.Long)
	 */
	public String retrieveReviewName(Long reviewBundleId) {
		getLogger().debug("retrieveReviewName(reviewBundleId) --> being executed.");
		return getReviewDao().findById(getReviewBundleDao().findById(reviewBundleId).getReviewId()).getReviewName();
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewBundleService#retrieveRejectedWithNoConflictsByReviewId(java.lang.Long)
	 */
	public List<RejectSodBundleDTO> retrieveRejectedWithNoConflictsByReviewId(Long reviewId) {
		/*
		 * retrieve bundles that have been rejected with no conflicts
		 */
		List<ReviewBundle> reviewBundles = getReviewBundleDao()
			.findByStatus(reviewId, ReviewBundle.REJECTED_W_NO_CONFLICTS_STATUS_CODE);
		/*
		 * build dtos
		 */
		List<RejectSodBundleDTO> dtos = new ArrayList<RejectSodBundleDTO>(reviewBundles.size());
		for (ReviewBundle reviewBundle : reviewBundles) {
			RejectSodBundleDTO dto = new RejectSodBundleDTO();
			dto.setBunldeName(buildBundleName(reviewBundle.getId()));
			dto.setBundleCreatedDate(reviewBundle.getCreatedDate());
			dto.setFilterCriteriaDtos(retrieveFilterCriteria(reviewBundle.getId()));
			dto.setSodConflictTypeText(retrieveSODConflictType(dto.getFilterCriteriaDtos().get(0).getFilterValueKey()));
			dtos.add(dto);
		}
		
		return dtos;
	}
	
	private String retrieveSODConflictType(String conflictId){
		Conflict conflict = getConflictDao().findById(Long.parseLong(conflictId));
		return conflict.getConflictType().getConflictTypeText();
	}
}
