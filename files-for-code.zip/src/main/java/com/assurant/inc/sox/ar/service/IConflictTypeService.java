package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.ConflictType;

public interface IConflictTypeService {
	
	public List<ConflictType> retrieveAllConflictTypes();
	public List<ConflictType> retrieveAllConflictTypesByName(String conflictTypeNameSearchText);
	public List<ConflictType> retrieveDeletedConflictTypes();
	public List<ConflictType> retrieveDeletedConflictTypesByName(String conflictTypeNameSearchText); 
	public Long add(String conflictTypeName, String conflictTypeCode);
	public ConflictType getById(Long id);
}
