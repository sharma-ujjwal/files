/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.service.IConflictService;
import com.assurant.inc.sox.dao.ar.IConflictDao;
import com.assurant.inc.sox.domain.ar.Conflict;

 /**
 * @author RuthSchmalz
 * 
 */
@Service
public class ConflictService implements IConflictService {

	@Autowired
	private IConflictDao conflictDao;
	
	public ConflictService() {
	}

	public List<Conflict> retrieveAllConflicts() {
		return this.conflictDao.findAll();
	}
	
	public List<Conflict> retrieveAllConflictsByName(String leftConflictSearchText, String rightConflictSearchText) {
		return this.conflictDao.findAllByName(leftConflictSearchText, rightConflictSearchText);
	}
	
	public List<Conflict> retrieveDeletedConflicts() {
		return this.conflictDao.findDeleted();
	}
	
	public List<Conflict> retrieveDeletedConflictsByName(String leftConflictSearchText, String rightConflictSearchText) {
		return this.conflictDao.findDeletedByName(leftConflictSearchText, rightConflictSearchText);
	}
}
