package com.assurant.inc.sox.ar.service.base;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.ar.service.impl.ReviewUserService;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import org.springframework.stereotype.Component;

@Component
public class ReviewUserServiceBase {

	@Autowired
	protected IReviewUserDao reviewUserDao = null;
	@Autowired
	protected IUserDao userDao;
	@Autowired
	protected IReviewUserAccessDao reviewUserAccessDao;
	
	@Resource(name = "savvionITComplianceUserId")
	@Autowired
	protected String savvionITComplianceUserId;
	@Autowired
	protected IWorkflowService workflowService=null;
	
	@Autowired
	protected IReviewerDao reviewerDao = null;
	@Autowired
	protected ICodeService codeService;

	protected static final Logger logger = LoggerFactory.getLogger(ReviewUserService.class);

	public static Logger getLogger() {
		return logger;
	}

	public IReviewUserDao getReviewUserDao() {
		return this.reviewUserDao;
	}

	public void setReviewUserDao(IReviewUserDao reviewUserDao) {
		this.reviewUserDao = reviewUserDao;
	}

	public IUserDao getUserDao() {
		return this.userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	public String getSavvionITComplianceUserId() {
		return savvionITComplianceUserId;
	}

	public void setSavvionITComplianceUserId(String savvionITComplianceUserId) {
		this.savvionITComplianceUserId = savvionITComplianceUserId;
	}

	public IReviewUserAccessDao getReviewUserAccessDao() {
		return reviewUserAccessDao;
	}

	public void setReviewUserAccessDao(IReviewUserAccessDao reviewUserAccessDao) {
		this.reviewUserAccessDao = reviewUserAccessDao;
	}

	public IReviewerDao getReviewerDao() {
		return reviewerDao;
	}

	public void setReviewerDao(IReviewerDao reviewerDao) {
		this.reviewerDao = reviewerDao;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

}
