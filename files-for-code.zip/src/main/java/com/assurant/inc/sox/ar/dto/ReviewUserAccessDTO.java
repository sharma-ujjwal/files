package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessKeepRemoveFlag;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.SoxConcern;

public class ReviewUserAccessDTO {

	private final ReviewUserAccess reviewUserAccess;
	private CodeDTO status;
	private boolean dirtyFlag;

	public ReviewUserAccessDTO(ReviewUserAccess reviewUserAccess, CodeDTO status) {
		this.reviewUserAccess = reviewUserAccess;
		this.status = status;
	}

	public ReviewUserAccess getReviewUserAccess() {
		return reviewUserAccess;
		
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getReviewUserAccessId()
	 */
	public Long getReviewUserAccessId() {
		return this.reviewUserAccess.getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getActiveFromDate()
	 */
	public Date getActiveFromDate() {
		return this.reviewUserAccess.getActiveFromDate();
	}

	/**
	 * @param activeFromDate
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setActiveFromDate(java.util.Date)
	 */
	public void setActiveFromDate(Date activeFromDate) {
		this.reviewUserAccess.setActiveFromDate(activeFromDate);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getActiveToDate()
	 */
	public Date getActiveToDate() {
		return this.reviewUserAccess.getActiveToDate();
	}

	/**
	 * @param activeToDate
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setActiveToDate(java.util.Date)
	 */
	public void setActiveToDate(Date activeToDate) {
		this.reviewUserAccess.setActiveToDate(activeToDate);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getApplicationId()
	 */
	public Long getApplicationId() {
		return this.reviewUserAccess.getApplicationSystem().getApplication().getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getApplicationName()
	 */
	public String getApplicationName() {
		return this.reviewUserAccess.getApplicationSystem().getApplication().getName();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getCreatedBy()
	 */
	public String getCreatedBy() {
		return this.reviewUserAccess.getCreatedBy();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getCreatedDate()
	 */
	public Date getCreatedDate() {
		return this.reviewUserAccess.getCreatedDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getFunctionDutyId()
	 */
	public Long getFunctionDutyId() {
		return this.reviewUserAccess.getFunctionDutyId();
	}

	/**
	 * @param functionDutyId
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setFunctionDutyId(Long)
	 */
	public void setFunctionDutyId(Long functionDutyId) {
		this.reviewUserAccess.setFunctionDutyId(functionDutyId);
	}

	public ReviewUserAccessKeepRemoveFlag getKeepRemoveFlag() {
		return ReviewUserAccessKeepRemoveFlag.getByFlagValue(this.reviewUserAccess.getKeepRemoveFlg());
	}

	public String getKeepRemoveString() {
		return this.reviewUserAccess.getKeepRemoveFlg();
	}

	public void setKeepRemoveString(String str) {
		String oldValue = this.reviewUserAccess.getKeepRemoveFlg();
		if (!str.equals(oldValue)) {
			this.dirtyFlag = true;
		}
		this.reviewUserAccess.setKeepRemoveFlg(str);
	}

	public void setKeepRemoveFlag(ReviewUserAccessKeepRemoveFlag keepRemoveFlg) {
		this.setKeepRemoveString(keepRemoveFlg.getFlagValue());
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getPrivilegeComment()
	 */
	public String getPrivilegeComment() {
		return this.reviewUserAccess.getPrivilegeComment();
	}

	/**
	 * @param privilegeComment
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setPrivilegeComment(java.lang.String)
	 */
	public void setPrivilegeComment(String privilegeComment) {
		this.reviewUserAccess.setPrivilegeComment(privilegeComment);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getPrivilegeDescription()
	 */
	public String getPrivilegeDescription() {
		return this.reviewUserAccess.getPrivilegeDescription();
	}

	/**
	 * @param privilegeDescription
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setPrivilegeDescription(java.lang.String)
	 */
	public void setPrivilegeDescription(String privilegeDescription) {
		this.reviewUserAccess.setPrivilegeDescription(privilegeDescription);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getPrivilegeValue()
	 */
	public String getPrivilegeValue() {
		return this.reviewUserAccess.getPrivilegeValue();
	}

	/**
	 * @param privilegeValue
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setPrivilegeValue(java.lang.String)
	 */
	public void setPrivilegeValue(String privilegeValue) {
		this.reviewUserAccess.setPrivilegeValue(privilegeValue);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getReviewUserAccessComment()
	 */
	public String getReviewUserAccessComment() {
		return this.reviewUserAccess.getReviewUserAccessComment();
	}

	/**
	 * @param reviewUserAccessComment
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setReviewUserAccessComment(java.lang.String)
	 */
	public void setReviewUserAccessComment(String reviewUserAccessComment) {
		this.reviewUserAccess.setReviewUserAccessComment(reviewUserAccessComment);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getReviewUserId()
	 */
	public Long getReviewUserId() {
		return this.reviewUserAccess.getReviewUserId();
	}

	/**
	 * @param reviewUserId
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setReviewUserId(Long)
	 */
	public void setReviewUserId(Long reviewUserId) {
		this.reviewUserAccess.setReviewUserId(reviewUserId);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getSourceName()
	 */
	public String getSourceName() {
		return this.reviewUserAccess.getSourceName();
	}

	/**
	 * @param sourceName
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#setSourceName(java.lang.String)
	 */
	public void setSourceName(String sourceName) {
		this.reviewUserAccess.setSourceName(sourceName);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getSystemId()
	 */
	public Long getSystemId() {
		return this.reviewUserAccess.getApplicationSystem().getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#getSystemName()
	 */
	public String getSystemName() {
		return this.reviewUserAccess.getApplicationSystem().getName();
	}

	public SoxConcern getSoxConcern() {
		return this.reviewUserAccess.getSoxConcern();
	}
	
	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUserAccess#toString()
	 */
	@Override
	public String toString() {
		return this.reviewUserAccess.toString();
	}

	public String getApplicationUserId() {
		return reviewUserAccess.getUserId();
	}

	public boolean isDirtyFlag() {
		return dirtyFlag;
	}

	public String getUserKeyId() {
		return reviewUserAccess.getUserKeyId();
	}

	public void setUserKeyId(String userKeyId) {
		reviewUserAccess.setUserKeyId(userKeyId);
	}

	public Date getCompleteDate() {
		return reviewUserAccess.getValidationCompleteDate();
	}

	public CodeDTO getStatus() {
		return this.status;
	}

	public void setStatus(CodeDTO status) {
		this.status = status;
	}

}
