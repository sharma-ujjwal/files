package com.assurant.inc.sox.ar.client.bean.reviewdetails;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandLink;
import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;


import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.review.CreateBundleBean;
import com.assurant.inc.sox.ar.client.bean.review.CreateReviewBean;
import com.assurant.inc.sox.ar.client.bean.reviewerreport.EmployeeListBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.FilterCriteriaUI;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.client.ui.UserDataUI;
import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.enums.EmployeeListMode;
import com.assurant.inc.sox.ar.dto.enums.ReviewDetailsTab;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerField;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.impl.InactiveReassignReviewerException;
import com.assurant.inc.sox.ar.service.impl.ReviewBundleService;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * JSF bean for the reviewDetailsPage.xhtml.
 *
 */
@Component("reviewDetailsBean")
@Scope("session")
public class ReviewDetailsBean {
	private static final Logger logger = LoggerFactory
			.getLogger(ReviewDetailsBean.class);
	private static final String SORT_ACTION_PARAM_NAME = "actionSortFieldName";
	private static final String STATUS_ACTION_PARAM_NAME = "actionStatusCodeValue";
	private static final String REVIEWER_ID_ACTION_PARAM_NAME = "actionReviewerId";

	private static final int MAX_REJECT_COMMENT_LENGTH = 100;
	private static final int MAX_REASSIGN_COMMENT_LENGTH = 100;
	private static final int MAX_REASSIGN_INSTRUC_LENGTH = 2000;

	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;

	private ReviewUI review;
	private List<ReviewBundleUI> reviewBundles;

	private String previousPendingSortFieldCodeValue;
	private String previousApprovedSortFieldCodeValue;
	private String previousDistributedSortFieldCodeValue;
	private String previousRejectedSortFieldCodeValue;

	private DataTable pendingTable;
	private DataTable approvedTable;
	private DataTable distributedTable;
	private DataTable rejectedTable;

	private ArrayList<SelectItem> availableReassignReviewerSelectItems;
	private ArrayList<UserDataUI> availableReassignReviewers;
	private Long selectedReassignUser;
	private ReviewerUI selectedReassignReviewer;
	private List<ReviewerUI> selectedReassignReviewers;

	private List<ReviewerUI> selectedReviewers;

	private boolean renderEditReviewCommentsModalPanel;
	private boolean renderReassignReviewerModalPanel;
	private boolean renderReassignSODReviewersModalPanel;
	private boolean renderRejectReviewerModalPanel;
	private boolean renderDistributeReviewerModalPanel;

	private String commentsInput;
	private Date targetCompDate;
	private String selectReasonInput;
	private String selectedTabId;

	private boolean renderCompleteTaskButton;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;

	private List<FilterCriteriaUI> filterCriteriaValues;
	private String filterCriteriaText;
	@Autowired
	@Qualifier("reviewBundleService")
	private ReviewBundleService reviewBundleService;

	// -------------------------- Faces Injected Properties -------------------
	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	// -------------------------- Page Properties -----------------------------

	public String getPendingTabId() {
		return ReviewDetailsTab.PENDING_TAB.getTabId();
	}

	public String getApprovedTabId() {
		return ReviewDetailsTab.APPROVED_TAB.getTabId();
	}

	public String getDistributedTabId() {
		return ReviewDetailsTab.DISTRIBUTED_TAB.getTabId();
	}

	public String getRejectedTabId() {
		return ReviewDetailsTab.REJECTED_TAB.getTabId();
	}

	public String getSelectedTabId() {
		return selectedTabId;
	}

	public void setSelectedTabId(
			@SuppressWarnings("unused") String selectedTabId) {
		// stubbed out for JSF
	}

	public DataTable getPendingTable() {
		return pendingTable;
	}

	public void setPendingTable(DataTable pendingTable) {
		this.pendingTable = pendingTable;
	}

	public DataTable getApprovedTable() {
		return approvedTable;
	}

	public void setApprovedTable(DataTable approvedTable) {
		this.approvedTable = approvedTable;
	}

	public DataTable getDistributedTable() {
		return distributedTable;
	}

	public void setDistributedTable(DataTable distributedTable) {
		this.distributedTable = distributedTable;
	}

	public DataTable getRejectedTable() {
		return rejectedTable;
	}

	public void setRejectedTable(DataTable rejectedTable) {
		this.rejectedTable = rejectedTable;
	}

	public ReviewUI getReview() {
		return review;
	}

	public String getActionSourceParamName() {
		return STATUS_ACTION_PARAM_NAME;
	}

	public String getPendingParam() {
		return ReviewerStatusCode.PENDING.getCode();
	}

	public String getApprovedParam() {
		return ReviewerStatusCode.APPROVED.getCode();
	}

	public String getPendingDisplayAmount() {
		return String.valueOf(this.pendingTable.getRows());
	}

	public void setPendingDisplayAmount(String displayAmount) {
		int rows = Integer.valueOf(displayAmount).intValue();
		if (this.pendingTable.getRows() != rows) {
			this.clearSelections();
		}
		this.pendingTable.setRows(rows);
	}

	public String getApprovedDisplayAmount() {
		return String.valueOf(this.approvedTable.getRows());
	}

	public void setApprovedDisplayAmount(String displayAmount) {
		int rows = Integer.valueOf(displayAmount).intValue();
		if (rows != this.approvedTable.getRows()) {
			this.clearSelections();
		}
		this.approvedTable.setRows(rows);
	}

	public String getDistributedDisplayAmount() {
		return String.valueOf(this.distributedTable.getRows());
	}

	public void setDistributedDisplayAmount(String displayAmount) {
		int rows = Integer.valueOf(displayAmount).intValue();
		if (rows != this.distributedTable.getRows()) {
			this.clearSelections();
		}
		this.distributedTable.setRows(rows);
	}

	public String getRejectedDisplayAmount() {
		return String.valueOf(this.rejectedTable.getRows());
	}

	public void setRejectedDisplayAmount(String displayAmount) {
		int rows = Integer.valueOf(displayAmount).intValue();
		if (rows != this.rejectedTable.getRows()) {
			this.clearSelections();
		}
		this.rejectedTable.setRows(rows);
	}

	public String getCommentsInput() {
		return commentsInput;
	}

	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	public Date getTargetCompDate() {
		return targetCompDate;
	}

	public void setTargetCompDate(Date targetCompDate) {
		this.targetCompDate = targetCompDate;
	}

	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	@SuppressWarnings("unchecked")
	public long getTotalNumberOfReports() {
		logger.debug("getTotalNumberOfReports() --> being executed.");
		long count = 0;
		List reviewers = this.extractReviewerList(this.pendingTable);
		count = count + reviewers.size();
		reviewers = this.extractReviewerList(this.approvedTable);
		count = count + reviewers.size();
		reviewers = this.extractReviewerList(this.distributedTable);
		count = count + reviewers.size();
		reviewers = this.extractReviewerList(this.rejectedTable);
		count = count + reviewers.size();
		return count;
	}

	// -------------------------- Page Actions --------------------------------

	/**
	 * Switches to the Pending tab.
	 *
	 * @return null to return to same page.
	 */
	public String doPendingTabSwitch() {
		logger.debug("doPendingTabSwitch() --> being executed.");
		this.selectedTabId = ReviewDetailsTab.PENDING_TAB.getTabId();
		return null;
	}

	/**
	 * Switches to the Approved tab.
	 *
	 * @return null to return to same page.
	 */
	public String doApprovedTabSwitch() {
		logger.debug("doApprovedTabSwitch() --> being executed.");
		this.selectedTabId = ReviewDetailsTab.APPROVED_TAB.getTabId();
		return null;
	}

	/**
	 * Switches to the distributed tab.
	 *
	 * @return null to return to same page.
	 */
	public String doDistributedTabSwitch() {
		logger.debug("doDistributedTabSwitch() --> being executed.");
		this.selectedTabId = ReviewDetailsTab.DISTRIBUTED_TAB.getTabId();
		return null;
	}

	/**
	 * Switches to the Rejected tab.
	 *
	 * @return null to return to same page.
	 */
	public String doRejectedTabSwitch() {
		logger.debug("doRejectedTabSwitch() --> being executed.");
		this.selectedTabId = ReviewDetailsTab.REJECTED_TAB.getTabId();
		return null;
	}

	/**
	 * Prepares the Edit review comment Panel.
	 *
	 * @return null to return to same page.
	 */
	public String doPrepareEditReviewCommentPanel() {
		logger.debug("doPrepareEditReviewCommentPanel() --> being executed.");
		this.commentsInput = this.review.getComments();
		this.renderEditReviewCommentsModalPanel = true;
		return null;
	}

	/**
	 * Performs the update to save the review comment onto the current review.
	 *
	 * @return null to navigate to the same page.
	 */
	public String doSaveEditReviewCommentsPanel() {
		logger.debug("doSaveEditReviewCommentsPanel() --> being executed.");
		if ((this.commentsInput != null)
				&& (this.commentsInput.length() > CreateReviewBean.COMMENT_MAXSIZE)) {
			JSFUtils.addFacesErrorMessage("Commment may not be longer than "
					+ CreateReviewBean.COMMENT_MAXSIZE
					+ "characters, is currently " + this.commentsInput.length()
					+ "characters.");
			return null;
		}

		this.review.setComments(this.commentsInput);
		this.review = new ReviewUI(this.reviewService.updateReview(this.review
				.getReview()));
		this.renderEditReviewCommentsModalPanel = false;
		return null;
	}

	/**
	 * Cancels the edit of the review comments.
	 *
	 * @return null to navigate to the same page.
	 */
	public String doCancelEditReviewCommentsPanel() {
		logger.debug("doCancelEditReviewCommentsPanel() --> being executed.");
		this.renderEditReviewCommentsModalPanel = false;
		return null;
	}

	/**
	 * Sorts the table for the specified field.
	 *
	 * @return null to navigate to the same page.
	 */
	public String doSortByField() {
		logger.debug("doSortByField() --> being executed.");
		String sortFieldCodeValue = JSFUtils
				.getParameter(SORT_ACTION_PARAM_NAME);
		String statusCodeParam = JSFUtils
				.getParameter(STATUS_ACTION_PARAM_NAME);
		if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper
					.sortListByField(this.approvedTable, sortFieldCodeValue,
							this.previousApprovedSortFieldCodeValue);
			this.previousApprovedSortFieldCodeValue = sortFieldCodeValue;
		} else if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper.sortListByField(this.pendingTable,
					sortFieldCodeValue, this.previousPendingSortFieldCodeValue);
			this.previousPendingSortFieldCodeValue = sortFieldCodeValue;
		} else if (ReviewerStatusCode.RELEASED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper.sortListByField(this.distributedTable,
					sortFieldCodeValue,
					this.previousDistributedSortFieldCodeValue);
			this.previousDistributedSortFieldCodeValue = sortFieldCodeValue;
		} else if (ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper
					.sortListByField(this.rejectedTable, sortFieldCodeValue,
							this.previousRejectedSortFieldCodeValue);
			this.previousRejectedSortFieldCodeValue = sortFieldCodeValue;
		}

		this.clearSelections();
		return null;
	}

	/**
	 * Selects current page of reviewers and cancels any selected item.
	 *
	 * @return null to navigate to the same page.
	 */
	public String doSelectAllToggle() {
		logger.debug("doSelectAllToggle() --> being executed.");
		String statusCodeParam = JSFUtils
				.getParameter(STATUS_ACTION_PARAM_NAME);
		if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper
					.selectPagedTableAllToggle(this.approvedTable);
		} else if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper.selectPagedTableAllToggle(this.pendingTable);
		} else if (ReviewerStatusCode.RELEASED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper
					.selectPagedTableAllToggle(this.distributedTable);
		} else if (ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(
				statusCodeParam)) {
			CommonPageActionHelper
					.selectPagedTableAllToggle(this.rejectedTable);
		}

		return null;
	}

	/**
	 * To view the reviewer details for a given reviewer.
	 *
	 * @return String navigate to the employee list page.
	 */
	public String doViewReviewerDetails() {
		logger.debug("doViewReviewerDetails() --> being executed.");
		String reviewerParam = JSFUtils
				.getParameter(REVIEWER_ID_ACTION_PARAM_NAME);
		String status = JSFUtils.getParameter(STATUS_ACTION_PARAM_NAME);
		DataTable table = this.getTableByStatus(status);
		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		Long reviewerId = Long.parseLong(reviewerParam);
		ReviewerUI selectedReviewer = null;
		for (ReviewerUI reviewer : reviewers) {
			if (reviewerId.equals(reviewer.getReviewerId())) {
				selectedReviewer = reviewer;
				break;
			}
		}

		if (selectedReviewer == null) {
			throw new RuntimeException(
					"An invalid reviewer id was found.  Id: " + reviewerParam);
		}

		Long bundleId = selectedReviewer.getReviewBundleId();
		ReviewBundleUI selectedBundle = null;
		for (ReviewBundleUI bundle : this.reviewBundles) {
			if (bundleId.equals(bundle.getReviewBundleId())) {
				selectedBundle = bundle;
				break;
			}
		}

		EmployeeListBean bean = (EmployeeListBean) JSFUtils
				.lookupBean("employeeListBean");
		// loads employee list bean. Passed null savvion id as no review users
		// attest process required here.
		bean.initEmployeeList(this.review, selectedBundle, selectedReviewer,
				EmployeeListMode.SCHEDULE_REVIEWS, null);
		return "employeeList";
	}

	/**
	 * Creates bundle for a given review.
	 *
	 * @return String navigate to create bundle page.
	 */
	public String doCreateBundle() {
		logger.debug("doCreateBundle() --> being executed.");
		CreateBundleBean bean = (CreateBundleBean) JSFUtils
				.lookupBean("createBundleBean");
		bean.receive(null, review);
		return "createBundle";
	}

	/**
	 * Approves the selected reviewers from the table.
	 *
	 * @return null navigate to same page.
	 */
	public String doApproveReviewers() {
		logger.debug("doApproveReviewers() --> being executed.");
		List<ReviewerUI> reviewers;
		try {
			reviewers = this.extractSelectedReviewers(this.pendingTable);
		} catch (InvalidiReviewerSelectionException e) {
			JSFUtils
					.addFacesErrorMessage("An invalid number of reviewers were selected.  At least one reviewer must be selected to preform an approval.");
			return null;
		}

		this.reviewerService.approveReviewers(this.unWrapReviewers(reviewers));

		this.removeFromTable(this.pendingTable, reviewers);
		this.refreshTable(ReviewerStatusCode.APPROVED);

		return null;
	}

	public String doPrepareReassignReviewersPanel() {
		return (this.review.isSODReview()) ? this
				.doPrepareReassignReviewersSODPanel() : this
				.doPrepareReassignReviewersNonSODPanel();
	}

	/**
	 * Prepares the reassign reviewer panel.
	 *
	 * @return null navigate to the same page.
	 */
	private String doPrepareReassignReviewersNonSODPanel() {
		logger.debug("doPrepareReassignReviewersPanel() --> being executed.");
		ReviewerUI selectedReviewer;
		try {
			String actionSource = JSFUtils
					.getParameter(STATUS_ACTION_PARAM_NAME);
			if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(
					actionSource)) {
				selectedReviewer = this
						.extractSelectedReassignReviewer(this.pendingTable);
			} else if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(
					actionSource)) {
				selectedReviewer = this
						.extractSelectedReassignReviewer(this.approvedTable);
			} else {
				throw new RuntimeException(
						"Unexpected action source was found for prepare for reassign reviewer.  Source value: "
								+ actionSource);
			}
		} catch (InvalidiReviewerSelectionException e) {
			JSFUtils
					.addFacesErrorMessage("An invalid number of reviewers were selected.  Exactly one reviewer must be selected to perform a reassignment.");
			this.renderReassignReviewerModalPanel = false;
			return null;
		}

		String typeCodeValue = this.review.getReview().getReviewTypeCd()
				.getValue();
		List<UserDataDTO> availableReviewers;
		boolean inactiveFound = false;
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(typeCodeValue)) {
			// if manager type review then only allow supervisor to reassign to.
			availableReviewers = this.reviewerService
					.getManagerReviewAvailableReassignReviewers(selectedReviewer
							.getUserId());
		} else {
			// retrieve all of the data owners that are able to be reassigned to
			// for the given
			// application.
			Long applicationId = selectedReviewer.getReviewer()
					.getApplicationId();

			try {
				availableReviewers = this.reviewerService
						.getDataOwnerReviewAvailableReassignReviewers(
								applicationId, selectedReviewer.getUserId());
			} catch (InactiveReassignReviewerException e) {
				availableReviewers = e.getInactiveUsers();
				inactiveFound = true;
			}
		}

		if (inactiveFound) {
			StringBuilder sb = new StringBuilder();
			sb
					.append("An inactive reassign reviewer was found.  The user record must be corrected before continuing: ");
			for (UserDataDTO user : availableReviewers) {
				sb.append(user.getName());
				sb.append(" - ");
				sb.append(user.getUserId());
				sb.append("; ");
			}
			JSFUtils.addFacesErrorMessage(sb.toString());
			availableReviewers.clear();
		} else if (availableReviewers.isEmpty()) {
			JSFUtils
					.addFacesErrorMessage("No reassignable reviewers were found.");
		}

		this.setReassignReviewers(availableReviewers);
		this.renderReassignReviewerModalPanel = true;
		this.selectedReassignUser = null;
		this.selectedReassignReviewer = selectedReviewer;
		this.commentsInput = null;
		this.selectReasonInput = null;

		return null;
	}

	/**
	 * Prepares the reassign reviewer panel.
	 *
	 * @return null navigate to the same page.
	 */
	private String doPrepareReassignReviewersSODPanel() {
		logger.debug("doPrepareReassignReviewersPanel() --> being executed.");
		List<ReviewerUI> reviewers;
		try {
			String actionSource = JSFUtils
					.getParameter(STATUS_ACTION_PARAM_NAME);
			if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(
					actionSource)) {
				reviewers = this
						.extractSelectedSODReassignReviewer(this.pendingTable);
			} else if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(
					actionSource)) {
				reviewers = this
						.extractSelectedSODReassignReviewer(this.approvedTable);
			} else {
				throw new RuntimeException(
						"Unexpected action source was found for prepare for reassign reviewer.  Source value: "
								+ actionSource);
			}
		} catch (InvalidiReviewerSelectionException e) {
			JSFUtils.addFacesErrorMessage(e.getMessage());
			this.renderReassignSODReviewersModalPanel = false;
			return null;
		}

		List<UserDataDTO> availableReviewers;
		try {
			// Modified for Tkt - 1887508 - SOX Prod Issue - SOD Review
			availableReviewers = this.reviewerService
					.getSODAvailableReassignReviewers(reviewers.get(0)
							.getReviewer().getConflict(), reviewers.get(0)
							.getReviewer().getUserId());

			if (availableReviewers == null) {
				availableReviewers = this.reviewerService
						.getDataOwnerReviewAvailableReassignReviewers(reviewers
										.get(0).getReviewer().getApplicationId(),
								reviewers.get(0).getReviewer().getUserId());
			}
		} catch (InactiveReassignReviewerException e) {
			availableReviewers = e.getInactiveUsers();
			StringBuilder sb = new StringBuilder();
			sb
					.append("An inactive reassign reviewer was found.  The user record must be corrected before continuing: ");
			for (UserDataDTO user : availableReviewers) {
				sb.append(user.getName());
				sb.append(" - ");
				sb.append(user.getUserId());
				sb.append("; ");
			}
			JSFUtils.addFacesErrorMessage(sb.toString());
		}

		if (availableReviewers.isEmpty()) {
			JSFUtils
					.addFacesErrorMessage("No reassignable reviewers were found.");
		}

		this.setReassignReviewers(availableReviewers);
		this.renderReassignSODReviewersModalPanel = true;
		this.selectedReassignUser = null;
		this.selectedReassignReviewers = reviewers;
		this.commentsInput = null;
		this.selectReasonInput = null;

		return null;
	}

	public String doSaveReassignReviewersPanel() {
		return (this.review.isSODReview()) ? this
				.doSaveReassignSODReviewersPanel() : this
				.doSaveReassignNonSODReviewersPanel();
	}

	/**
	 * Performs the actual reassignment if the input data is valid.
	 *
	 * @return null to navigate back to the same page.
	 */
	private String doSaveReassignNonSODReviewersPanel() {
		logger.debug("doSaveReassignReviewersPanel() --> being executed.");

		if (this.selectedReassignUser == null) {
			// if a data owner review then a data owner must have been selected.
			JSFUtils.addFacesErrorMessage("A reviewer must be selected.");
		} else if (StringUtils.isBlank(this.selectReasonInput)) {
			// a reason must be selected to do a reassign
			JSFUtils
					.addFacesErrorMessage("A reason must be selected to perform a reassignment.");
		} else if (StringUtils.isNotBlank(this.commentsInput)
				&& this.commentsInput.length() > MAX_REASSIGN_COMMENT_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a reject comment is "
							+ MAX_REASSIGN_COMMENT_LENGTH);
		} else {

			UserDataUI newReassignUser = null;

			Long selectedDataOwnerId = this.selectedReassignUser;
			for (UserDataUI user : this.availableReassignReviewers) {
				if (selectedDataOwnerId.equals(user.getUserId())) {
					newReassignUser = user;
					break;
				}
			}

			if (newReassignUser == null) {
				throw new RuntimeException(
						"An invalid user id was found for the selected data owner.  Id = "
								+ selectedDataOwnerId);
			}

			this.renderReassignReviewerModalPanel = false;
			this.reviewerService.reassignReviewer(this.selectedReassignReviewer
							.getReviewer(), this.selectReasonInput, this.commentsInput,
					newReassignUser.getUserData());

			this.refreshTable(ReviewerStatusCode.RELEASED);
			this.refreshTable(ReviewerStatusCode.APPROVED);
			this.refreshTable(ReviewerStatusCode.PENDING);
		}
		return null;
	}

	/**
	 * Performs the actual reassignment if the input data is valid.
	 *
	 * @return null to navigate back to the same page.
	 */
	public String doSaveReassignSODReviewersPanel() {
		logger.debug("doSaveReassignReviewersPanel() --> being executed.");

		if (this.selectedReassignUser == null) {
			// if a data owner review then a data owner must have been selected.
			JSFUtils.addFacesErrorMessage("A reviewer must be selected.");
		} else if (StringUtils.isBlank(this.selectReasonInput)) {
			// a reason must be selected to do a reassign
			JSFUtils
					.addFacesErrorMessage("A reason must be selected to perform a reassignment.");
		} else if (StringUtils.isNotBlank(this.commentsInput)
				&& this.commentsInput.length() > MAX_REASSIGN_COMMENT_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a reject comment is "
							+ MAX_REASSIGN_COMMENT_LENGTH);
		} else {

			UserDataUI newReassignUser = null;

			Long selectedDataOwnerId = this.selectedReassignUser;
			for (UserDataUI user : this.availableReassignReviewers) {
				if (selectedDataOwnerId.equals(user.getUserId())) {
					newReassignUser = user;
					break;
				}
			}

			if (newReassignUser == null) {
				throw new RuntimeException(
						"An invalid user id was found for the selected data owner.  Id = "
								+ selectedDataOwnerId);
			}

			this.renderReassignSODReviewersModalPanel = false;
			this.reviewerService.reassignReviewers(this
							.unWrapReviewers(this.selectedReassignReviewers),
					this.selectReasonInput, this.commentsInput, newReassignUser
							.getUserData());

			this.refreshTable(ReviewerStatusCode.RELEASED);
			this.refreshTable(ReviewerStatusCode.APPROVED);
			this.refreshTable(ReviewerStatusCode.PENDING);
		}
		return null;
	}

	/**
	 * Cancels the reassignment processes.
	 *
	 * @return null to return to the same page.
	 */
	public String doCancelReassignReviewersPanel() {
		logger.debug("doCancelReassignReviewersPanel() --> being executed.");
		this.renderReassignReviewerModalPanel = false;
		this.renderReassignSODReviewersModalPanel = false;
		return null;
	}

	/**
	 * Prepares the reject reviewer panel.
	 *
	 * @return null navigate to the same page.
	 */
	public String doPrepareRejectReviewersPanel() {
		logger.debug("doPrepareRejectReviewersPanel() --> being executed.");
		try {
			String actionSource = JSFUtils
					.getParameter(STATUS_ACTION_PARAM_NAME);
			if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(
					actionSource)) {
				this.selectedReviewers = this
						.extractSelectedReviewers(this.pendingTable);
			} else if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(
					actionSource)) {
				this.selectedReviewers = this
						.extractSelectedReviewers(this.approvedTable);
			} else {
				throw new RuntimeException(
						"Unexpected action source was found for prepare for reject reviewer.  Source value: "
								+ actionSource);
			}

			this.commentsInput = null;
			this.selectReasonInput = null;
			this.renderRejectReviewerModalPanel = true;
		} catch (InvalidiReviewerSelectionException e) {
			JSFUtils
					.addFacesErrorMessage("An invalid number of reviewers were selected.  At least one reviewer must be selected to preform a rejection.");
			this.renderRejectReviewerModalPanel = false;
		}
		return null;
	}

	/**
	 * Performs the actual rejection if the provided data is valid.
	 *
	 * @return null to return to the same page.
	 */
	public String doSaveRejectReviewersPanel() {
		logger.debug("doSaveRejectReviewersPanel() --> being executed.");

		if (StringUtils.isBlank(this.selectReasonInput)) {
			JSFUtils
					.addFacesErrorMessage("A reason must be selected to perform a rejection.");
		} else if (StringUtils.isNotBlank(this.commentsInput)
				&& this.commentsInput.length() > MAX_REJECT_COMMENT_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a reassignment comment is "
							+ MAX_REJECT_COMMENT_LENGTH);
		} else {

			this.reviewerService.rejectReviewers(this
							.unWrapReviewers(this.selectedReviewers),
					this.selectReasonInput, this.commentsInput);

			this.removeFromTable(this.pendingTable, this.selectedReviewers);
			this.removeFromTable(this.approvedTable, this.selectedReviewers);
			this.refreshTable(ReviewerStatusCode.REJECTED);
			this.renderRejectReviewerModalPanel = false;

		}
		return null;
	}

	/**
	 * Cancels the rejection process.
	 *
	 * @return null to return to the same page.
	 */
	public String doCancelRejectReviewersPanel() {
		logger.debug("doCancelRejectReviewersPanel() --> being executed.");
		this.renderRejectReviewerModalPanel = false;
		return null;
	}

	/**
	 * Listener for the data table scroller. Clears selections so that when the
	 * user changes table pages all selections will be cleared.
	 *
	 * @param event
	 *            not used.
	 */
	@SuppressWarnings("unused")
	public void doScrollerListener(PageEvent event) {
		logger
				.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	/**
	 * Distributes the selected users.
	 *
	 * @return null to return to the same page.
	 */
	public String doPrepareDistributeReviewersPanel() {
		logger.debug("doPrepareDistributeReviewersPanel --> being executed.");
		try {
			this.selectedReviewers = this
					.extractSelectedReviewers(this.approvedTable);

			this.targetCompDate = new Date();
			this.commentsInput = null;
			this.renderDistributeReviewerModalPanel = true;
		} catch (InvalidiReviewerSelectionException e) {
			JSFUtils
					.addFacesErrorMessage("An invalid number of reviewers were selected.  At least one reviewer must be selected to preform a distribution.");
			this.renderDistributeReviewerModalPanel = false;
		}
		return null;
	}

	/**
	 * Cancels the distribute reviewers panel.
	 *
	 * @return null to return to the same page.
	 */
	public String doCancelDistributeReviewersPanel() {
		logger.debug("doCancelDistributeReviewersPanel --> being executed.");
		this.renderDistributeReviewerModalPanel = false;
		return null;
	}

	/**
	 * Distributes the selected reviewers.
	 *
	 * @return null to return to the same page.
	 */
	public String doSaveDistributeReviewersPanel() {
		logger.debug("doSaveDistributeReviewersPanel --> being executed.");

		int commentLength = this.commentsInput.length();
		if (commentLength > MAX_REASSIGN_INSTRUC_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a Reviewer instructions is "
							+ MAX_REASSIGN_INSTRUC_LENGTH
							+ " provided length: " + commentLength);
		} else {

			List<ReviewerDTO> notFoundReviewers = this.reviewerService
					.distributeReviewers(this
									.unWrapReviewers(this.selectedReviewers),
							this.targetCompDate, this.commentsInput);

			this.removeFromTable(this.approvedTable, this.selectedReviewers);
			this.refreshTable(ReviewerStatusCode.APPROVED);
			this.refreshTable(ReviewerStatusCode.RELEASED);
			this.renderDistributeReviewerModalPanel = false;

			if (!notFoundReviewers.isEmpty()) {
				for (ReviewerDTO notFoundReviewer : notFoundReviewers) {
					JSFUtils
							.addFacesErrorMessage("User not found in sdt025_user table, or invalid emails address (Not able to Distribute): "
									+ notFoundReviewer.getReviewerName()
									+ " - UserId: "
									+ notFoundReviewer.getUserId());
				}
			}
		}

		return null;
	}

	/**
	 * Completes the review details task.
	 *
	 * @return String navigate to the task list page
	 */
	public String doCompleteReviewDetailsTask() {
		Set<Long> reviewBundleIds = new HashSet<Long>();
		for (ReviewBundleUI ui : this.reviewBundles) {
			reviewBundleIds.add(ui.getReviewBundleId());
		}
		this.reviewerService.completeSavvionProcess(reviewBundleIds);
		this.renderCompleteTaskButton = false;
		// return to the task list page after complete process.
		this.sessionDataBean.initSelectedTasklistBean();
		return "taskList";
	}

	// -------------------------- Helper Methods ------------------------------

	/**
	 * Initiates the review details bean.
	 */
	public void initBean(ReviewUI selectedReview,
						 List<ReviewBundleUI> selectedBundles) {
		logger.debug("initBean --> being executed.");
		this.review = selectedReview;
		this.reviewBundles = selectedBundles;
		this.selectedTabId = ReviewDetailsTab.PENDING_TAB.getTabId();
		this.filterCriteriaValues = this.buildFilterCriteriaList();
		this.filterCriteriaText = DisplayStringBuilder
				.buildFilterCriteriaText(this.filterCriteriaValues);
		this.buildTables();
	}

	private List<FilterCriteriaUI> buildFilterCriteriaList() {
		ReviewBundleUI retrievedBundle = null;
		for (ReviewBundleUI bundle : this.reviewBundles) {
			retrievedBundle = bundle;
		}
		List<FilterCriteriaDTO> filters = this.reviewBundleService
				.retrieveFilterCriteria(retrievedBundle.getReviewBundleId());
		List<FilterCriteriaUI> result = new ArrayList<FilterCriteriaUI>(filters
				.size());
		for (FilterCriteriaDTO filter : filters) {
			result.add(new FilterCriteriaUI(filter));
		}
		return result;
	}

	private List<ReviewerUI> retrieveReviewers(ReviewerStatusCode statusCode) {
		logger.debug("retrieveReviewers --> being executed.");
		List<ReviewerUI> results = new ArrayList<ReviewerUI>();

		for (ReviewBundleUI bundle : this.reviewBundles) {
			List<ReviewerDTO> reviewerDTOs = this.reviewerService
					.retrieveByStatus(bundle.getReviewBundleId(), statusCode);
			if (ReviewerStatusCode.PENDING.equals(statusCode)) {
				this.reviewerService
						.populateHasManagerAccessToApplication(reviewerDTOs);
			}

			for (ReviewerDTO reviewerDTO : reviewerDTOs) {
				results.add(new ReviewerUI(reviewerDTO));
			}
		}

		return results;
	}

	@SuppressWarnings("unchecked")
	private void sortReviews(List<ReviewerUI> reviewers,
							 ReviewerStatusCode statusCode, ReviewerField field) {
		logger.debug("sortReviews --> being executed.");
		String sortField = field.getFieldName();
		CommonPageActionHelper.sortListByField(reviewers, sortField, null);
		switch (statusCode) {
			case APPROVED:
				this.previousApprovedSortFieldCodeValue = sortField;
				break;
			case PENDING:
				this.previousPendingSortFieldCodeValue = sortField;
				break;
			case REJECTED:
				this.previousRejectedSortFieldCodeValue = sortField;
				break;
			default:
				this.previousDistributedSortFieldCodeValue = sortField;
				break;
		}
	}

	private void buildTables() {
		logger.debug("buildTables --> being executed.");
		CodeDTO reviewTypeCode = this.review.getReview().getReviewTypeCd();
		List<ReviewerUI> reviewers = this
				.retrieveReviewers(ReviewerStatusCode.PENDING);
		this.sortReviews(reviewers, ReviewerStatusCode.PENDING,
				ReviewerField.REVIEWER_NAME);
		this.buildPendingTable(reviewers, reviewTypeCode);

		reviewers = this.retrieveReviewers(ReviewerStatusCode.APPROVED);
		this.sortReviews(reviewers, ReviewerStatusCode.APPROVED,
				ReviewerField.REVIEWER_NAME);
		this.buildApprovedTable(reviewers, reviewTypeCode);

		reviewers = this.retrieveReviewers(ReviewerStatusCode.RELEASED);
		this.sortReviews(reviewers, ReviewerStatusCode.RELEASED,
				ReviewerField.REVIEWER_NAME);
		this.buildDistributedTable(reviewers, reviewTypeCode);

		reviewers = this.retrieveReviewers(ReviewerStatusCode.REJECTED);
		this.sortReviews(reviewers, ReviewerStatusCode.REJECTED,
				ReviewerField.REVIEWER_NAME);
		this.buildRejectedTable(reviewers, reviewTypeCode);
	}

	@SuppressWarnings("unchecked")
	private void buildRejectedTable(List<ReviewerUI> rejectedReviewers,
									CodeDTO reviewTypeCode) {
		logger.debug("buildRejectedTable --> being executed.");
		DataTable table = this.buildCoreTable(rejectedReviewers);
		List tableChildren = table.getChildren();
		String statusCode = ReviewerStatusCode.REJECTED.getCode();
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(
				reviewTypeCode.getValue())) {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildEscalationMgrColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# Direct Reports"));
			tableChildren.add(this.buildDateRejectedColumn(statusCode));
			tableChildren.add(this.buildRejectedByColumn(statusCode));
			tableChildren.add(this.buildRejectCodeColumn(statusCode));
			tableChildren.add(this.buildRejectCommentsColumn(statusCode));
		} else if ("SGDU".equalsIgnoreCase(reviewTypeCode.getValue())) {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildSODOwnerColumn(statusCode));
			tableChildren.add(this.buildSODConflictTypeColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateRejectedColumn(statusCode));
			tableChildren.add(this.buildRejectedByColumn(statusCode));
			tableChildren.add(this.buildRejectCodeColumn(statusCode));
			tableChildren.add(this.buildRejectCommentsColumn(statusCode));
		} else {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildDataOwnerColumn(statusCode));
			tableChildren.add(this.buildApplicationColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateRejectedColumn(statusCode));
			tableChildren.add(this.buildRejectedByColumn(statusCode));
			tableChildren.add(this.buildRejectCodeColumn(statusCode));
			tableChildren.add(this.buildRejectCommentsColumn(statusCode));
		}
		this.rejectedTable = table;
	}

	@SuppressWarnings("unchecked")
	private void buildDistributedTable(List<ReviewerUI> distributedReviewers,
									   CodeDTO reviewTypeCode) {
		logger.debug("buildDistributedTable --> being executed.");
		DataTable table = this.buildCoreTable(distributedReviewers);

		List tableChildren = table.getChildren();
		String statusCode = ReviewerStatusCode.RELEASED.getCode();
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(
				reviewTypeCode.getValue())) {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildEscalationMgrColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# Direct Reports"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
			tableChildren.add(this.buildDateSentColumn(statusCode));
			tableChildren.add(this.buildTargetDueDateColumn(statusCode));
		} else if ("SGDU".equalsIgnoreCase(reviewTypeCode.getValue())) {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildSODOwnerColumn(statusCode));
			tableChildren.add(this.buildSODConflictTypeColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
			tableChildren.add(this.buildDateSentColumn(statusCode));
			tableChildren.add(this.buildTargetDueDateColumn(statusCode));
		} else {
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildDataOwnerColumn(statusCode));
			tableChildren.add(this.buildApplicationColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
			tableChildren.add(this.buildDateSentColumn(statusCode));
			tableChildren.add(this.buildTargetDueDateColumn(statusCode));
		}
		this.distributedTable = table;
	}

	@SuppressWarnings("unchecked")
	private void buildApprovedTable(List<ReviewerUI> approvedReviewers,
									CodeDTO reviewTypeCode) {
		logger.debug("buildApprovedTable --> being executed.");
		DataTable table = this.buildCoreTable(approvedReviewers);
		List tableChildren = table.getChildren();
		String statusCode = this.getApprovedParam();
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(
				reviewTypeCode.getValue())) {
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildEscalationMgrColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# Direct Reports"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
		} else if ("SGDU".equalsIgnoreCase(reviewTypeCode.getValue())) {
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildSODOwnerColumn(statusCode));
			tableChildren.add(this.buildSODConflictTypeColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
		} else {
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildDataOwnerColumn(statusCode));
			tableChildren.add(this.buildApplicationColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
		}
		this.approvedTable = table;
	}

	@SuppressWarnings( { "deprecation", "unchecked" })
	private void buildPendingTable(List<ReviewerUI> pendingReviewers,
								   CodeDTO reviewTypeCode) {
		logger.debug("buildPendingTable --> being executed.");
		DataTable table = this.buildCoreTable(pendingReviewers);
		List tableChildren = table.getChildren();
		String statusCode = this.getPendingParam();
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(
				reviewTypeCode.getValue())) {
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildActiveUserColumn());
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildEscalationMgrColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# Direct Reports"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
		} else if ("SGDU".equalsIgnoreCase(reviewTypeCode.getValue())) {
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildActiveUserColumn());
			tableChildren.add(this.buildSODOwnerColumn(statusCode));
			tableChildren.add(this.buildSODConflictTypeColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));

		} else {// data owner or priv access
			tableChildren.add(this.buildSelectColumn(statusCode));
			tableChildren.add(this.buildBundleColumn(statusCode));
			tableChildren.add(this.buildActiveUserColumn());
			tableChildren.add(this.buildDataOwnerColumn(statusCode));
			tableChildren.add(this.buildApplicationColumn(statusCode));
			tableChildren.add(this.buildReviewerColumn(statusCode));
			tableChildren.add(this.buildDivisionColumn(statusCode));
			tableChildren.add(this.buildDepartmentColumn(statusCode));
			tableChildren.add(this.buildNumberOfDepartmentsColumn(statusCode));
			tableChildren.add(this.buildNumberOfUsersColumn(statusCode,
					"# users in report"));
			tableChildren.add(this.buildDateCreatedColumn(statusCode));
		}
		this.pendingTable = table;
	}

	private Object buildSODConflictTypeColumn(String statusCode) {
		logger.debug("buildSODConflictTypeColumn --> being executed.");
		return this.buildColumn("SOD Conflict Type",
				ReviewerField.SOD_CONFLICT_DISPLAY,
				"sortBySODConflictTypeLink", statusCode);
	}

	private Object buildSODOwnerColumn(String statusCode) {
		logger.debug("buildSODOwnerColumn --> being executed.");
		return this.buildColumn("SOD Owner", ReviewerField.SOD_OWNER,
				"sortBySODOwnerLink", statusCode);
	}

	private Object buildRejectCommentsColumn(String statusCode) {
		return this.buildColumn("Reject Comments",
				ReviewerField.REJECT_COMMENTS, "sortByRejectColumnHeaderLink",
				statusCode);
	}

	private Object buildRejectCodeColumn(String statusCode) {
		return this.buildColumn("Reject Code",
				ReviewerField.REJECT_CODE_DISPLAY, "sortByRejectCodeLink",
				statusCode);
	}

	private Object buildRejectedByColumn(String statusCode) {
		return this.buildColumn("Rejected By", ReviewerField.REJECTED_BY,
				"sortByRejectByLink", statusCode);
	}

	private Object buildDateRejectedColumn(String statusCode) {
		return this
				.buildDateColumn("Date Rejected", ReviewerField.DATE_REJECTED,
						"sortByRejectDateLink", statusCode);
	}

	private Object buildTargetDueDateColumn(String statusCode) {
		return this.buildDateColumn("Target DueDate",
				ReviewerField.TARGET_DUE_DATE, "sortByDueDateLink", statusCode);
	}

	private Object buildDateSentColumn(String statusCode) {
		return this.buildDateColumn("Date Sent", ReviewerField.DATE_SENT,
				"sortByDateSentLink", statusCode);
	}

	private Object buildNumberOfDepartmentsColumn(String statusCode) {
		return this.buildColumn("# of Departments",
				ReviewerField.NUMBER_OF_DEPARTMENTS,
				"sortByNumberOfDepartmentsLink", statusCode);
	}

	private Object buildApplicationColumn(String statusCode) {
		return this.buildColumn("Application", ReviewerField.APPLICATION,
				"sortByApplicationLink", statusCode);
	}

	private Object buildDataOwnerColumn(String statusCode) {
		return this.buildColumn("Data Owner", ReviewerField.OWNER,
				"sortByDataOwnerLink", statusCode);
	}

	private Object buildDateCreatedColumn(String statusCode) {
		return this.buildDateColumn("Date Created", ReviewerField.DATE_CREATED,
				"sortByDateCreatedLink", statusCode);
	}

	private Object buildNumberOfUsersColumn(String statusCode,
											String headerValue) {
		return this.buildColumn(headerValue,
				ReviewerField.NUMBER_OF_REVIEWED_USERS,
				"sortByReviewUserNumberLink", statusCode);
	}

	private Object buildDepartmentColumn(String statusCode) {
		logger.debug("buildDepartmentColumn --> being executed.");
		String fieldName = ReviewerField.DEPARTMENT.getFieldName();
		StringBuilder sb = new StringBuilder(20).append("#{reviewer.").append(
				fieldName).append('}');
		HtmlOutputText text = HtmlTableBuilderUtil.buildOutputText(sb
				.toString());
		sb = new StringBuilder(20).append("Reviewer Id: " + "#{reviewer.")
				.append(ReviewerField.ID.getFieldName()).append('}');
		JSFUtils.setValueBinding(text, "title", sb.toString());

		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(
				"Department", fieldName, "sortByDepartmentLink", statusCode),
				text);

	}

	private Object buildDivisionColumn(String statusCode) {
		logger.debug("buildDivisionColumn --> being executed.");
		return this.buildColumn("Division", ReviewerField.DIVISION,
				"sortByDivisionLink", statusCode);
	}

	@SuppressWarnings("unchecked")
	private Object buildReviewerColumn(String statusCode) {
		logger.debug("buildReviewerColumn --> being executed.");
		HtmlCommandLink link = new HtmlCommandLink();
		link.setId("viewReviewerDetailsLink");

		String fieldName = ReviewerField.REVIEWER_NAME.getFieldName();
		StringBuilder sb = new StringBuilder(20).append("#{reviewer.").append(
				fieldName).append('}');
		JSFUtils.setValueBinding(link, "value", sb.toString());
		JSFUtils.setActionBinding(link,
				"#{reviewDetailsBean.doViewReviewerDetails}");

		List linkChildren = link.getChildren();

		UIParameter param = new UIParameter();
		sb = new StringBuilder(20).append("#{reviewer.").append(
				ReviewerField.ID.getFieldName()).append('}');
		JSFUtils.setValueBinding(param, "value", sb.toString());
		param.setName(REVIEWER_ID_ACTION_PARAM_NAME);
		linkChildren.add(param);

		param = new UIParameter();
		param.setValue(statusCode);
		param.setName(STATUS_ACTION_PARAM_NAME);
		linkChildren.add(param);

		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(
				"Reviewer", fieldName, "sortByReviewerLink", statusCode), link);
	}

	private Object buildEscalationMgrColumn(String statusCode) {
		logger.debug("buildEscalationMgrColumn --> being executed.");
		return this.buildColumn("Escalation Manager",
				ReviewerField.ESCALATION_MGR, "sortByEscalationMgrLink",
				statusCode);
	}

	private Column buildActiveUserColumn() {
		logger.debug("buildActiveUserColumn --> being executed.");
		HtmlGraphicImage image = new HtmlGraphicImage();
		image.setValue("/images/errorMessage.gif");
		// only display image if the user is invalid
		JSFUtils.setValueBinding(image, "rendered", "#{reviewer.invalidUser}");
		JSFUtils.setValueBinding(image, "title", "#{reviewer.reviewerStatus}");

		Column col = HtmlTableBuilderUtil.buildColumn(new HtmlOutputText(),
				image);
		HtmlGraphicImage noAccessImage = new HtmlGraphicImage();
		noAccessImage.setValue("/images/ico_notice.gif");
		noAccessImage
				.setTitle("User either doesn't have access to the Sox application, or doesn't have the manager role");
		// only display image if the user doesn't have access to the sox app.
		JSFUtils.setValueBinding(noAccessImage, "rendered",
					"#{!reviewer.hasAccessToApplication}");
		col.getChildren().add(noAccessImage);
		return col;
	}

	private Object buildBundleColumn(String statusCode) {
		return this.buildColumn("Bundle", ReviewerField.BUNDLE_NAME,
				"sortByBundleLink", statusCode);
	}

	private Column buildSelectColumn(String statusCode) {
		logger.debug("buildSelectColumn --> being executed.");
		HtmlSelectBooleanCheckbox checkBox = new HtmlSelectBooleanCheckbox();
		checkBox.setId("reviewerSelectedCheckBox");
		JSFUtils.setValueBinding(checkBox, "value", "#{reviewer.selected}");

		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink(
				"All/None", "#{reviewDetailsBean.doSelectAllToggle}",
				"selectAllLink");

		UIParameter param = new UIParameter();
		param.setValue(statusCode);
		param.setName(STATUS_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		return HtmlTableBuilderUtil.buildColumn(link, checkBox);
	}

	private Column buildColumn(String colHeaderValue, ReviewerField field,
								 String headerLinkId, String statusCode) {
		String fieldName = field.getFieldName();
		StringBuilder sb = new StringBuilder(20).append("#{reviewer.").append(
				fieldName).append('}');
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(
				colHeaderValue, fieldName, headerLinkId, statusCode),
				HtmlTableBuilderUtil.buildOutputText(sb.toString()));
	}

	private Column buildDateColumn(String colHeaderValue,
									 ReviewerField field, String headerLinkId, String statusCode) {
		String fieldName = field.getFieldName();
		StringBuilder sb = new StringBuilder(20).append("#{reviewer.").append(
				fieldName).append('}');
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(
				colHeaderValue, fieldName, headerLinkId, statusCode),
				HtmlTableBuilderUtil.buildDateOutputText(sb.toString()));
	}

	private CommandLink buildHeaderLink(String colHeaderValue,
												String fieldName, String headerLinkId, String statusCode) {
		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink(
				colHeaderValue, "#{reviewDetailsBean.doSortByField}",
				headerLinkId);

		UIParameter param = new UIParameter();
		param.setValue(fieldName);
		param.setName(SORT_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		param = new UIParameter();
		param.setValue(statusCode);
		param.setName(STATUS_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		return link;
	}

	private DataTable buildCoreTable(List<ReviewerUI> reviewers) {
		DataTable table = new DataTable();
		table.setVar("reviewer");
		table.setStyleClass("defaultTableHeader");
		table.setRows(10);
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		table.setValue(reviewers);
		return table;
	}

	private void setReassignReviewers(List<UserDataDTO> reviewers) {
		int reviewersCnt = reviewers.size();
		this.availableReassignReviewerSelectItems = new ArrayList<SelectItem>(
				reviewersCnt);
		this.availableReassignReviewers = new ArrayList<UserDataUI>(
				reviewersCnt);
		for (UserDataDTO reviewer : reviewers) {
			this.availableReassignReviewers.add(new UserDataUI(reviewer));
			String ownerType = (reviewer.getOwnerTypeDescription() != null ? reviewer
					.getOwnerTypeDescription()
					: "MANAGER");
			String name = reviewer.getName() + " (" + ownerType + ")";
			this.availableReassignReviewerSelectItems.add(new SelectItem(
					(reviewer.getUserId()), name));
		}
	}

	/**
	 * Extracts the selected reviewers from the provided list of reviewers.
	 *
	 * @param table
	 *            the reviewers to search for selected reviewers.
	 * @return a list of the selected reviewers from the list of provided
	 *         reviewers.
	 * @throws InvalidiReviewerSelectionException
	 *             if no reviewers are selected.
	 */
	@SuppressWarnings("unchecked")
	private List<ReviewerUI> extractSelectedReviewers(DataTable table)
			throws InvalidiReviewerSelectionException {

		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		List<ReviewerUI> results = new ArrayList<ReviewerUI>(5);
		for (ReviewerUI reviewer : reviewers) {
			if (reviewer.isSelected()) {
				results.add(reviewer);
			}
		}

		if (results.isEmpty()) {
			throw new InvalidiReviewerSelectionException();
		}
		return results;
	}

	private List<ReviewerDTO> unWrapReviewers(List<ReviewerUI> reviewers) {
		List<ReviewerDTO> results = new ArrayList<ReviewerDTO>(reviewers.size());
		for (ReviewerUI reviewer : reviewers) {
			results.add(reviewer.getReviewer());
		}
		return results;
	}

	// -------------------------- Helper Methods ------------------------------

	@SuppressWarnings("unchecked")
	private void refreshTable(ReviewerStatusCode statusCode) {
		DataTable table = this.getTableByStatus(statusCode.getCode());
		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		reviewers.clear();
		reviewers.addAll(this.retrieveReviewers(statusCode));
		this.sortReviews(reviewers, statusCode, ReviewerField.REVIEWER_NAME);
	}

	@SuppressWarnings("unchecked")
	private void removeFromTable(DataTable table,
								 List<ReviewerUI> reviewersToRemove) {

		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		reviewers.removeAll(reviewersToRemove);
	}

	@SuppressWarnings("unchecked")
	private List<ReviewerUI> extractReviewerList(DataTable table) {
		return (List<ReviewerUI>) table.getValue();
	}

	private DataTable getTableByStatus(String code) {
		DataTable result;
		if (ReviewerStatusCode.PENDING.getCode().equalsIgnoreCase(code)) {
			result = this.pendingTable;
		} else if (ReviewerStatusCode.APPROVED.getCode().equalsIgnoreCase(code)) {
			result = this.approvedTable;
		} else if (ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(code)) {
			result = this.rejectedTable;
		} else if (ReviewerStatusCode.RELEASED.getCode().equalsIgnoreCase(code)) {
			result = this.distributedTable;
		} else {
			throw new RuntimeException(
					"An invalid reviewer status code was found with a value of: "
							+ code);
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private ReviewerUI extractSelectedReassignReviewer(DataTable table)
			throws InvalidiReviewerSelectionException {
		ReviewerUI selectedReviewer = null;
		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		for (ReviewerUI reviewer : reviewers) {
			if (reviewer.isSelected()) {
				// only one reviewer can be selected for reassignment so if
				// multi then add error
				// message.
				if (selectedReviewer != null) {
					throw new InvalidiReviewerSelectionException();
				}
				selectedReviewer = reviewer;
			}
		}

		if (selectedReviewer == null) {
			throw new InvalidiReviewerSelectionException();
		}

		return selectedReviewer;
	}

	@SuppressWarnings("unchecked")
	private List<ReviewerUI> extractSelectedSODReassignReviewer(
			DataTable table) throws InvalidiReviewerSelectionException {
		List<ReviewerUI> sodReviewers = new ArrayList<ReviewerUI>(3);
		List<ReviewerUI> reviewers = this.extractReviewerList(table);
		for (ReviewerUI reviewer : reviewers) {
			if (reviewer.isSelected()) {
				sodReviewers.add(reviewer);
			}
		}

		if (sodReviewers.size() == 0) {
			throw new InvalidiReviewerSelectionException();
		}

		if (sodReviewers.size() > 1) {
			// must check that all selected have the same conflict type code.
			ReviewerUI firstReviewer = sodReviewers.get(0);
			ConflictDTO conflict = firstReviewer.getReviewer().getConflict();
			Long conflictId = conflict.getId();
			for (ReviewerUI reviewer : sodReviewers) {
				if (!(conflictId.equals(reviewer.getReviewer().getConflict()
						.getId()))) {
					throw new InvalidiReviewerSelectionException(
							"The selected reviewers are from different conflicts.");
				}
			}
		}

		return sodReviewers;
	}

	/**
	 * Clears the selected reviewers across all statuses. This method must be
	 * call by any function that changes the order of items in a list. If it is
	 * not called then items that are not displayed in the UI could be selected
	 * and get processed with out the user knowing.
	 *
	 */
	@SuppressWarnings("unchecked")
	private void clearSelections() {

		for (ReviewerUI reviewer : this.extractReviewerList(this.approvedTable)) {
			reviewer.setSelected(false);
		}

		for (ReviewerUI reviewer : this.extractReviewerList(this.pendingTable)) {
			reviewer.setSelected(false);
		}

		for (ReviewerUI reviewer : this
				.extractReviewerList(this.distributedTable)) {
			reviewer.setSelected(false);
		}

		for (ReviewerUI reviewer : this.extractReviewerList(this.rejectedTable)) {
			reviewer.setSelected(false);
		}
	}

	/**
	 * An exception that represents an invalid reviewer selection.
	 */
	private class InvalidiReviewerSelectionException extends Exception {
		private static final long serialVersionUID = 1L;

		public InvalidiReviewerSelectionException() {
			super();
		}

		public InvalidiReviewerSelectionException(String message) {
			super(message);
		}
	}

	public boolean isRenderDistributeReviewerModalPanel() {
		return renderDistributeReviewerModalPanel;
	}

	public List<ReviewerUI> getSelectedReviewers() {
		return selectedReviewers;
	}

	public boolean isRenderEditReviewCommentsModalPanel() {
		return renderEditReviewCommentsModalPanel;
	}

	public boolean isRenderReassignReviewerModalPanel() {
		return renderReassignReviewerModalPanel;
	}

	public Long getSelectedReassignUser() {
		return selectedReassignUser;
	}

	public void setSelectedReassignUser(Long selectedReassignUser) {
		this.selectedReassignUser = selectedReassignUser;
	}

	public ArrayList<SelectItem> getAvailableReassignReviewerSelectItems() {
		return availableReassignReviewerSelectItems;
	}

	public boolean isRenderRejectReviewerModalPanel() {
		return renderRejectReviewerModalPanel;
	}

	public ReviewerUI getSelectedReassignReviewer() {
		return selectedReassignReviewer;
	}

	public void setSelectedReassignReviewer(ReviewerUI selectedReassignReviewer) {
		this.selectedReassignReviewer = selectedReassignReviewer;
	}

	public boolean isRenderReassignSODReviewersModalPanel() {
		return renderReassignSODReviewersModalPanel;
	}

	public boolean isRenderCompleteTaskButton() {
		ReviewBundleUI selectedBundle = null;
		for (ReviewBundleUI ui : this.reviewBundles) {
			selectedBundle = ui;
		}
		return this.reviewerService.isReviewDetailCompleted(selectedBundle
				.getReviewBundleId());
	}

	public void setRenderCompleteTaskButton(boolean renderCompleteTaskButton) {
		this.renderCompleteTaskButton = renderCompleteTaskButton;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public List<FilterCriteriaUI> getFilterCriteriaValues() {
		return filterCriteriaValues;
	}

	public void setFilterCriteriaValues(
			List<FilterCriteriaUI> filterCriteriaValues) {
		this.filterCriteriaValues = filterCriteriaValues;
	}

	public String getFilterCriteriaText() {
		return filterCriteriaText;
	}

	public void setFilterCriteriaText(String filterCriteriaText) {
		this.filterCriteriaText = filterCriteriaText;
	}

	public ReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(ReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

}
