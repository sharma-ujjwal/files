package com.assurant.inc.sox.ar.service;

import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.utils.exceptions.DuplicateReviewNameException;
import com.assurant.inc.sox.ar.utils.exceptions.NonClosableReview;

/**
 * The service that retrieves review data and performs actions on reviews.
 */
public interface IReviewService {

	/**
	 * Persists the provided review to the data store. The review name must be unique.
	 * 
	 * @param reviewDto the review template containing the data to store.
	 * @return the persisted review.
	 * @throws DuplicateReviewNameException if the provided name is already in use.
	 */
	public ReviewDTO createReview(String name, ReviewTypeCode typeCode, String comments, Date targetDate, boolean adHoc)
	    throws DuplicateReviewNameException;

	/**
	 * Updates the provided review to persist any changes made.
	 * 
	 * @param reviewDto the review to persist.
	 * @return the persisted review.
	 */
	public ReviewDTO updateReview(ReviewDTO reviewDto);

	/**
	 * Retrieves all of the reviews with the given status.
	 * 
	 * @param status the status to retrieve reviews for.
	 * @return all of the reviews with the given status. If no reveiws are found then an empty list will be returned.
	 */
	public List<ReviewDTO> retrieveReviewsByStatus(ReviewStatusCode status);

	/**
	 * Retrieves all of the reviews by the given id.
	 * 
	 * @param reviewId the id of the review to retrieve.
	 * @return the review for the given id. If no reviews are found then a null will be returned.
	 */
	public ReviewDTO retrieveReviewById(Long reviewId);

	public List<ReviewDashboardDTO> retrieveOutstandingDashboardReviews();

	public List<ReviewDashboardDTO> retrieveCompletedDashboardReviews();

	public void calculateStatistics(ReviewDashboardDTO reviewDashboardDTO);

	public void closeReview(Long reviewId) throws NonClosableReview;
}
