package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.luad.InternalIdentifierType;

public interface IInternalIdentifierTypeService {
	public List<InternalIdentifierType> findAll();
	public InternalIdentifierType findById(Long idTypId);
	public Long getTypeIdByTypeCD(String typeCD);
	
}
