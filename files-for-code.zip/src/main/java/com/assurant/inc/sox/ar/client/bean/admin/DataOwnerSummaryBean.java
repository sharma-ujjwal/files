package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.admin.ui.DataOwnerSummaryUI;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.service.IDataOwnerSummaryService;
import com.assurant.inc.sox.domain.admin.DataOwnerSummary;
import com.assurant.inc.sox.domain.searchable.DataOwnerSummarySearchCriteria;
import org.primefaces.component.datascroller.DataScroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("dataOwnerSummaryBean")
@Scope("session")
public class DataOwnerSummaryBean {
	//injected resources
	@Autowired
	@Qualifier("dataOwnerSummaryService")
	private IDataOwnerSummaryService dataOwnerSummaryService;
	
	private List<DataOwnerSummaryUI> dataOwnerSummaryList;
	private DataOwnerSummarySearchCriteria criteria;
	private String displayAmount = "10";
	private String oldSortColumn;

	DataScroller dataScroller;
	
	public IDataOwnerSummaryService getDataOwnerSummaryService() {
		return dataOwnerSummaryService;
	}

	public void setDataOwnerSummaryService(
			IDataOwnerSummaryService dataOwnerSummaryService) {
		this.dataOwnerSummaryService = dataOwnerSummaryService;
	}

	public String getSearchApplicationName() {
		return this.criteria.getApplicationName();
	}

	public void setSearchApplicationName(String searchApplicationName) {
		this.criteria.setApplicationName(searchApplicationName);
	}

	public String getSearchDataOwnerName() {
		return this.criteria.getDataOwnerName();
	}

	public void setSearchDataOwnerName(String searchDataOwnerName) {
		this.criteria.setDataOwnerName(searchDataOwnerName);
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getOldSortColumn() {
		return oldSortColumn;
	}

	public void setOldSortColumn(String oldSortColumn) {
		this.oldSortColumn = oldSortColumn;
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

	public List<DataOwnerSummaryUI> getDataOwnerSummaryList() {
		if (dataOwnerSummaryList == null) {
			resetCriteria();
			refreshList();
		}
		return dataOwnerSummaryList;
	}

	private void resetCriteria() {
		this.criteria = new DataOwnerSummarySearchCriteria();
		criteria.setActiveOnly(Boolean.TRUE);
	}
	
	public void refreshList() {
		List<DataOwnerSummary> summaryList = this.dataOwnerSummaryService
				.retrieveDataOwnerSummariesByCriteria(this.criteria);
		
		this.dataOwnerSummaryList = new ArrayList<DataOwnerSummaryUI>();
		for (DataOwnerSummary summary : summaryList) {
			this.dataOwnerSummaryList.add(new DataOwnerSummaryUI(summary));
		}
	    this.doSort();
	}

	public String doSearch() {
		refreshList();
		return "";
	}
	
	public String resetSearch() {
		this.dataOwnerSummaryList = null; 
		this.oldSortColumn = null;
		resetCriteria();
		refreshList();
		return "";
	}
	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "applicationName";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(dataOwnerSummaryList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}
	
	public void init() {
		this.dataOwnerSummaryList = null;
		this.oldSortColumn = null;
		this.resetCriteria();
		this.displayAmount = "10";
	}
}

