package com.assurant.inc.sox.ar.client.ui;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;

public class ReviewBundleUI {

	private final ReviewBundleDTO reviewBundle;
	
	public ReviewBundleUI(ReviewBundleDTO reviewBundle) {
		this.reviewBundle = reviewBundle;
	}

	public Date getLuadCycleDate() {
	    return reviewBundle.getLuadCycleDate();
    }

	public Long getReviewBundleId() {
	    return reviewBundle.getReviewBundleId();
    }
	
	public Date getCreatedDate() {
		return reviewBundle.getCreatedDate();
	}

	public String getCreatedBy() {
		return reviewBundle.getCreatedBy();
	}	
}
