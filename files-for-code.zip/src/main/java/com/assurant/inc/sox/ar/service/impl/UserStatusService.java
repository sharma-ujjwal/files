/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IUserStatusService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IUserStatusDao;
import com.assurant.inc.sox.domain.ar.UserStatus;

 /**
 * @author RuthSchmalz
 */
@Service
public class UserStatusService implements IUserStatusService {
	@Autowired
	private IUserStatusDao userStatusDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public UserStatusService() {
	}

	public List<UserStatus> retrieveAllUserStatusByCode(String codeSelect){
		return  this.userStatusDao.findByValue(codeSelect);
	}
	
	public List<UserStatus> retrieveAllUserStatuss() {
		return this.userStatusDao.findAll();
	}
	
	public UserStatus findDuplicate(String name) {
		return this.userStatusDao.findDuplicate(name);
	}

	public List<UserStatus> retrieveDeletedUserStatuss() {
		return this.userStatusDao.findDeleted();
	}
	
	public List<UserStatus> retrieveDeletedUserStatussByName(String userStatusNameSearchText) {
		return this.userStatusDao.findDeletedByName(userStatusNameSearchText);
	}


	public List<UserStatus> retrieveUnassignedUserStatuss() {
		return this.userStatusDao.findUnassigned();
	}

	public List<UserStatus> retrieveUnassignedUserStatussByName(String userStatusNameSearchText) {
		return this.userStatusDao.findUnassignedByName(userStatusNameSearchText);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String userStatusDescription) {
		Date currentDate = new Date();
		
		//Create a UserStatus record.
		UserStatus userStatus = new UserStatus();

		userStatus.setUserStatusDescription(userStatusDescription);
		userStatus.setDeleteFlag(IFlags.NOT_DELETED);
		userStatus.setCreatedBy(this.systemUser.getUserId());
		userStatus.setCreatedDate(currentDate);
		
		userStatus.setActiveFromDate(currentDate);
		userStatus.setActiveToDate(DateUtil.END_OF_TIME);
		this.userStatusDao.save(userStatus);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(UserStatus userStatus) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		UserStatus currentUserStatus = new UserStatus();
		
		currentUserStatus.setUserStatusDescription(userStatus.getUserStatusDescription());
		currentUserStatus.setDeleteFlag(IFlags.NOT_DELETED);
		currentUserStatus.setCreatedBy(userStatus.getCreatedBy());
		currentUserStatus.setCreatedDate(userStatus.getCreatedDate());
		currentUserStatus.setLastChangedBy(this.systemUser.getUserId());
		currentUserStatus.setLastChangedDate(currentDate);
	
		currentUserStatus.setActiveFromDate(userStatus.getActiveFromDate());
		currentUserStatus.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.userStatusDao.save(currentUserStatus);
			
		//Create a Deleted UserStatus record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		// Val says we need to add one sec to the TimeDateStamp 
		userStatus.setDeleteFlag(IFlags.DELETED);
		userStatus.setActiveFromDate(currentDate);
		userStatus.setActiveToDate(currentDate);
		this.userStatusDao.save(userStatus);
	}

	public boolean canUserStatusBeDeleted(Long id) {
		return this.userStatusDao.canUserStatusBeDeleted(id);
	}
}
