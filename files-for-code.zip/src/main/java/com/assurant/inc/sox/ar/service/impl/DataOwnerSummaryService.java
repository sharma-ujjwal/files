/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.service.IDataOwnerSummaryService;
import com.assurant.inc.sox.dao.ar.IReviewOwnerSummaryDao;
import com.assurant.inc.sox.domain.admin.DataOwnerSummary;
import com.assurant.inc.sox.domain.searchable.DataOwnerSummarySearchCriteria;

/**
 * @author Brian Olson
 * 
 *
 */
@Service
public class DataOwnerSummaryService implements IDataOwnerSummaryService {

	@Autowired
	private IReviewOwnerSummaryDao reviewOwnerSummaryDao;
	
	public IReviewOwnerSummaryDao getReviewOwnerSummaryDao() {
		return reviewOwnerSummaryDao;
	}

	public void setReviewOwnerSummaryDao(IReviewOwnerSummaryDao reviewOwnerSummaryDao) {
		this.reviewOwnerSummaryDao = reviewOwnerSummaryDao;
	}

	@Transactional(readOnly = true)
	public List<DataOwnerSummary> retrieveDataOwnerSummariesByCriteria(
			DataOwnerSummarySearchCriteria criteria) {
		return this.reviewOwnerSummaryDao.findDataOwnerSummariesByCriteria(criteria);
	}
}
