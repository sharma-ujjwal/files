package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;

import com.assurant.inc.sox.ar.client.admin.ui.SoxConcernUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.ISoxConcernService;
import com.assurant.inc.sox.domain.ar.SoxConcern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("soxConcernSummaryBean")
@Scope("session")
public class SoxConcernSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(SoxConcernSummaryBean.class);
	private List<SoxConcernUI> soxConcernList;
	private List<SoxConcernUI> deletedSoxConcernList = new ArrayList<SoxConcernUI>();
	@Autowired
	@Qualifier("soxConcernService")
	private ISoxConcernService soxConcernService;
	private String displayAmount = "10";
	private String oldSortColumn;
	private String soxConcernCode;
	private String soxConcernDescription;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String soxConcernDescriptionSearchText;
	private boolean renderAddSoxConcernModalPanel;
	private boolean renderDeleteSoxConcernModalPanel;
	private SessionDataBean sessionDataBean;
	private boolean allChecked;
	private String pageNumber = "1";
	private String 	lastPageNumber= "1";
	private DataScroller dataScroller;

	public List<SoxConcernUI> getSoxConcernList() {
		if (soxConcernList == null) {
			this.refreshList();
		}
		return soxConcernList;
	}
	
	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.soxConcernList = new ArrayList<SoxConcernUI>();
		List<SoxConcern> soxConcernsRetrieved = new ArrayList<SoxConcern>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.soxConcernDescriptionSearchText)) {
				soxConcernsRetrieved = this.soxConcernService
					.retrieveAllSoxConcernByCode(this.soxConcernDescriptionSearchText);
			} else {
				soxConcernsRetrieved = this.soxConcernService.retrieveAllSoxConcerns();
			}
			
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.soxConcernDescriptionSearchText)) {
				soxConcernsRetrieved = this.soxConcernService
					.retrieveDeletedSoxConcernsByName(this.soxConcernDescriptionSearchText);
			} else {
				soxConcernsRetrieved = this.soxConcernService.retrieveDeletedSoxConcerns();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.soxConcernDescriptionSearchText)) {
				soxConcernsRetrieved = this.soxConcernService.retrieveUnassignedSoxConcernsByCode(this.soxConcernDescriptionSearchText);
			} else {
				soxConcernsRetrieved = this.soxConcernService.retrieveUnassignedSoxConcerns(); // constructor JSF call
			}
		}
		for (SoxConcern soxConcern : soxConcernsRetrieved) {
			this.soxConcernList.add(new SoxConcernUI(soxConcern));
		}
		this.doSort();
	}

	// ******* GO button *******	
	public String goSearch() {
		this.refreshList();
		return "";
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		this.soxConcernList = null;
		this.soxConcernDescriptionSearchText = null;
		this.oldSortColumn = null;
		this.refreshList();
		return "";
	}
	
	
	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		this.refreshList();
		this.clearSelections();
		return "";
	}

	// *******  List Headers *******	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "soxConcernCode";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(soxConcernList, column, this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}
	
	// ******* Add SoxConcern Panel  *******
	public String showAddSoxConcernPanel() {
		this.renderAddSoxConcernModalPanel = true;
		this.soxConcernCode = "";
		this.soxConcernDescription = "";
		this.clearSelections();
		return null;
	}

	// *******  Add SoxConcern Panel  CANCEL  *******
	public String doCancelAdd() {
		logger.debug("doCancelAddSoxConcernPanel() --> being executed.");
		this.renderAddSoxConcernModalPanel = false;
		this.clearSelections();
		return null;
	}

	// ******* Add SoxConcern Panel  SAVE *******
	public String doAddSoxConcern() {
		logger.debug("doAddSoxConcern() --> being executed.");
		// Displays error message if SoxConcern not provided

		if (!validSoxConcernCode()) {
			String message = "SoxConcern name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddSoxConcernModalPanel = true;
			return null;
		}
		
		this.soxConcernDescription = this.soxConcernDescription.toUpperCase(); 
		this.soxConcernCode = this.soxConcernCode.toUpperCase(); 
		
		SoxConcern duplicate = this.soxConcernService.findDuplicate(soxConcernCode);		
		if (duplicate != null) {
			String message = "SoxConcern code  " + soxConcernCode 
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		soxConcernService.add(soxConcernCode, soxConcernDescription);   

		String message = "Added SoxConcern " + soxConcernCode;
		JSFUtils.addFacesMessage(message);
		this.refreshList();

		this.renderAddSoxConcernModalPanel = false;
		return "";
	}

	
	// ******* Delete SoxConcern  Panel *******
	public String showDeleteSoxConcernPanel() {
		populateDeletedSoxConcernList();
		if (this.deletedSoxConcernList.isEmpty()) {
			String message = "Please select at least one soxConcern.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteSoxConcernModalPanel = true;
		}

		return null;
	}

	private void populateDeletedSoxConcernList() {
		this.deletedSoxConcernList = new ArrayList<SoxConcernUI>();
		
		for (SoxConcernUI ui : this.soxConcernList) {
			if (ui.isChecked()) {
				this.deletedSoxConcernList.add(ui);
			}
		}
	}
	

	public void doDisplayRowListener() {
		logger
				.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = Integer.parseInt(displayAmount);
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)soxConcernList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), soxConcernList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				soxConcernList.get(currRow).setChecked(true);
			}
		} else {
			for (SoxConcernUI soxConcernUI : this.soxConcernList) {
				soxConcernUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (SoxConcernUI soxConcernUI : this.soxConcernList) {
			soxConcernUI.setChecked(false);
		}
	}

	// ******* Delete Division  Panel  DELETE  *******
	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (SoxConcernUI ui : this.deletedSoxConcernList) {
			// first perform a check to ensure that no one priv comment record has the
			// current SOX concern assigned
			if (this.soxConcernService.canSoxConcernBeDeleted(ui.getSoxConcernCode())) {
				this.soxConcernService.delete(ui.getSoxConcern());
			} else {
				unableToDelete.add(ui.getSoxConcernCode() + " - " + 
						ui.getSoxConcernDescription() + " (" + ui.getId() + ")");
			}
		}	

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected SOX concern records were deleted " +
					"except for the following, which are assigned to at least one " +
					"priv comment record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected SOX concern records");
		}

		this.refreshList();
		
		this.deletedSoxConcernList = new ArrayList<SoxConcernUI>();
		this.renderDeleteSoxConcernModalPanel = false;
		return null;
	}
	
	// ******* Delete SoxConcern  Panel  CANCEL  *******
	public String doCancelDelete() {
		this.deletedSoxConcernList = new ArrayList<SoxConcernUI>();
		this.renderDeleteSoxConcernModalPanel = false;
		return null;
	}

	// *******   gets & setters           *******
	public boolean validSoxConcernCode() {
		return (StringUtils.isNotEmpty(soxConcernCode));
	}
	
	public boolean isRenderAddSoxConcernModalPanel() {
		return renderAddSoxConcernModalPanel;
	}

	public void setRenderAddSoxConcernModalPanel(
			boolean renderAddSoxConcernModalPanel) {
		this.renderAddSoxConcernModalPanel = renderAddSoxConcernModalPanel;
	}

	public boolean isRenderDeleteSoxConcernModalPanel() {
		return renderDeleteSoxConcernModalPanel;
	}

	public void setRenderDeleteSoxConcernModalPanel(
			boolean renderDeleteSoxConcernModalPanel) {
		this.renderDeleteSoxConcernModalPanel = renderDeleteSoxConcernModalPanel;
	}

	public List<SoxConcernUI> getDeletedSoxConcernList() {
		return deletedSoxConcernList;
	}

	public void setDeletedSoxConcernList(List<SoxConcernUI> deletedSoxConcernList) {
		this.deletedSoxConcernList = deletedSoxConcernList;
	}
	
	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}
	
	public String getSoxConcernCode() {
		return this.soxConcernCode;
	}

	public void setSoxConcernCode(String Code) {
		this.soxConcernCode = Code;
	}

	public String getSoxConcernDescription() {
		return this.soxConcernDescription;
	}

	public void setSoxConcernDescription(String Description) {
		this.soxConcernDescription = Description;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getSoxConcernDescriptionSearchText() {
		return soxConcernDescriptionSearchText;
	}

	public void setSoxConcernDescriptionSearchText(String soxConcernDescriptionSearchText) {
		this.soxConcernDescriptionSearchText = soxConcernDescriptionSearchText;
	}

	public void setSoxConcernList(List<SoxConcernUI> soxConcernList) {
		this.soxConcernList = soxConcernList;
	}

	public ISoxConcernService getSoxConcernService() {
		return soxConcernService;
	}

	public void setSoxConcernService(ISoxConcernService soxConcernService) {
		this.soxConcernService = soxConcernService;
	}


	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.soxConcernList = null;
		this.deletedSoxConcernList = null;
		this.soxConcernCode = null;
		this.soxConcernDescription = null;
		this.allChecked = false;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}

