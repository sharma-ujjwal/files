package com.assurant.inc.sox.ar.dto.enums;

public enum ReviewFields {

    TYPE("typeCode"), NAME("name"), NUM_REPORTS("numberOfReports"), CREATE_DATE("createdDate");

    private final String fieldName;

    private ReviewFields(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldName() {
        return this.fieldName;
    }
}
