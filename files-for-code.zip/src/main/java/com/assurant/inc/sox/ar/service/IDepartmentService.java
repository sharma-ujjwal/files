package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Department;

public interface IDepartmentService {
	
	public void add(String departmentName, String costCenterNumber); 	
	public void delete(Department department);	
	public Department findDuplicate(String departmentName, String costCenter); 
	public Department findById(Long id); 
	
	public List<Department> retrieveAllDepartments();
	public List<Department> retrieveAllDepartmentsByDepartmentNameCostCenter(String searchText);
	public List<Department> retrieveDeletedDepartments();
	public List<Department> retrieveDeletedDepartmentsByDepartmentNameCostCenter(String searchText); 
	public List<Department> retrieveUnassignedDepartments();
	public List<Department> retrieveUnassignedDepartmentsByDepartmentNameCostCenter(String searchText);
	public boolean canDepartmentBeDeleted(Long id); 
}
