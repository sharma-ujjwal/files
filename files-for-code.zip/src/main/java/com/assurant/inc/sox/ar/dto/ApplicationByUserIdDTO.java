package com.assurant.inc.sox.ar.dto;

public class ApplicationByUserIdDTO implements Comparable<ApplicationByUserIdDTO>{

	private String applicationName;
	private String applicationUserId;
	
	public ApplicationByUserIdDTO(String applicationName, String applicationUserId) {
		super();
		this.applicationName = applicationName;
		this.applicationUserId = applicationUserId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getApplicationUserId() {
		return applicationUserId;
	}

	public void setApplicationUserId(String applicationUserId) {
		this.applicationUserId = applicationUserId;
	}
	
	public int compareTo(ApplicationByUserIdDTO o) {
		int compare = o.applicationName.compareTo(applicationName);

		/*
		 * compare application name, if it is the same then go ahead and compare
		 * the application user id.  multiple by -1 to switch the sort order to be ascending.
		 */
		return -1 *(compare != 0 ? compare : o.applicationUserId
				.compareTo(applicationUserId));
	}
}
