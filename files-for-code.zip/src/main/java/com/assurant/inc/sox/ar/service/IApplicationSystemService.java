package com.assurant.inc.sox.ar.service;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Environment;

public interface IApplicationSystemService {
	
	public void addNewApplicationSystem(Environment environment, Application application, Date currentDate);
	public void deleteAllApplicationSystemByEnvironmentId(Environment environment, Date currentDate);
	public void deleteAllApplicationSystemByApplicationId(Application application, Date currentDate);
	


}
