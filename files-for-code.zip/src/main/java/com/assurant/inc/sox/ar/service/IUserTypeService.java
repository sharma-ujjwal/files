package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.UserType;

public interface IUserTypeService {
	public void add(String userTypeName); 	
	public void delete(UserType userType);	

	public UserType findDuplicate(String name); 
	public List<UserType> retrieveAllUserTypes(); 
	public List<UserType> retrieveAllUserTypeByCode(String CodeSelect); 
	public List<UserType> retrieveDeletedUserTypes() ; 
	public List<UserType> retrieveDeletedUserTypesByName(String userTypeNameSearchText) ;
	public List<UserType> retrieveUnassignedUserTypes() ; 
	public List<UserType> retrieveUnassignedUserTypesByName(String userTypeNameSearchText);
	public boolean canUserTypeBeDeleted(Long id); 

	
}
