package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.admin.SodOwnerSummary;
import com.assurant.inc.sox.domain.searchable.SodOwnerSummarySearchCriteria;

public interface ISodOwnerSummaryService {

	public List<SodOwnerSummary> retrieveSodOwnerSummariesByCriteria(
			SodOwnerSummarySearchCriteria criteria);
	

}