package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IInternalIdentifierTypeService;
import com.assurant.inc.sox.ar.service.IUserAkaService;
import com.assurant.inc.sox.ar.service.IUserService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IDepartmentDao;
import com.assurant.inc.sox.dao.ar.IDivisionDao;
import com.assurant.inc.sox.dao.ar.IRejectedUserDAO;
import com.assurant.inc.sox.dao.ar.ISupervisorDao;
import com.assurant.inc.sox.dao.ar.IUserStatusDao;
import com.assurant.inc.sox.dao.ar.IUserTypeDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.RejectedUser;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;
import com.assurant.inc.sox.domain.luad.UserPk;

@Service
public class UserService implements IUserService {
	

	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	@Autowired
	private IDepartmentDao departmentDao;
	

	@Autowired
	private IDivisionDao divisionDao;

	@Autowired
	private IUserTypeDao userTypeDao;

	@Autowired
	private IUserStatusDao userStatusDao;
	
	@Autowired
	private ISupervisorDao supervisorDao;

	@Autowired
	IInternalIdentifierTypeService internalIdentifierTypeService;

	@Autowired
	IUserAkaService userAkaService;
	@Autowired
	private IRejectedUserDAO rejectedUserDAO;
	
	List<User> supervisorUsers;

	public IDepartmentDao getDepartmentDao() {
		return departmentDao;
	}

	public void setDepartmentDao(IDepartmentDao departmentDao) {
		this.departmentDao = departmentDao;
	}

	public IDivisionDao getDivisionDao() {
		return divisionDao;
	}

	public void setDivisionDao(IDivisionDao divisionDao) {
		this.divisionDao = divisionDao;
	}

	public IUserTypeDao getUserTypeDao() {
		return userTypeDao;
	}

	public void setUserTypeDao(IUserTypeDao userTypeDao) {
		this.userTypeDao = userTypeDao;
	}

	public IUserStatusDao getUserStatusDao() {
		return userStatusDao;
	}

	public void setUserStatusDao(IUserStatusDao userStatusDao) {
		this.userStatusDao = userStatusDao;
	}

	public UserService() {
	}

	public void save(User user) {
		this.userDao.save(user);
	}

	public List<User> retrieveAllUser() {
		return this.userDao.findActiveUsers();
	}
	
	public List<User> retrieveAllUserByName(String userNameSearchText) {
		return this.userDao.findByUserName(userNameSearchText, "");
	}

	public IUserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}
	
	public User findById(Long id) {
		return this.userDao.findByUserId(id);
	}

	public List<User> retrieveAllActiveUsers() {

		return this.userDao.findAllActiveUsers();
	}

	public List<User> getUsersFiltered(boolean isActive, String searchKeyId,
			Long searchSupervisor, String searchFirstNm, String searchLastNm,
			List searchUserType, List searchStatus, List searchDprtmntId,
			List searchDivisionId, List<String> searchCostCenter,
			List<String> searchBsnssSgmnt) {

		return this.userDao.findByValue(isActive, searchKeyId, searchSupervisor,
				searchFirstNm, searchLastNm, searchUserType, searchStatus, searchDprtmntId,
				searchDivisionId, searchCostCenter, searchBsnssSgmnt);
	}
	
	public List<String> createStringList(String keyId, String satMFId, 
			String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, 
			String satAltId1, String satAltId2, String satAltId3){
		List<String> values = new ArrayList<String>();
		if (keyId!=null && StringUtils.isNotEmpty(keyId))
			values.add(keyId);

		if (satMFId!=null && StringUtils.isNotEmpty(satMFId))
			values.add(satMFId);
		if (satCFId!=null && StringUtils.isNotEmpty(satCFId))
			values.add(satCFId);
		if (satGFId!=null && StringUtils.isNotEmpty(satGFId))
			values.add(satGFId);
		if (satLCSId!=null && StringUtils.isNotEmpty(satLCSId))
			values.add(satLCSId);
		if (satFDMSId!=null && StringUtils.isNotEmpty(satFDMSId))
			values.add(satFDMSId);
		if (satSiteminderId!=null && StringUtils.isNotEmpty(satSiteminderId))
			values.add(satSiteminderId);
		if (satAltId1!=null && StringUtils.isNotEmpty(satAltId1))
			values.add(satAltId1);
		if (satAltId2!=null && StringUtils.isNotEmpty(satAltId2))
			values.add(satAltId2);
		if (satAltId3!=null && StringUtils.isNotEmpty(satAltId3))
			values.add(satAltId3);


		return values;
	}
	
	public String findUserExist(Long excludeUserId, String searchKeyId, String satMFId, String satGFId, 
			String satCFId, String satLCSId,String satFDMSId, String satSiteminderId, 
			String searchSatAltId1,	String searchSatAltId2, String searchSatAltId3) {
		StringBuffer errorMsg = new StringBuffer();

		List<String> altIdList = this.createStringList(searchKeyId, satMFId, satGFId, 
				satCFId, satLCSId, satFDMSId, satSiteminderId, 
				searchSatAltId1, searchSatAltId2, searchSatAltId3);

		List<User> results = this.userDao.findUserExist(searchKeyId, satMFId, satGFId, 
				satCFId, satLCSId, satFDMSId, satSiteminderId,
				searchSatAltId1, searchSatAltId2, searchSatAltId3);

		if (!results.isEmpty()) {
			for (User user : results) {
				String keyId = (user.getPk().getKeyId()!=null)?user.getPk().getKeyId():"";
				String mfId = (user.getSatMfId()!=null)?user.getSatMfId():"";
				String cfId = (user.getSatCfId()!=null)?user.getSatCfId():"";
				String gfId = (user.getSatGfId()!=null)?user.getSatGfId():"";
				String lcsId = (user.getSatLcsId()!=null)?user.getSatLcsId():"";
				String fdmsId = (user.getSatFdmsId()!=null)?user.getSatFdmsId():"";
				String siteminderId = (user.getSatSiteminderId()!=null)?user.getSatSiteminderId():"";
				String altId1 = (user.getSatAltId1()!=null)?user.getSatAltId1():"";
				String altId2 = (user.getSatAltId2()!=null)?user.getSatAltId2():"";
				String altId3 = (user.getSatAltId3()!=null)?user.getSatAltId3():"";

				if(excludeUserId.compareTo(user.getUserId())!= 0) {
					if (altIdList.contains(keyId)) {
						errorMsg.append("Key Id - " + keyId
								+ " , ");
					}
					if ( !"".equals(mfId) && altIdList.contains(mfId)){
						errorMsg.append("SatMFId - " + mfId
								+ " , ");
					}
					if ( !"".equals(cfId) && altIdList.contains(cfId)){
						errorMsg.append("SatGFId - " + cfId
								+ " , ");
					}
					if ( !"".equals(gfId) && altIdList.contains(gfId)){
						errorMsg.append("SatCFId - " + gfId
								+ " , ");
					}
					if ( !"".equals(lcsId) && altIdList.contains(lcsId)){
						errorMsg.append("SatLCSId - " + lcsId
								+ " , ");
					}
					if ( !"".equals(fdmsId) && altIdList.contains(fdmsId)){
						errorMsg.append("SatFDMSId - " + fdmsId
								+ " , ");
					}
					if ( !"".equals(siteminderId) && altIdList.contains(siteminderId)){
						errorMsg.append("Siteminder Id - " + siteminderId
								+ " , ");
					}
					if ( !"".equals(altId1) && altIdList.contains(altId1)){
						errorMsg.append("Alternate Id1 - " + altId1
								+ " , ");
					}
					if ( !"".equals(altId2) && altIdList.contains(altId2)){
						errorMsg.append("Alternate Id2 - " + altId2
								+ " , ");
					}
					if ( !"".equals(altId3) && altIdList.contains(altId3)){
						errorMsg.append("Alternate Id3 - " + altId3
								+ " , ");
					}

					if(errorMsg.length()>0){
						errorMsg.append(" already exists for UserId " + user.getUserId());
						errorMsg.append(" Name " + user.getLastName() + ", " + user.getFirstName());
						errorMsg.append(" Status " + user.getUserStatusDescription() + "  || ");
					}
				}
			}
		}
		return errorMsg.toString();
	}
	
	@Transactional
	public void addUser(String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String bsnssSgmnt, String phone, String emailAddress, Long userStatusId, 
			String satStatus, String satJobRole, String satComment, Long extractSysId, Date extractSysDate) {
		
		Department department = (Department) this.departmentDao.findById(departmentId);
		Division division = this.divisionDao.findById(divisionId);
		UserType userType = this.userTypeDao.findById(userTypeId);
		UserStatus userStatus = this.userStatusDao.findById(userStatusId);
		User supUser = this.userDao.findByUserId(supervisorId);
		String middleName = (supUser.getMiddleName()==null)?"":(supUser.getMiddleName());
		String supervisor = supUser.getLastName()+", "+supUser.getFirstName() + " " + middleName;
		
		UserPk pk = new UserPk();

		Date currentDate = new Date();

		User user = new User();
		pk.setKeyId(keyId);
		pk.setEffectiveFromDate(currentDate);
		pk.setEffectiveToDate(DateUtil.END_OF_TIME);
		user.setPk(pk);
		if(extractSysId== -1){
			extractSysId=null;
		}
		user.setExtractSystemId(extractSysId);
		if(extractSysDate!=null)
			user.setExtractDate(extractSysDate);
		
		user.setFirstName(firstNm);
		user.setMiddleName(mddlNm);
		user.setLastName(lastNm);
		
		user.setUserType(userType);
		user.setUserTypeDescription(userType.getUserTypeDescription());
		user.setDepartment(department);
		user.setDepartmentName(department.getDepartmentNmCostCenter());
		user.setCostCenter(department.getCostCenter());
		
		user.setDivision(division);
		user.setDivisionName(division.getName());
		
		user.setLocation(location);
		user.setJobTitle(jobTitle);
		
		user.setSupervisorId(supervisorId);
		user.setSupervisor(supervisor);
		
		user.setBusinessSegment(bsnssSgmnt);
		
		user.setEmailAddress(emailAddress);
		user.setPhone(phone);
		
		user.setUserStatus(userStatus);
		user.setUserStatusDescription(userStatus.getUserStatusDescription());
		user.setDeleteFlag("N");

		user.setSatStatus(satStatus); 
		user.setCrtdBy(this.systemUser.getUserId());
		user.setCrtdDt(currentDate);
		user.setSatJobRole(satJobRole);
		user.setSatComment(satComment);
		System.out.println("Himanshu Testing @ User Service");
		this.userDao.save(user);
		
	}

	public void add(String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3, 
			String satStatus, String satJobRole, String satComment) {

		Department department = (Department) this.departmentDao.findById(departmentId);
		Division division = this.divisionDao.findById(divisionId);
		UserType userType = this.userTypeDao.findById(userTypeId);
		UserStatus userStatus = this.userStatusDao.findById(userStatusId);
		User supUser = this.userDao.findByUserId(supervisorId);
		String middleName = (supUser.getMiddleName()==null)?"":(supUser.getMiddleName());
		String supervisor = supUser.getLastName()+", "+supUser.getFirstName() + " " + middleName;
		
		UserPk pk = new UserPk();

		Date currentDate = new Date();

		User user = new User();
		pk.setKeyId(keyId);
		pk.setEffectiveFromDate(currentDate);
		pk.setEffectiveToDate(DateUtil.END_OF_TIME);
		user.setPk(pk);
		user.setExtractSystemId(0L);
		
		user.setFirstName(firstNm);
		user.setMiddleName(mddlNm);
		user.setLastName(lastNm);
		
		user.setUserType(userType);
		user.setUserTypeDescription(userType.getUserTypeDescription());
		user.setDepartment(department);
		user.setDepartmentName(department.getDepartmentNmCostCenter());
		user.setCostCenter(department.getCostCenter());
		
		user.setDivision(division);
		user.setDivisionName(division.getName());
		
		user.setLocation(location);
		user.setJobTitle(jobTitle);
		
		user.setSupervisorId(supervisorId);
		user.setSupervisor(supervisor);
		
		user.setBusinessSegment(bsnssSgmnt);
		
		user.setEmailAddress(emailAddress);
		user.setPhone(phone);
		
		user.setUserStatus(userStatus);
		user.setUserStatusDescription(userStatus.getUserStatusDescription());
		user.setDeleteFlag("N");

		user.setSatStatus(satStatus); 
		user.setCrtdBy(this.systemUser.getUserId());
		user.setCrtdDt(currentDate);
		user.setSatJobRole(satJobRole);
		user.setSatComment(satComment);

		user.setSatMfId(satMFId);
		user.setSatGfId(satGFId);
		user.setSatCfId(satCFId);
		user.setSatLcsId(satLCSId);
		user.setSatFdmsId(satFDMSId);
		user.setSatSiteminderId(satSiteminderId);
		user.setSatAltId1(satAltId1);
		user.setSatAltId2(satAltId2);
		user.setSatAltId3(satAltId3);

		
		this.userDao.save(user);
	
/*
		this.addUser(keyId, firstNm, mddlNm, lastNm, userTypeId, 
				departmentId, divisionId, location, jobTitle, supervisorId, 
				bsnssSgmnt, phone, emailAddress, userStatusId, 
				satStatus, satJobRole, satComment, 0L, null);

		//reconcile rejects if the key id is in 199 reject table
		this.reconcileRejects(keyId);

		Long userId = this.userDao.findActiveUserIdByKeyId(keyId);

		if(userId!=null)
			this.updateAltIds(userId, keyId, emailAddress, satMFId, satGFId, satCFId, satLCSId, 
				satFDMSId, satSiteminderId, satAltId1, satAltId2, satAltId3); 

*/
	}
	
	//reconcile 199 Rejects
	public void reconcileRejects(String keyOrAltId){
		List<RejectedUser> rejectedList = this.rejectedUserDAO.findBySrcUserId(keyOrAltId);
		if(rejectedList!=null && rejectedList.size()>0){
			for (RejectedUser rjct: rejectedList){
				rjct.setDeleteFlag(IFlags.DELETED);
				rjct.setLastChangedBy(systemUser.getUserId());
				rjct.setLastChangedDate(new Date());
				this.rejectedUserDAO.save(rjct);
				//this.rejectedUserDAO.delete(rjct);
			}
		}
	}

			// ** DELETE ******
	@Transactional
	// This causes a RollBack if any errors are encountered.
	public void delete(User user) {

		Long userId = user.getUserId();

		// create Audit record before any modifications.
		this.createAuditRecord(user);

		// Logical delete -- Mark existing row with deleted flag as Y, with active from and to as sysdate
		this.userDao.markAsDelete(userId, this.systemUser.getUserId());

		//update direct report information with supervisor as -1
		this.updateDirectReportInfo(userId);
		
		//Delete Alt Ids
		this.userAkaService.deleteAllByUserId(userId);

	}


	public void updateDirectReportInfo(Long supervisorId){
		// update all users 
		List<User> directReportList = this.userDao.populateSupevisorData(supervisorId);
		if(directReportList!=null && directReportList.size()>0)
		for(User rep:directReportList){
			// create Audit record before any modifications.
			this.createAuditRecord(rep);
			
			//update supervisor id to -1
			this.userDao.updateSupervisorOnUserDelete(rep.getUserId(), this.systemUser.getUserId());
			
		}
		
		
	}
	
	public void bulkUpdateUsers(List<User> updateUserList, Long supervisorId, Long userStatusId, 
			Long userTypeId, Long departmentId, Long divisionId, String cstCntr, String bsnssSgmnt) {

		
		Department department = (Department) departmentDao.findById(departmentId);
		Division division = divisionDao.findById(divisionId);
		UserType userType = userTypeDao.findById(userTypeId);
		UserStatus userStatus = userStatusDao.findById(userStatusId);
		User supUser = userDao.findByUserId(supervisorId);
		String middleName = (supUser.getMiddleName()==null)?"":(supUser.getMiddleName());
		String supervisor = supUser.getLastName()+", "+supUser.getFirstName() + " " + middleName;

		for (User user : updateUserList) {

			// create Audit record before any modifications.
			this.createAuditRecord(user);

			user.setUserType(userType);
			user.setUserTypeDescription(userType.getUserTypeDescription());
			user.setDepartment(department);
			user.setDepartmentName(department.getDepartmentNmCostCenter());
			
			user.setDivision(division);
			user.setDivisionName(division.getName());
			
			user.setSupervisorId(supervisorId);
			user.setSupervisor(supervisor);
			
			user.setUserStatus(userStatus);
			user.setUserStatusDescription(userStatus.getUserStatusDescription());

			user.setCostCenter(cstCntr);
			user.setBusinessSegment(bsnssSgmnt);

			user.setLastChngdBy(this.systemUser.getUserId());
			user.setLastChngdDt(new Date());
		}
		this.userDao.updateUsers(updateUserList);
	}

	public void updateUsers(List<User> updateUserList) {
		for (User user : updateUserList) {
			user.setLastChngdBy(this.systemUser.getUserId());
			user.setLastChngdDt(new Date());
		}
		this.userDao.updateUsers(updateUserList);
	}

	public void updateUser(User updateUser) {
			updateUser.setLastChngdBy(this.systemUser.getUserId());
			updateUser.setLastChngdDt(new Date());
			this.userDao.save(updateUser);
	}

	public void populatSupevisorData(Long supervisor) {
		supervisorUsers = null;
		supervisorUsers = new ArrayList<User>();
		supervisorUsers = this.userDao.populateSupevisorData(supervisor);

	}

	public List<SelectItem> populateSupevisorDepartments(Long supervisor) {
		List<SelectItem> supevisorDepartments;

		List<Department> divisionSet = this.userDao.findSupDistinctDepartments(supervisor);
		supevisorDepartments = new ArrayList<SelectItem>();
		supevisorDepartments.add(new SelectItem("",""));

		for (Department dep : divisionSet) {
			if(dep != null && dep.getDepartmentNmCostCenter()!=null)
				supevisorDepartments.add(new SelectItem(dep.getId(), dep.getDepartmentNmCostCenter()));
		}
		if ((divisionSet == null) || (divisionSet.size()==0))
			supevisorDepartments.add(new SelectItem(-1L,"UNKNOWN"));

		return supevisorDepartments;
	}

	public List<SelectItem> populateSupevisorDivisions(Long supervisor) {
		List<SelectItem> supevisorDivisions;
		List<Division> divisionSet = this.userDao.findSupDistinctDivision(supervisor);
		supevisorDivisions = new ArrayList<SelectItem>();
		supevisorDivisions.add(new SelectItem("",""));
		
		for (Division div : divisionSet) {
			if(div != null && div.getName() != null)
				supevisorDivisions.add(new SelectItem(div.getId(), div.getName()));
		}
		if ((divisionSet == null) || (divisionSet.size()==0))
			supevisorDivisions.add(new SelectItem(-1L,"UNKNOWN"));
		return supevisorDivisions;
	}

	public List<SelectItem> populateSupevisorCostCenters(Long supervisor) {
		List<SelectItem> supevisorCostCenter;
		
		List<String> costCenter = this.userDao.findSupDistinctCostCenter(supervisor);
		supevisorCostCenter = new ArrayList<SelectItem>();
		supevisorCostCenter.add(new SelectItem("",""));
		for (String user : costCenter) {
			if(user != null)
				supevisorCostCenter.add(new SelectItem(user, user));
		}
		if ((costCenter == null) || (costCenter.size()==0))
			supevisorCostCenter.add(new SelectItem("","UNKNOWN"));

		return supevisorCostCenter;
	}

	public List<SelectItem> populateSupevisorBusinessSegments(Long supervisor) {
		List<SelectItem> segmentList;

		List<String> businessSeg = this.userDao.findSupDistinctBusinessSegment(supervisor);
		segmentList = new ArrayList<SelectItem>();
		segmentList.add(new SelectItem("",""));

		for (String user : businessSeg) {
			if(user != null)
				segmentList.add(new SelectItem(user,user));
		}
		if ((businessSeg == null) || (businessSeg.size()==0))
			segmentList.add(new SelectItem("","UNKNOWN"));
		
		return segmentList;
	}

	public List<SelectItem> populateSupevisorJobTitles(Long supervisor, String existingJobTitle) {
		List<SelectItem> supevisorJobTitles;

		List<String> supervisorList = this.userDao.findSupDistinctJobTitle(supervisor);
		supevisorJobTitles = new ArrayList<SelectItem>();
		supevisorJobTitles.add(new SelectItem("",""));
		for (String user : supervisorList) {
			if(user != null)
				supevisorJobTitles.add(new SelectItem(user,user));
		}
		if ((supervisorList == null) || (supervisorList.size()==0))
			supevisorJobTitles.add(new SelectItem("","UNKNOWN"));

		return supevisorJobTitles;
	}

	public List<SelectItem> populateSupevisorLocations(Long supervisor, String existingLocation) {
		List<SelectItem> supevisorLocations;

		List<String> locations = this.userDao.findSupDistinctLocation(supervisor);
		supevisorLocations = new ArrayList<SelectItem>();
		supevisorLocations.add(new SelectItem("",""));
		for (String user : locations) {
			if(user != null)
				supevisorLocations.add(new SelectItem(user,user));
		}
		if ((locations == null) || (locations.size()==0))
			supevisorLocations.add(new SelectItem("","UNKNOWN"));

		return supevisorLocations;
	}
	
	
	public List<SelectItem> populateSupevisorUserType(Long supervisor) {
		List<SelectItem> types;

		List<UserType> divisionSet = this.userTypeDao.findAll();

		//List<UserType> divisionSet = this.userDao.findSupDistinctUserTypes(supervisor);
		types = new ArrayList<SelectItem>();
		
		for (UserType div : divisionSet) {
			types.add(new SelectItem(div.getId(), div.getUserTypeDescription()));
		}
		if ((types == null) || (types.size()==0))
			types.add(new SelectItem(-1L,"UNKNOWN"));
		return types;
	}

	public void updateSupervisorOnUserDelete(Long searchUserId, String lastChangedBy) {
		this.userDao.updateSupervisorOnUserDelete(searchUserId, this.systemUser.getUserId());
	}

	public List<User> findByUserName(String searchFirstName,
			String searchLastName) {
		return this.userDao.findByUserName(searchFirstName, searchLastName);
	}

	public List<UserUI> searchAssociatedUser(String searchFirstNm,
			String searchLastNm, String keyId, Long supervisorId,
			List userStatuses, List userTypes,
			List departments, List divisions, String location) {
		List<UserUI> results = new ArrayList<UserUI>();
		List<User> users = this.userDao.searchAssociatedUser(searchFirstNm,
				searchLastNm, keyId, supervisorId, userStatuses, userTypes,
				departments, divisions, location);
		for (User user : users) {
			results.add(new UserUI(user));
		}
		return results;
	}
	
	@Transactional
	public void updateUser(Long userId, String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String cstCntr, String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId,
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3, 
			String satStatus, String satJobRole, String satComment) {

		Department department = (Department) this.departmentDao.findById(departmentId);
		Division division = this.divisionDao.findById(divisionId);
		UserType userType = this.userTypeDao.findById(userTypeId);
		UserStatus userStatus = this.userStatusDao.findById(userStatusId);
		User supUser = this.userDao.findByUserId(supervisorId);
		String middleName = (supUser.getMiddleName()==null)?"":(supUser.getMiddleName());
		String supervisorName = supUser.getLastName()+", "+supUser.getFirstName() + " " + middleName;

		// create Audit record before any modifications.
		User auditRecord = this.userDao.findByUserId(userId);
		this.createAuditRecord(auditRecord);

		this.userDao.updateUser(userId, keyId, firstNm, mddlNm, lastNm, 
				userStatusId, userStatus.getUserStatusDescription(), 
				userTypeId, userType.getUserTypeDescription(), 
				supervisorId, supervisorName, 
				departmentId, department.getDepartmentNmCostCenter(), cstCntr, bsnssSgmnt, 
				divisionId, division.getName(),  
				jobTitle, location, phone, emailAddress, 
				satStatus, satJobRole, satComment, 
				satMFId, satGFId, satCFId, satLCSId, satFDMSId, 
				satSiteminderId, satAltId1, satAltId2, satAltId3, this.systemUser.getUserId());
	}

	public void updateAltIds(Long userId, String keyId, String emailAddress,
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3) {
	
		this.populateAka(userId,  
					this.internalIdentifierTypeService.getTypeIdByTypeCD("KEY_ID"), keyId);
		this.populateAka(userId, 
				this.internalIdentifierTypeService.getTypeIdByTypeCD("EMAIL_ADDR"), emailAddress);

		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_MF_ID"), satMFId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_GF_ID"), satGFId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_CF_ID"), satCFId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_LCS_ID"), satLCSId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_FDMS_ID"), satFDMSId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_SITEMIND_ID"), satSiteminderId);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_ALT_ID1"), satAltId1);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_ALT_ID2"), satAltId2);
		this.populateAka(userId, 
					this.internalIdentifierTypeService.getTypeIdByTypeCD("SAT_ALT_ID3"), satAltId3);

	}
	
	public void populateAka(Long userId, Long typeId, String altId){
		if (altId != null && !StringUtils.isEmpty(altId)) {
			this.userAkaService.update(userId, typeId, altId);
			this.reconcileRejects(altId);
		}else{
			this.userAkaService.markAsDelete(userId, typeId);
		}
	}

	@Transactional
	public void updateAltIdsForUser(Long userId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3) {
	
		User historicUser = this.userDao.findActiveUserByUserId(userId);
		// create Audit record before any modifications.
		this.createAuditRecord(historicUser);
		
		this.userDao.updateAltIds(userId, this.systemUser.getUserId(), satMFId, 
				satGFId, satCFId, satLCSId, satFDMSId, satSiteminderId, satAltId1, satAltId2, satAltId3);
	}
	
	public List<UserStatus> findUserStatusList() {
		return this.userStatusDao.findAll();
	}

	public List<Department> retrieveAllDepartments(){
		return this.departmentDao.findAll();
	}
	
	public List<Division> retrieveAllDivisions(){
		return this.divisionDao.findAll();
	}
	
	public List<UserType> retrieveAllUserTypes(){
		return this.userTypeDao.findAll();
	}
	
	public List<String> retrieveAllBusinessSeg(){
		return this.userDao.findDistinctBusinessSegment();
	}
	

	public List<String> retrieveAllCostCenter(){
		return this.userDao.findDistinctCostCenter();
	}

	public List<Supervisor> retrieveAllSupervisors() {
		return this.supervisorDao.findAll();
	}

	public UserType findUserTypeById(Long id) {
		return this.userTypeDao.findById(id);
	}

	public UserStatus findUserStatusById(Long id) {
		return this.userStatusDao.findById(id);
	}

	public Department findDepartmentById(Long id) {
		return this.departmentDao.findById(id);
	}

	public Division findDivisionById(Long id) {
		return this.divisionDao.findById(id);
	}

	public User findUserById(Long id) {
		return this.userDao.findByMgrUserId(id);
	}
	
	@Transactional
	public void updateRejectedUser(Long userId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String cstCntr, String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId, 
			String satStatus, String satJobRole, String satComment) {
		
		Department department = (Department) this.departmentDao.findById(departmentId);
		Division division = this.divisionDao.findById(divisionId);
		UserType userType = this.userTypeDao.findById(userTypeId);
		UserStatus userStatus = this.userStatusDao.findById(userStatusId);
		User supUser = this.userDao.findByUserId(supervisorId);
		String middleName = (supUser.getMiddleName()==null)?"":(supUser.getMiddleName());
		String supervisorName = supUser.getLastName()+", "+supUser.getFirstName() + " " + middleName;

		// create Audit record before any modifications.
		User auditRecord = this.userDao.findByUserId(userId);
		this.createAuditRecord(auditRecord);

		this.userDao.updateRejectedUser(userId, firstNm, mddlNm, lastNm, 
				userStatusId, userStatus.getUserStatusDescription(), 
				userTypeId, userType.getUserTypeDescription(), 
				supervisorId, supervisorName, 
				departmentId, department.getDepartmentNmCostCenter(), cstCntr, bsnssSgmnt, 
				divisionId, division.getName(),  
				jobTitle, location, phone, emailAddress, 
				satStatus, satJobRole, satComment, this.systemUser.getUserId());
	}

	public Long findActiveUserIdByKeyId(String keyId){
		return this.userDao.findActiveUserIdByKeyId(keyId);
	}

	public boolean isAltIdExists(String altId){
		return this.userAkaService.isAltIdExists(altId);
	}

	public List<User> findUsersBySupevisorId(Long supervisorId) {
		return this.userDao.populateSupevisorData(supervisorId);
	}

	public boolean isActiveReviewOwner(Long userId){
		return this.userDao.isActiveReviewOwner(userId);
	}
	
	public List<Review> outstandingReviewsForUserId(Long userId){
		return this.userDao.outstandingReviewsForUserId(userId);
	}

	public String activeReviewsMessage(Long userId){
		StringBuffer errorMsg = new StringBuffer();
		List<Review> reviewList = this.userDao.outstandingReviewsForUserId(userId);
		if (reviewList!=null && reviewList.size()>0){
			for(Review rev:reviewList){
				errorMsg.append(rev.getReviewName() + " (ID:"+ rev.getId() +") ");
			}
			return errorMsg.toString();
		}
		else
			return "";
	}

	public void createAuditRecord(User existingUser){
		Date currentDate = new Date();
		
		User historyUser = new User();
		UserPk historyUserPk = new UserPk();
		historyUserPk.setEffectiveFromDate(existingUser.getPk().getEffectiveFromDate());
		historyUserPk.setEffectiveToDate(DateUtils.addSeconds(currentDate, -1));
		historyUserPk.setKeyId(existingUser.getPk().getKeyId());
		historyUser.setPk(historyUserPk);
		
		historyUser.setBusinessSegment(existingUser.getBusinessSegment());
		historyUser.setCostCenter(existingUser.getCostCenter());
		historyUser.setCrtdBy(existingUser.getCrtdBy());
		historyUser.setCrtdDt(existingUser.getCrtdDt());
		historyUser.setDeleteFlag(existingUser.getDeleteFlag());
		historyUser.setDepartment(existingUser.getDepartment());
		historyUser.setDepartmentName(existingUser.getDepartmentName());
		historyUser.setDivision(existingUser.getDivision());
		historyUser.setDivisionName(existingUser.getDivisionName());
		historyUser.setEmailAddress(existingUser.getEmailAddress());
		historyUser.setExtractDate(existingUser.getExtractDate());
		historyUser.setExtractSystemId(existingUser.getExtractSystemId());
		historyUser.setFirstName(existingUser.getFirstName());
		historyUser.setJobTitle(existingUser.getJobTitle());
		historyUser.setLastChngdBy(existingUser.getLastChngdBy());
		historyUser.setLastChngdDt(existingUser.getLastChngdDt());
		historyUser.setLastName(existingUser.getLastName());
		historyUser.setLocation(existingUser.getLocation());
		historyUser.setMiddleName(existingUser.getMiddleName());
		historyUser.setPhone(existingUser.getPhone());
		historyUser.setSatAltId1(existingUser.getSatAltId1());
		historyUser.setSatAltId2(existingUser.getSatAltId2());
		historyUser.setSatAltId3(existingUser.getSatAltId3());
		historyUser.setSatCfId(existingUser.getSatCfId());
		historyUser.setSatComment(existingUser.getSatComment());
		historyUser.setSatStatus(existingUser.getSatStatus());
		historyUser.setSatFdmsId(existingUser.getSatFdmsId());
		historyUser.setSatGfId(existingUser.getSatGfId());
		historyUser.setSatJobRole(existingUser.getSatJobRole());
		historyUser.setSatLcsId(existingUser.getSatLcsId());
		historyUser.setSatMfId(existingUser.getSatMfId());
		historyUser.setSatSiteminderId(existingUser.getSatSiteminderId());
		historyUser.setSatStatus(existingUser.getSatStatus());
		historyUser.setSupervisor(existingUser.getSupervisor());
		historyUser.setSupervisorId(existingUser.getSupervisorId());
		historyUser.setUserStatus(existingUser.getUserStatus());
		historyUser.setUserStatusDescription(existingUser.getUserStatusDescription());
		historyUser.setUserType(existingUser.getUserType());
		historyUser.setUserTypeDescription(existingUser.getUserTypeDescription());
		this.userDao.save(historyUser);
	}

	public boolean isActiveUser(Long userId){
		return this.userDao.isActiveUser(userId);
	}

	public List<User> findPotentialSupervisors(String keyId, String firstName, String lastName) {
		return this.userDao.findPotentialSupervisors(keyId, firstName, lastName);
	}
	
	public boolean isIpsUser(){
		if (systemUser != null)
			return this.systemUser.isIpsUser();
		else
			return false;
	}
}
