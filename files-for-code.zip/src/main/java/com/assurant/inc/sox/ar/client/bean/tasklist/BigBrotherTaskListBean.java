package com.assurant.inc.sox.ar.client.bean.tasklist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.reviewerreport.EmployeeListBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.ReviewerTaskListUI;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.EmployeeListMode;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListField;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListFilterType;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.tasklist.IReviewerTaskListService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("bigBrotherTaskListBean")
@Scope("session")
public class BigBrotherTaskListBean extends AbstractTaskListBean<ReviewerTaskListUI, ReviewerTaskListDTO> implements Serializable {

	private static final long serialVersionUID = 1L;
	@Autowired
	@Qualifier("reviewerTaskListService")
	private IReviewerTaskListService reviewerTaskListService;
	private static final Logger logger = LoggerFactory.getLogger(BigBrotherTaskListBean.class);
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewBundleService")
	private IReviewBundleService reviewBundleService;
	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;

	public List<ReviewerTaskListDTO> getMyTeamTaskListBeanResults() {
		return myTeamTaskListBeanResults;
	}

	public void setMyTeamTaskListBeanResults(List<ReviewerTaskListDTO> myTeamTaskListBeanResults) {
		this.myTeamTaskListBeanResults = myTeamTaskListBeanResults;
	}

	List<ReviewerTaskListDTO> myTeamTaskListBeanResults;

	public BigBrotherTaskListBean() {
		super(TaskListFilterType.REVIEW_TYPE, "bigBrotherTaskListBean", "bigBrotherTaskList");
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewerTaskListService getReviewerTaskListService() {
		return reviewerTaskListService;
	}

	public void setReviewerTaskListService(IReviewerTaskListService reviewerTaskListService) {
		this.reviewerTaskListService = reviewerTaskListService;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	@Override
	protected ReviewerTaskListUI buildClientObject(ReviewerTaskListDTO dto) {
		logger.debug("buildClientObject() --> being executed.");
		return new ReviewerTaskListUI(dto);
	}

	@Override
	protected List<ReviewerTaskListDTO> retrieveTaskListDTOs() {
		logger.debug("retrieveTaskListDTOs() --> being executed.");
		List<ReviewerTaskListDTO> results;
		if(this.sessionDataBean.getSelectedTabId().equals(this.sessionDataBean.getBigBrotherTaskTabId())){
			results =  this.reviewerTaskListService.retrieveTaskListForReviewersTeam();
		}
		else{
			results = new ArrayList<ReviewerTaskListDTO>();
		}

		for (ReviewerTaskListDTO result : results) {
			buildClientObject(result);
		}

		String sortField = TaskListField.CREATE_DATE.getFieldName();
		Collections.sort(results, new GenericComparator(sortField, false));
		this.previousSortFieldCodeValue = sortField;

		myTeamTaskListBeanResults = results;
		return results;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String doWorkTask() {
		logger.debug("doWorkTask() --> being executed.");
		ReviewerTaskListDTO selectedTask = (ReviewerTaskListDTO) this.extractSelectedTaskListDTO();
		ReviewerDTO selectedReviewer = selectedTask.getReviewer();
		ReviewBundleDTO selectedBundle = this.reviewBundleService.retrieveById(selectedReviewer.getReviewBundleId());
		if(selectedBundle == null){
			String message = "A bundle could not be found for the selected task.  Bundle id: "
					+ selectedReviewer.getReviewBundleId();
			logger.warn(message);
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		EmployeeListBean bean = (EmployeeListBean) JSFUtils.lookupBean("employeeListBean");
		//loads employee list bean. Passed null savvion id as no review users attest process required here.
		bean.initEmployeeList(new ReviewUI(selectedTask.getReview()), new ReviewBundleUI(selectedBundle), new ReviewerUI(
				selectedReviewer), EmployeeListMode.BIG_BROTHER_VERIFY, null);

		this.unloadBean();
		return "employeeList";
	}

	@Override
	protected void loadBean() {
		logger.debug("loadBean() --> being executed.");
		this.renderTaskList = this.sessionDataBean.getSystemUser().isReviewer();
		super.loadBean();
	}

}
