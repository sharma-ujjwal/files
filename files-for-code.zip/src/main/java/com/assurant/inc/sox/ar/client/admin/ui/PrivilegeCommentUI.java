package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.luad.PrivilegeComment;

import java.util.Date;

public class PrivilegeCommentUI {
	private final PrivilegeComment privilegeComment;
	private boolean checked;
	private int index;

	public PrivilegeCommentUI(PrivilegeComment privilegeComment) {
		this.privilegeComment = privilegeComment;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public Date getEffectiveFromDate() {
		return this.privilegeComment.getPk().getEffectiveFromDate();
	}

	public Date getEffectiveToDate() {
		return this.privilegeComment.getPk().getEffectiveToDate();
	}

	public Date getExtractDate() {
		return this.privilegeComment.getExtractDate();
	}

	/*
    a.crtd_by, a.crtd_dt, a.last_chngd_by, a.last_chngd_dt
    */

	public String getComment() {
		return this.privilegeComment.getComment();
	}

	public String getValue() {
		return this.privilegeComment.getPk().getValue();
	}

	public String getDescription() {
		return this.privilegeComment.getPk().getDescription();
	}

	public PrivilegeComment getPrivilegeComment() {
		return privilegeComment;
	}

	public String getApplicationName() {
		return this.privilegeComment.getApplicationName();
	}
		
	public Long getFunctionDutyId() {
		return this.privilegeComment.getPk().getFunctionDutyId();
	}
		
	public Long getExtractSystemId() {
		return this.privilegeComment.getExtractSystemId();
	}
	
	public String getDeleteFlag() {
		return this.privilegeComment.getDeleteFlag();
	}

	public String getSoxConcern() {
		return this.privilegeComment.getSoxConcern();
	}
	
	public String getCreatedBy() {
		return this.privilegeComment.getCreatedBy();
	}

	public String getLastChangedBy() {
		return this.privilegeComment.getLastChangedBy();
	}

	public Date getLastChangedDate() {
		return this.privilegeComment.getLastChangedDate();
	}
	 public Date getCreatedDate() {
			return this.privilegeComment.getCreatedDate();
	}	
		
}
