package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.assurant.inc.sox.ar.client.admin.ui.UserTypeUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IUserTypeService;
import com.assurant.inc.sox.domain.ar.UserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("userTypeSummaryBean")
@Scope("session")
public class UserTypeSummaryBean {
	private static final Logger logger = LoggerFactory.getLogger(UserTypeSummaryBean.class);
	private List<UserTypeUI> userTypeList;
	private List<UserTypeUI> deletedUserTypeList = new ArrayList<>();
	@Autowired
	@Qualifier("userTypeService")
	private IUserTypeService userTypeService;
	private Integer displayAmount = 10;
	private String oldSortColumn;
	private String userTypeName;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String userTypeNameSearchText;
	private boolean renderAddUserTypeModalPanel;
	private boolean renderDeleteUserTypeModalPanel;
	private SessionDataBean sessionDataBean;
	private boolean allChecked;
	private String pageNumber = "1";
	private String 	lastPageNumber= "1";

	public List<UserTypeUI> getUserTypeList() {
		if (userTypeList == null) {
			refreshList();
		}
		return userTypeList;
	}
	
	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.userTypeList = new ArrayList<>();
		List<UserType> userTypesRetrieved = new ArrayList<>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userTypeNameSearchText)) {
				userTypesRetrieved = this.userTypeService
					.retrieveAllUserTypeByCode(this.userTypeNameSearchText);
			} else {
				userTypesRetrieved = this.userTypeService.retrieveAllUserTypes();
			}
			
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userTypeNameSearchText)) {
				userTypesRetrieved = this.userTypeService
					.retrieveDeletedUserTypesByName(this.userTypeNameSearchText);
			} else {
				userTypesRetrieved = this.userTypeService.retrieveDeletedUserTypes();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userTypeNameSearchText)) {
				userTypesRetrieved = this.userTypeService.retrieveUnassignedUserTypesByName(this.userTypeNameSearchText);
			} else {
				userTypesRetrieved = this.userTypeService.retrieveUnassignedUserTypes(); // constructor JSF call
			}
		}
		for (UserType userType : userTypesRetrieved) {
			this.userTypeList.add(new UserTypeUI(userType));
		}
	    doSort();
	}

	public String goSearch() {
		refreshList();
		return "";
	}
	
	public String resetSearch() {
		this.userTypeList = null;
		this.userTypeNameSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}
	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		clearSelections();		
		return "";
	}

	// *******  List Headers *******	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "userTypeDescription";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(userTypeList, column, this.oldSortColumn);
		this.oldSortColumn = column;
		clearSelections();
	}
	
	// ******* Add UserType Panel  *******
	public String showAddUserTypePanel() {
		this.renderAddUserTypeModalPanel = true;
		this.userTypeName = "";
		clearSelections();
		return null;
	}

	// *******  Add UserType Panel  CANCEL  *******
	public String doCancelAdd() {
		logger.debug("doCancelAddUserTypePanel() --> being executed.");
		this.renderAddUserTypeModalPanel = false;
		clearSelections();
		return null;
	}

	// ******* Add UserType Panel  SAVE *******
	public String doAddUserType() {
		logger.debug("doAddUserType() --> being executed.");

		if (!validUserTypeName()) {
			String message = "UserType name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserTypeModalPanel = true;
			return null;
		}
		
		this.userTypeName = this.userTypeName.toUpperCase(); 
		
		UserType duplicate = this.userTypeService.findDuplicate(userTypeName);		
		if (duplicate != null) {
			String message = "User type " + userTypeName 
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		userTypeService.add(userTypeName);      

		String message = "Added UserType " + userTypeName;
		JSFUtils.addFacesMessage(message);
		refreshList();

		this.renderAddUserTypeModalPanel = false;
		return "";
	}

	public String showDeleteUserTypePanel() {
		populateDeletedUserTypeList();
		if (this.deletedUserTypeList.isEmpty()) {
			String message = "Please select at least one userType.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteUserTypeModalPanel = true;
		}

		return null;
	}

	private void populateDeletedUserTypeList() {
		this.deletedUserTypeList = new ArrayList<UserTypeUI>();
		
		for (UserTypeUI ui : this.userTypeList) {
			if (ui.isChecked()) {
				this.deletedUserTypeList.add(ui);
			}
		}
	}
	

	public void doDisplayRowListener() {
		logger
				.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = displayAmount;
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)userTypeList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math.min((firstRow + pageSize), userTypeList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				userTypeList.get(currRow).setChecked(true);
			}
		} else {
			for (UserTypeUI userTypeUI : this.userTypeList) {
				userTypeUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (UserTypeUI userTypeUI : this.userTypeList) {
			userTypeUI.setChecked(false);
		}
	}

	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (UserTypeUI ui : this.deletedUserTypeList) {
			// first perform a check to ensure that no user record has the
			// current user type assigned
			if (this.userTypeService.canUserTypeBeDeleted(ui.getId())) {
				this.userTypeService.delete(ui.getUserType()); 
			} else {
				unableToDelete.add(ui.getUserTypeDescription() + " (" + ui.getId() + ")");
			}
		}

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected user types were deleted " +
					"except for the following, which are assigned to at least one " +
					"user record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected user types");
		}

		refreshList();
		
		this.deletedUserTypeList = new ArrayList<UserTypeUI>();
		this.renderDeleteUserTypeModalPanel = false;
		return null;
	}
	
	
	
	
	// ******* Delete UserType  Panel  CANCEL  *******
	public String doCancelDelete() {
		this.deletedUserTypeList = new ArrayList<UserTypeUI>();
		this.renderDeleteUserTypeModalPanel = false;
		return null;
	}

	public boolean validUserTypeName() {
		return (StringUtils.isNotEmpty(userTypeName));
	}
	
	// *******   gets & setters           *******
	
	public boolean isRenderAddUserTypeModalPanel() {
		return renderAddUserTypeModalPanel;
	}

	public void setRenderAddUserTypeModalPanel(
			boolean renderAddUserTypeModalPanel) {
		this.renderAddUserTypeModalPanel = renderAddUserTypeModalPanel;
	}

	public boolean isRenderDeleteUserTypeModalPanel() {
		return renderDeleteUserTypeModalPanel;
	}

	public void setRenderDeleteUserTypeModalPanel(
			boolean renderDeleteUserTypeModalPanel) {
		this.renderDeleteUserTypeModalPanel = renderDeleteUserTypeModalPanel;
	}

	public List<UserTypeUI> getDeletedUserTypeList() {
		return deletedUserTypeList;
	}

	public void setDeletedUserTypeList(List<UserTypeUI> deletedUserTypeList) {
		this.deletedUserTypeList = deletedUserTypeList;
	}
	
	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}
	public String getUserTypeName() {
		return this.userTypeName;
	}

	public void setUserTypeName(String name) {
		this.userTypeName = name;
	}

	public Integer getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getUserTypeNameSearchText() {
		return userTypeNameSearchText;
	}

	public void setUserTypeNameSearchText(String userTypeNameSearchText) {
		this.userTypeNameSearchText = userTypeNameSearchText;
	}

	public void setUserTypeList(List<UserTypeUI> userTypeList) {
		this.userTypeList = userTypeList;
	}

	public IUserTypeService getUserTypeService() {
		return userTypeService;
	}

	public void setUserTypeService(IUserTypeService userTypeService) {
		this.userTypeService = userTypeService;
	}


	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.userTypeList = null;
		this.deletedUserTypeList = null;
		this.userTypeNameSearchText = null;
		this.allChecked = false;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = 10;
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}
}
