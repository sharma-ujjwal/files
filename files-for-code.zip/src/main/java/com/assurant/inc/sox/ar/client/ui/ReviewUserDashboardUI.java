package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.ReviewUserDashboardDTO;

public class ReviewUserDashboardUI extends ReviewUserUI {
	private ReviewUserDashboardDTO dto;

	public ReviewUserDashboardUI(ReviewUserDashboardDTO dto) {
		super(dto);
		this.dto = dto;
	}

	public String getName() {
		return this.dto.getUserName();
	}

	public String getDepartment() {
		return this.dto.getDepartmentName();
	}

	public String getDivision() {
		return this.dto.getDivisionName();
	}

	public int getAccesses() {
		return this.dto.getAccessesCount();
	}

	public int getAccepted() {
		return this.dto.getAcceptedCount();
	}

	public int getRejected() {
		return this.dto.getRejectedCount();
	}

	public String getComment() {
		return this.dto.getRejectComment();
	}

	public boolean isNotUserRejected() {
		return !this.dto.isUserRejected();
	}

	public String getStyle() {
		if (this.dto.isUserRejected()) {
			return "line-through;";
		}
		return "none";
	}

	public void setStyle(String style) {
		// No implementation needed
	}
}
