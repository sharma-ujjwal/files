package com.assurant.inc.sox.ar.dto.tasklist;

public interface ILockableTaskList {

}
