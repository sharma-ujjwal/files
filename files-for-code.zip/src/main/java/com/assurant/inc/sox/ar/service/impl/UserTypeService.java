/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IUserTypeService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IUserTypeDao;
import com.assurant.inc.sox.domain.ar.UserType;

 /**
 * @author RuthSchmalz
 */
@Service
public class UserTypeService implements IUserTypeService {
	

	@Autowired
	private IUserTypeDao userTypeDao;
	@Autowired
	private SystemUserDTO systemUser;

	public UserTypeService() {
	}

	public List<UserType> retrieveAllUserTypeByCode(String codeSelect){
		return  this.userTypeDao.findByValue(codeSelect);
	}
	
	public List<UserType> retrieveAllUserTypes() {
		return this.userTypeDao.findAll();
	}
	
	public UserType findDuplicate(String name) {
		return this.userTypeDao.findDuplicate(name);
	}

	public List<UserType> retrieveDeletedUserTypes() {
		return this.userTypeDao.findDeleted();
	}
	
	public List<UserType> retrieveDeletedUserTypesByName(String userTypeNameSearchText) {
		return this.userTypeDao.findDeletedByName(userTypeNameSearchText);
	}


	public List<UserType> retrieveUnassignedUserTypes() {
		return this.userTypeDao.findUnassigned();
	}

	public List<UserType> retrieveUnassignedUserTypesByName(String userTypeNameSearchText) {
		return this.userTypeDao.findUnassignedByName(userTypeNameSearchText);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String userTypeDescription) {
		Date currentDate = new Date();
		
		//Create a UserType record.
		//id, setCreatedBy, setCreatedDate, setLastChangedBy, setLastChangedDate
		// are populated in  AuditInterceptor.java

		UserType userType = new UserType();
		
		userType.setUserTypeDescription(userTypeDescription);
		userType.setDeleteFlag(IFlags.NOT_DELETED);
		userType.setCreatedBy(this.systemUser.getUserId());
		userType.setCreatedDate(currentDate);

		userType.setActiveFromDate(currentDate);
		userType.setActiveToDate(DateUtil.END_OF_TIME);
		
		this.userTypeDao.save(userType);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(UserType userType) {
		Date currentDate = new Date();
		// id, setCreatedBy, setCreatedDate, setLastChangedBy, setLastChangedDate
		// are populated in  AuditInterceptor.java

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		UserType currentUserType = new UserType();
		currentUserType.setUserTypeDescription(userType.getUserTypeDescription());
		currentUserType.setDeleteFlag(IFlags.NOT_DELETED);
		currentUserType.setCreatedBy(userType.getCreatedBy());
		currentUserType.setCreatedDate(userType.getCreatedDate());
		currentUserType.setLastChangedBy(this.systemUser.getUserId());
		currentUserType.setLastChangedDate(currentDate);
		
		
		currentUserType.setActiveFromDate(userType.getActiveFromDate());
		currentUserType.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.userTypeDao.save(currentUserType);
			
		//Create a Deleted UserType record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		// Val says we need to add one sec to the TimeDateStamp 
		userType.setDeleteFlag(IFlags.DELETED);
		userType.setActiveFromDate(currentDate);
		userType.setActiveToDate(currentDate);
		this.userTypeDao.save(userType);
	}

	public boolean canUserTypeBeDeleted(Long id) {
		return this.userTypeDao.canUserTypeBeDeleted(id);
	}
}
