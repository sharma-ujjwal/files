package com.assurant.inc.sox.ar.dto.enums;

public enum WorkOrderField {
	COMMENTS("comments"), CREATE_DATE("createDate"), REASON_CODE("reasonCode"), WORK_ORDER_NUMBER("workOrderNumber"), ACCESS_LINE_NUMBERS(
	    "accessLineNos");

	private final String fieldName;

	private WorkOrderField(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return fieldName;
	}
}
