package com.assurant.inc.sox.ar.dto.enums.reviewUser;

import com.assurant.inc.sox.domain.ar.ReviewUser;

public enum ReviewUserCompletedFlag {

	YES(ReviewUser.COMPLETED_FLAG_YES), NO(null);

	private final String flag;

	private ReviewUserCompletedFlag(String flag) {
		this.flag = flag;
	}

	public String getFlag() {
		
		return flag;
	}

	public String getFlagDisplayValue() {
		return (this.flag == null) ? "No" : "Yes";
	}
}
