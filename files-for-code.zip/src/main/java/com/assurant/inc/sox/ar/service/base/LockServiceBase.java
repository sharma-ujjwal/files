package com.assurant.inc.sox.ar.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.impl.CodeService;
import com.assurant.inc.sox.dao.ar.IProcessLockDao;
import org.springframework.stereotype.Component;

@Component
public class LockServiceBase {

	protected static final Logger logger = LoggerFactory.getLogger(CodeService.class);

	@Autowired
	protected IProcessLockDao lockDao;
	
	@Autowired
	protected SystemUserDTO sessionSystemUser;

	public IProcessLockDao getLockDao() {
		return lockDao;
	}

	public void setLockDao(IProcessLockDao lockDao) {
		this.lockDao = lockDao;
	}

	public SystemUserDTO getSessionSystemUser() {
		return sessionSystemUser;
	}

	public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
		this.sessionSystemUser = sessionSystemUser;
	}

}
