package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;


import javax.faces.component.UISelectOne;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import org.primefaces.PrimeFaces;

import com.assurant.inc.sox.ar.client.admin.ui.EnvironmentUI;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IEnvironmentService;
import com.assurant.inc.sox.domain.ar.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("environmentSummaryBean")
@Scope("session")
public class EnvironmentSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(EnvironmentSummaryBean.class);
	private List<EnvironmentUI> environmentList;
	private List<EnvironmentUI> deletedEnvironmentList = new ArrayList<EnvironmentUI>();
	@Autowired
	@Qualifier("environmentService")
	private IEnvironmentService environmentService;
	private Integer displayAmount = 10;
	private String oldSortColumn;
	private String environmentName;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String environmentNameSearchText;
	private boolean renderAddEnvironmentModalPanel;

	public List<EnvironmentUI> getEnvironmentList() {
		if (environmentList == null || environmentList.isEmpty()) {
			this.refreshList();
		}
		return environmentList;
	}

	// ******* Refresh the List RESET button *******
	public void refreshList() {
		this.environmentList = new ArrayList<EnvironmentUI>();
		
		List<Environment> environmentsRetrieved = new ArrayList<Environment>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.environmentNameSearchText)) {
				environmentsRetrieved = this.environmentService
						.retrieveAllEnvironmentsByName(this.environmentNameSearchText);
			} else {
				environmentsRetrieved = this.environmentService
						.retrieveAllEnvironments();
			}

		} else if (FilterTableCode.DELETED_ROWS.name()
				.equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.environmentNameSearchText)) {
				environmentsRetrieved = this.environmentService
						.retrieveDeletedEnvironmentsByName(this.environmentNameSearchText);
			} else {
				environmentsRetrieved = this.environmentService
						.retrieveDeletedEnvironments();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.environmentNameSearchText)) {
				environmentsRetrieved = this.environmentService
						.retrieveUnassignedByName(this.environmentNameSearchText);
			} else {
				environmentsRetrieved = this.environmentService
						.retrieveUnassignedEnvironments(); // constructor JSF call
			}

		}
		for (Environment environment : environmentsRetrieved) {
			this.environmentList.add(new EnvironmentUI(environment));
		}
		this.doSort();
	}

	// ******* GO button *******
	public String goSearch() {
		refreshList();
		return "";
	}

	// ******* RESET button *******
	public String resetSearch() {
		this.environmentList = null;
		this.environmentNameSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// ******* Filter ListBox *******
	public String switchFilterTables(AjaxBehaviorEvent event) {
		UISelectOne selectOne = (UISelectOne) event.getSource();
        this.activeFilter = (String) selectOne.getValue();
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// ******* List Headers *******
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "name";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(environmentList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}

	public String showAddEnvironmentPanel() {
		this.renderAddEnvironmentModalPanel = true;
		this.environmentName = null;
		PrimeFaces.current().executeScript("PF('addEnvironmentModalAjaxPanelPopupDialog').show();");
		return null;
	}

	public String doCancelSave() {
		logger.debug("doCancelAddEnvironmentPanel() --> being executed.");
		this.renderAddEnvironmentModalPanel = false;
		return null;
	}

	public String doSave() {
		logger.debug("doSaveAddEnvironmentPanel() --> being executed.");
		// Displays error message if reason not provided

		if (!validEnvironmentName()) {
			String message = "Environment name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddEnvironmentModalPanel = true;
			return null;
		}

		this.environmentName = this.environmentName.toUpperCase();

		Environment duplicate = this.environmentService.findDuplicate(environmentName);
		if (duplicate != null) {
			String message = "Environment " + environmentName
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		// Add record on the Environment table
		environmentService.add(environmentName);

		// Display Message.
		String message = "Added Environment " + environmentName;
		JSFUtils.addFacesMessage(message);
		this.refreshList();

		this.renderAddEnvironmentModalPanel = false;
		return "";
	}

	public boolean validEnvironmentName() {
		return (StringUtils.isNotEmpty(environmentName));
	}

	public boolean isRenderAddEnvironmentModalPanel() {
		if (this.renderAddEnvironmentModalPanel) {
			PrimeFaces.current().executeScript("PF('addEnvironmentModalAjaxPanelPopupDialog').show();");
		} else {
			PrimeFaces.current().executeScript("PF('addEnvironmentModalAjaxPanelPopupDialog').hide();");
		}
		return renderAddEnvironmentModalPanel;
	}

	public void setRenderAddEnvironmentModalPanel(
			boolean renderAddEnvironmentModalPanel) {
		this.renderAddEnvironmentModalPanel = renderAddEnvironmentModalPanel;
	}

	public List<EnvironmentUI> getDeletedEnvironmentList() {
		return deletedEnvironmentList;
	}

	public void setDeletedEnvironmentList(
			List<EnvironmentUI> deletedEnvironmentList) {
		this.deletedEnvironmentList = deletedEnvironmentList;
	}

	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}

	public String getEnvironmentName() {
		return this.environmentName;
	}

	public void setEnvironmentName(String name) {
		this.environmentName = name;
	}

	public Integer getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getEnvironmentNameSearchText() {
		return environmentNameSearchText;
	}

	public void setEnvironmentNameSearchText(String environmentNameSearchText) {
		this.environmentNameSearchText = environmentNameSearchText;
	}

	public void setEnvironmentList(List<EnvironmentUI> environmentList) {
		this.environmentList = environmentList;
	}

	public IEnvironmentService getEnvironmentService() {
		return environmentService;
	}

	public void setEnvironmentService(IEnvironmentService environmentService) {
		this.environmentService = environmentService;
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.environmentList = new ArrayList<>();
		this.deletedEnvironmentList = null;
		this.environmentNameSearchText = null;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = 10;
	}
}

