package com.assurant.inc.sox.ar.dto.enums.tasklist;

public enum TaskListFilterType {
	REVIEW_TYPE("Review Type", false, false),
	TASK_NAME("Task", false, false),
	ASSIGNED_TO("Assigned To", true, true);

	private final String value;
	/**
	 * true, if the comparison is text based rather than from a drop-down
	 */
	private final boolean text;
	/**
	 * true, if the comparison should be if the comparison should be made with
	 * contains instead of startsWith.
	 */
	private final boolean containsCompare;

	private TaskListFilterType(String value, boolean text, boolean containsCompare) {
		this.value = value;
		this.text = text;
		this.containsCompare = containsCompare;
	}

	public String getDisplayValue() {
		return this.value;
	}
	
	public boolean isText() {
		return this.text;
	}

	public String getCode() {
		return this.value;
	}
	
	public boolean isContainsCompare() {
		return this.containsCompare;
	}

	public static TaskListFilterType getByCodeValue(String codeValue) {
		TaskListFilterType result = null;
		for(TaskListFilterType code : TaskListFilterType.values()){
			if(code.value.equalsIgnoreCase(codeValue)){
				result = code;
				break;
			}
		}
		return result;
	}
}
