package com.assurant.inc.sox.ar.dto.enums.reviewUser;

public enum ReviewUserField {
	NAME("userName"), DEPT("departmentName"), MANAGER_NAME("managerName"), COMPLETED("completedDisplay"), REJECT_DATE(
	    "reviewUserStatusDate"), REJECT_CODE("rejectCodeDisplay"), REJECT_COMMENTS("reviewUserComment"),
	    DIVISION("divisionName");

	private final String fieldName;

	private ReviewUserField(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return fieldName;
	}
}
