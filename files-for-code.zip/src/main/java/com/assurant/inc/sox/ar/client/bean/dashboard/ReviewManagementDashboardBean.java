package com.assurant.inc.sox.ar.client.bean.dashboard;

import java.util.ArrayList;
import java.util.List;



import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewDashboardUI;
import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.utils.NavigationUtility;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

@Component("reviewManagementDashboardBean")
@Scope("session")
public class ReviewManagementDashboardBean {
	
	private static final Logger logger = LoggerFactory.getLogger(ReviewManagementDashboardBean.class);

	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;
	private String oldSortColumnForCompleted = "";
	private String oldSortColumnForOutstanding = "";
	private List<ReviewDashboardUI> outstandingReviews;
	private List<ReviewDashboardUI> completedReviews;
	private Integer displayAmountForOutstanding = 10;
	private Integer displayAmountForCompleted = 10;
	private DataTable outstandingReviewsTable;
	private DataTable completedReviewsTable;

	public ReviewManagementDashboardBean() {
		super();
	}
	
	public void clear() {
		outstandingReviews = null;
		completedReviews = null;
	}

	public String doSelectOutstandingReview(ActionEvent event) {
		logger.debug("doSelectOutstandingReview() --> being executed.");
		// Get the DataTable component from the event
		UIComponent component = event.getComponent();
		setOutstandingReviewsTable((DataTable)component.findComponent("outstandingReviewsTable"));

		ReviewDashboardUI ui = (ReviewDashboardUI) outstandingReviewsTable.getRowData();
		ReviewDashboardBean bean = (ReviewDashboardBean) JSFUtils.lookupBean("reviewDashboardBean");
		bean.initReview(ui);

		var navigationHandler = NavigationUtility.getNavigationHandlerInstance();
		navigationHandler.handleNavigation(NavigationUtility.getFacesContextInstance(), null, "selectReview");

		return "selectReview";
	}

	public void doSelectCompletedReview(ActionEvent event) {
		logger.debug("doSelectCompletedReview() --> being executed.");

		// Get the DataTable component from the event
		UIComponent component = event.getComponent();
		setCompletedReviewsTable((DataTable)component.findComponent("completedReviewsTable"));

		ReviewDashboardUI ui = (ReviewDashboardUI) completedReviewsTable.getRowData();
		ReviewDashboardDTO dto = ui.getReviewDashboardDTO();
		getReviewService().calculateStatistics(dto);
		ReviewDashboardBean bean = (ReviewDashboardBean) JSFUtils.lookupBean("reviewDashboardBean");
		bean.initReview(ui);

		var navigationHandler = NavigationUtility.getNavigationHandlerInstance();
		navigationHandler.handleNavigation(NavigationUtility.getFacesContextInstance(), null, "selectReview");
	}

	public void doSort() {
		logger.debug("doSort() --> being executed.");
		final String table = JSFUtils.getParameter("table");
		final String column = JSFUtils.getParameter("column");
		if ("completedReviews".equals(table)) {
			CommonPageActionHelper.sortListByField(completedReviews, column, oldSortColumnForCompleted);
			oldSortColumnForCompleted = column;
		} else {
			CommonPageActionHelper.sortListByField(outstandingReviews, column, oldSortColumnForOutstanding);
			oldSortColumnForOutstanding = column;
		}
	}

	public List<ReviewDashboardUI> getCompletedReviews() {
		if (completedReviews == null) {
			completedReviews = loadCompletedReviews();
		}
		return completedReviews;
	}

	public DataTable getCompletedReviewsTable() {
		return completedReviewsTable;
	}

	public Integer getDisplayAmountForCompleted() {
		return displayAmountForCompleted;
	}

	public Integer getDisplayAmountForOutstanding() {
		return displayAmountForOutstanding;
	}

	public List<ReviewDashboardUI> getOutstandingReviews() {
		if (outstandingReviews == null) {
			outstandingReviews = loadOutstandingReviews();
		}
		return outstandingReviews;
	}

	public DataTable getOutstandingReviewsTable() {
		return outstandingReviewsTable;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public List<ReviewDashboardUI> loadCompletedReviews() {
		logger.debug("loadCompletedReviews() --> being executed.");
		List<ReviewDashboardDTO> dtos = reviewService.retrieveCompletedDashboardReviews();
		List<ReviewDashboardUI> results = new ArrayList<ReviewDashboardUI>(dtos.size());
		for (ReviewDashboardDTO dto : dtos) {
			results.add(new ReviewDashboardUI(dto));
		}
		CommonPageActionHelper.sortListByField(results, "name", "");
		this.oldSortColumnForCompleted = "name";
		return results;
	}

	public List<ReviewDashboardUI> loadOutstandingReviews() {
		logger.debug("loadOutstandingReviews() --> being executed.");
		List<ReviewDashboardDTO> dtos = reviewService.retrieveOutstandingDashboardReviews();
		List<ReviewDashboardUI> results = new ArrayList<ReviewDashboardUI>(dtos.size());
		for (ReviewDashboardDTO dto : dtos) {
			results.add(new ReviewDashboardUI(dto));
		}
		CommonPageActionHelper.sortListByField(results, "name", "");
		this.oldSortColumnForOutstanding = "name";
		return results;
	}

	public void setCompletedReviewsTable(DataTable completedReviewsTable) {
		this.completedReviewsTable = completedReviewsTable;
	}

	public void setDisplayAmountForCompleted(Integer displayAmountForCompleted) {
		this.displayAmountForCompleted = displayAmountForCompleted;
	}

	public void setDisplayAmountForOutstanding(Integer displayAmountForOutstanding) {
		this.displayAmountForOutstanding = displayAmountForOutstanding;
	}

	public void setOutstandingReviewsTable(DataTable outstandingReviewsTable) {
		this.outstandingReviewsTable = outstandingReviewsTable;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}
}
