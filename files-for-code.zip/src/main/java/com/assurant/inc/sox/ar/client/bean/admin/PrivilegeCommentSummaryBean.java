package com.assurant.inc.sox.ar.client.bean.admin;

import com.assurant.inc.sox.ar.client.admin.ui.PrivilegeCommentUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IExtractSystemService;
import com.assurant.inc.sox.ar.service.IPrivilegeCommentService;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ExtractSystem;
import com.assurant.inc.sox.domain.ar.FunctionDuty;
import com.assurant.inc.sox.domain.luad.PrivilegeComment;
import com.assurant.inc.sox.domain.luad.PrivilegeCommentPk;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

@Component("privilegeCommentSummaryBean")
@Scope("session")
public class PrivilegeCommentSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(PrivilegeCommentSummaryBean.class);
	private List<PrivilegeCommentUI> privilegeCommentList;
	private List<PrivilegeCommentUI> deletedPrivilegeCommentList = new ArrayList<PrivilegeCommentUI>();
	private List<PrivilegeCommentUI> duplicatePrivilegeCommentList = new ArrayList<PrivilegeCommentUI>();
	private List<PrivilegeCommentUI> bulkUpdateList = new ArrayList<PrivilegeCommentUI>();
	private boolean renderBulkUpdatePanel;
	private PrivilegeComment updatePrivComment;
	
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String soxConcernFilter = "?";
	private String privDescriptionFilter;
	private String privValueFilter;
	private Long functionDutyIdFilter;
	private String applicationNameFilter;
	private Long extractSystemIdFilter;

	public Long getExtractSystemIdFilter() {
		return extractSystemIdFilter;
	}

	public void setExtractSystemIdFilter(Long extractSystemIdFilter) {
		this.extractSystemIdFilter = extractSystemIdFilter;
	}

	public String getSoxConcernFilter() {
		return soxConcernFilter;
	}

	public void setSoxConcernFilter(String soxConcernFilter) {
		this.soxConcernFilter = soxConcernFilter;
	}

	public String getPrivDescriptionFilter() {
		return privDescriptionFilter;
	}

	public void setPrivDescriptionFilter(String privDescriptionFilter) {
		this.privDescriptionFilter = privDescriptionFilter;
	}

	public String getPrivValueFilter() {
		return privValueFilter;
	}

	public void setPrivValueFilter(String privValueFilter) {
		this.privValueFilter = privValueFilter;
	}

	public Long getFunctionDutyIdFilter() {
		return functionDutyIdFilter;
	}

	public void setFunctionDutyIdFilter(Long functionDutyIdFilter) {
		this.functionDutyIdFilter = functionDutyIdFilter;
	}

	public String getApplicationNameFilter() {
		return applicationNameFilter;
	}

	public void setApplicationNameFilter(String applicationNameFilter) {
		this.applicationNameFilter = applicationNameFilter;
	}

	@Autowired
	@Qualifier("privilegeCommentService")
	private IPrivilegeCommentService privilegeCommentService;
	private String displayAmount = "10";
	private String oldSortColumn;
	//private String userNameSearchText;
	private boolean renderAddPrivilegeCommentModalPanel;
	private boolean renderDeletePrivilegeCommentModalPanel;
	private boolean renderUpdatePrivilegeCommentModalPanel;
	private boolean renderUpdateFieldsPanelModalPanel;
	private boolean renderDuplicatePrivilegeComment;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private boolean allChecked;
	private String pageNumber = "1";
	private String 	lastPageNumber= "1";
	private DataScroller dataScroller;
	
	private String deleteFlag;
	private Date extractDate;
	private String comment;
	private Long extractSystemId;
	private Date effectiveFromDate;
	private Date effectiveToDate;
	private String lastChangedBy;
	private Date lastChangedDate;
	private String createdBy;
	private Date createdDate;
	
	private String soxConcern = "?";
	private String privDescription;
	private String privValue;
	private Long functionDutyId;
	private String applicationName;
	private List<SelectItem> availableFunctionDuties;
	private List<SelectItem> availableSOXConcerns;
	private List<SelectItem> availableApplicationNames;
	private List<SelectItem> availableExtractSystems;
	private IExtractSystemService extractSystemService;
	private List<SelectItem> availableFilters;

	//bulk fields
	private String bulkSoxConcern;
	private Long bulkFunctionDutyId;
	private String bulkAppName;
	private String bulkComment;

	
	
	public IExtractSystemService getExtractSystemService() {
		return extractSystemService;
	}

	public void setExtractSystemService(IExtractSystemService extractSystemService) {
		this.extractSystemService = extractSystemService;
	}

	public List<PrivilegeCommentUI> getPrivilegeCommentList() {
		
		if (privilegeCommentList == null) {
			refreshList(true);
		}
		
		return privilegeCommentList;
	}

	public List<SelectItem> getAvailableApplicationNames(){
		List<Application> apps = this.privilegeCommentService.retrieveApplications();

		//Sort 
		Collections.sort(apps, new Comparator<Application>() {
			public int compare(Application app1, Application app2) {
				return app1.getName().compareTo(app2.getName());
			}
		});

		this.availableApplicationNames = new ArrayList<SelectItem>();
		this.availableApplicationNames.add(new SelectItem("",""));
		for(Application app : apps){
			if(app.getName()!=null)
				this.availableApplicationNames.add(new SelectItem(app.getName(), app.getName()));
		}
		
		return this.availableApplicationNames;
	}

	public List<SelectItem> getAvailableSOXConcerns(){
		List<String> SOXConcerns = this.privilegeCommentService.retrieveDistinctSOXConcerns();
		
		//Sort 
		Collections.sort(SOXConcerns, new Comparator<String>() {
			public int compare(String sox1, String sox2) {
				return sox1.compareTo(sox2);
			}
		});

		this.availableSOXConcerns = new ArrayList<SelectItem>();
		this.availableSOXConcerns.add(new SelectItem("",""));
		for(String SOXConcern:SOXConcerns){
			if(SOXConcern!=null)
				this.availableSOXConcerns.add(new SelectItem(SOXConcern, SOXConcern));
		}
		return this.availableSOXConcerns;
	}

	public List<SelectItem> getAvailableFunctionDuties(){

		List<FunctionDuty> dutyList = this.privilegeCommentService.retrieveFunctionDuties();
		//Sort 
		Collections.sort(dutyList, new Comparator<FunctionDuty>() {
			public int compare(FunctionDuty duty1, FunctionDuty duty2) {
				return duty1.getId().compareTo(duty2.getId());
			}
		});

		this.availableFunctionDuties = new ArrayList<SelectItem>();
		this.availableFunctionDuties.add(new SelectItem("",""));
		for(FunctionDuty functionDuty: dutyList){
			if(functionDuty.getDescription()!=null)
				this.availableFunctionDuties.add(new SelectItem(functionDuty.getId(), 
					functionDuty.getId()+" - "+functionDuty.getDescription()));
		}
		return this.availableFunctionDuties;
	}

	public List<SelectItem> getAvailableExtractSystems(){
		List<ExtractSystem> extractSys = this.privilegeCommentService.retrieveExtractSystems();
		//Sort 
		Collections.sort(extractSys, new Comparator<ExtractSystem>() {
			public int compare(ExtractSystem sys1, ExtractSystem sys2) {
				return sys1.getExtrctSysId().compareTo(sys2.getExtrctSysId());
			}
		});

		this.availableExtractSystems = new ArrayList<SelectItem>();
		this.availableExtractSystems.add(new SelectItem("-1","Please select"));

		for(ExtractSystem es : extractSys ){
			if (es.getExtrctSysNm()!=null)
				this.availableExtractSystems.add(new SelectItem(es.getExtrctSysId(),
						es.getExtrctSysId()+" - "+es.getExtrctSysNm()));
		}
		return this.availableExtractSystems;
	}

	// ******* Refresh the List  RESET button *******
	public void refreshList(boolean resort) {
		oldSortColumn = "";
		this.privilegeCommentList = new ArrayList<PrivilegeCommentUI>();
		allChecked = false;
		boolean searchForDuplicate = false;
		List<PrivilegeComment> privilegeCommentsRetrievedList = new ArrayList<PrivilegeComment>();

		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			privilegeCommentsRetrievedList = this.privilegeCommentService.findByFilters(true,
					this.soxConcernFilter, this.applicationNameFilter, this.privDescriptionFilter, 
					this.privValueFilter, this.functionDutyIdFilter, this.extractSystemIdFilter);
		}  
		else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			privilegeCommentsRetrievedList = this.privilegeCommentService.findByFilters(false,
					this.soxConcernFilter, this.applicationNameFilter, this.privDescriptionFilter, 
					this.privValueFilter, this.functionDutyIdFilter, this.extractSystemIdFilter);
		} else 
			privilegeCommentsRetrievedList = this.privilegeCommentService.retrieveAll();
	
		for (PrivilegeComment privilegeComment : privilegeCommentsRetrievedList) {
			this.privilegeCommentList.add(new PrivilegeCommentUI(privilegeComment));
		}
		if (resort)
		    this.doSort();

	}

	public boolean isBlankValueSelected(List multiList){
		if(multiList.size() == 1 && StringUtils.isBlank(multiList.get(0).toString()))
			return true;
		else
			return false;
	}

	// ******* GO button *******	
	public String goSearch() {
		

		if(this.soxConcernFilter !=null  && StringUtils.isNotBlank(this.soxConcernFilter))
			if(this.soxConcernFilter.equals("?")){
				System.out.println("In SOX Concern Filter ?**");
			refreshList(true);
			return "";
		}

		int filterCounter=0;
		if(this.privDescriptionFilter!=null && !"".equals(this.privDescriptionFilter))
			filterCounter++;
		System.out.println("In privDescriptionFilte" + privDescriptionFilter);
		if(this.privValueFilter!=null && !"".equals(this.privValueFilter))
			filterCounter++;
		System.out.println("In privValueFilter" + privValueFilter);
		if(this.functionDutyIdFilter!=null && this.functionDutyIdFilter!=0)
			filterCounter++;
		System.out.println("In functionDutyIdFilter" + functionDutyIdFilter);
		if(this.applicationNameFilter!=null && !"".equals(this.applicationNameFilter))
			filterCounter++;
		System.out.println("In applicationNameFilter" + applicationNameFilter);
		if(this.extractSystemIdFilter ==-1){
			this.extractSystemIdFilter=null;
		}
		if(this.extractSystemIdFilter!=null &&!"".equals(this.extractSystemIdFilter))
			filterCounter++;
		System.out.println("In extractSystemIdFilter" + extractSystemIdFilter);
		if(this.soxConcernFilter!=null && !"".equals(this.soxConcernFilter))
			filterCounter++;
		System.out.println("In soxConcernFilter" + soxConcernFilter);

		if ( filterCounter >= 2){ 
			refreshList(true);
			System.out.println("In filter count" + filterCounter);
		}
		else{
			String message = "Please enter at least two search criteria OR Select SoxConcern as ?";
			FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
			return "";
		}
		refreshList(true);
		return "";
	}

	// ********** INIT method *****
	public void init() {
		this.privilegeCommentList = null;
		this.allChecked = false;
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.soxConcernFilter = "?";
		this.extractSystemIdFilter = null;
		this.privDescriptionFilter = null;
		this.privValueFilter = null;
		this.applicationNameFilter = null;
		this.functionDutyIdFilter = null;
		this.oldSortColumn = null;
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		//this.userNameSearchText = null;
		this.deleteFlag = null;
		this.extractDate = null;
		this.comment = null;
		this.extractSystemId = null;
		this.soxConcern = null;
		this.privDescription = null;
		this.privValue = null;
		this.functionDutyId = null;
		this.applicationName = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.functionDutyIdFilter = null;
		this.applicationNameFilter = null;
		this.privDescriptionFilter = null;
		this.privValueFilter = null;
		this.extractSystemIdFilter = null;
		this.soxConcernFilter = "?";
		this.privilegeCommentList = null;
		this.oldSortColumn = null;
		return "";
	}
	
	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		//this.userNameSearchText = null;
		refreshList(true);
		this.clearSelections();
		return "";
	}
	
	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = Integer.parseInt(displayAmount);
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)privilegeCommentList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), privilegeCommentList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				privilegeCommentList.get(currRow).setChecked(true);
			}
		} else {
			for (PrivilegeCommentUI privilegeCommentUI : this.privilegeCommentList) {
				privilegeCommentUI.setChecked(false);
			}
		}
	}
	

	// *******  List Headers *******	
	public void doSort() {
		final String column = (JSFUtils.getParameter("column") == null ? "soxConcern" : JSFUtils.getParameter("column"));
		CommonPageActionHelper.sortListByField(privilegeCommentList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}

	public void doDisplayRowListener() {
		logger
				.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.pageNumber = "1";
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}


	public List<PrivilegeCommentUI> getDeletedPrivilegeCommentList() {
		return deletedPrivilegeCommentList;
	}

	public void setDeletedPrivilegeCommentList(
			List<PrivilegeCommentUI> deletedPrivilegeCommentList) {
		this.deletedPrivilegeCommentList = deletedPrivilegeCommentList;
	}

	private void clearSelections() {
		this.allChecked = false;
		for (PrivilegeCommentUI privilegeCommentUI : this.privilegeCommentList) {
			privilegeCommentUI.setChecked(false);
		}
	}
	
	private void clearFields(){
		this.privDescription = "";
		this.privValue = "";
		this.comment = "";
		this.functionDutyId = null;
		this.soxConcern = null;
		this.applicationName = null;
	}

	// ******* Add PrivilegeComment Panel *******
	public String showAddPrivilegeCommentPanel(){
		this.clearFields();
		this.renderAddPrivilegeCommentModalPanel = true;
		this.renderDuplicatePrivilegeComment = false;
		this.clearSelections();
		return null;
	}
	// ******* Add PrivilegeComment Panel CANCEL *******
	public String doCancelAddPrivilegeCommentPanel(){
		this.renderAddPrivilegeCommentModalPanel = false;
		this.clearSelections();
		this.resetSearch();
		return null;
	}
	
	// ******* Add PrivilegeComment Panel SAVE *******
	public String doAddPrivilegeComment(){
		boolean blankField=false;		
		boolean searchForDuplicate =true;
		List<PrivilegeComment> privilegeCommentsRetrievedList = new ArrayList<PrivilegeComment>();
		if(StringUtils.isBlank(privDescription)){
			
			String message = "Privilege Description is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}
		
		if(StringUtils.isBlank(privValue)){
			String message = "Privilege Value is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		
		if(functionDutyId == null){
			String message = "FunctionDutyId is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(comment)){
			String message = "Privilege Comment is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(soxConcern)){
			String message = "SOX Concern is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(applicationName)){
			String message = "Application Name is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(blankField){
			this.renderAddPrivilegeCommentModalPanel = true;
			return null;
		}
		this.soxConcern = this.soxConcern.toUpperCase();
		this.privDescription = this.privDescription.toUpperCase();
		this.privValue = this.privValue.toUpperCase();
		this.applicationName = this.applicationName.toUpperCase();
		this.comment = this.comment.toUpperCase();

		if (!this.privilegeCommentService.isDuplicate(this.privDescription,this.privValue,false)){
			this.privilegeCommentService.add(this.privDescription,this.privValue,
					this.functionDutyId,this.comment,this.soxConcern,this.applicationName);
			this.renderDuplicatePrivilegeComment = false;
			this.renderAddPrivilegeCommentModalPanel= false;
			// Display Message.
			String message = "Added Privilege Comment ";
			FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(message));
			this.resetSearch();
//			((PrivilegeCommentSummaryBean) JSFUtils.lookupBean("privilegeCommentSummaryBean"))
	//						.refreshList(true);
		}else{
			JSFUtils.addFacesErrorMessage("Priv Comment already exists");
		}
		
		return null;
	}
	// ******* Delete priv comment Panel *******
	public String showDeletePrivilegeCommentPanel(){
		for(PrivilegeCommentUI ui: this.privilegeCommentList){
			if(ui.isChecked()){
				if(this.privilegeCommentService.isActivePrivilegeComment(ui.getPrivilegeComment()))
					this.deletedPrivilegeCommentList.add(ui);
				else{
					String message = "Please select active Privilege Comment.";
					FacesContext.getCurrentInstance().addMessage(message,
							new FacesMessage(message));
					return null;
				}
			}
		}
		if(this.deletedPrivilegeCommentList.isEmpty()){
			String message = "Please select at least one Privilege Comment.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		}
		else{
			this.renderDeletePrivilegeCommentModalPanel = true;
		}
		return null;
	}
	// ******* Delete PrivilegeComment Panel DELETE *******
	public String doDelete(){
		for(PrivilegeCommentUI ui: this.deletedPrivilegeCommentList){
			//commented check to User Access table SDY050_USER_ACCESS
			if(!this.privilegeCommentService.isAccessActive(ui.getValue(), ui.getDescription())){
				this.privilegeCommentService.delete(ui.getPrivilegeComment());
				String msg = "PrivComment: " + ui.getValue() +" - " 
					+ ui.getDescription() +" deleted.";
				FacesContext.getCurrentInstance().addMessage(msg, new FacesMessage(msg));
			}
			else{
				String msg = "PrivComment: " + ui.getValue() +" - " 
					+ ui.getDescription() +" is still active in UserAccess (50) table.";
				FacesContext.getCurrentInstance().addMessage(msg, new FacesMessage(msg));
			}
				
		}
		
		this.deletedPrivilegeCommentList= new ArrayList<PrivilegeCommentUI>();
		this.renderDeletePrivilegeCommentModalPanel = false;
		refreshList(true);
		return null;
	}
	
	// ******* Delete PrivilegeComment Panel CANCEL *******
	public String doCancelDelete() {
		
		this.deletedPrivilegeCommentList= new ArrayList<PrivilegeCommentUI>();
		this.renderDeletePrivilegeCommentModalPanel = false;
		return null;
	}

	// ******* Update Priv comments Panel *******
	public String showUpdatePrivilegeCommentPanel(){
		int selectedItems=0;
		for(PrivilegeCommentUI ui: this.privilegeCommentList){
			if(ui.isChecked()){
				if(this.privilegeCommentService.isActivePrivilegeComment(ui.getPrivilegeComment())){
					selectedItems++;
					this.updatePrivComment = ui.getPrivilegeComment();
					this.privDescription = this.updatePrivComment.getPk().getDescription();
					this.privValue = this.updatePrivComment.getPk().getValue();
					this.functionDutyId = this.updatePrivComment.getPk().getFunctionDutyId();
					this.soxConcern = this.updatePrivComment.getSoxConcern();
					this.comment = this.updatePrivComment.getComment();
					this.applicationName = this.updatePrivComment.getApplicationName();
				}else{
					String message = "Please select active Privilege Comment.";
					FacesContext.getCurrentInstance().addMessage(message,
							new FacesMessage(message));
					return null;
				}
			}
		}
		if(selectedItems == 1 )
			this.renderUpdatePrivilegeCommentModalPanel = true;
		else{
			String message = "Please select one Privilege Comment.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		}
		return null;
	}
	// ******* Update PrivilegeComment Panel Update *******
	public String doUpdate(){
		boolean blankField=false;		
		
		if(this.functionDutyId == null){
			String message = "FunctionDutyId is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(this.comment)){
			String message = "Privilege Comment is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(this.soxConcern)){
			String message = "SOX Concern is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(StringUtils.isBlank(this.applicationName)){
			String message = "Application Name is required";
			JSFUtils.addFacesErrorMessage(message);
			blankField = true;
		}	
		if(blankField){
			this.renderUpdatePrivilegeCommentModalPanel = true;
			return null;
		}

		// update using query
		this.privilegeCommentService.updatePrivComment(this.updatePrivComment, this.privValue, 
				this.privDescription, this.comment, 
				this.functionDutyId, this.soxConcern, this.applicationName);
		
		//Display message
		String message = "Updated PrivilegeComment row ";
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(message));
		((PrivilegeCommentSummaryBean)JSFUtils.lookupBean("privilegeCommentSummaryBean")).refreshList(false);
		
		this.renderUpdatePrivilegeCommentModalPanel = false;
		refreshList(true);
		return null;
	}
	
	// ******* Update PrivilegeComment Panel CANCEL *******
	public String doCancelUpdate() {
		this.renderUpdatePrivilegeCommentModalPanel = false;
		return null;
	}

	public boolean isDeleteEnabled() {
		//return (privilegeCommentList.size()>1);
		return true;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public void setPrivilegeCommentList(List<PrivilegeCommentUI> privilegeCommentList) {
		this.privilegeCommentList = privilegeCommentList;
	}

	public IPrivilegeCommentService getPrivilegeCommentService() {
		return privilegeCommentService;
	}

	public void setPrivilegeCommentService(IPrivilegeCommentService privilegeCommentService) {
		this.privilegeCommentService = privilegeCommentService;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public boolean isAllChecked() {
		return allChecked;
	}

	public void setAllChecked(boolean allChecked) {
		this.allChecked = allChecked;
	}

	public boolean isRenderAddPrivilegeCommentModalPanel() {
		return renderAddPrivilegeCommentModalPanel;
	}

	public void setRenderAddPrivilegeCommentModalPanel(
			boolean renderAddPrivilegeCommentModalPanel) {
		this.renderAddPrivilegeCommentModalPanel = renderAddPrivilegeCommentModalPanel;
	}

	public boolean isRenderDeletePrivilegeCommentModalPanel() {
		return renderDeletePrivilegeCommentModalPanel;
	}

	public void setRenderDeletePrivilegeCommentModalPanel(
			boolean renderDeletePrivilegeCommentModalPanel) {
		this.renderDeletePrivilegeCommentModalPanel = renderDeletePrivilegeCommentModalPanel;
	}
	public String getSoxConcern() {
		return soxConcern;
	}

	public void setSoxConcern(String soxConcern) {
		this.soxConcern = soxConcern;
	}

	public String getPrivDescription() {
		return privDescription;
	}

	public void setPrivDescription(String privDescription) {
		this.privDescription = privDescription;
	}

	public Long getFunctionDutyId() {
		return functionDutyId;
	}

	public void setFunctionDutyId(Long functionDutyId) {
		this.functionDutyId = functionDutyId;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getPrivValue() {
		return privValue;
	}
	public void setPrivValue(String privValue) {
		this.privValue = privValue;
	}
	public Long getExtractSystemId() {
		return extractSystemId;
	}
	public void setExtractSystemId(Long extractSystemId) {
		this.extractSystemId = extractSystemId;
	}
	public List<PrivilegeCommentUI> getDuplicatePrivilegeCommentList() {
		return duplicatePrivilegeCommentList;
	}
	public void setDuplicatePrivilegeCommentList(
			List<PrivilegeCommentUI> duplicatePrivilegeCommentList) {
		this.duplicatePrivilegeCommentList = duplicatePrivilegeCommentList;
	}
	public boolean isRenderDuplicatePrivilegeComment() {
		return renderDuplicatePrivilegeComment;
	}
	public void setRenderDuplicatePrivilegeComment(
			boolean renderDuplicatePrivilegeComment) {
		this.renderDuplicatePrivilegeComment = renderDuplicatePrivilegeComment;
	}
	public boolean isRenderUpdatePrivilegeCommentModalPanel() {
		return renderUpdatePrivilegeCommentModalPanel;
	}
	public void setRenderUpdatePrivilegeCommentModalPanel(
			boolean renderUpdatePrivilegeCommentModalPanel) {
		this.renderUpdatePrivilegeCommentModalPanel = renderUpdatePrivilegeCommentModalPanel;
	}
	public boolean isRenderUpdateFieldsPanelModalPanel() {
		return renderUpdateFieldsPanelModalPanel;
	}
	public void setRenderUpdateFieldsPanelModalPanel(
			boolean renderUpdateFieldsPanelModalPanel) {
		this.renderUpdateFieldsPanelModalPanel = renderUpdateFieldsPanelModalPanel;
	}


	public Date getExtractDate() {
		return extractDate;
	}

	public void setExtractDate(Date extractDate) {
		this.extractDate = extractDate;
	}

	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveToDate() {
		return effectiveToDate;
	}

	public void setEffectiveToDate(Date effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}

	public String getLastChangedBy() {
		return lastChangedBy;
	}

	public void setLastChangedBy(String lastChangedBy) {
		this.lastChangedBy = lastChangedBy;
	}

	public Date getLastChangedDate() {
		return lastChangedDate;
	}

	public void setLastChangedDate(Date lastChangedDate) {
		this.lastChangedDate = lastChangedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	// bulk update functionality
	// ******* Update Priv comments Panel *******

	public String showBulkUpdatePanel(){
		
		this.bulkAppName = null;
		this.bulkComment = null;
		this.bulkFunctionDutyId = null;
		this.bulkSoxConcern = null;
		
		for(PrivilegeCommentUI ui: this.privilegeCommentList){
			if(ui.isChecked()){
				this.bulkUpdateList.add(ui);
			}
		}
		if(this.bulkUpdateList.isEmpty()){
			this.renderBulkUpdatePanel = false;
			this.bulkUpdateList = new ArrayList<PrivilegeCommentUI>();
			String message = "Please select at least one Privilege Comment.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		}
		else{
			this.renderBulkUpdatePanel = true;
		}
		return null;
	}
	
	// ******* Update PrivilegeComment Panel *******
	public String doBulkUpdate() {
		// get confirmed list todo bulk update
		List<PrivilegeComment> confirmedList= new ArrayList<PrivilegeComment>();
		PrivilegeComment privCommentRow = null;

		PrivilegeCommentPk privCommentPk = null;
		

		int filterCounter=0;
		if(this.bulkFunctionDutyId!=null)
			filterCounter++;
		if(this.bulkAppName!= null && StringUtils.isNotBlank(this.bulkAppName))
			filterCounter++;
		if(this.bulkSoxConcern!= null && StringUtils.isNotBlank(this.bulkSoxConcern))
			filterCounter++;
		if(this.bulkComment!= null && StringUtils.isNotBlank(this.bulkComment))
			filterCounter++;

		if ( filterCounter == 0) {
			String message = "Please enter at least value to update";
			FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
			this.renderBulkUpdatePanel = true;
			return null;
		}
		boolean isSelectedAtleasetOne = false;
		for (PrivilegeCommentUI ui : this.bulkUpdateList) {
			if (ui.isChecked())
				isSelectedAtleasetOne = true;
		}

		if (!isSelectedAtleasetOne){
			String message = "Please seelct at least one row to update";
			FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
			this.renderBulkUpdatePanel = true;
			return null;
		}

		for (PrivilegeCommentUI ui : this.bulkUpdateList) {
			if (ui.isChecked()) {
				privCommentRow = ui.getPrivilegeComment();
				privCommentPk = privCommentRow.getPk();
				// set values
				//if(this.bulkFunctionDutyId!=null)
				//	privCommentRow.getPk().setFunctionDutyId(this.bulkFunctionDutyId);
				if(this.bulkAppName!= null && StringUtils.isNotBlank(this.bulkAppName))
					privCommentRow.setApplicationName(this.bulkAppName);
				if(this.bulkSoxConcern!= null && StringUtils.isNotBlank(this.bulkSoxConcern))
					privCommentRow.setSoxConcern(this.bulkSoxConcern);
				if(this.bulkComment!= null && StringUtils.isNotBlank(this.bulkComment))
					privCommentRow.setComment(this.bulkComment);

				this.privilegeCommentService.update(privCommentRow);
/*
				this.privilegeCommentService.updatePrivComment(privCommentRow.getPk().getValue(),
						privCommentRow.getPk().getDescription(), this.bulkComment,
						this.bulkFunctionDutyId, this.bulkSoxConcern, this.bulkAppName);
*/
			}
		}
		this.renderBulkUpdatePanel = false;
		this.bulkUpdateList = null;
		// refresh summary page
		refreshList(true);

		return null;
	}

	// ******* Update PrivilegeComment Panel CANCEL *******
	public String doCancelBulkUpdate() {
		
		this.bulkUpdateList= new ArrayList<PrivilegeCommentUI>();
		this.renderBulkUpdatePanel = false;
		return null;
	}
	
	public boolean isRenderBulkUpdatePanel() {
		return renderBulkUpdatePanel;
	}
	public void setRenderBulkUpdatePanel(
			boolean renderBulkUpdatePanel) {
		this.renderBulkUpdatePanel = renderBulkUpdatePanel;
	}

	public List<PrivilegeCommentUI> getBulkUpdateList() {
		return this.bulkUpdateList;
	}

	public boolean isUpdateCheckbox() {
		return true;
	}

	public String getBulkSoxConcern() {
		return bulkSoxConcern;
	}

	public void setBulkSoxConcern(String bulkSoxConcern) {
		this.bulkSoxConcern = bulkSoxConcern;
	}

	public Long getBulkFunctionDutyId() {
		return bulkFunctionDutyId;
	}

	public void setBulkFunctionDutyId(Long bulkFunctionDutyId) {
		this.bulkFunctionDutyId = bulkFunctionDutyId;
	}

	public String getBulkAppName() {
		return bulkAppName;
	}

	public void setBulkAppName(String bulkAppName) {
		this.bulkAppName = bulkAppName;
	}

	public String getBulkComment() {
		return bulkComment;
	}

	public void setBulkComment(String bulkComment) {
		this.bulkComment = bulkComment;
	}

	public List<SelectItem> getAvailableFilters() {
		this.availableFilters = new ArrayList<SelectItem>();
		this.availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		this.availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		return this.availableFilters;
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

} //end PrivilegeCommentSummaryBean


