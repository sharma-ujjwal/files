package com.assurant.inc.sox.ar.client.bean.admin;

import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IDepartmentService;
import com.assurant.inc.sox.ar.service.IDivisionService;
import com.assurant.inc.sox.ar.service.IUserService;
import com.assurant.inc.sox.ar.service.IUserStatusService;
import com.assurant.inc.sox.ar.service.IUserTypeService;
import com.assurant.inc.sox.ar.service.impl.DivisionService;
import com.assurant.inc.sox.ar.service.impl.UserService;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;
import org.apache.commons.lang3.StringUtils;


import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Component("userSummaryBean")
@Scope("session")
public class UserSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(UserSummaryBean.class);
	@Autowired
	@Qualifier("userService")
	private IUserService userService;
	private List<UserUI> userList;
	private User updateUser;

	boolean isInitialLoad = true;
	//filter fields
	private String searchLastName;
	private String searchFirstName;
	private String searchMiddleName;
	private List searchDepartmentId;
	private List searchDivisionId;
	private String searchKeyId;
	private List searchStatus;
	private List searchUserType;
	private List<String> searchCostCenter;
	private List<String> searchBsnssSgmnt;
	private Long searchSupervisorId;
	private boolean showDeleteButton;




	public boolean isShowDeleteButton() {
		return showDeleteButton;
	}

	public void setShowDeleteButton(boolean showDeleteButton) {
		this.showDeleteButton = showDeleteButton;
	}

	public List<String> getSearchCostCenter() {
		return searchCostCenter;
	}

	public void setSearchCostCenter(List<String> searchCostCenter) {
		this.searchCostCenter = searchCostCenter;
	}

	public List<String> getSearchBsnssSgmnt() {
		return searchBsnssSgmnt;
	}

	public void setSearchBsnssSgmnt(List<String> searchBsnssSgmnt) {
		this.searchBsnssSgmnt = searchBsnssSgmnt;
	}

	public List<String> getSearchStatus() {
		return searchStatus;
	}

	public void setSearchStatus(List searchStatus) {
		this.searchStatus = searchStatus;
	}

	public List getSearchUserType() {
		return searchUserType;
	}

	public void setSearchUserType(List searchUserType) {
		this.searchUserType = searchUserType;
	}

	public String getSearchLastName() {
		return searchLastName;
	}

	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}

	public String getSearchFirstName() {
		return searchFirstName;
	}

	public void setSearchFirstName(String searchFirstName) {
		this.searchFirstName = searchFirstName;
	}

	public String getSearchMiddleName() {
		return searchMiddleName;
	}

	public void setSearchMiddleName(String searchMiddleName) {
		this.searchMiddleName = searchMiddleName;
	}

	public List getSearchDepartmentId() {
		return searchDepartmentId;
	}

	public void setSearchDepartmentId(List searchDepartmentId) {
		this.searchDepartmentId = searchDepartmentId;
	}

	public List getSearchDivisionId() {
		return searchDivisionId;
	}

	public void setSearchDivisionId(List searchDivisionId) {
		this.searchDivisionId = searchDivisionId;
	}

	public String getSearchKeyId() {
		return searchKeyId;
	}

	public void setSearchKeyId(String searchKeyId) {
		this.searchKeyId = searchKeyId;
	}

	private Long userId;
	private String lastName;
	private String firstName;
	private String middleName;
	private Long departmentId;
	private Long divisionId;
	private String keyId;
	private Long supervisorId;
	private Long status;
	private Long userType;
	private String costCenter;
	private String deleteFlag;
	private String jobTitle;
	private String emailAddress;
	private String phone;
	private String satStatus;
	private String location;
	private String satAltId1;
	private String satMFId;
	private String satAltId2;
	private String satAltId3;

	private String satGFId;
	private String satCFId;
	private String satLCSId;
	private String satFDMSId;
	private String satSiteMinderId;

	private String satJobRole;
	private String satComment;
	private String bsnssSgmnt;

	private String displayAmount = "10";
	private String oldSortColumn;

	private boolean renderAddUserModalPanel;
	private boolean renderDeleteUserModalPanel;
	private boolean renderUpdateUserModalPanel;
	private boolean renderUpdateSingleUserModalPanel;

	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private DataScroller dataScroller;


	@Autowired
	private IDivisionService divisionService = new DivisionService();
	@Autowired
	private IUserStatusService userStatusService;
	@Autowired
	private IUserTypeService userTypeService;

	private List<SelectItem> availableDepartment;
	private List<SelectItem> availableDivision;
	private List<SelectItem> availableStatus;
	private List<SelectItem> availableUserType;
	//	private List<SelectItem> availableLocation;
//	private List<SelectItem> availableJobTitle;
	private List<SelectItem> availableBusinessSeg;
	private List<SelectItem> availableCostCenter;
	private List<SelectItem> availableFilters;


	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private DataTable updateUserTable;

	private boolean allChecked;
	private String pageNumber = "1";
	private String lastPageNumber = "1";
	private List<UserUI> selectedUserList = new ArrayList<UserUI>();
	private List<SelectItem> supevisorDepartments = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorDivisions = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorCostCenters = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorBusinessSegments = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorJobTitles = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorLocations = new ArrayList<SelectItem>();
	//private List<SelectItem> supevisorUserType = new ArrayList<SelectItem>();
	private List<UserUI> supervisorDirectReports = new ArrayList<UserUI>();


	public List<UserUI> getSupervisorDirectReports() {
		if (this.supervisorDirectReports == null || this.supervisorId == null)
			this.supervisorDirectReports = new ArrayList<UserUI>();
		return this.supervisorDirectReports;
	}

	public void setSupervisorDirectReports(List<UserUI> supervisorDirectReports) {
		this.supervisorDirectReports = supervisorDirectReports;
	}

	@Autowired
	private IDepartmentService departmentService;


	public String getSatMFId() {
		return satMFId;
	}

	public void setSatMFId(String satMFId) {
		this.satMFId = satMFId;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getSatGFId() {
		return satGFId;
	}

	public void setSatGFId(String satGFId) {
		this.satGFId = satGFId;
	}

	public String getSatCFId() {
		return satCFId;
	}

	public void setSatCFId(String satCFId) {
		this.satCFId = satCFId;
	}

	public String getSatLCSId() {
		return satLCSId;
	}

	public void setSatLCSId(String satLCSId) {
		this.satLCSId = satLCSId;
	}

	public String getSatFDMSId() {
		return satFDMSId;
	}

	public void setSatFDMSId(String satFDMSId) {
		this.satFDMSId = satFDMSId;
	}

	public String getSatSiteMinderId() {
		return satSiteMinderId;
	}

	public void setSatSiteMinderId(String satSiteMinderId) {
		this.satSiteMinderId = satSiteMinderId;
	}
/*
	public String getLastNameText() {
		return LastNameText;
	}

	public void setLastNameText(String LastNameText) {
		this.LastNameText = LastNameText;
	}
*/

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}


	public IDepartmentService getDepartmentService() {
		return departmentService;
	}

	public void setDepartmentService(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public IDivisionService getDivisionService() {
		return divisionService;
	}

	public void setDivisionService(IDivisionService divisionService) {
		this.divisionService = divisionService;
	}

	public IUserStatusService getUserStatusService() {
		return userStatusService;
	}

	public void setUserStatusService(IUserStatusService userStatusService) {
		this.userStatusService = userStatusService;
	}

	public IUserTypeService getUserTypeService() {
		return userTypeService;
	}

	public void setUserTypeService(IUserTypeService userTypeService) {
		this.userTypeService = userTypeService;
	}


	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public Long getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(Long divisionId) {
		this.divisionId = divisionId;
	}

	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public Long getSupervisorId() {
		return supervisorId;
	}

	public void setSupervisorId(Long supervisorId) {
		this.supervisorId = supervisorId;
	}

	public Long getSearchSupervisorId() {
		return searchSupervisorId;
	}

	public void setSearchSupervisorId(Long searchSupervisorId) {
		this.searchSupervisorId = searchSupervisorId;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSatStatus() {
		return satStatus;
	}

	public void setSatStatus(String satStatus) {
		this.satStatus = satStatus;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLastPageNumber() {
		return lastPageNumber;
	}

	public void setLastPageNumber(String lastPageNumber) {
		this.lastPageNumber = lastPageNumber;
	}

	public boolean isRenderAddUserModalPanel() {
		return renderAddUserModalPanel;
	}

	public void setRenderAddUserModalPanel(boolean renderAddUserModalPanel) {
		this.renderAddUserModalPanel = renderAddUserModalPanel;
	}

	public boolean isRenderDeleteUserModalPanel() {
		return renderDeleteUserModalPanel;
	}

	public void setRenderDeleteUserModalPanel(boolean renderDeleteUserModalPanel) {
		this.renderDeleteUserModalPanel = renderDeleteUserModalPanel;
	}

	public boolean isRenderUpdateUserModalPanel() {
		return renderUpdateUserModalPanel;
	}

	public void setRenderUpdateUserModalPanel(boolean renderUpdateUserModalPanel) {
		this.renderUpdateUserModalPanel = renderUpdateUserModalPanel;
	}

	public boolean isRenderUpdateSingleUserModalPanel() {
		return renderUpdateSingleUserModalPanel;
	}

	public void setRenderUpdateSingleUserModalPanel(
			boolean renderUpdateSingleUserModalPanel) {
		this.renderUpdateSingleUserModalPanel = renderUpdateSingleUserModalPanel;
	}

	public String getSatAltId1() {
		return satAltId1;
	}

	public void setSatAltId1(String satAltId1) {
		this.satAltId1 = satAltId1;
	}

	public String getSatAltId2() {
		return satAltId2;
	}

	public void setSatAltId2(String satAltId2) {
		this.satAltId2 = satAltId2;
	}

	public String getSatAltId3() {
		return satAltId3;
	}

	public void setSatAltId3(String satAltId3) {
		this.satAltId3 = satAltId3;
	}

	public String getSatJobRole() {
		return satJobRole;
	}

	public void setSatJobRole(String satJobRole) {
		this.satJobRole = satJobRole;
	}

	public String getSatComment() {
		return satComment;
	}

	public void setSatComment(String satComment) {
		this.satComment = satComment;
	}

	public String getBsnssSgmnt() {
		return bsnssSgmnt;
	}

	public void setBsnssSgmnt(String bsnssSgmnt) {
		this.bsnssSgmnt = bsnssSgmnt;
	}

	public List<UserUI> getSelectedUserList() {
		return selectedUserList;
	}

	public void setSelectedUserList(List<UserUI> selectedUserList) {
		this.selectedUserList = selectedUserList;
	}

	public List<UserUI> getUserList() {
		if (this.userList == null) {
			defaultFilters(true);
			if(isInitialLoad){
				this.isInitialLoad = false;
				this.userList = new ArrayList<UserUI>();
			}
			else{
				System.out.println("in getUserList");
				refreshList(true);


			}
		}

		return this.userList;
	}

	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}
	/*
        public String getUserNameSearchText() {
            return userNameSearchText;
        }

        public void setUserNameSearchText(String userNameSearchText) {
            this.userNameSearchText = userNameSearchText;
        }
    */
	public void setUserList(List<UserUI> userList) {
		this.userList = userList;
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	/*
	 * public SessionDataBean getSessionDataBean() { return sessionDataBean; }
	 *
	 * public void setSessionDataBean(SessionDataBean sessionDataBean) {
	 * this.sessionDataBean = sessionDataBean; }
	 */

	public boolean isAllChecked() {
		return allChecked;
	}

	public void setAllChecked(boolean allChecked) {
		this.allChecked = allChecked;
	}

	public List<SelectItem> getSupevisorDepartments() {

		if (supevisorDepartments == null) {
			this.supevisorDepartments = new ArrayList<SelectItem>();
			this.supevisorDepartments.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorDepartments;
	}

	public List<SelectItem> getSupevisorDivisions() {

		if (supevisorDivisions == null) {
			supevisorDivisions = new ArrayList<SelectItem>();
			this.supevisorDivisions.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorDivisions;
	}

	public List<SelectItem> getSupevisorCostCenters() {

		if (supevisorCostCenters == null) {
			supevisorCostCenters = new ArrayList<SelectItem>();
			this.supevisorCostCenters.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorCostCenters;
	}

	public List<SelectItem> getSupevisorBusinessSegments() {

		if (supevisorBusinessSegments == null) {
			supevisorBusinessSegments = new ArrayList<SelectItem>();
			this.supevisorBusinessSegments.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorBusinessSegments;
	}

	public List<SelectItem> getSupevisorJobTitles() {

		if (supevisorJobTitles == null) {
			supevisorJobTitles = new ArrayList<SelectItem>();
			this.supevisorJobTitles.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorJobTitles;
	}

	public List<SelectItem> getSupevisorLocations() {

		if (supevisorLocations == null) {
			supevisorLocations = new ArrayList<SelectItem>();
			this.supevisorLocations.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorLocations;
	}
	/*
	public List<SelectItem> getSupevisorUserType() {

		if (supevisorUserType== null) {
			supevisorUserType = new ArrayList<SelectItem>();
			this.supevisorUserType.add(new SelectItem("Not Available",
					"Not Available"));
		}

		return supevisorUserType;
	}
*/
	public void setSupevisorDepartments(List<SelectItem> supevisorDepartments) {
		this.supevisorDepartments = supevisorDepartments;
	}

	public void setSupevisorDivisions(List<SelectItem> supevisorDivisions) {
		this.supevisorDivisions = supevisorDivisions;
	}

	public void setSupevisorCostCenters(List<SelectItem> supevisorCostCenters) {
		this.supevisorCostCenters = supevisorCostCenters;
	}

	public void setSupevisorBusinessSegments(
			List<SelectItem> supevisorBusinessSegments) {
		this.supevisorBusinessSegments = supevisorBusinessSegments;
	}

	public void setSupevisorJobTitles(List<SelectItem> supevisorJobTitles) {
		this.supevisorJobTitles = supevisorJobTitles;
	}

	public void setSupevisorLocations(List<SelectItem> supevisorLocations) {
		this.supevisorLocations = supevisorLocations;
	}
	/*
        public void setSupevisorUserType(List<SelectItem> supevisorUserType) {
            this.supevisorUserType = supevisorUserType;
        }
    */
	public DataTable getUpdateUserTable() {
		return updateUserTable;
	}

	public void setUpdateUserTable(DataTable updateUserTable) {
		this.updateUserTable = updateUserTable;
	}

	public String showAddUserPanel() {
		this.clearFields();
		this.status = 1L;
		//commented clearselections to improve performance
		//this.clearSelections();
		this.renderAddUserModalPanel = true;
		return null;
	}

	// ******* Add User Panel SAVE *******
	public String doAddUser() {
		System.out.println("In doadduser");
		if (StringUtils.isEmpty(this.keyId)) {
			String message = "Key Id is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Key Id is required.");
		if (StringUtils.isEmpty(this.firstName)) {
			String message = "First Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("First Name is required.");
		if (StringUtils.isEmpty(this.lastName)) {
			String message = "Last Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Last Name is required.");
		if (this.status == null || this.status == 0) {
			String message = "User Status is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("User Status is required.");
		if (this.supervisorId == null || this.supervisorId == 0) {
			String message = "Supervisor is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Supervisor id :" + supervisorId);
		System.out.println("Supervisor is required.");
		if (this.userType == null || this.userType == 0 ) {
			String message = "User Type is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("User type :" + userType);
		System.out.println("User Type is required.");
		if (this.departmentId == null || this.departmentId == 0 ) {
			String message = "Department is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Depatment is:"+ department );
		System.out.println("Department is required.");
		if (this.divisionId == null || this.divisionId == 0) {
			String message = "Division is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Division Id :" + divisionId);
		System.out.println("Division is required.");
		if (StringUtils.isEmpty(this.bsnssSgmnt) ) {
			String message = "Business Segment is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Business Segment:" +bsnssSgmnt );
		System.out.println("Business Segment is required.");


		this.keyId = this.keyId.toUpperCase();
		this.firstName = this.firstName.toUpperCase();
		this.middleName = this.middleName.toUpperCase();
		this.lastName = this.lastName.toUpperCase();
		this.jobTitle = this.jobTitle.toUpperCase();

		String duplicateMsg = this.duplicateMessage(keyId, satMFId, satGFId, satCFId, satLCSId,
				satFDMSId, satSiteMinderId, satAltId1, satAltId2, satAltId3);
		if (!"".equals(duplicateMsg)) {
			JSFUtils.addFacesErrorMessage(duplicateMsg);
			this.renderAddUserModalPanel = true;
			return null;
		}

		String userExistMsg = this.userService.findUserExist(-1L, keyId,
				satMFId, satGFId, satCFId, satLCSId,
				satFDMSId, satSiteMinderId,
				satAltId1, satAltId2, satAltId3);
		if (!"".equals(userExistMsg)) {
			JSFUtils.addFacesErrorMessage(userExistMsg);
			this.renderAddUserModalPanel = true;
			return null;
		}

		this.userService.add(keyId, firstName, middleName, lastName, userType,
				departmentId, divisionId, location, jobTitle, supervisorId,
				bsnssSgmnt, phone, emailAddress, status,
				satMFId, satGFId, satCFId, satLCSId, satFDMSId,
				satSiteMinderId, satAltId1, satAltId2, satAltId3,
				satStatus, satJobRole, satComment);

/*
		this.userService.addUser(keyId, firstName, middleName, lastName, userType,
				departmentId, divisionId, location, jobTitle, supervisorId,
				bsnssSgmnt, phone, emailAddress, status,
				satStatus, satJobRole, satComment, 0L, null);
*/
		Long newUserId = this.userService.findActiveUserIdByKeyId(keyId);

		if(newUserId!=null)
			this.userService.updateAltIds(newUserId, keyId, emailAddress, satMFId, satGFId, satCFId,
					satLCSId, satFDMSId, satSiteMinderId, satAltId1, satAltId2, satAltId3);

		// Display Message.
		String message = "Added User " + lastName + " " + firstName + " "
				+ middleName;

		FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
		this.searchKeyId = keyId;
		this.searchLastName = lastName;
		this.searchFirstName = firstName;
		System.out.println("in 879 line");
		refreshList(false);
		this.renderAddUserModalPanel = false;
		return "added";
	}

	public String duplicateMessage(String keyId, String satMFId,
								   String satGFId, String satCFId, String satLCSId,
								   String satFDMSId, String satSiteminderId,
								   String satAltId1, String satAltId2, String satAltId3){

		satMFId = satMFId==null ? "":satMFId;
		satCFId = satCFId==null ? "": satCFId;
		satGFId = satGFId==null ? "": satGFId;
		satLCSId = satLCSId==null ? "": satLCSId;
		satFDMSId = satFDMSId==null ? "": satFDMSId;
		satSiteminderId = satSiteminderId==null ? "": satSiteminderId;
		satAltId1 = satAltId1==null ? "": satAltId1;
		satAltId2 = satAltId2==null ? "": satAltId2;
		satAltId3 = satAltId3==null ? "": satAltId3;
		if (!"".equals(satMFId)){
			if (
					( satMFId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satCFId) && satMFId.equalsIgnoreCase(satCFId) )
							|| ( !"".equals(satGFId) && satMFId.equalsIgnoreCase(satGFId) )
							|| ( !"".equals(satLCSId) && satMFId.equalsIgnoreCase(satLCSId) )
							|| ( !"".equals(satFDMSId) && satMFId.equalsIgnoreCase(satFDMSId) )
							|| ( !"".equals(satSiteminderId) && satMFId.equalsIgnoreCase(satSiteminderId) )
							|| ( !"".equals(satAltId1) && satMFId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satMFId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satMFId.equalsIgnoreCase(satAltId3) )
					)
				return "SatMFId is duplicate";
		}
		if (!"".equals(satCFId)){
			if (
					( satCFId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satGFId) && satCFId.equalsIgnoreCase(satGFId) )
							|| ( !"".equals(satLCSId) && satCFId.equalsIgnoreCase(satLCSId) )
							|| ( !"".equals(satFDMSId) && satCFId.equalsIgnoreCase(satFDMSId) )
							|| ( !"".equals(satSiteminderId) && satCFId.equalsIgnoreCase(satSiteminderId) )
							|| ( !"".equals(satAltId1) && satCFId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satCFId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satCFId.equalsIgnoreCase(satAltId3) )
					)
				return "SatCFId is duplicate";
		}

		if (!"".equals(satGFId)){
			if (
					( satGFId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satLCSId) && satGFId.equalsIgnoreCase(satLCSId) )
							|| ( !"".equals(satFDMSId) && satGFId.equalsIgnoreCase(satFDMSId) )
							|| ( !"".equals(satSiteminderId) && satGFId.equalsIgnoreCase(satSiteminderId) )
							|| ( !"".equals(satAltId1) && satGFId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satGFId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satGFId.equalsIgnoreCase(satAltId3) )
					)
				return "SatGFId is duplicate";
		}
		if (!"".equals(satLCSId)){
			if (
					( satLCSId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satFDMSId) && satLCSId.equalsIgnoreCase(satFDMSId) )
							|| ( !"".equals(satSiteminderId) && satLCSId.equalsIgnoreCase(satSiteminderId) )
							|| ( !"".equals(satAltId1) && satLCSId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satLCSId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satLCSId.equalsIgnoreCase(satAltId3) )
					)
				return "SatLCSId is duplicate";
		}
		if (!"".equals(satFDMSId)){
			if (
					( satFDMSId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satSiteminderId) && satFDMSId.equalsIgnoreCase(satSiteminderId) )
							|| ( !"".equals(satAltId1) && satFDMSId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satFDMSId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satFDMSId.equalsIgnoreCase(satAltId3) )
					)
				return "SatFDMSId is duplicate";
		}
		if (!"".equals(satSiteminderId)){
			if (
					( satSiteminderId.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satAltId1) && satSiteminderId.equalsIgnoreCase(satAltId1) )
							|| ( !"".equals(satAltId2) && satSiteminderId.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satSiteminderId.equalsIgnoreCase(satAltId3) )
					)
				return "satSiteminderId is duplicate";
		}
		if (!"".equals(satAltId1)){
			if (
					( satAltId1.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satAltId2) && satAltId1.equalsIgnoreCase(satAltId2) )
							|| ( !"".equals(satAltId3) && satAltId1.equalsIgnoreCase(satAltId3) )
					)
				return "SatAltId1 is duplicate";
		}
		if (!"".equals(satAltId2)){
			if (
					( satAltId2.equalsIgnoreCase(keyId) )
							|| ( !"".equals(satAltId3) && satAltId2.equalsIgnoreCase(satAltId3) )
					)
				return "SatAltId1 is duplicate";
		}
		return "";
	}

	// ******* set filter criteria*******
	public void defaultFilters(boolean isDefault) {
		if (isDefault){
			this.keyId = null;
			this.searchSupervisorId = null;
			this.departmentId = null;
			this.lastName = null;
			this.status = 1L;
			this.divisionId = null;
			this.firstName = null;
			this.userType = null;
			this.bsnssSgmnt = null;
			this.costCenter = null;
			// filters
			this.searchLastName = null;
			this.searchFirstName = null;
			this.searchMiddleName = null;
			this.searchKeyId = null;
			this.searchUserType = null;
			this.searchStatus = null;
			this.searchCostCenter = null;
			this.searchBsnssSgmnt = null;
			this.searchDepartmentId = null;
			this.searchDivisionId = null;

			this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		}

	}

	// ******* Refresh the List RESET button *******

	public void refreshList(boolean resort) {
		System.out.println("in 1020 line");
		//	defaultFilters(true);
		oldSortColumn = "";
		this.userList = new ArrayList<UserUI>();
		allChecked = false;
		List<User> usersRetrieved = new ArrayList<User>();

		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			System.out.println("in active row");
			usersRetrieved = this.userService.getUsersFiltered(
					true, this.searchKeyId, this.searchSupervisorId, this.searchFirstName,
					this.searchLastName, this.searchUserType, this.searchStatus, this.searchDepartmentId,
					this.searchDivisionId, this.searchCostCenter, this.searchBsnssSgmnt);

		}
		else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			System.out.println("in deleted row");
			usersRetrieved = this.userService.getUsersFiltered(
					false, this.searchKeyId, this.searchSupervisorId, this.searchFirstName,
					this.searchLastName, this.searchUserType, this.searchStatus, this.searchDepartmentId,
					this.searchDivisionId, this.searchCostCenter, this.searchBsnssSgmnt);
		} else {
			System.out.println("in second else");
			usersRetrieved = this.userService.retrieveAllActiveUsers();
		}
		logger.debug("Varun***Total No. Of Records Fetched from Database: "+ usersRetrieved.size());
		for (User user : usersRetrieved) {
			this.userList.add(new UserUI(user));
		}

		if (resort)
			this.doSort();
	}

	// ******* CLEAR FIELDS ******
	public void clearFields(){
		this.userId = null;
		this.lastName = "";
		this.firstName = "";
		this.middleName = "";
		this.departmentId = null;
		this.divisionId = null;
		this.keyId = "";
		this.supervisorId = null;
		this.populateSupevisorData();
		this.status = null;
		this.userType = null;
		this.costCenter = "";
		//this.deleteFlag = ;
		this.jobTitle = "";
		this.emailAddress = "";
		this.phone = "";
		this.location = "";

		this.satJobRole = "";
		this.bsnssSgmnt = "";
		this.satAltId1 = "";
		this.satAltId2 = "";
		this.satAltId3 = "";
		this.satMFId = "";
		this.satGFId = "";
		this.satCFId = "";
		this.satFDMSId = "";
		this.satLCSId = "";
		this.satSiteMinderId = "";

	}

	// ******* RESET button ******
	public String resetSearch() {
		//this.userNameSearchText = null;
		this.searchKeyId = "";
		this.searchSupervisorId = null;
		this.searchFirstName = "";
		this.searchLastName = "";
		this.searchUserType = null;
		this.searchStatus = null;
		this.searchCostCenter = null;
		this.searchBsnssSgmnt = null;
		this.searchDepartmentId = null;
		this.searchDivisionId = null;
		defaultFilters(true);
		this.userList = new ArrayList<UserUI>();
		System.out.println("in 1104 line");
		//refreshList(true);
		return "";
	}

	// ******* Filter ListBox *******
	public String switchFilterTables() {
		this.oldSortColumn = null;
		//this.userNameSearchText = null;
		System.out.println("in 1113 line");
		refreshList(true);
		this.clearSelections();
		return "";
	}

	// ******* List Headers *******
	public void doSort() {
		final String column = (JSFUtils.getParameter("column") == null ? "name"
				: JSFUtils.getParameter("column"));
		CommonPageActionHelper.sortListByField(userList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}

	public void doDisplayRowListener() {
		logger.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.pageNumber = "1";
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ***************************************
	// Patni**************************************

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked; // toggle true & false

		if (allChecked) {
			int pageSize = Integer.parseInt(displayAmount);
			int intLastPageNumber = Integer.parseInt(lastPageNumber);

			int pageNum;

			// user pressed an arrow "first", "last", "next", "previous",
			// "fastforward", "fastrewind"
			if ("first".equals(pageNumber))
				pageNum = 1;
			else if ("last".equals(pageNumber))
				pageNum = (int) (Math.ceil((double) userList.size() / pageSize));
			else if ("next".equals(pageNumber))
				pageNum = intLastPageNumber + 1;
			else if ("previous".equals(pageNumber))
				pageNum = intLastPageNumber - 1;
			else if ("fastforward".equals(pageNumber))
				pageNum = intLastPageNumber + 1;
			else if ("fastrewind".equals(pageNumber))
				pageNum = intLastPageNumber - 1;
			else
				// user pressed a real number
				pageNum = Integer.parseInt(this.pageNumber);

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math.min((firstRow + pageSize), userList.size());

			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				userList.get(currRow).setChecked(true);
			}
		} else {
			for (UserUI userUI : this.userList) {
				userUI.setChecked(false);
			}
		}
	}

	// ******* Delete Panel *******
	public String showDeleteUserPanel() {
		if (this.selectedUserList == null)
			this.selectedUserList = new ArrayList<UserUI>();
		StringBuilder sb =  new StringBuilder(256);
		for (UserUI ui : this.userList) {
			if (ui.isChecked()) {
				if(!this.userService.isActiveUser(ui.getUserId())){
					String message = "Selected user with key " + ui.getKeyId()
							+" has already been deleted. Please select active row.";
					JSFUtils.addFacesErrorMessage(message);
					return null;
				}
				else if( !"".equals(this.userService.activeReviewsMessage(ui.getUserId()))){
					String msg = " Reviewer " + ui.getName() + " with UserId= " + ui.getUserId()
							+ " has active review(s) " +
							this.userService.activeReviewsMessage(ui.getUserId());
					JSFUtils.addFacesErrorMessage(msg);
					return null;

				}
				else
				if(this.userService.isActiveReviewOwner(ui.getUserId())){
					sb.append("  User: " + ui.getName() + " with UserId= " + ui.getUserId() );
				}
				else
					this.selectedUserList.add(ui);
//				populateSelectedUser(ui);
			}
		}
		if (sb.length() > 0){
			sb.append(" has active records in Review Owner table and cannot be deleted. ");
			JSFUtils.addFacesErrorMessage(sb.toString());
		} else if ((this.selectedUserList==null) || (this.selectedUserList.isEmpty())) {
			String message = "Please select at least one User to delete";
			JSFUtils.addFacesErrorMessage(message);
		} else {
			this.renderDeleteUserModalPanel = true;
		}
		this.clearSelections();

		return null;
	}

	public String showUpdateUserPanel() {
		int selectedItems = 0;
		if (this.selectedUserList == null)
			this.selectedUserList = new ArrayList<UserUI>();
		for (UserUI ui : this.userList) {
			if (ui.isChecked()) {
				selectedItems++;
				this.updateUser = ui.getUser();
				this.selectedUserList.add(ui);
				populateSelectedUser(ui);
			}
		}
		if (selectedItems ==1 ) {
			if(!this.userService.isActiveUser(this.updateUser.getUserId())){
				String message = "Selected user with key " + this.updateUser.getPk().getKeyId()
						+" is Inactive. Please select an Active row to Update.";
				JSFUtils.addFacesErrorMessage(message);
				return null;
			}
			else
				this.renderUpdateUserModalPanel = true;
		}
		else {
			String message = "Please select one User for update";
			JSFUtils.addFacesErrorMessage(message);
		}
		return null;
	}

	// to populate all values for selected user from the UI
	private void populateSelectedUser(UserUI ui) {
		this.userId = ui.getUserId();
		this.lastName = ui.getLastName();
		this.firstName = ui.getFirstName();
		this.middleName = (ui.getMiddleName()!=null)?ui.getMiddleName():"";
		this.departmentId = ui.getDeptID();
		this.divisionId = ui.getDivisionID();
		this.keyId = ui.getKeyId();
		this.supervisorId = ui.getSupervisorId();
		this.status = ui.getUserStatusID();
		this.userType = ui.getUserTypeID();
		this.costCenter = ui.getCostCenter();
		//this.deleteFlag = ;
		this.jobTitle = ui.getJobTitle();
		this.emailAddress = ui.getEmailAddress();
		this.phone = ui.getPhone();
		this.location = ui.getLocation();

		this.satJobRole = ui.getSatJobRole();
		this.bsnssSgmnt = ui.getBusinessSeg();
		this.satAltId1 = ui.getSatAltId1();
		this.satAltId2 = ui.getSatAltId2();
		this.satAltId3 = ui.getSatAltId3();
		this.satMFId = ui.getSatMFId();
		this.satGFId = ui.getSatGFId();
		this.satCFId = ui.getSatCFId();
		this.satFDMSId = ui.getSatFDMSId();
		this.satLCSId = ui.getSatLCSId();
		this.satSiteMinderId = ui.getSatSiteMinderId();

		this.satStatus = ui.getSatStatus();
		this.satComment = ui.getSatComment();

		populateSupevisorData();
	}

	public String doDelete(){
		for(UserUI ui: this.selectedUserList){
			this.userService.delete(ui.getUser());
			//this.userService.updateDirectReportInfo(ui.getUserId());
		}
		//Display message
		String message = "Deleted row(s)";
		FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(message));
		System.out.println("in 1305 line");
		this.refreshList(true);
		this.selectedUserList= new ArrayList<UserUI>();
		this.renderDeleteUserModalPanel = false;
		return null;
	}

	// ******* Delete User Panel CANCEL *******
	public String doCancelDelete() {
		this.selectedUserList = new ArrayList<UserUI>();
		this.renderDeleteUserModalPanel = false;
		this.clearSelections();
		return null;
	}

	// ******* Update User Panel *******
	public String doUpdate() {
		// setValues
		if (StringUtils.isEmpty(this.keyId)) {
			String message = "Key Id is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (StringUtils.isEmpty(this.firstName)) {
			String message = "First Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (StringUtils.isEmpty(this.lastName)) {
			String message = "Last Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (this.status == null) {
			String message = "User Status is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (this.supervisorId == null) {
			String message = "Supervisor is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (this.userType == null) {
			String message = "User Type is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (this.departmentId == null) {
			String message = "Department is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
		if (this.divisionId == null) {
			String message = "Division is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
/*
		if (this.bsnssSgmnt == null) {
			String message = "Business Segment is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderUpdateUserModalPanel = true;
			return null;
		}
*/
		String duplicateMsg = this.duplicateMessage(keyId,
				satMFId, satGFId, satCFId, satLCSId, satFDMSId,
				satSiteMinderId, satAltId1,	satAltId2, satAltId3);
		if (!"".equals(duplicateMsg)) {
			JSFUtils.addFacesErrorMessage(duplicateMsg);
			this.renderUpdateUserModalPanel = true;
			return null;
		}

		String userExistMsg = this.userService.findUserExist(userId, keyId,
				satMFId, satGFId, satCFId, satLCSId,
				satFDMSId, satSiteMinderId,
				satAltId1, satAltId2, satAltId3);
		if (!"".equals(userExistMsg)) {
			JSFUtils.addFacesErrorMessage(userExistMsg);
			this.renderUpdateUserModalPanel = true;
			return null;
		}

		this.userService.updateUser(userId,keyId, firstName, middleName, lastName, userType,
				departmentId, divisionId, location, jobTitle, supervisorId,
				costCenter, bsnssSgmnt, phone, emailAddress, status,
				satMFId, satGFId, satCFId, satLCSId, satFDMSId,
				satSiteMinderId, satAltId1,	satAltId2, satAltId3,
				satStatus, satJobRole, satComment);

		this.userService.updateAltIds(userId,keyId,emailAddress,
				satMFId, satGFId, satCFId, satLCSId, satFDMSId,
				satSiteMinderId, satAltId1,	satAltId2, satAltId3);

		// Display Message.
		String message = "Updated user row for KeyId " + keyId;
		FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
		System.out.println("in 1413 line");
		refreshList(false);

		this.selectedUserList = new ArrayList<UserUI>();
		this.renderUpdateUserModalPanel = false;
		return null;
	}

	public String doSaveUpdates() {
		// this.renderUpdateUserModalPanel = false;
		this.renderUpdateSingleUserModalPanel = false;
		return null;
	}

	// ******* Delete User Panel CANCEL *******
	public String doCancelUpdate() {
		this.selectedUserList = new ArrayList<UserUI>();
		this.renderUpdateUserModalPanel = false;
		this.clearSelections();
		return null;
	}

	private void clearSelections() {
		this.allChecked = false;
		for (UserUI userUI : this.userList) {
			userUI.setChecked(false);
		}
	}

	// ******* Add User Panel CANCEL *******
	public String doCancelAddUser() {
		logger.debug("doCancelAddUserPanel() --> being executed.");
		this.renderAddUserModalPanel = false;
		//this.clearSelections();
		return null;
	}
	public boolean isBlankValueSelected(List multiList){
		if(multiList.size() == 1 && StringUtils.isBlank(multiList.get(0).toString()))
			return true;
		else
			return false;
	}


	// ******* GO button *******
	public String goSearch() {
		System.out.println("inside go search");
		int filterCounter=0;

		if (this.searchKeyId!=null && StringUtils.isNotBlank(this.searchKeyId))
			filterCounter++;
		System.out.println("Filter count in searchKeyId :"+filterCounter );
		if (this.searchSupervisorId!=null && this.searchSupervisorId!=0)
			filterCounter++;
		System.out.println("Filter count in searchSupervisorId :"+filterCounter );
		if (this.searchDepartmentId!=null && this.searchDepartmentId.size()>0)
			if(!isBlankValueSelected(this.searchDepartmentId))
				filterCounter++;
		System.out.println("Filter count in searchDepartmentId :"+filterCounter );
		if (this.searchDivisionId!=null && this.searchDivisionId.size()>0)
			if(!isBlankValueSelected(this.searchDivisionId))
				filterCounter++;
		System.out.println("Filter count in searchDivisionId :"+filterCounter );
		if (this.searchFirstName!=null && StringUtils.isNotBlank(this.searchFirstName))
			filterCounter++;
		System.out.println("Filter count in searchFirstName :"+filterCounter );
		if (this.searchLastName!=null && StringUtils.isNotBlank(this.searchLastName)) {
			logger.debug("Varun****Last Name of User Is :" +this.searchLastName);
			filterCounter++;
			System.out.println("Filter count in searchLastName :"+filterCounter );
		}
		if (this.searchCostCenter!=null && this.searchCostCenter.size()>0)
			if(!isBlankValueSelected(this.searchCostCenter))
				filterCounter++;
		System.out.println("Filter count in searchCostCenter :"+filterCounter );
		if (this.searchBsnssSgmnt!=null && this.searchBsnssSgmnt.size()>0)
			if(!isBlankValueSelected(this.searchBsnssSgmnt))
				filterCounter++;
		System.out.println("Filter count in searchBsnssSgmnt :"+filterCounter );
		if((FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) && filterCounter >0){
			System.out.println("in 1486 line");
			refreshList(true);
			return "";
		}
		if(FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)){
			System.out.println("inside delete row line row 1491");
			if (this.searchUserType!=null && this.searchUserType.size()>0)
				if(!isBlankValueSelected(this.searchUserType))
					filterCounter++;
			if (this.searchStatus!=null && this.searchStatus.size()>0)
				if(!isBlankValueSelected(this.searchStatus))
					filterCounter++;
			if(filterCounter>=2){
				System.out.println("Filter count in DELETED_ROWS :"+filterCounter );
						System.out.println("in 1499 line");
				refreshList(true);
				return "";
			}
			else{
				String message = "Please enter at least two search criteria";
				FacesContext.getCurrentInstance().addMessage(message,
						new FacesMessage(message));
				return "";
			}

		}


		boolean userTypeSelected = false;
		boolean userStatusSelected = false;
		if (this.searchUserType!=null && this.searchUserType.size()>0)
			if(!isBlankValueSelected(this.searchUserType))
				userTypeSelected = true;
		if (this.searchStatus!=null && this.searchStatus.size()>0)
			if(!isBlankValueSelected(this.searchStatus))
				userStatusSelected = true;
		if(userStatusSelected && userTypeSelected){
			System.out.println("in 1521 line");
			refreshList(true);
			return "";
		}
		else{
			String message = "Please enter at least two search criteria";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
			//this.userList = new ArrayList<UserUI>();
		}
		return "";
	}

	public void populateSupevisorData() {

		supevisorDepartments = new ArrayList<SelectItem>();
		supevisorDivisions = new ArrayList<SelectItem>();
		supevisorCostCenters = new ArrayList<SelectItem>();
		supevisorBusinessSegments = new ArrayList<SelectItem>();
		supevisorJobTitles = new ArrayList<SelectItem>();
		supevisorLocations = new ArrayList<SelectItem>();

		if(this.supervisorId!=null){
//			this.userService.populatSupevisorData(this.supervisorId);
			this.supevisorDepartments = this.userService.populateSupevisorDepartments(this.supervisorId);
			this.supevisorDivisions = this.userService.populateSupevisorDivisions(this.supervisorId);
			this.supevisorCostCenters = this.userService.populateSupevisorCostCenters(this.supervisorId);
			this.supevisorBusinessSegments = this.userService
					.populateSupevisorBusinessSegments(this.supervisorId);
			this.supevisorJobTitles = this.userService.populateSupevisorJobTitles(this.supervisorId,"");
			this.supevisorLocations = this.userService.populateSupevisorLocations(this.supervisorId,"");
			List<User> directReports = this.userService.findUsersBySupevisorId(this.supervisorId);
			this.supervisorDirectReports = new ArrayList<UserUI>();
			for (User user : directReports) {
				this.supervisorDirectReports.add(new UserUI(user));
			}
			CommonPageActionHelper.sortListByField(this.supervisorDirectReports, "name",
					this.oldSortColumn);
		}
	}

	public List<SelectItem> getMultiSelectDepartmentList(){
		List<Department> deptNames = this.userService.retrieveAllDepartments();
		//Sort
		Collections.sort(deptNames, new Comparator<Department>() {
			public int compare(Department dept1, Department dept2) {
				if (dept1.getName() != null && dept2.getName() != null) {
					return dept1.getName().compareTo(dept2.getName());
				} else
					return 0;
			}
		});
		List<SelectItem> deptList = new ArrayList<SelectItem>();
		deptList.add(new SelectItem("", ""));
		for(Department dep:deptNames){
			if(dep.getName()!=null)
				deptList.add(new SelectItem(""+dep.getId(), dep.getDepartmentNmCostCenter()));
		}
		return deptList;
	}


	public List<SelectItem> getMultiSelectDivisionList() {
		List<Division> divName = this.userService.retrieveAllDivisions();
		//Sort
		Collections.sort(divName, new Comparator<Division>() {
			public int compare(Division div1, Division div2) {
				return div1.getName().compareTo(div2.getName());
			}
		});
		List<SelectItem> divList = new ArrayList<SelectItem>();
		divList.add(new SelectItem("", ""));
		for(Division div:divName){
			if(div.getName()!=null)
				divList.add(new SelectItem(""+div.getId(), div.getName()));
		}
		return divList;
	}


	public List<SelectItem> getMultiSelectUserStatusList() {
		List<UserStatus> userStatusList = this.userService.findUserStatusList();

		//Sort
		Collections.sort(userStatusList, new Comparator<UserStatus>() {
			public int compare(UserStatus userStatus1, UserStatus userStatus2) {
				return userStatus1.getUserStatusDescription().compareTo(userStatus2.getUserStatusDescription());
			}
		});

		List<SelectItem> statusList = new ArrayList<SelectItem>();
		statusList.add(new SelectItem("", ""));
		for (UserStatus us : userStatusList) {
			if (us.getUserStatusDescription()!=null)
				statusList.add(new SelectItem(""+us.getId(), us.getUserStatusDescription()));
		}
		return statusList;
	}

	public List<SelectItem> getMultiSelectUserTypeList() {
		List<UserType> userTypeName = this.userService.retrieveAllUserTypes();

		//Sort
		Collections.sort(userTypeName, new Comparator<UserType>() {
			public int compare(UserType userType1, UserType userType2) {
				return userType1.getUserTypeDescription().compareTo(userType2.getUserTypeDescription());
			}
		});

		List<SelectItem> usrTypeList = new ArrayList<SelectItem>();
		usrTypeList.add(new SelectItem("", ""));
		for(UserType ut:userTypeName){
			if(ut.getUserTypeDescription()!=null){
				usrTypeList.add(new SelectItem(""+ut.getId(), ut.getUserTypeDescription()));
			}
		}
		return usrTypeList;
	}


	public List<SelectItem> getAvailableDepartment(){
//		if(this.availableDepartment==null){
		List<Department> deptNames = this.userService.retrieveAllDepartments();

		//Sort
		Collections.sort(deptNames, new Comparator<Department>() {
			public int compare(Department dept1, Department dept2) {
				return dept1.getName().compareTo(dept2.getName());
			}
		});

		this.availableDepartment = new ArrayList<SelectItem>();
		this.availableDepartment.add(new SelectItem("", ""));
		for(Department dep:deptNames){
			if(dep.getName()!=null)
				availableDepartment.add(new SelectItem(dep.getId(), dep.getDepartmentNmCostCenter()));
		}
//			this.availableDepartment = Collections.unmodifiableList(availableDeptNamesList);
//		}
		return this.availableDepartment;
	}


	public List<SelectItem> getAvailableDivision() {
		List<Division> divName = this.userService.retrieveAllDivisions();

		//Sort
		Collections.sort(divName, new Comparator<Division>() {
			public int compare(Division div1, Division div2) {
				return div1.getName().compareTo(div2.getName());
			}
		});

		this.availableDivision = new ArrayList<SelectItem>();
		this.availableDivision.add(new SelectItem("", ""));
		for(Division div:divName){
			if(div.getName()!=null)
				this.availableDivision.add(new SelectItem(div.getId(), div.getName()));
		}
		return this.availableDivision;
	}

	public List<SelectItem> getAvailableStatus() {
		List<UserStatus> userStatusList = this.userService.findUserStatusList();

		//Sort
		Collections.sort(userStatusList, new Comparator<UserStatus>() {
			public int compare(UserStatus userStatus1, UserStatus userStatus2) {
				return userStatus1.getUserStatusDescription().compareTo(userStatus2.getUserStatusDescription());
			}
		});

		this.availableStatus = new ArrayList<SelectItem>();
		this.availableStatus.add(new SelectItem("", ""));
		for (UserStatus us : userStatusList) {
			if (us.getUserStatusDescription()!=null)
				this.availableStatus.add(new SelectItem(us.getId(), us.getUserStatusDescription()));
		}
		return this.availableStatus;
	}

	public List<SelectItem> getAvailableUserType() {
		List<UserType> userTypeName = this.userService.retrieveAllUserTypes();

		//Sort
		Collections.sort(userTypeName, new Comparator<UserType>() {
			public int compare(UserType userType1, UserType userType2) {
				return userType1.getUserTypeDescription().compareTo(userType2.getUserTypeDescription());
			}
		});

		this.availableUserType = new ArrayList<SelectItem>();
		this.availableUserType.add(new SelectItem("", ""));
		for(UserType ut:userTypeName){
			if(ut.getUserTypeDescription()!=null){
				this.availableUserType.add(new SelectItem(ut.getId(), ut.getUserTypeDescription()));
			}
		}
		return this.availableUserType;
	}

	public List<SelectItem> getAvailableCostCenter() {
		List<String> costCenter = this.userService.retrieveAllCostCenter();

		//Sort
		Collections.sort(costCenter, new Comparator<String>() {
			public int compare(String cc1, String cc2) {
				return cc1.compareTo(cc2);
			}
		});

		this.availableCostCenter = new ArrayList<SelectItem>();
		this.availableCostCenter.add(new SelectItem("", ""));
		for(String cc:costCenter){
			if(cc!=null && !"".equals(cc.trim()))
				this.availableCostCenter.add(new SelectItem(cc,cc));
		}

		return this.availableCostCenter;
	}

	public List<SelectItem> getAvailableBusinessSeg() {
		List<String> businessSeg = this.userService.retrieveAllBusinessSeg();

		//Sort
		Collections.sort(businessSeg, new Comparator<String>() {
			public int compare(String cc1, String cc2) {
				return cc1.compareTo(cc2);
			}
		});

		this.availableBusinessSeg = new ArrayList<SelectItem>();
		this.availableBusinessSeg.add(new SelectItem("", ""));
		for(String seg : businessSeg){
			if(seg!=null && !"".equals(seg.trim()))
				this.availableBusinessSeg.add(new SelectItem(seg, seg));
		}
		return this.availableBusinessSeg;
	}

	public List<SelectItem> getAvailableFilters() {
		this.availableFilters = new ArrayList<SelectItem>();
		this.availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.name()));
		this.availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.name()));
		return this.availableFilters;
	}

	public List<SelectItem> getAvailableSupervisors() {
		List<Supervisor> supervisorsList = this.userService.retrieveAllSupervisors();

		List<SelectItem> availableSupervisors = new ArrayList<SelectItem>();
		availableSupervisors.add(new SelectItem("", ""));
		for (Supervisor supervisor : supervisorsList) {
			StringBuilder formattedName = new StringBuilder();
			String firstName = supervisor.getFirstName();
			String lastName = supervisor.getLastName();
			String middleName = (supervisor.getMiddleName()!=null)?supervisor.getMiddleName():"";

			if (StringUtils.isNotEmpty(lastName)) {
				formattedName.append(lastName);

				if (StringUtils.isNotEmpty(firstName)) {
					formattedName.append(", ");
				}
			}

			if (StringUtils.isNotEmpty(firstName)) {
				formattedName.append(firstName);

				if (StringUtils.isNotEmpty(middleName)) {
					formattedName.append(" ").append(middleName.substring(0, 1));
				}
			}

			availableSupervisors.add(new SelectItem(supervisor.getUserId(),
					formattedName.toString()));
		}

		return availableSupervisors;
	}

	public void init() {
		this.userList = null;
		this.selectedUserList = null;
		this.allChecked = false;
		this.defaultFilters(true);
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
		this.isInitialLoad = true;
		this.availableDepartment = null;
		this.availableDivision = null;
		this.availableStatus = null;
		this.availableUserType = null;
		this.availableBusinessSeg = null;
		this.availableCostCenter = null;
		this.showDeleteButton = !(this.userService.isIpsUser());

	}

	// BULK Updates

	// bulk update functionality
	// ******* Update user Panel *******

	private List<UserUI> bulkUpdateList = new ArrayList<UserUI>();
	private boolean renderBulkUpdatePanel;
	private Long bulkDepartmentId;
	private Long bulkDivisionId;
	private Long bulkStatus;
	private Long bulkUserType;
	private String bulkCostCenter;
	private String bulkBsnssSgmnt;
	private Long bulkSupervisorId;


	public Long getBulkDepartmentId() {
		return bulkDepartmentId;
	}

	public void setBulkDepartmentId(Long bulkDepartmentId) {
		this.bulkDepartmentId = bulkDepartmentId;
	}

	public Long getBulkDivisionId() {
		return bulkDivisionId;
	}

	public void setBulkDivisionId(Long bulkDivisionId) {
		this.bulkDivisionId = bulkDivisionId;
	}

	public Long getBulkStatus() {
		return bulkStatus;
	}

	public void setBulkStatus(Long bulkStatus) {
		this.bulkStatus = bulkStatus;
	}

	public Long getBulkUserType() {
		return bulkUserType;
	}

	public void setBulkUserType(Long bulkUserType) {
		this.bulkUserType = bulkUserType;
	}

	public String getBulkCostCenter() {
		return bulkCostCenter;
	}

	public void setBulkCostCenter(String bulkCostCenter) {
		this.bulkCostCenter = bulkCostCenter;
	}

	public String getBulkBsnssSgmnt() {
		return bulkBsnssSgmnt;
	}

	public void setBulkBsnssSgmnt(String bulkBsnssSgmnt) {
		this.bulkBsnssSgmnt = bulkBsnssSgmnt;
	}

	public Long getBulkSupervisorId() {
		return bulkSupervisorId;
	}

	public void setBulkSupervisorId(Long bulkSupervisorId) {
		this.bulkSupervisorId = bulkSupervisorId;
	}

	public String showBulkUpdatePanel(){
		for(UserUI ui: this.userList){
			if(ui.isChecked()){
				this.bulkUpdateList.add(ui);
			}
		}
		if(this.bulkUpdateList.isEmpty()){
			this.renderBulkUpdatePanel = false;
			this.bulkUpdateList = new ArrayList<UserUI>();
			String message = "Please select at least one User.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		}
		else{
			this.renderBulkUpdatePanel = true;
		}
		return null;
	}

	// ******* Update User Panel *******
	public String doBulkUpdate() {
		// get confirmed list todo bulk update
		List<User> confirmedList= new ArrayList<User>();
		User userRow = null;
		UserType userType;
		UserStatus userStatus;
		Department dept;
		Division div;
		User superUser;

		for (UserUI ui : this.bulkUpdateList) {
			if (ui.isChecked()) {
				userRow = this.userService.findById(ui.getUserId());
				if((this.bulkSupervisorId != null) && (this.bulkSupervisorId !=0)){
					superUser = this.userService.findById(this.bulkSupervisorId);
					userRow.setSupervisorId(this.bulkSupervisorId);
					userRow.setSupervisor(superUser.getLastName()+", "+superUser.getFirstName());
				}
				if((this.bulkDepartmentId != null) && (this.bulkDepartmentId !=0)){
					dept = this.userService.findDepartmentById(this.bulkDepartmentId);
					userRow.setDepartment(dept);
					userRow.setDepartmentName(dept.getName());
				}
				if((this.bulkDivisionId != null) && (this.bulkDivisionId !=0)){
					div = this.userService.findDivisionById(this.bulkDivisionId);
					userRow.setDivision(div);
					userRow.setDivisionName(div.getName());
				}
				if((this.bulkUserType != null) && (this.bulkUserType !=0)){
					userType = this.userService.findUserTypeById(this.bulkUserType);
					userRow.setUserType(userType);
					userRow.setUserTypeDescription(userType.getUserTypeDescription());
				}
/*
				if((this.bulkStatus != null) && (this.bulkStatus !=0)){
					userStatus = this.userService.findUserStatusById(this.bulkStatus);
					userRow.setUserStatus(userStatus);
					userRow.setUserStatusDescription(userStatus.getUserStatusDescription());
				}
*/
				this.userService.updateUser(userRow);
				confirmedList.add(userRow);
			}
		}

//		this.userService.updateUsers(confirmedList);

		this.renderBulkUpdatePanel = false;
		this.bulkUpdateList = null;
		// refresh summary page
		System.out.println("in 1962 line");
		refreshList(true);
		return null;
	}

	// ******* Update user Panel CANCEL *******
	public String doCancelBulkUpdate() {

		this.bulkUpdateList= new ArrayList<UserUI>();
		this.renderBulkUpdatePanel = false;
		return null;
	}

	public boolean isRenderBulkUpdatePanel() {
		return renderBulkUpdatePanel;
	}
	public void setRenderBulkUpdatePanel(
			boolean renderBulkUpdatePanel) {
		this.renderBulkUpdatePanel = renderBulkUpdatePanel;
	}

	public List<UserUI> getBulkUpdateList() {
		return this.bulkUpdateList;
	}

	public boolean isUpdateCheckbox() {
		return true;
	}

	// *********** View Panel *********
	private boolean renderViewPanel;


	public boolean isRenderViewPanel() {
		return renderViewPanel;
	}

	public void setRenderViewPanel(boolean renderViewPanel) {
		this.renderViewPanel = renderViewPanel;
	}

	private String department;
	private String division;
	private String userTypeString;
	private String userStatusString;
	private String supervisorName;

	public String getSupervisorName() {
		return supervisorName;
	}

	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}

	public String getUserTypeString() {
		return userTypeString;
	}

	public void setUserTypeString(String userTypeString) {
		this.userTypeString = userTypeString;
	}

	public String getUserStatusString() {
		return userStatusString;
	}

	public void setUserStatusString(String userStatusString) {
		this.userStatusString = userStatusString;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String showViewUserPanel() {
		Long viewUserId = 0L;
		if(JSFUtils.getParameter("viewUserId") != null)
			viewUserId = Long.parseLong(JSFUtils.getParameter("viewUserId"));

		for (UserUI ui : userList) {
			if (ui.getUserId() == viewUserId) {
				populateSelectedUser(ui);
				this.userId = ui.getUserId();
				this.lastName = ui.getLastName();
				this.firstName = ui.getFirstName();
				this.middleName = (ui.getMiddleName()!=null)?ui.getMiddleName():"";
				this.department = ui.getDepartment();
				this.division = ui.getDivision();
				this.keyId = ui.getKeyId();
				this.supervisorName = ui.getSupervisorName();
				this.userStatusString = ui.getStatus();
				this.userTypeString = ui.getUserType();
				this.costCenter = ui.getCostCenter();
				//this.deleteFlag = ;
				this.jobTitle = ui.getJobTitle();
				this.emailAddress = ui.getEmailAddress();
				this.phone = ui.getPhone();
				this.location = ui.getLocation();

				this.satJobRole = ui.getSatJobRole();
				this.bsnssSgmnt = ui.getBusinessSeg();
				this.satAltId1 = ui.getSatAltId1();
				this.satAltId2 = ui.getSatAltId2();
				this.satAltId3 = ui.getSatAltId3();
				this.satMFId = ui.getSatMFId();
				this.satGFId = ui.getSatGFId();
				this.satCFId = ui.getSatCFId();
				this.satFDMSId = ui.getSatFDMSId();
				this.satLCSId = ui.getSatLCSId();
				this.satSiteMinderId = ui.getSatSiteMinderId();

				this.satStatus = ui.getSatStatus();
				this.satComment = ui.getSatComment();
			}
		}
		this.renderViewPanel = true;
		return null;
	}
	public String closeViewUserPanel() {
		this.renderViewPanel = false;
		return null;
	}


	// *********** Show Direct Reports Panel *********
	private boolean renderDirectReportsPanel;

	public String showDirectReportsPanel() {
		if(this.supervisorId!=null)
			this.renderDirectReportsPanel = true;
		return null;
	}
	public String closeDirectReportsPanel() {
		this.renderDirectReportsPanel = false;
		return null;
	}


	public boolean isRenderDirectReportsPanel() {
		return renderDirectReportsPanel;
	}

	public void setRenderDirectReportsPanel(boolean renderDirectReportsPanel) {
		this.renderDirectReportsPanel = renderDirectReportsPanel;
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

}

