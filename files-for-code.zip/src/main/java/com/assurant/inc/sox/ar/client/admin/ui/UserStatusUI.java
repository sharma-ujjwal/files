package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.UserStatus;
import java.util.Date;

public class UserStatusUI {
	private final UserStatus userStatus;
	private boolean checked;

	public UserStatusUI(UserStatus userStatus) {
		this.userStatus = userStatus;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.userStatus.getId();
	}
	
	public String getUserStatusDescription() {
		return this.userStatus.getUserStatusDescription();
	}

	
	public String getCreatedBy() {
		return this.userStatus.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.userStatus.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.userStatus.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.userStatus.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.userStatus.getDeleteFlag();
	}

	public UserStatus getUserStatus() {
		return userStatus;
	}
	
	public Date getActiveFromDate() {
		return this.userStatus.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.userStatus.getActiveToDate();
	}
	
}  //end of UserStatusUI
