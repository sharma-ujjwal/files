package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the department selection modal panel
 * 
 */
@Component("divisionSelectionBean")
@Scope("session")
public class DivisionSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(DivisionSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("DepartmentSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> divisions = createBundleBean.getDivisions();
        divisions.clear();
        for (SelectAdapter item : chosen) {
        	divisions.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (DivisionDTO div : metaDataService.retrieveDivisions(searchString)) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.DIVISION);
            dto.setFilterValueName(div.getName());
            dto.setFilterValueKey(String.valueOf(div.getId()));
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        
        if (results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}        
        
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getDivisions()) {
            results.add(adapter);
        }
        return results;
    }
}
