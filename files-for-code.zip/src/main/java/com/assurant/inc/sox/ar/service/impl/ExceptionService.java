/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.client.admin.ui.ExceptionSummaryUI;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IExceptionService;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IDepartmentDao;
import com.assurant.inc.sox.dao.ar.IDivisionDao;
import com.assurant.inc.sox.dao.ar.IExceptionDao;
import com.assurant.inc.sox.dao.ar.IInternalIdentifierTypeDAO;
import com.assurant.inc.sox.dao.ar.IUserAkaDAO;
import com.assurant.inc.sox.dao.ar.IUserStatusDao;
import com.assurant.inc.sox.dao.ar.IUserTypeDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import com.assurant.inc.sox.domain.admin.ExceptionSummary;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.InternalIdentifierType;
import com.assurant.inc.sox.domain.luad.User;
import com.assurant.inc.sox.domain.luad.UserAka;
import com.assurant.inc.sox.domain.luad.UserPk;

/**
 * @author Brian Olson
 * 
 *
 */
@Service
@Transactional
public class ExceptionService implements IExceptionService {

	@Autowired
	private IExceptionDao exceptionDao;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private IDepartmentDao departmentDao;
	
	@Autowired
	private IDivisionDao divisionDao;
	
	@Autowired
	private IUserStatusDao userStatusDao;
	
	@Autowired
	private IUserTypeDao userTypeDao;

	@Autowired
	private SystemUserDTO systemUser;
	
	@Autowired
	private IInternalIdentifierTypeDAO internalIdentifierTypeDAO;

	@Autowired
	private IUserAkaDAO userAkaDAO;
	
	@Transactional(readOnly = true)
	public ExceptionSummary getExceptionSummaryByUserId(Long userId) {
		return this.exceptionDao.findByUserId(userId);
	}
	
	@Transactional(readOnly = true)
	public List<ExceptionSummary> retrieveActiveExceptions() {
		return this.exceptionDao.findActiveExceptions();
	}

	@Transactional(readOnly = true)
	public List<ExceptionSummary> retrieveInactiveExceptions() {
		return this.exceptionDao.findInactiveExceptions();
	}

	@Transactional(readOnly = true)
	public List<ExceptionSummary> retrieveDirectReportsBySupervisorId(Long userId, Long supervisorId) {
		return this.exceptionDao.findDirectReportsBySupervisorId(userId, supervisorId);
	}

	@Transactional(readOnly = false)
	public void updateUser(ExceptionSummaryUI exceptionSummaryUI) {
		User existingUser = this.userDao.findByUserId(exceptionSummaryUI.getUserId());
		boolean changed = false;
		
		Date currentDate = new Date();
		
		User historyUser = new User();
		UserPk historyUserPk = new UserPk();
		historyUserPk.setEffectiveFromDate(existingUser.getPk().getEffectiveFromDate());
		historyUserPk.setEffectiveToDate(DateUtils.addSeconds(currentDate, -1));
		historyUserPk.setKeyId(existingUser.getPk().getKeyId());
		historyUser.setPk(historyUserPk);
		
		historyUser.setBusinessSegment(existingUser.getBusinessSegment());
		historyUser.setCostCenter(existingUser.getCostCenter());
		historyUser.setCrtdBy(existingUser.getCrtdBy());
		historyUser.setCrtdDt(existingUser.getCrtdDt());
		historyUser.setDeleteFlag(existingUser.getDeleteFlag());
		historyUser.setDepartment(existingUser.getDepartment());
		historyUser.setDepartmentName(existingUser.getDepartmentName());
		historyUser.setDivision(existingUser.getDivision());
		historyUser.setDivisionName(existingUser.getDivisionName());
		historyUser.setEmailAddress(existingUser.getEmailAddress());
		historyUser.setExtractDate(existingUser.getExtractDate());
		historyUser.setExtractSystemId(existingUser.getExtractSystemId());
		historyUser.setFirstName(existingUser.getFirstName());
		historyUser.setJobTitle(existingUser.getJobTitle());
		historyUser.setLastChngdBy(existingUser.getLastChngdBy());
		historyUser.setLastChngdDt(existingUser.getLastChngdDt());
		historyUser.setLastName(existingUser.getLastName());
		historyUser.setLocation(existingUser.getLocation());
		historyUser.setMiddleName(existingUser.getMiddleName());
		historyUser.setPhone(existingUser.getPhone());
		historyUser.setSatAltId1(existingUser.getSatAltId1());
		historyUser.setSatAltId2(existingUser.getSatAltId2());
		historyUser.setSatAltId3(existingUser.getSatAltId3());
		historyUser.setSatCfId(existingUser.getSatCfId());
		historyUser.setSatComment(existingUser.getSatComment());
		historyUser.setSatFdmsId(existingUser.getSatFdmsId());
		historyUser.setSatGfId(existingUser.getSatGfId());
		historyUser.setSatJobRole(existingUser.getSatJobRole());
		historyUser.setSatLcsId(existingUser.getSatLcsId());
		historyUser.setSatMfId(existingUser.getSatMfId());
		historyUser.setSatSiteminderId(existingUser.getSatSiteminderId());
		historyUser.setSatStatus(existingUser.getSatStatus());
		historyUser.setSupervisor(existingUser.getSupervisor());
		historyUser.setSupervisorId(existingUser.getSupervisorId());
		historyUser.setUserStatus(existingUser.getUserStatus());
		historyUser.setUserStatusDescription(existingUser.getUserStatusDescription());
		historyUser.setUserType(existingUser.getUserType());
		historyUser.setUserTypeDescription(existingUser.getUserTypeDescription());
		
		// modify existing user record as necessary
		if (!exceptionSummaryUI.isMissingDepartment() && 
				!existingUser.getDepartment().getId().equals(exceptionSummaryUI.getDepartmentId())) {
			Department department = this.departmentDao.findById(exceptionSummaryUI.getDepartmentId());
			exceptionSummaryUI.setDepartmentNameCostCenter(department.getDepartmentNmCostCenter());
			changed = true;
		}
		
		if (!exceptionSummaryUI.isMissingDivision() && 
				!existingUser.getDivision().getId().equals(exceptionSummaryUI.getDivisionId())) {
			Division division = this.divisionDao.findById(exceptionSummaryUI.getDivisionId());
			exceptionSummaryUI.setDivisionName(division.getName());
			changed = true;
		}
		
		if (!exceptionSummaryUI.isMissingUserStatus() && 
				!existingUser.getUserStatus().getId().equals(exceptionSummaryUI.getUserStatusId())) {
			UserStatus userStatus = this.userStatusDao.findById(exceptionSummaryUI.getUserStatusId());
			exceptionSummaryUI.setUserStatusName(userStatus.getUserStatusDescription());
			changed = true;
		}
		
		if (!exceptionSummaryUI.isMissingUserType() && 
				!existingUser.getUserType().getId().equals(exceptionSummaryUI.getUserTypeId())) {
			UserType userType = this.userTypeDao.findById(exceptionSummaryUI.getUserTypeId());
			exceptionSummaryUI.setUserTypeName(userType.getUserTypeDescription());
			changed = true;
		}

		if (!exceptionSummaryUI.isMissingSupervisor() && existingUser.getSupervisorId() != null &&
				!existingUser.getSupervisorId().equals(exceptionSummaryUI.getSupervisorId())) {
			User supervisor = this.userDao.findByUserId(exceptionSummaryUI.getSupervisorId());
			
			StringBuilder supervisorName = new StringBuilder();
			if (StringUtils.isNotEmpty(supervisor.getLastName())) {
				supervisorName.append(supervisor.getLastName());
				
				if (StringUtils.isNotEmpty(supervisor.getFirstName())) {
					supervisorName.append(", ");
				}
			}
			
			if (StringUtils.isNotEmpty(supervisor.getFirstName())) {
				supervisorName.append(supervisor.getFirstName());
				
				if (StringUtils.isNotEmpty(supervisor.getMiddleName())) {
					supervisorName.append(" ").append(supervisor.getMiddleName().substring(0, 1));
				}
			}
			
			exceptionSummaryUI.setSupervisorName(supervisorName.toString());
			
			changed = true;
		}
		
		if (!exceptionSummaryUI.isMissingEmail() &&
				!exceptionSummaryUI.getEmail().equals(existingUser.getEmailAddress())) {
			exceptionSummaryUI.setEmail(exceptionSummaryUI.getEmail().toUpperCase());
			
			InternalIdentifierType type = this.internalIdentifierTypeDAO.findByTypeCD("EMAIL_ADDR");
			
			// if the email address has been updated, also add/update the user aka record
			UserAka userAka = this.userAkaDAO.findByUserAndType(existingUser.getUserId(), type.getIdTypId());
			
			if (userAka == null) {
				userAka = new UserAka();
				userAka.setCrtdBy(systemUser.getUserId());
				userAka.setCrtdDt(currentDate);
				userAka.setDltFlg(IFlags.NOT_DELETED);
				userAka.setInternalIdentifierType(type);
				userAka.setUserId(existingUser.getUserId());
			} else {
				userAka.setLstChngdBy(systemUser.getUserId());
				userAka.setLstChngdDt(currentDate);
			}
			
			userAka.setIntrnlIdntfyrTxt(exceptionSummaryUI.getEmail().toUpperCase());
			
			this.userAkaDAO.save(userAka);
			changed = true;
		}
		

		if (changed) {
			this.userDao.save(historyUser);
			
			this.exceptionDao.updateExistingExceptionRecord(
					exceptionSummaryUI.getExceptionSummary(), systemUser.getUserId(), 
					currentDate);
		}
	}
}
