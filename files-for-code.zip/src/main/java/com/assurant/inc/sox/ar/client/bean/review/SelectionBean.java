package com.assurant.inc.sox.ar.client.bean.review;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.assurant.inc.sox.ar.comparators.GenericComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author JW14004
 * 
 * An abstract implementation of a bean for a modal dual list selection panel. Override the abstract methods to define
 * instance specific behavior.  Bind this bean to selectionModal.xhtml.
 * 
 * Methods to override:
 * <ul>
 * <li>apply() - called when user clicks the apply button on the panel, should do something with the chosen list.</li>
 * <li>retrieve(searchString) - called when user hits the search button, should return a list of items found.</li>
 * <li>restore() - called when panel is opened, should return a list of the currently selected items to be populated in
 * the chosen list.</li>
 * </ul>
 */
public abstract class SelectionBean {
    
    protected static Logger logger = LoggerFactory.getLogger(SelectionBean.class);
    
    /**
     * List of items available for selection, i.e. the left side list.
     */
    protected List<SelectAdapter> available = new ArrayList<>();
    /**
     * List of items that have been chosen, i.e. the right side list.
     */
    protected List<SelectAdapter> chosen = new ArrayList<>();
    /**
     * Text the user wants to search for to populate the availableList.
     */
    protected String availableSearchText;

    public SelectionBean() {
        super();
    }

    /**
     * Called when add button is pressed, adds selected items to chosen list and removes it from the available list.
     * 
     * @return
     */
    public final String add() {
    	logger.debug("add() --> being executed.");
        Iterator<SelectAdapter> i = available.iterator();
        while (i.hasNext()) {
            SelectAdapter item =  i.next();
            if (item.isSelected()) {
                i.remove();
                chosen.add(item);
                item.setSelected(false);
            }
        }
        sort(chosen);
        return null;
    }

    public final String addAll() {
		logger.debug("addAll() --> being executed.");
		Iterator<SelectAdapter> i = available.iterator();
		while (i.hasNext()) {
			SelectAdapter item = i.next();
			i.remove();
			chosen.add(item);
			item.setSelected(false);
		}
		sort(chosen);
		return null;
	}
    
    /**
	 * Override to apply the chosen SelectItems. Usually copies the selected
	 * items to some other Object.
	 * 
	 * @return
	 */
    public abstract String apply();

    public final List<SelectAdapter> getAvailable() {
        return available;
    }

    public final String getAvailableSearchText() {
        return availableSearchText;
    }

    public final List<SelectAdapter> getChosen() {
        return chosen;
    }

    /**
     * Called when panel is opened, and calls restore() to pre-populate the chosen list.
     * 
     * @return
     */
    public final String init() {
    	logger.debug("init() --> being executed.");
        if (retrieveOnInit()) {
	        available = retrieve("");
	        sort(available);
        } else {
        	if (available != null)
                available.clear();
        }

        if (chosen != null)
            chosen.clear();
        for (SelectAdapter item : restore()) {
            chosen.add(item);
            available.remove(item);
        }

        availableSearchText = "";
        
        return null;
    }
    
    /**
     * Override and return true if using basic modal panel, and need
     * the lists to be populated when opened, if lists are empty.
     * 
     * @return
     */
    protected boolean retrieveOnInit() {
    	return false;
    }

    /**
     * Called when remove button is hit. Removes selected items from the chosen list and replaces them in the available
     * list, if it doesn't already contain that item.
     * 
     * @return
     */
    public final String remove() {
    	logger.debug("remove() --> being executed.");
    	Iterator<SelectAdapter> i = chosen.iterator();
        while (i.hasNext()) {
            SelectAdapter item = i.next();
            if (item.isSelected()) {
                i.remove();
                if (!available.contains(item)) {
                    available.add(item);
                }
                item.setSelected(false);
            }
        }
        sort(available);
        return null;
    }
    
    public final String removeAll() {
    	logger.debug("removeAll() --> being executed.");
    	Iterator<SelectAdapter> i = chosen.iterator();
        while (i.hasNext()) {
            SelectAdapter item = i.next();
            i.remove();
            if (!available.contains(item)) {
                available.add(item);
            }
            item.setSelected(false);
        }
        sort(available);
        return null;
	}

    /**
     * Override this method to return a list of the currently selected SelectAdapters representing currently selected
     * items on the main page.
     * 
     * @return
     */
    public abstract List<SelectAdapter> restore();

    /**
     * Override this method to return a list of available SelectAdapters to appear in the left list.
     * 
     * @return
     */
    public abstract List<SelectAdapter> retrieve(String searchString);

    /**
     * Called when search button is hit.
     * 
     * @return
     */
    public final String searchAvailable() {
    	logger.debug("searchAvailable() --> being executed.");
        if (available != null)
            available.clear();
        for (SelectAdapter select : retrieve(availableSearchText)) {
            if (chosen!= null && !chosen.contains(select)) {
                available.add(select);
            }

            if (chosen == null) {
                available.add(select);
            }
        }
        sort(available);
        return null;
    }

    public final void setAvailable(List<SelectAdapter> available) {
        if(available != null)
            this.available = available;
    }

    public final void setAvailableSearchText(String availableSearchText) {
        this.availableSearchText = availableSearchText;
    }

    public final void setChosen(List<SelectAdapter> chosen) {
        if (chosen != null)
            this.chosen = chosen;
    }

    @SuppressWarnings("unchecked")
    public final void sort(List<SelectAdapter> list) {
        Collections.sort(list, new GenericComparator("displayString"));
    }
}