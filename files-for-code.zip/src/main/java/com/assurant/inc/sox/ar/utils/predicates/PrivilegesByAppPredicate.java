/*
 * Created on Jan 19, 2007
 *
 */
package com.assurant.inc.sox.ar.utils.predicates;

import org.apache.commons.collections.Predicate;

import com.assurant.inc.sox.domain.ar.ReviewUserAccess;

/**
 * <p>
 * Takes the List of all applications and filters out for only
 * the desired list. 
 * </p>
 * @author BB68602
 * 
 * @version 1.0
 */
public class PrivilegesByAppPredicate implements Predicate{

	private String searchedApplicationName;
	
	/**
	 * @see org.apache.commons.collections.Predicate#evaluate(java.lang.Object)
	 */
	public boolean evaluate(Object o) {
		if(o instanceof ReviewUserAccess){
			/*
			 * if an instance of ReviewUserAccess.
			 */
			ReviewUserAccess userAccess = (ReviewUserAccess)o;
			
			/*
			 * is the ReviewUserAccess.applicationName equal to searchedAppNm
			 */
			if(searchedApplicationName.equalsIgnoreCase(userAccess.getApplicationSystem().getApplication().getName())){
				/*
				 * if it's there then return true.
				 */
				return true;
			}else{
				return false;				
			} 
		}else{
			return false;
		} /* if o instance of ReviewUserAccess */
	} /* end method */
	
	/**
	 * @param searchedApplicationName
	 */
	public PrivilegesByAppPredicate(String searchedApplicationName){
		this.searchedApplicationName = searchedApplicationName;
	} /* end method */
}
