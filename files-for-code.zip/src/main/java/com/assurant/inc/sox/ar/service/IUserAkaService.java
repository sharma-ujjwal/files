package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.luad.UserAka;

public interface IUserAkaService {
	public void update(Long userId, Long internalIdentifierTypeId,
			String lookUpAltId);
	public void delete(Long userId, Long internalIdentifierTypeId,
			String lookUpAltId);
	public UserAka findByUserAndType(Long uId, Long typeId);
	public List<UserAka> findAllByUser(Long uId);
	public List<UserAka> findAll();
	
	public void add(Long userId, Long internalIdentifierTypeId,
			String lookUpAltId);
	public void deleteAllByUserId(Long userId);
	public boolean isAltIdExists(String altId);	
	public void markAsDelete(Long userId, Long typeId);
	
}
