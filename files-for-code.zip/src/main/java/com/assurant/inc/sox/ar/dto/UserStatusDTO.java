package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.UserStatus;

public class UserStatusDTO {
    private UserStatus userStatus;
    
    public UserStatusDTO(UserStatus userStatus) {
        super();
        this.userStatus = userStatus;
        
    }

    public long getUserStatusId() {
		Long id = userStatus.getId();
        return (id == null) ? 0 : id.longValue();
	}

	public String getUserStatusDescription() {
        return userStatus.getUserStatusDescription();
    }
    
    public UserStatus getUserStatus()
    {
        return this.userStatus;
    }
    
    public Date getActiveFromDate() {
		return this.userStatus.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.userStatus.getActiveToDate();
	}
}
