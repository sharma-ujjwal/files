package com.assurant.inc.sox.ar.client.admin.ui;

import java.util.Date;
import com.assurant.inc.sox.domain.ar.RejectedUser;

public class RejectedUserUI {
	private final RejectedUser rejectedUser;
	private boolean showAddUser;
	private boolean showSearchUser;

	public boolean isShowSearchUser() {
		return showSearchUser;
	}

	public void setShowSearchUser(boolean showSearchUser) {
		this.showSearchUser = showSearchUser;
	}

	public boolean isShowAddUser() {
		return showAddUser;
	}

	public void setShowAddUser(boolean showAddUser) {
		this.showAddUser = showAddUser;
	}

	public RejectedUserUI(RejectedUser rejectedUser) {
		this.rejectedUser = rejectedUser;
	}

	public RejectedUser getRejectedUser() {
		return rejectedUser;
	}

	public String getSrcUserId() {
		return this.rejectedUser.getSrcUserId();
	}

	public Long getRejectedUserId() {
		return this.rejectedUser.getRejectedUserId();
	}

	public Long getExtractSystemId() {
		return this.rejectedUser.getExtractSystem().getExtrctSysId();
	}

	public String getExtractSystemName() {
		String extractSystemName = this.rejectedUser.getExtractSystem()
				.getExtrctSysNm();
		return (extractSystemName == null) ? "" : extractSystemName;

	}

	public String getSrcUserName() {
		return (this.rejectedUser.getSrcUserName() == null) ? ""
				: this.rejectedUser.getSrcUserName();
	}

	public String getSrcApplicationName() {
		return this.rejectedUser.getSrcApplicationName();
	}

	public String getSrcProcessName() {
		return this.rejectedUser.getSrcProcessName();
	}

	public String getAdditionalValues() {
		StringBuilder formattedValue = new StringBuilder();
		String email = (this.rejectedUser.getSrcEmailAddress()!=null)?this.rejectedUser.getSrcEmailAddress():"";
		String oraIns = (this.rejectedUser.getOraInstncNm()!=null)?this.rejectedUser.getOraInstncNm():"";
		String comment = (this.rejectedUser.getCommentText()!=null)?this.rejectedUser.getCommentText():"";
		if(this.rejectedUser.getExtractSystem().getExtrctSysId()!=26 && !"".equals(email))
			formattedValue.append(email + " - ");
		if(!"".equals(oraIns))
			formattedValue.append(oraIns + " - ");
		if(!"".equals(comment))
			formattedValue.append(comment);
		return formattedValue.toString();
	}

	public Date getCreatedDate() {
		return this.rejectedUser.getCreatedDate();
	}
}
