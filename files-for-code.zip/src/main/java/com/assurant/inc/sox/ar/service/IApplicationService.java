package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Application;

public interface IApplicationService {	
	public List<Application> retrieveAllApplications();
	public List<Application> retrieveAllApplicationsByName(String searchString); 
	public List<Application> retrieveDeletedApplications(); 
	public List<Application> retrieveDeletedApplicationsByName(String searchString);
	public List<Application> retrieveUnassignedApplications();
	public List<Application> retrieveUnassignedByName(String searchString);
	
	public Application findById(Long id);
	public Application findDuplicate(String name);
	public void add(String applicationName);
	public void delete(Application application);
	public boolean canApplicationBeDeleted(String applicationName); 

}
