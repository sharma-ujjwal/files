package com.assurant.inc.sox.ar.dto;

import java.util.Date;
import java.util.List;

public class RejectSodBundleDTO {

	private String bunldeName;
	private Date bundleCreatedDate;
	private List<FilterCriteriaDTO> filterCriteriaDtos;
	private String sodConflictTypeText;
	
	public String getBunldeName() {
		return bunldeName;
	}
	public void setBunldeName(String bunldeName) {
		this.bunldeName = bunldeName;
	}
	public Date getBundleCreatedDate() {
		return bundleCreatedDate;
	}
	public void setBundleCreatedDate(Date bundleCreatedDate) {
		this.bundleCreatedDate = bundleCreatedDate;
	}
	public List<FilterCriteriaDTO> getFilterCriteriaDtos() {
		return filterCriteriaDtos;
	}
	public void setFilterCriteriaDtos(List<FilterCriteriaDTO> filterCriteriaDtos) {
		this.filterCriteriaDtos = filterCriteriaDtos;
	}
	public String getSodConflictTypeText() {
		return sodConflictTypeText;
	}
	public void setSodConflictTypeText(String sodConflictTypeText) {
		this.sodConflictTypeText = sodConflictTypeText;
	}
	
	
}
