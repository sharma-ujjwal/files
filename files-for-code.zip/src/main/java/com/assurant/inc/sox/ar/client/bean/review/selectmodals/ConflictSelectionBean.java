package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ConflictUI;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Bean to handle data for the application selection modal panel
 * 
 */
@Component("conflictSelectionBean")
@Scope("session")
public class ConflictSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(ConflictSelectionBean.class);
	
	//private String lastConflictType = "";
	
    @Override
    public String apply() {
        logger.debug("ConflictSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> conflicts = createBundleBean.getConflicts();
        conflicts.clear();
        for (SelectAdapter item : chosen) {
            conflicts.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("ConflictSelectionBean.retrieve(...) -> Being executed.");

        String type = getCreateBundleBean().getSelectedConflictType();
        //lastConflictType = type;

        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        
        for (ConflictDTO conflict : metaDataService.retreiveConflicts(Long.parseLong(type))) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.CONFLICT);
            dto.setFilterValueName(new ConflictUI(conflict).getConflictDisplay());
            dto.setFilterValueKey(String.valueOf(conflict.getId()));
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        if (results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        logger.debug("ConflictSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getConflicts()) {
            results.add(adapter);
        }
        return results;
    }

	/* (non-Javadoc)
	 * @see com.assurant.inc.sox.ar.client.bean.review.SelectionBean#retrieveOnInit()
	 */
	@Override
	protected boolean retrieveOnInit() {
		/*
		 * retrieve whenever the last conflict type changes
		 */
		//return !lastConflictType.equals(createBundleBean.getSelectedConflictType());
		return true;
	}
}
