package com.assurant.inc.sox.ar.client.bean.admin;

import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import org.primefaces.event.TabChangeEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * 
 * @author Brian Olson
 *
 */
@Component("adminConsoleBean")
@Scope("session")
public class AdminConsoleBean {

	@Autowired
	@Qualifier("sessionSystemUser")
	private SystemUserDTO systemUser;
	
	private static final String REJECTS_TAB_ID = "rejectsTab";
	private static final String EXCEPTIONS_TAB_ID = "exceptionReportingTab";
	private static final String TABLE_MAINTENANCE_TAB_ID = "tableMaintenanceTab";
	
	private int selectedTab;
	private int activeIndex;

	public void setSelectedTab(int selectedTabIndex) {
		if (selectedTabIndex == 0) {
			this.selectedTab = 0;
		} else if (selectedTabIndex == 1) {
			this.selectedTab = 1;
		} else if (selectedTabIndex == 2) {
			this.selectedTab = 2;
		}
	}
	
	public void init() {
		this.switchToTableMaintenance();
	}
	
	public String switchToTableMaintenance() {
		this.clearTabData();
		this.activeIndex = 2;
		this.selectedTab = 2;
		TableMaintenanceBean bean = (TableMaintenanceBean) JSFUtils.lookupBean("tableMaintenanceBean");
		return bean.switchMaintenanceTable();
	}

	public String switchToExceptionReporting() {
		clearTabData();
		this.activeIndex = 1;
		this.selectedTab = 1;
		return "switchToExceptionReporting";
	}
	
	public String switchToRejectedUsers() {
		clearTabData();
		this.activeIndex = 0;
		this.selectedTab = 0;
		return "switchToRejectedUsers";
	}

	public void onTabChange(TabChangeEvent event) {
			String tabId = event.getTab().getId();
			if (REJECTS_TAB_ID.equals(tabId)) {
				this.activeIndex = 0;
				this.selectedTab = activeIndex;
				switchToRejectedUsers();
			} else if (EXCEPTIONS_TAB_ID.equals(tabId)) {
				this.activeIndex = 1;
				this.selectedTab = activeIndex;
				switchToExceptionReporting();
			} else if (TABLE_MAINTENANCE_TAB_ID.equals(tabId)) {
				this.activeIndex = 2;
				this.selectedTab = activeIndex;
				switchToTableMaintenance();
			}
	}
	
	private void clearTabData() {
		TableMaintenanceBean tableMaintenanceBean = (TableMaintenanceBean) JSFUtils.lookupBean("tableMaintenanceBean");
		tableMaintenanceBean.init();
		ExceptionSummaryBean exceptionSummaryBean = (ExceptionSummaryBean) JSFUtils.lookupBean("exceptionSummaryBean");
		exceptionSummaryBean.init();
		RejectedUserSummaryBean rejectedUserSummaryBean = (RejectedUserSummaryBean) JSFUtils.lookupBean("rejectedUserSummaryBean");
		rejectedUserSummaryBean.init();
	}

	public SystemUserDTO getSystemUser() {
		return systemUser;
	}

	public void setSystemUser(SystemUserDTO systemUser) {
		this.systemUser = systemUser;
	}

	public int getActiveIndex() {
		return activeIndex;
	}

	public void setActiveIndex(int activeIndex) {
		this.activeIndex = activeIndex;
	}

	public int getSelectedTab() {
		return selectedTab;
	}
}
