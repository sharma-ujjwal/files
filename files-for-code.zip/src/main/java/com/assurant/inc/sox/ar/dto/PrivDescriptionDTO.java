package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.luad.PrivilegeComment;


public class PrivDescriptionDTO {
	
	private PrivilegeComment privilege = null;
	
	public PrivDescriptionDTO(PrivilegeComment privilege) {
		this.privilege = privilege;
	}
	
	public PrivDescriptionDTO() {
		this.privilege = new PrivilegeComment();
		
	}	
	
    private String name;
    private String id;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }


    
    
}
