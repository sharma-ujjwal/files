package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.sf.ehcache.Element;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.base.CodeServiceBase;
import com.assurant.inc.sox.domain.ar.Code;

@Service
public class CodeService extends CodeServiceBase implements ICodeService {

	private Code retrieveCodeByValue(CodeSet codeSet, String value) {
		Code code = this.codeDao.findCodeByValue(codeSet.getTableName(),
				codeSet.getColumnName(), value);
		return code;
	}

	public List<CodeDTO> retrieveAllCodesByType(CodeSet codeSet) {
		List<Code> codes = this.codeDao.findAllCodesByType(codeSet
				.getTableName(), codeSet.getColumnName());
		List<CodeDTO> codeResults = new ArrayList<CodeDTO>(codes.size());
		for (Code code : codes) {
			codeResults.add(new CodeDTO(code));
		}
		return codeResults;
	}

	private CodeDTO buildDTO(Code code) {
		return new CodeDTO(code);
	}

	public CodeDTO retrieveCodeByValueFromCache(CodeSet codeSet, String value) {
		Element element = getSoxRefTableCache().get(
				codeSet.getTableName() + codeSet.getColumnName() + value);

		if (element != null) {
			Code code = (Code) element.getValue();
			return (code == null) ? null : buildDTO(code);
		} else {
			logger.debug("element not found in cache, getting from Database");		
			Code code = retrieveCodeByValue(codeSet, value);
			if(code != null){
				loadPlanCoveragesToCache(code);
			}
			else{
				return null;
			}
			return buildDTO(code);
		}
	}

	public void loadPlanCoveragesToCache(Code code) {
		logger.debug("loadPlanCoveragesToCache");
		String key = code.getPk().getTableName() + code.getPk().getColumnName()	+ code.getPk().getValue();
		Element element = new Element(key, code);
		getSoxRefTableCache().putQuiet(element);
		logger.debug("populated cache for: " + code);
	}
}
