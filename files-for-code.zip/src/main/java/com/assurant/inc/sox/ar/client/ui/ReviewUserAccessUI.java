package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessKeepRemoveFlag;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.SoxConcern;

public class ReviewUserAccessUI {
	private ReviewUserAccessDTO dto;

	//no args constructor
	public ReviewUserAccessUI() {
		super();
		this.dto = new ReviewUserAccessDTO(new ReviewUserAccess(), new CodeDTO(new Code()));
	}

	public ReviewUserAccessUI(ReviewUserAccessDTO dto) {
		super();
		this.dto = dto;
	}

	public String getKeepRemoveClass() {
		if (getKeepRemoveFlag() != null) {
			switch (getKeepRemoveFlag()) {
			case KEEP:
				return "approve";
			case REMOVE:
				return "reject";
			}
		}
		return "";
	}
	
	public String getKeepRemoveDisplay() {
		if (getKeepRemoveFlag() != null) {
			switch (getKeepRemoveFlag()) {
			case KEEP:
				return "Accepted";
			case REMOVE:
				return "Rejected";
			}
		}
		return "";
	}

	public ReviewUserAccessKeepRemoveFlag getKeepRemoveFlag() {
		return dto.getKeepRemoveFlag();
	}

	public String getKeepRemoveString() {
		return dto.getKeepRemoveString();
	}

	public String getPrivilegeComment() {
		return dto.getPrivilegeComment();
	}

	public String getPrivilegeDescription() {
		return dto.getPrivilegeDescription();
	}

	public String getPrivilegeValue() {
		return dto.getPrivilegeValue();
	}

	public String getSourceName() {
		return dto.getSourceName();
	}

	public String getSoxConcern() {
		SoxConcern sox = dto.getSoxConcern();
		return (sox == null) ? null : sox.getSoxConcernCode();
	}

	public void setKeepRemoveFlag(ReviewUserAccessKeepRemoveFlag keepRemoveFlg) {
		dto.setKeepRemoveFlag(keepRemoveFlg);
	}

	public void setKeepRemoveString(String str) {
		if(null!=str){
			dto.setKeepRemoveString(str);
		}
	}
}