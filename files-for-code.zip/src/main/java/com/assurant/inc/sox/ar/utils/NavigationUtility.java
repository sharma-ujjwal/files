package com.assurant.inc.sox.ar.utils;

import javax.faces.application.NavigationHandler;
import javax.faces.context.FacesContext;

public class NavigationUtility {

	public static NavigationHandler getNavigationHandlerInstance() {
		FacesContext context = getFacesContextInstance();
		return context.getApplication().getNavigationHandler();
	}

	public static FacesContext getFacesContextInstance() {
		return FacesContext.getCurrentInstance();
	}
}