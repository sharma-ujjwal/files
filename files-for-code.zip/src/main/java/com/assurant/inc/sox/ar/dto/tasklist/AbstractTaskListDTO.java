package com.assurant.inc.sox.ar.dto.tasklist;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.Review;

public abstract class AbstractTaskListDTO {
	private final ReviewDTO review;
	private Date createDate;
	private String name;
	private TaskTypeCode typeCode;
	private String taskId;
	private String assignedTo;
	private LockDTO lock;

	private boolean lockResult = false;
	private String lockTitle = "";
	private String taskStatus = "";
	
	protected AbstractTaskListDTO(ReviewDTO review) {
		if (review != null) {
			this.review = review;
		} else {
			this.review = new ReviewDTO(new Review(), new CodeDTO(new Code()), new CodeDTO(new Code()));
		}
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date taskCreateDate) {
		this.createDate = taskCreateDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String taskName) {
		this.name = taskName;
	}

	public TaskTypeCode getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(TaskTypeCode taskCode) {
		this.typeCode = taskCode;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String TaskId) {
		this.taskId = TaskId;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public ReviewDTO getReview() {
		return review;
	}
	
	public boolean isLocked() {
		return this.lock != null;
	}
	
	public String getLockedBy() {
		return (this.lock == null) ? null : this.lock.getHolder();
	}
	
	public Date getLockedDate() {
		return (this.lock == null) ? null : this.lock.getCreated();
	}
	
	public void setLock(LockDTO lock) {
		this.lock = lock;
	}

	/**
	 * Retrieves the current status of the task. The source of this value can change based on the task type.
	 * 
	 * @return the current status of the task.
	 */
	public abstract String getStatus();

	public boolean isLockResult() {
		return lockResult;
	}

	public void setLockResult(boolean lockResult) {
		this.lockResult = lockResult;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getLockTitle() {
		return lockTitle;
	}

	public void setLockTitle(String lockTitle) {
		this.lockTitle = lockTitle;
	}
}
