package com.assurant.inc.sox.ar.client.ui.tasklist;

import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.RejectedUserTasklistDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RejectedUserTasklistUI extends AbstractTaskListUI {

	public RejectedUserTasklistUI() {
		super(); // Calls the no-args constructor of AbstractTaskListUI
	}

	@Override
	protected AbstractTaskListDTO createDefaultTaskListDTO() {
		return new RejectedUserTasklistDTO(null, null, null);
	}

	@Autowired
	public RejectedUserTasklistUI(RejectedUserTasklistDTO taskList) {
		super(taskList);
	}

	@Override
	public String getBackingEntityName() {
		return "Review User";
	}

	@Override
	public Long getBackingEntiyId() {
		return ((RejectedUserTasklistDTO) this.taskList).getRejectedReviewUserId();
	}

}
