package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.ar.Code;

public class CodeDTO {

	private final Code code;
	

	public CodeDTO(Code code) {
		this.code = code;
	}

	public String getValue() {
		if(this.code.getPk() != null){
			return this.code.getPk().getValue();

		}
		return "";
	}

	public String getDisplay() {
		return this.code.getDisplay();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final CodeDTO other = (CodeDTO) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		return true;
	}

	public Code getCode() {
		return code;
	}
}
