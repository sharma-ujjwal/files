package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.ar.service.IReviewOwnerSummaryService;
import com.assurant.inc.sox.domain.admin.ReviewOwnerSummary;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ConflictType;
import com.assurant.inc.sox.domain.searchable.ReviewOwnerSummarySearchCriteria;

import org.primefaces.component.datascroller.DataScroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("reviewOwnerSummaryBean")
@Scope("session")
public class ReviewOwnerSummaryBean {
	//injected resources
	@Autowired
	@Qualifier("reviewOwnerSummaryService")
	private IReviewOwnerSummaryService reviewOwnerSummaryService;
	@Autowired
	@Qualifier("applicationService")
	private IApplicationService applicationService;
	
	private List<ReviewOwnerSummary> reviewOwnerSummaryList;
	private ReviewOwnerSummarySearchCriteria criteria;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String displayAmount = "10";
	private String oldSortColumn;
	
	DataScroller dataScroller;
	
	public IReviewOwnerSummaryService getReviewOwnerSummaryService() {
		return reviewOwnerSummaryService;
	}

	public void setReviewOwnerSummaryService(
			IReviewOwnerSummaryService reviewOwnerSummaryService) {
		this.reviewOwnerSummaryService = reviewOwnerSummaryService;
	}

	public IApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(IApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public String getActiveFilter() {
		return activeFilter;
	}
	
	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}
	
	public String getSearchReviewOwnerName() {
		return this.criteria.getReviewOwnerName();
	}
	
	public void setSearchReviewOwnerName(String reviewOwnerName) {
		this.criteria.setReviewOwnerName(reviewOwnerName);
	}
	
	public String getSearchOwnerTypeDescription() {
		return this.criteria.getOwnerTypeDescription();
	}
	
	public void setSearchOwnerTypeDescription(String ownerTypeDescription) {
		this.criteria.setOwnerTypeDescription(ownerTypeDescription);
	}
	
	public Long getSearchConflictTypeId() {
		return this.criteria.getConflictTypeId();
	}

	public void setSearchConflictTypeId(Long searchConflictTypeId) {
		this.criteria.setConflictTypeId(searchConflictTypeId);
	}

	public String getSearchConflictCode() {
		return this.criteria.getConflictCode();
	}

	public void setSearchConflictCode(String searchConflictCode) {
		this.criteria.setConflictCode(searchConflictCode);
	}

	public String getSearchLeftConflictName() {
		return this.criteria.getLeftConflictName();
	}

	public void setSearchLeftConflictName(String searchLeftConflictName) {
		this.criteria.setLeftConflictName(searchLeftConflictName);
	}

	public String getSearchRightConflictName() {
		return this.criteria.getRightConflictName();
	}

	public void setSearchRightConflictName(String searchRightConflictName) {
		this.criteria.setRightConflictName(searchRightConflictName);
	}

	public String getSearchCommentText() {
		return this.criteria.getCommentText();
	}
	
	public void setSearchCommentText(String searchCommentText) {
		this.criteria.setCommentText(searchCommentText);
	}
	
	public Long getSearchApplicationId() {
		return this.criteria.getApplicationId();
	}
	
	public void setSearchApplicationId(Long searchApplicationId) {
		this.criteria.setApplicationId(searchApplicationId);
	}
	
	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getOldSortColumn() {
		return oldSortColumn;
	}

	public void setOldSortColumn(String oldSortColumn) {
		this.oldSortColumn = oldSortColumn;
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

	public void setReviewOwnerSummaryList(List<ReviewOwnerSummary> reviewOwnerSummaryList) {
		this.reviewOwnerSummaryList = reviewOwnerSummaryList;
	}

	public List<ReviewOwnerSummary> getReviewOwnerSummaryList() {
		if (reviewOwnerSummaryList == null) {
			this.resetCriteria();
			this.refreshList();
		}
		return reviewOwnerSummaryList;
	}

	private void resetCriteria() {
		this.criteria = new ReviewOwnerSummarySearchCriteria();
	}
	
	public void refreshList() {
		switch(FilterTableCode.valueOf(this.activeFilter)) {
		case ACTIVE_ROWS:
			this.criteria.setActiveOnly(Boolean.TRUE);
			break;
		case DELETED_ROWS:
			this.criteria.setActiveOnly(Boolean.FALSE);
			break;
		}

		/*this.reviewOwnerSummaryList = this.reviewOwnerSummaryService
				.retrieveReviewOwnerSummariesByCriteria(this.criteria);*/

		System.out.println("Into ReviewSummary bean before service call");
		this.reviewOwnerSummaryList = this.reviewOwnerSummaryService
				.retrieveReviewOwnerSummariesByCriteria(this.criteria);
		System.out.println("Into ReviewSummary bean after service call");
		System.out.println("**Review Owner List Size is***"+ reviewOwnerSummaryList.size());
	    this.doSort();
	}

	public String doSearch() {
		this.refreshList();
		return null;
	}
	
	public String resetSearch() {
		this.reviewOwnerSummaryList = null;
		this.resetCriteria();
		this.oldSortColumn = null;
		this.refreshList();
		return null;
	}
	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "conflictType";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(reviewOwnerSummaryList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}

	public String switchFilter() {
		this.oldSortColumn = null;
		this.refreshList();
		return null;
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));

		return availableFilters;
	}
	
	public List<SelectItem> getAvailableConflictCodes() {
		List<SelectItem> availableConflictCodes = new ArrayList<SelectItem>(3);
		availableConflictCodes.add(new SelectItem("", ""));
		availableConflictCodes.add(new SelectItem(ConflictType.CONFLICT_CODE_APP_APP, "App to App"));
		availableConflictCodes.add(new SelectItem(ConflictType.CONFLICT_CODE_APP_DIV, "App to Div"));
	
		return availableConflictCodes;
	}
	
	public List<SelectItem> getAvailableApplications() {
		List<Application> applicationList = this.applicationService.retrieveAllApplications();
		Collections.sort(applicationList, new Comparator<Application>() {
			public int compare(Application application1, Application application2) {
				return application1.getName().compareTo(application2.getName());
			}
		});
		List<SelectItem> availableApplications = new ArrayList<SelectItem>();
		availableApplications.add(new SelectItem("", ""));
		for (Application application : applicationList) {
			availableApplications.add(new SelectItem(application.getId(), application.getName()));
		}
		
		return availableApplications;
	}
	
	public void init() {
		this.reviewOwnerSummaryList = null;
		this.resetCriteria();
		this.oldSortColumn = null;
		this.displayAmount = "10";
	}
}

