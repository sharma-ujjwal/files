/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.ar.service.IApplicationSystemService;
import com.assurant.inc.sox.ar.service.IEnvironmentService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IApplicationDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Environment;


/**
 * @author RuthSchmalz
 */
@Service
public class ApplicationService implements IApplicationService {
	@Autowired
	private IApplicationDao applicationDao;
	
	@Autowired
	private IApplicationSystemService applicationSystemService;	
	
	@Autowired
	private IEnvironmentService environmentService;	
	@Autowired
	private SystemUserDTO systemUser;

	public List<Application> retrieveAllApplications(){
		return  this.applicationDao.findAll();
	}
	
	public List<Application> retrieveAllApplicationsByName(String applicationNameSearchText) {
		return this.applicationDao.findAllByName(applicationNameSearchText);
	}
	
	public List<Application> retrieveDeletedApplications() {
		return this.applicationDao.findDeleted();
	}

	public List<Application> retrieveDeletedApplicationsByName(String applicationNameSearchText) {
		return this.applicationDao.findDeletedByName(applicationNameSearchText);
	}

	public List<Application> retrieveUnassignedApplications() {
		return this.applicationDao.findUnassigned();
	}

	public List<Application> retrieveUnassignedByName(String searchString) {
		return this.applicationDao.findUnassignedByName(searchString);
	}

	public IApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(IApplicationDao applicationDao) {
		this.applicationDao = applicationDao;
	}
	
	public Application findById(Long id) {
		return this.applicationDao.findById(id);
	}

	public Application  findDuplicate(String name) {
		return this.applicationDao.findDuplicate(name);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String applicationName) {
		Date currentDate = new Date();

		//Create a Application record.
		Application application = new Application();
		application.setName(applicationName);
		application.setDeleteFlag(IFlags.NOT_DELETED);
		application.setCreatedBy(this.systemUser.getUserId());
		application.setCreatedDate(currentDate);
		application.setActiveFromDate(currentDate);
		application.setActiveToDate(DateUtil.END_OF_TIME);

		this.applicationDao.save(application);

		//Get a list of all 81_Environments
		List<Environment> environmentList = this.environmentService.retrieveAllEnvironments();

		//Join the new 86Application record to each 81Environment record
        // and create new 83ApplicationSystem record for each.   
		for (Environment environment   : environmentList) {
			this.applicationSystemService.addNewApplicationSystem(environment, application,  currentDate);
		}
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(Application application) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		Application currentApplication = new Application();
		currentApplication.setName(application.getName());
		currentApplication.setDeleteFlag(IFlags.NOT_DELETED);
		currentApplication.setCreatedBy(application.getCreatedBy());
		currentApplication.setCreatedDate(application.getCreatedDate());
		currentApplication.setLastChangedBy(this.systemUser.getUserId());
		currentApplication.setLastChangedDate(currentDate);
		currentApplication.setActiveFromDate(application.getActiveFromDate());
     	currentApplication.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.applicationDao.save(currentApplication);

		
		//Create a Deleted Application record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		//Val says we need to add one sec to the TimeDateStamp 
		application.setDeleteFlag(IFlags.DELETED);
		application.setActiveFromDate(currentDate);
		application.setActiveToDate(currentDate);
		this.applicationDao.save(application);
		
		
		//Delete "Application Systems" that are attached to this Application. 
		this.applicationSystemService.deleteAllApplicationSystemByApplicationId(application, currentDate);

	}

	public boolean canApplicationBeDeleted(String applicationName) {
		return this.applicationDao.canBeDeleted(applicationName);
	}
}
