package com.assurant.inc.sox.ar.client.bean.tasklist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.service.impl.ReviewBundleService;
import com.assurant.inc.sox.ar.service.impl.ReviewService;
import com.assurant.inc.sox.ar.service.impl.ReviewerService;
import com.assurant.inc.sox.ar.service.impl.tasklist.ReviewerTaskListService;
import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.UserDataUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.ReviewerTaskListUI;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListField;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListFilterType;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.impl.InactiveReassignReviewerException;
import com.assurant.inc.sox.ar.service.tasklist.IReviewerTaskListService;
import com.assurant.inc.sox.ar.utils.exceptions.UnReassignableException;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import static org.primefaces.behavior.validate.ClientValidator.PropertyKeys.event;

@Component("allTaskListBean")
@Scope("session")
public class AllTaskListBean extends
		AbstractTaskListBean<ReviewerTaskListUI, ReviewerTaskListDTO> implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private static final int MAX_REASSIGN_COMMENT_LENGTH = 100;
	private static final int MAX_REASSIGN_INSTRUC_LENGTH = 2000;
	private static final Logger logger = LoggerFactory
			.getLogger(AllTaskListBean.class);

	@Autowired
	@Qualifier("reviewerService")
	private ReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewBundleService")
	private ReviewBundleService reviewBundleService;
	@Autowired
	@Qualifier("reviewService")
	private ReviewService reviewService;
	@Autowired
	@Qualifier("reviewerTaskListService")
	private ReviewerTaskListService reviewerTaskListService;
	private boolean renderReassignReviewerModalPanel;
	private List<SelectItem> availableReassignReviewerSelectItems;
	private List<UserDataUI> availableReassignReviewers;
	private Long selectedReassignUserId;
	private ReviewerTaskListUI selectedReassignTaskList;
	private String commentsInput;
	private String selectReasonInput;
	private Date targetCompDate;
	private String instructions;

	List<ReviewerTaskListDTO> taskResults;

	public List<ReviewerTaskListDTO> myReviewerTaskListBeanResults;

	private List<ReviewerTaskListDTO> selectedTasksList = new ArrayList<>();

	private ReviewerTaskListDTO selectedTaskListDTO;

	public List<ReviewerTaskListDTO> getMyReviewerTaskListBeanResults() {
		return myReviewerTaskListBeanResults;
	}

	public void setMyReviewerTaskListBeanResults(List<ReviewerTaskListDTO> myReviewerTaskListBeanResults) {
		this.myReviewerTaskListBeanResults = myReviewerTaskListBeanResults;
	}

	public AllTaskListBean() {
		super(TaskListFilterType.REVIEW_TYPE, "allTaskListBean", "allTaskList");
	}

	// ----------------------------- Faces injected properties ----------------

	public ReviewerTaskListService getReviewerTaskListService() {
		return reviewerTaskListService;
	}

	public void setReviewerTaskListService(
			ReviewerTaskListService reviewerTaskListService) {
		this.reviewerTaskListService = reviewerTaskListService;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(ReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(ReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(ReviewService reviewService) {
		this.reviewService = reviewService;
	}

	// -------------------------- abstract method impls -----------------------

	/*
	 * The all task tab cannot be drilled into so override the column to be
	 * display only.
	 */
	@Override
	protected Object buildTaskNameColumn() {
		return this.buildColumn("Task", TaskListField.TASK_NAME,
				"SortByTaskNameLink");
	}

	/*
	 * The all task list will contain the reviewer tasks for all reviewers.
	 * 
	 * @seecom.assurant.inc.sox.ar.client.bean.tasklist.AbstractTaskListBean#
	 * retrieveTaskListDTOs()
	 */
	@Override
	protected List<ReviewerTaskListDTO> retrieveTaskListDTOs() {
		List<ReviewerTaskListDTO> results;
		if (this.sessionDataBean.getSelectedTabId().equals(
				this.sessionDataBean.getAllTaskTabId())) {
			results = this.reviewerTaskListService
					.retrieveTaskListForAllReviewers();
		} else {
			results = new ArrayList<ReviewerTaskListDTO>();
		}

		for (ReviewerTaskListDTO result : results) {
			buildClientObject(result);

		}
		// Sort the results by
		String sortField = TaskListField.CREATE_DATE.getFieldName();
		Collections.sort(results, new GenericComparator(sortField, false));
		this.previousSortFieldCodeValue = sortField;

		taskResults = results;
		myReviewerTaskListBeanResults = results;
		return results;
	}

	/*
	 * The all task list will only contain reviewer tasks.
	 * 
	 * @seecom.assurant.inc.sox.ar.client.bean.tasklist.AbstractTaskListBean#
	 * buildClientObject
	 * (com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO)
	 */
	@Override
	protected ReviewerTaskListUI buildClientObject(ReviewerTaskListDTO dto) {
		return new ReviewerTaskListUI(dto);
	}

	@Override
	protected void loadBean() {
		this.renderTaskList = this.sessionDataBean.getSystemUser()
				.isItComplianceUser();
		super.loadBean();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void addTableColumns(DataTable table) {
		logger.debug("addTableColumns -- enter");
		List tableChildren = table.getChildren();
		tableChildren.add(this.buildSelectTypeColumn());
		super.addTableColumns(table);
	}

	private Column buildSelectTypeColumn() {
		HtmlSelectBooleanCheckbox checkBox = new HtmlSelectBooleanCheckbox();
		checkBox.setId("reviewUserCheckBox");
		StringBuilder sb = new StringBuilder(20).append("#{taskList.").append(
				TaskListField.SELECTED.getFieldName()).append('}');
		JSFUtils.setValueBinding(checkBox, "value", sb.toString());

		sb.setLength(0);
		sb.append("#{").append(this.beanName).append(".doSelectedToggle");
		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink(
				"All/None", "#{" + this.beanName + ".doSelectedToggle}",
				(this.idPrefix + "SelectAllLink"));
		return HtmlTableBuilderUtil.buildColumn(link, checkBox);
	}

//	public String doSelectedToggle() {
//		logger.debug("doSelectedToggle -- enter");
//		CommonPageActionHelper.selectPagedTableAllToggle(this.taskListTable);
//		return null;
//	}

	public void onRowSelect() {
		selectedTasksList.clear();
		for (ReviewerTaskListDTO task : myReviewerTaskListBeanResults) {
			if (task.isRowSelected()) {
				selectedTasksList.add(task);
			}
		}
	}


	@SuppressWarnings("unchecked")
	public String doPrepareReassignReviewersPanel() {
		logger.debug("doPrepareReassignReviewersPanel -- enter");
		ReviewerTaskListDTO selectedTaskList = null;
		boolean validSelection = true;
		for (ReviewerTaskListDTO task : selectedTasksList) {
			if (task.isRowSelected()) {
				if (selectedTaskList != null) {
					validSelection = false;
					break;
				}
				selectedTaskList = task;
			}
		}

		if (!(validSelection) || selectedTaskList == null) {
			JSFUtils
					.addFacesErrorMessage("An invalid number of reviewers were selected.  Exactly one reviewer must be selected to perform a reassignment.");
			this.renderReassignReviewerModalPanel = false;
			return null;
		}
		String typeCodeValue = selectedTasksList.get(0).getReview().getReviewTypeCd().getValue();
		ReviewerDTO reviewer = selectedTasksList.get(0).getReviewer();
//		String typeCodeValue = selectedTaskList.getTaskList().getReview()
//				.getReviewTypeCd().getValue();
//		ReviewerDTO reviewer = ((ReviewerTaskListDTO) selectedTaskList
//				.getTaskList()).getReviewer();
		List<UserDataDTO> availableReviewers;
		boolean inactiveFound = false;
		if (ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(typeCodeValue)) {
			// if manager type review then only allow supervisor to reassign to.
			logger.info("Manager reviewer for reassignment");
			availableReviewers = this.reviewerService
					.getManagerReviewAvailableReassignReviewers(reviewer
							.getUserId());
		} // else if
		// (ReviewTypeCode.SEGREGATION_OF_DUTIES.equals(typeCodeValue)) {
		else if ("SGDU".equals(typeCodeValue)) {
			try {
				
				availableReviewers = this.reviewerService
						.getSODAvailableReassignReviewers(reviewer
								.getConflict(), reviewer.getUserId());
				if (availableReviewers == null) {
					logger.info("SOD Reviewers are not available...");
					availableReviewers = this.reviewerService
							.getDataOwnerReviewAvailableReassignReviewers(
									reviewer.getApplicationId(), reviewer
											.getUserId());
				}
			} catch (InactiveReassignReviewerException e) {
				availableReviewers = e.getInactiveUsers();
				inactiveFound = true;
			}
		} else {
			// retrieve all of the data owners that are able to be reassigned to
			// for the given
			// application.
			try {
				
				availableReviewers = this.reviewerService
						.getDataOwnerReviewAvailableReassignReviewers(reviewer
								.getApplicationId(), reviewer.getUserId());
			} catch (InactiveReassignReviewerException e) {
				availableReviewers = e.getInactiveUsers();
				inactiveFound = true;
			}
		}

		if (inactiveFound) {
			StringBuilder sb = new StringBuilder();
			sb
					.append("An inactive reassign reviewer was found.  The user record must be corrected before continuing: ");
			for (UserDataDTO user : availableReviewers) {
				sb.append(user.getName());
				sb.append(" - ");
				sb.append(user.getUserId());
				sb.append("; ");
			}
			JSFUtils.addFacesErrorMessage(sb.toString());
			availableReviewers.clear();
		}

		else if (availableReviewers.isEmpty()) {
			JSFUtils
					.addFacesErrorMessage("No reassignable reviewers were found.");
		}

		this.setReassignReviewers(availableReviewers);
		this.renderReassignReviewerModalPanel = true;
		this.selectedReassignUserId = null;
		this.selectedTaskListDTO = selectedTaskList;
		this.commentsInput = null;
		this.selectReasonInput = null;
		this.targetCompDate = reviewer.getDistributionTargetCompleteDate();
		this.instructions = reviewer.getDistributionInstructions();
		return null;
	}

	private void setReassignReviewers(List<UserDataDTO> reviewers) {
		int reviewersCnt = reviewers.size();
		this.availableReassignReviewerSelectItems = new ArrayList<SelectItem>(
				reviewersCnt);
		this.availableReassignReviewers = new ArrayList<UserDataUI>(
				reviewersCnt);
		for (UserDataDTO reviewer : reviewers) {
			this.availableReassignReviewers.add(new UserDataUI(reviewer));
		}

		for (UserDataUI reviewer : this.availableReassignReviewers) {
			String ownerType = (reviewer.getOwnerTypeDescription() != null ? reviewer
					.getOwnerTypeDescription()
					: "MANAGER");
			String name = reviewer.getName() + " (" + ownerType + ")";
			this.availableReassignReviewerSelectItems.add(new SelectItem(
					reviewer.getUserId(), name));
		}
	}

	/**
	 * Performs the actual reassignment if the input data is valid.
	 * 
	 * @return null to navigate back to the same page.
	 */
	public String doSaveReassignReviewersPanel() {

		if (this.selectedReassignUserId == null) {
			// if a data owner review then a data owner must have been selected.
			JSFUtils.addFacesErrorMessage("A data owner must be selected.");
		} else if (StringUtils.isBlank(this.selectReasonInput)) {
			// a reason must be selected to do a reassign
			JSFUtils
					.addFacesErrorMessage("A reason must be selected to perform a reassignment.");
		} else if (StringUtils.isNotBlank(this.commentsInput)
				&& this.commentsInput.length() > MAX_REASSIGN_COMMENT_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a reject comment is "
							+ MAX_REASSIGN_COMMENT_LENGTH);
		} else if (this.instructions.length() > MAX_REASSIGN_INSTRUC_LENGTH) {
			JSFUtils
					.addFacesErrorMessage("The maximum length of a Reviewer instructions is "
							+ MAX_REASSIGN_INSTRUC_LENGTH);
		} else {

			UserDataUI newReassignUser = null;

			Long selectedDataOwnerId = this.selectedReassignUserId;
			for (UserDataUI user : this.availableReassignReviewers) {
				if (selectedDataOwnerId.equals(user.getUserId())) {
					newReassignUser = user;
					break;
				}
			}

			if (newReassignUser == null) {
				throw new RuntimeException(
						"An invalid user id was found for the selected data owner.  Id = "
								+ selectedDataOwnerId);
			}

			this.renderReassignReviewerModalPanel = false;

			// set reassigned data, target due date and reviewer instructions
			newReassignUser.setReassignedInstructions(this.instructions);
			newReassignUser
					.setReassignedTargetCompleteDate(this.targetCompDate);

			try {
				this.reviewerService.reassignReleasedReviewer(
						this.selectedTaskListDTO.getReviewer(),
						this.selectReasonInput, this.commentsInput,
						newReassignUser.getUserData(),
						this.selectedTaskListDTO.getTaskId());
				this.renderReassignReviewerModalPanel = false;
				this.resetTaskListValues();
			} catch (UnReassignableException e) {
				JSFUtils.addFacesErrorMessage(e.getLocalizedMessage());
			}

		}
		return null;
	}

	/**
	 * Cancels the reassignment processes.
	 * 
	 * @return null to return to the same page.
	 */
	public String doCancelReassignReviewersPanel() {
		this.renderReassignReviewerModalPanel = false;
		return null;
	}

	public String getCommentsInput() {
		return commentsInput;
	}

	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	public List<SelectItem> getAvailableReassignReviewerSelectItems() {
		return availableReassignReviewerSelectItems;
	}

	public Long getSelectedReassignUserId() {
		return selectedReassignUserId;
	}

	public void setSelectedReassignUserId(Long selectedReassignUserId) {
		this.selectedReassignUserId = selectedReassignUserId;
	}

	public boolean isRenderReassignReviewerModalPanel() {
		return renderReassignReviewerModalPanel;
	}

	public Date getTargetCompDate() {
		return targetCompDate;
	}

	public void setTargetCompDate(Date targetCompDate) {
		this.targetCompDate = targetCompDate;
	}

	public String getInstructions() {
		return instructions;
	}

	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	/**
	 * Listener for the data table scroller. Clears selections so that when the
	 * user changes table pages all selections will be cleared.
	 * 
	 * @param event
	 *            not used.
	 */
	public void doScrollerListener(PageEvent event) {
		logger
				.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	@SuppressWarnings("unchecked")
	private void clearSelections() {
		for (ReviewerTaskListUI taskList : (List<ReviewerTaskListUI>) this.taskListTable
				.getValue()) {
			taskList.setSelected(false);
		}
	}

	@Override
	public String doSortByField() {
		this.clearSelections();
		return super.doSortByField();
	}

	public List<ReviewerTaskListDTO> getSelectedTasksList() {
		return selectedTasksList;
	}

	public void setSelectedTasksList(List<ReviewerTaskListDTO> selectedTasksList) {
		this.selectedTasksList = selectedTasksList;
	}

	public void setRenderReassignReviewerModalPanel(boolean renderReassignReviewerModalPanel) {
		this.renderReassignReviewerModalPanel = renderReassignReviewerModalPanel;
	}
}