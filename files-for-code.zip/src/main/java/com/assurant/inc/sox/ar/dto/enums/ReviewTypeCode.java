package com.assurant.inc.sox.ar.dto.enums;

import com.assurant.inc.sox.domain.ar.Review;

public enum ReviewTypeCode {
	MANAGER(Review.MANAGER_TYPE_CODE), DATA_OWNER(Review.DATA_OWNER_TYPE_CODE), SEGREGATION_OF_DUTIES(
	    Review.SEGREGATION_OF_DUTIES_TYPE_CODE), PRIVILEGED_ACCESS(Review.PRIVILEGED_ACESS_TYPE_CODE);

	private final String code;

	private ReviewTypeCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
		
	}

	public static ReviewTypeCode getByCodeValue(String codeValue) {
		ReviewTypeCode result = null;
		for (ReviewTypeCode codeValueIn : ReviewTypeCode.values()) {
			if (codeValueIn.code.equalsIgnoreCase(codeValue)) {
				result = codeValueIn;
				break;
			}
		}
		return result;
	}
}
