package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;


import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.component.datascroller.DataScroller;

import com.assurant.inc.sox.ar.client.admin.ui.ReviewOwner;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IConflictService;
import com.assurant.inc.sox.domain.ar.Conflict;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("conflictSummaryBean")
@Scope("session")
public class ConflictSummaryBean {
	private List<ReviewOwner> conflictList;
	@Autowired
	@Qualifier("conflictService")
	private IConflictService conflictService;
	private String displayAmount = "10";
	private String oldSortColumn;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String conflictCode;
	private String leftConflictSearchText;
	private String rightConflictSearchText;
	private SessionDataBean sessionDataBean;
	private Long selectedConflictId;
	private DataScroller dataScroller;

	public List<ReviewOwner> getConflictList() {
		if (conflictList == null) {
			refreshList();
		}
		return conflictList;
	}

	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.conflictList = new ArrayList<ReviewOwner>();

		List<Conflict> conflictsRetrieved = new ArrayList<Conflict>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.leftConflictSearchText) ||
				StringUtils.isNotEmpty(this.rightConflictSearchText)	) {
				conflictsRetrieved = this.conflictService.retrieveAllConflictsByName(this.leftConflictSearchText, this.rightConflictSearchText);
			} else {
				conflictsRetrieved = this.conflictService.retrieveAllConflicts();
			}
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.leftConflictSearchText) ||
				StringUtils.isNotEmpty(this.rightConflictSearchText)) {
				conflictsRetrieved = this.conflictService.retrieveDeletedConflictsByName(this.leftConflictSearchText, this.rightConflictSearchText);
			} else {
				conflictsRetrieved = this.conflictService.retrieveDeletedConflicts();
			}
		}
		for (Conflict conflict : conflictsRetrieved) {
			this.conflictList.add(new ReviewOwner(conflict));
		}
	    this.doSort();
	}

	// ******* GO button *******
	public String goSearch() {
		refreshList();
		return "";
	}

	// ******* RESET  button *******
	public String resetSearch() {
		this.conflictList = null;
		this.rightConflictSearchText = null;
		this.leftConflictSearchText  = null;
		this.oldSortColumn = null;

		refreshList();
		return "";
	}

	// *******  Filter ListBox *******
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// *******  List Headers *******
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "leftConflictName";
			}

			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(conflictList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}


	public boolean validConflict() {
		return this.selectedConflictId != null;
	}


	public String getConflictCode() {
		return this.conflictCode;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getLeftConflictSearchText() {
		return leftConflictSearchText;
	}

	public void setLeftConflictSearchText(String leftConflictSearchText) {
		this.leftConflictSearchText = leftConflictSearchText;
	}

	public String getRightConflictSearchText() {
		return rightConflictSearchText;
	}

	public void setRightConflictSearchText(String rightConflictSearchText) {
		this.rightConflictSearchText = rightConflictSearchText;
	}

	public void setConflictList(List<ReviewOwner> conflictList) {
		this.conflictList = conflictList;
	}

	public IConflictService getConflictService() {
		return conflictService;
	}

	public void setConflictService(IConflictService conflictService) {
		this.conflictService = conflictService;
	}

	public Long getSelectedConflictId() {
		return selectedConflictId;
	}

	public void setSelectedConflictId(Long selectedConflict) {
		this.selectedConflictId = selectedConflict;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.conflictList = null;
		this.leftConflictSearchText = null;
		this.rightConflictSearchText = null;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}
