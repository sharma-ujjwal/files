package com.assurant.inc.sox.ar.dto;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.consts.ISecurityAccessType;

public class SystemUserDTO {

	private String firstName;

	private String lastName;

	private String userId;

	private List<String> ldapRoles = new ArrayList<String>();

	private List<String> functionAccessCodes;

	boolean itComplianceUser;

	boolean reviewer;
	
	boolean ipsUser;

	public SystemUserDTO() {
		// ldapRoles.add("EBSOXSA");
		// firstName = "Test";
		// lastName = "User";
		// userId = "tu1234";
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public List<String> getFunctionAccessCodes() {
		/*
		 * null protect
		 */
		if (this.functionAccessCodes == null) {
			this.functionAccessCodes = new ArrayList<String>();
		}
		return this.functionAccessCodes;
	}

	public void setFunctionAccessCodes(List<String> functionAccessCodes) {
		this.functionAccessCodes = functionAccessCodes;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<String> getLdapRoles() {
		return this.ldapRoles;
	}

	public void setLdapRoles(List<String> ldapRoles) {
		this.ldapRoles = ldapRoles;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean isCallerInRole(String method) {
		return (this.getFunctionAccessCodes().contains(method));
	}

	public boolean isViewDashBoard() {
		return (this.getFunctionAccessCodes().contains(ISecurityAccessType.VIEW_DASHBOARD));
	}

	public boolean isPerformReviewActions() {
		return this.getFunctionAccessCodes()
		    .contains(ISecurityAccessType.REVIEW_SERVICE + ISecurityAccessType.PERFORM_REVIEW_ACTIONS);
	}

	public boolean isPerformAdminActions() {
		return (this.itComplianceUser || this.ipsUser);
	}
	
	public boolean isItComplianceUser() {
		return itComplianceUser;
	}

	public void setItComplianceUser(boolean itComplianceUser) {
		this.itComplianceUser = itComplianceUser;
	}

	public boolean isReviewer() {
		return reviewer;
	}

	public void setReviewer(boolean reviewer) {
		this.reviewer = reviewer;
	}

	public boolean isIpsUser() {
		return ipsUser;
	}

	public void setIpsUser(boolean ipsUser) {
		this.ipsUser = ipsUser;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("firstName: ").append(this.firstName).append("\n");
		sb.append("lastName: ").append(this.lastName).append("\n");
		sb.append("userId: ").append(this.userId).append("\n");
		sb.append("ldapRoles: ").append(this.ldapRoles).append("\n");
		return sb.toString();
	}

	public String getName() {
		return this.firstName + " " + this.lastName;
	}
}
