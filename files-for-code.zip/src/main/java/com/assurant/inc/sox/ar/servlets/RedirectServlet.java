package com.assurant.inc.sox.ar.servlets;

import com.assurant.inc.sox.ar.utils.http.HttpHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Business rule states that if user is an ITCompliance user then the default
 * page should be the dashboard, otherwise default to the tasklist. This servlet
 * will determine that and redirect the logged in user to the correct page.
 */
public class RedirectServlet extends BaseServlet {

	/*
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(RedirectServlet.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		logger.debug("in RedirectServlet");
		ApplicationContext context = getContext(request.getSession().getServletContext());

		/*
		 * Get the user's ldap groups
		 */
		String ldapGroups = request.getHeader("sm_groups");
		if(ldapGroups == null) {
			System.out.println("Inside redirect servlet- failed to get the sm_groups");
			ldapGroups = "EBSOXITOWNER";

			((HttpServletResponse) response).setHeader("sm_groups",
					"EBSOXITOWNER");
			((HttpServletResponse) response).setHeader("sm_user",
					"TB42140");
		}
		/*
		 * parse out only the ldap web roles
		 */
		List<String> ldapRoles = HttpHelper.parseHttpHeaderGroups(ldapGroups);
		
		/*
		 * get the ITCompliance ldap group name
		 */
		String soxLdapITComplianceRole = (String) context.getBean("soxLdapITComplianceRole");
		String soxLdapIpsUserRole = (String) context.getBean("soxLdapIpsUserRole");
		
		if (ldapRoles.contains(soxLdapITComplianceRole)) {
			String defaultPageITComp = (String) context.getBean("defaultPageITComp");
			request.getRequestDispatcher(defaultPageITComp).forward(request, response);
		} else if (ldapRoles.contains(soxLdapIpsUserRole)){
			String defaultPageIpsUser = (String) context.getBean("defaultPageIpsUser");
			request.getRequestDispatcher(defaultPageIpsUser).forward(request, response);
			
		} else {
			String defaultPageReviewer = (String) context.getBean("defaultPageReviewer");
			
			RequestDispatcher dispatcher = request.getRequestDispatcher(defaultPageReviewer);
			if(dispatcher != null){
				dispatcher.forward(request, response);
			}
		}
		
	}
}
