package com.assurant.inc.sox.ar.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.enums.ReviewBundleStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.base.ReviewerServiceBase;
import com.assurant.inc.sox.ar.service.util.EmailService;
import com.assurant.inc.sox.ar.service.util.WorkflowUtil;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;
import com.assurant.inc.sox.ar.utils.exceptions.UnReassignableException;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewApplication;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.ReviewOwner;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.domain.ar.ReviewerReassignment;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.luad.User;
import com.assurant.inc.sox.domain.luad.UserAccess;

/**
 * A service for persisting and retrieving reviewer data.
 * 
 */
@Service("reviewerService")
public class ReviewerService extends ReviewerServiceBase implements
		IReviewerService {
	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#retrieveByBundleId(java
	 * .lang.Long)
	 */
	public List<ReviewerDTO> retrieveByBundleId(Long reviewBundleId) {
		return this.retrieveByBundleId(reviewBundleId, true);
	}

	/**
	 * Retrieves all of the reviewers for the given bundle id.
	 * 
	 * @param reviewBundleId
	 *            the id of the bundle to retrieved reviewers for.
	 * @param checkDeptLoad
	 *            flag to determine if the department should be loaded. If true
	 *            then a check will be done to see if the departments will be
	 *            loaded. If false then departments will not be loaded.
	 * @return
	 */
	private List<ReviewerDTO> retrieveByBundleId(Long reviewBundleId,
			boolean checkDeptLoad) {
		getLogger().debug(
				"retrieveByBundleId(reviewBundleId) --> being executed.");

		boolean loadReviewerDistinctDeptCount = (checkDeptLoad)
				&& (this.loadReviewerDistinctDeptCount(reviewBundleId));
		return buildReviewerDTOList(this.reviewerDao
				.findByReviewBundleId(reviewBundleId),
				loadReviewerDistinctDeptCount);
	}

	private boolean loadReviewerDistinctDeptCount(Long reviewBundleId) {
		boolean loadDepts = true;
		ReviewBundle bundle = this.reviewBundleDao.findById(reviewBundleId);
		if (bundle != null) {
			Review review = this.reviewDao.findById(bundle.getReviewId());
			if (review != null) {
				loadDepts = !(ReviewTypeCode.MANAGER.getCode()
						.equalsIgnoreCase(review.getReviewTypeCd()));
			}
		}

		return loadDepts;
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#retrieveByStatus(java
	 * .lang.Long,
	 * com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode)
	 */
	public List<ReviewerDTO> retrieveByStatus(Long reviewBundleId,
			ReviewerStatusCode status) {
		getLogger().debug(
				"retrieveByStatus(reviewBundleId, status) --> being executed.");

		return buildReviewerDTOList(this.reviewerDao.findByStatus(
				reviewBundleId, status.getCode()), this
				.loadReviewerDistinctDeptCount(reviewBundleId));
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * populateReviewerAdditionalDetails
	 * (com.assurant.inc.sox.ar.dto.ReviewerDTO)
	 */
	public void populateReviewerDistinctEnvName(ReviewerDTO reviewer) {
		getLogger()
				.debug(
						"populateReviewerAdditionalDetails(ReviewerDTO reviewer)--> being executed.");
		List<String> envs = this.reviewerDao.findDistinctEnvironments(reviewer
				.getReviewerId());
		reviewer.setDistinctEnvName(DisplayStringBuilder
				.buildCommaDelimitedList(envs));
	}

	public void populateHasManagerAccessToApplication(
			List<ReviewerDTO> reviewers) {
		for (ReviewerDTO dto : reviewers) {
			// set if the user has access to the application
			User user = this.userDao.findByUserId(dto.getUserId());
			if (user != null) {
				List<String> accesses = this.userAccessDao
						.checkManagerAccessToSoxApp(user.getPk().getKeyId());
				dto
						.setHasAccessToApplication((accesses
								.contains(UserAccess.SOX_APP_PRIV_VALUE_APP) && accesses
								.contains(UserAccess.SOX_APP_PRIV_VALUE_MANAGER)));
			} else {
				logger
						.error("Active User Not Found in the SDT025_USER table for: "
								+ dto);
			}
		}
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#approveReviewers(java
	 * .util.List)
	 */
	public void approveReviewers(List<ReviewerDTO> reviewerDTOs) {
		getLogger().debug(
				"approveReviewers(List<ReviewerDTO>) --> being executed.");
		List<Reviewer> reviewers = new ArrayList<Reviewer>(reviewerDTOs.size());
		Date now = new Date();
		for (ReviewerDTO reviewerDTO : reviewerDTOs) {
			Reviewer reviewer = reviewerDTO.getReviewer();
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.APPROVED
					.getCode());
			reviewer.setReviewerApprovedDate(now);
			reviewer.setReviewerApprovedBy(getSessionSystemUser().getUserId());
			reviewers.add(reviewer);
		}
		this.reviewerDao.save(reviewers);
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#distributeReviewers(
	 * java.util.List, java.util.Date, java.lang.String)
	 */
	public List<ReviewerDTO> distributeReviewers(
			List<ReviewerDTO> reviewerDTOs, Date targetDate, String instructions) {
		getLogger().debug(
				"distributeReviewers(List<ReviewerDTO>) --> being executed.");
		List<Reviewer> reviewers = new ArrayList<Reviewer>(reviewerDTOs.size());
		Date now = new Date();
		Set<Long> reviewBundleIds = new HashSet<Long>();

		Long tempReviewBundleId = null;
		String reviewName = null;
		for (ReviewerDTO reviewerDTO : reviewerDTOs) {
			Reviewer reviewer = reviewerDTO.getReviewer();
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.RELEASED
					.getCode());
			reviewer.setReviewerReleaseDate(now);
			reviewer.setReviewerReleaseBy(getSessionSystemUser().getUserId());
			reviewer.setDistributionInstructions(instructions);
			reviewer.setDistributionTargetCompleteDate(targetDate);

			/*
			 * if we have the same review bundle id no need to get the review
			 * name again
			 */
			if (!reviewer.getReviewBundleId().equals(tempReviewBundleId)) {
				reviewName = getReviewBundleService().retrieveReviewName(
						reviewer.getReviewBundleId());

				/*
				 * set temp id to current bundle id
				 */
				tempReviewBundleId = reviewer.getReviewBundleId();
			}

			reviewBundleIds.add(reviewer.getReviewBundleId());
			reviewers.add(reviewer);
		}

		/*
		 * create savvions task for the reviewers, this will return any
		 * reviewers that now don't currently have an active record for the
		 * userId. This happens sometimes when bad data gets in the sdt025_user
		 * table and their record gets logically deleted and reinserted with a
		 * new userId
		 */
		List<Reviewer> notFoundUsers = this.beginReviewerSavvionProcess(
				reviewers, reviewName);

		/*
		 * remove any not found users so they do not get updated with a
		 * distributed status
		 */
		reviewers.removeAll(notFoundUsers);

		this.reviewerDao.save(reviewers);

		List<ReviewerDTO> notFoundReviewers = new ArrayList<ReviewerDTO>();
		String bundleName = getReviewBundleService().retrieveBundleName(
				reviewers.get(0).getReviewBundleId());
		for (Reviewer notFoundUser : notFoundUsers) {
			CodeDTO rejectCode = null;
			CodeDTO statusCode = null;
			if (notFoundUser.getRejectCode() != null) {
				rejectCode = this.codeService.retrieveCodeByValueFromCache(
						CodeSet.REVIEWER_REJECT_REASON, notFoundUser
								.getRejectCode());
			}
			if (notFoundUser.getReviewerLastStatusCd() != null) {
				statusCode = this.codeService.retrieveCodeByValueFromCache(
						CodeSet.REVIEWER_STATUS, notFoundUser
								.getReviewerLastStatusCd());
			}
			notFoundReviewers.add(new ReviewerDTO(notFoundUser, rejectCode,
					statusCode, bundleName));
		}

		return notFoundReviewers;
	}

	public void completeSavvionProcess(Set<Long> reviewBundleIds) {
		getLogger()
				.debug(
						"completeSavvionProcess(Set<Long> reviewBundleIds) --> being executed.");
		for (Long reviewBundleId : reviewBundleIds) {
			if (isReviewDetailCompleted(reviewBundleId)) {
				// mark the bundle as complete and complete the savvion process.
				ReviewBundle bundle = this.reviewBundleDao
						.findById(reviewBundleId);
				if (bundle != null) {
					bundle.setBundleStatusCode(ReviewBundleStatusCode.COMPLETED
							.getCode());
					this.reviewBundleDao.save(bundle);
					// Time being change added variables
					Map<String, Object> variables = new HashMap<String, Object>(1);	        
					variables.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, "test");
					
					
					// Added by Shiv Start 
					variables.put(ITaskValues.DATASLOTS_ASSIGNEDTO, "ITCompliance");
					variables.put(ITaskValues.TEMPLATE_CODE, TaskTypeCode.REVIEWER_TASK );
					variables.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX, ITaskValues.PROCESS_TEMPLATE_NAME_VERIFY);
					variables.put(ITaskValues.DATASLOTS_TEMPLATECODE, DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY);
					//variables.put(ITaskValues.DATASLOTS_REVIEWER_ID,reviewBundleId);
					getWorkflowService().updateProcessDataSlots(bundle.getTaskProcessId(),variables);
					// Added by Shiv End
					// Commented by Shiv Start
					/*getWorkflowService().completeProcess(
							bundle.getTaskProcessId(),variables);*/
					// Commented by Shiv End
					
				} else {
					logger
							.warn("A completed bundle could not be found with the bundle id of: "
									+ reviewBundleId);
				}
			}
		}
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#reassignReleasedReviewer
	 * (com.assurant.inc.sox.ar.dto.ReviewerDTO, ReviewerReassignReasonCode,
	 * String, UserDataDTO, String)
	 */
	public void reassignReleasedReviewer(ReviewerDTO reviewerDTO,
			String reasonCode, String comments, UserDataDTO newUser,
			String taskProcessId) throws UnReassignableException {
		String emailAddress = newUser.getEmailAddress();
		if (emailAddress.equals("-1")) {
			throw new UnReassignableException(
					"The task can not be reassigned to the provided user due to an invalid email address.  User Name: "
							+ newUser.getName()
							+ " email address: "
							+ emailAddress);
		}
		getLogger().debug("reassignReleasedReviewer() --> being executed.");
		Reviewer reviewer = reviewerDTO.getReviewer();

		this.reassignReviewer(reviewerDTO, reasonCode, comments, newUser);

		// update savvion task so that it will be routed back to the new
		// reviewer.
		reassignSavvionTask(reviewer, taskProcessId);
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#reassignReviewer(ReviewerDTO
	 * , ReviewerReassignReasonCode, String, UserDataDTO)
	 */
	public void reassignReviewer(ReviewerDTO reviewerDTO, String reasonCode,
			String comments, UserDataDTO newUser) {
		getLogger().debug("reassignReviewer() --> being executed.");
		Reviewer reviewer = reviewerDTO.getReviewer();

		// make the reassignment
		Long newUserId = newUser.getUserId();
		// make the reassignment
		this.saveReassignmentData(reviewer, reasonCode, comments);

		// update the reviewer with the new reviewers data.
		reviewer.setUserId(newUserId);
		reviewer.setReviewerName(newUser.getName());
		reviewer.setUserStatus(newUser.getStatus().getUserStatus());
		reviewer.setDepartment(newUser.getDepartment().getDepartment());
		reviewer.setReviewerEmailAddress(newUser.getEmailAddress());
		reviewer.setDistributionInstructions(newUser
				.getReassignedInstructions());
		reviewer.setDistributionTargetCompleteDate(newUser
				.getReassignedTargetCompleteDate());
		reviewer.setEscalationMgrId(newUser.getSupervisorId());
		reviewer.setDivision(newUser.getDivisionDTO().getDivision());
		this.reviewerDao.save(reviewer);

	}

	public void reassignReviewers(List<ReviewerDTO> reviewerDTOs,
			String reasonCode, String comments, UserDataDTO newUser) {
		getLogger().debug("reassignReviewers() --> being executed.");

		for (ReviewerDTO reviewerDTO : reviewerDTOs) {
			reassignReviewer(reviewerDTO, reasonCode, comments, newUser);
		}
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#rejectReviewers(java
	 * .util.List, java.lang.String, java.lang.String)
	 */
	public void rejectReviewers(List<ReviewerDTO> reviewerDTOs,
			String reasonCode, String comments) {
		getLogger().debug("rejectReviewers() --> being executed.");
		List<Reviewer> reviewers = new ArrayList<Reviewer>(reviewerDTOs.size());
		Date now = new Date();
		Set<Long> reviewBundleIds = new HashSet<Long>();
		for (ReviewerDTO reviewerDTO : reviewerDTOs) {
			Reviewer reviewer = reviewerDTO.getReviewer();
			reviewer.setReviewerRejectDate(now);
			reviewer.setReviewerLastStatusCd(ReviewerStatusCode.REJECTED
					.getCode());
			reviewer.setReviewerRejectBy(getSessionSystemUser().getUserId());
			reviewer.setRejectCode(reasonCode);
			reviewer.setRejectText(comments);
			reviewBundleIds.add(reviewer.getReviewBundleId());
			reviewers.add(reviewer);
		}
		this.reviewerDao.save(reviewers);
	}

	/*
	 * @see
	 * com.assurant.inc.sox.ar.service.IReviewerService#retrieveNumberOfReviewers
	 * (java.util.List)
	 */
	public int retrieveNumberOfReviewers(List<Long> reviewBundleIds) {
		getLogger()
				.debug(
						"retrieveNumberOfReviewers(List<Long> reviewBundleIds) --> being executed.");
		int count = 0;
		for (Long reviewBundleId : reviewBundleIds) {
			count += this.reviewerDao
					.findReviewerCountForBundle(reviewBundleId);
		}
		return count;
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * getManagerReviewAvailableReassignReviewers(Long)
	 */
	public List<UserDataDTO> getManagerReviewAvailableReassignReviewers(
			Long userId) {
		getLogger()
				.debug(
						"getManagerReviewAvailableReassignReviewers(Long userId) --> being executed.");
		List<UserDataDTO> results = new ArrayList<UserDataDTO>(2);
		User supervisorUser = userDao.findUsersSupervisor(userId);
		if (supervisorUser != null) {
			results.add(this.mapUserToUserDataDTO(supervisorUser));
		}

		this.retrieveItComplianceUsers(results);

		return results;
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * getDataOwnerReviewAvailableReassignReviewers(Long)
	 */
	public List<UserDataDTO> getDataOwnerReviewAvailableReassignReviewers(
			Long applicationId, Long currentAssignedUserId)
			throws InactiveReassignReviewerException {
		getLogger()
				.debug(
						"getDataOwnerReviewAvailableReassignReviewers(Long applicationId) --> being executed.");
		List<UserDataDTO> results = new ArrayList<UserDataDTO>(3);
		List<UserDataDTO> inactiveUsers = new ArrayList<UserDataDTO>(3);

		List<ReviewOwner> owners = this.reviewOwnerDao
				.findDataOwnerReviewersByApplicationId(applicationId);
		if (owners.size() == 0) {
			logger
					.info("Dataowner Reviewers are not available for application Id "
							+ applicationId);
		}

		for (ReviewOwner owner : owners) {
			User user = this.userDao.findByUserId(owner.getUserId());
			if (user == null) {
				user = this.userDao.findByUserIdInactive(owner.getUserId());
				UserDataDTO userDTO = this.mapUserToUserDataDTO(user);
				userDTO
						.setOwnerTypeDescription(owner
								.getOwnerTypeDescription());
				inactiveUsers.add(userDTO);
			} else {
				/*
				 * exclude the reviewer that is currently assigned the task
				 */
				if (!currentAssignedUserId.equals(user.getUserId())) {
					UserDataDTO userDTO = this.mapUserToUserDataDTO(user);
					userDTO.setOwnerTypeDescription(owner
							.getOwnerTypeDescription());
					results.add(userDTO);
				}
			}
		}

		if (inactiveUsers.size() > 0) {
			// if found an inactive user then throw an exception.
			throw new InactiveReassignReviewerException(inactiveUsers);
		}
		
			this.addItComplianceUsers(results);
		
		return results;
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * getSODAvailableReassignReviewers(Long)
	 */
	public List<UserDataDTO> getSODAvailableReassignReviewers(
			ConflictDTO conflict, Long currentAssignedUserId)
			throws InactiveReassignReviewerException {
		getLogger()
				.debug(
						"getSODAvailableReassignReviewers(Long userId) --> being executed.");

		List<ReviewOwner> reviewers = new ArrayList<ReviewOwner>();
		if (conflict != null) {
			reviewers.addAll(this.reviewOwnerDao
					.findSODReviewersByConflictTypeId(conflict.getId()));
			if (reviewers.size() == 0) {
				// if there are no SOD reviewers then need to get reviewers for
				// application(s)
				reviewers.addAll(this.reviewOwnerDao
						.findDataOwnerReviewersByApplicationId(conflict
								.getLeftConflictId()));

				Long rightAppId = conflict.getRightApplicationId();
				if (rightAppId != null) {
					reviewers.addAll(this.reviewOwnerDao
							.findDataOwnerReviewersByApplicationId(rightAppId));
				}
			}
		} else {
			return null;
		}

		List<UserDataDTO> results = new ArrayList<UserDataDTO>(3);
		List<UserDataDTO> inactiveUsers = new ArrayList<UserDataDTO>(3);

		Set<Long> userIds = new HashSet<Long>(3);
		for (ReviewOwner reviewer : reviewers) {
			if (userIds.add(reviewer.getUserId())) {
				User user = this.userDao.findByUserId(reviewer.getUserId());
				if (user == null) {
					user = this.userDao.findByUserIdInactive(reviewer
							.getUserId());
					UserDataDTO userDTO = this.mapUserToUserDataDTO(user);
					userDTO.setOwnerTypeDescription(reviewer
							.getOwnerTypeDescription());
					inactiveUsers.add(userDTO);
				} else {
					/*
					 * exclude the reviewer that is currently assigned the task
					 */
					if (!currentAssignedUserId.equals(user.getUserId())) {
						UserDataDTO userDTO = this.mapUserToUserDataDTO(user);
						userDTO.setOwnerTypeDescription(reviewer
								.getOwnerTypeDescription());
						results.add(userDTO);
					}
				}
			}
		}

		if (inactiveUsers.size() > 0) {
			// if found an inactive user then throw an exception.
			throw new InactiveReassignReviewerException(inactiveUsers);
		}
		
			this.addItComplianceUsers(results);
	
		return results;
	}

	/**
	 * Retrieves the user data dto data representing the it compliance manager
	 * user.
	 * 
	 * @return the it compliance manager user. If none is found then a null will
	 *         be returned.
	 */
	private void retrieveItComplianceUsers(List<UserDataDTO> results) {
		getLogger()
				.debug(
						"retrieveItComplianceUser(List<UserDataDTO> results)--> being executed.");
		List<ReviewOwner> itComplianceManagers = this.reviewOwnerDao
				.retrieveITComplianceManagers();

		List<UserDataDTO> validManagers = new ArrayList<UserDataDTO>();

		if (itComplianceManagers != null) {
			for (ReviewOwner manager : itComplianceManagers) {

				// Make sure to only add the IT compliance manager to the
				// available
				// reviewers if they have not already been added
				boolean found = false;
				for (UserDataDTO userData : results) {
					if (manager.getUserId().equals(
							Long.valueOf(userData.getUserId()))) {
						found = true;
						break;
					}
				}

				if (!found) {
					User itCompUser = this.userDao.findByUserId(manager
							.getUserId());
					if (itCompUser != null) {
						UserDataDTO userDTO = this
								.mapUserToUserDataDTO(itCompUser);
						userDTO.setOwnerTypeDescription(manager
								.getOwnerTypeDescription());
						validManagers.add(userDTO);
					}
				}
			}
		}

		// Sort the IT comp manager list in alpha order before adding to the
		// results list
		Collections.sort(validManagers, new Comparator<UserDataDTO>() {
			public int compare(UserDataDTO o1, UserDataDTO o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});

		results.addAll(validManagers);
	}

	/**
	 * Retrieves the user data dto data representing the it compliance manager
	 * user.
	 * 
	 * @return the it compliance manager user. If none is found then a null will
	 *         be returned.
	 */
	private void addItComplianceUsers(List<UserDataDTO> results) {
		getLogger()
				.debug(
						"addItComplianceUsers(List<UserDataDTO> results)--> being executed.");
		List<ReviewOwner> itComplianceManagers = this.reviewOwnerDao
				.retrieveITComplianceManagers();

		List<UserDataDTO> validManagers = new ArrayList<UserDataDTO>();

		if (itComplianceManagers != null) {
			for (ReviewOwner manager : itComplianceManagers) {

				User itCompUser = this.userDao
						.findByUserId(manager.getUserId());
				if (itCompUser != null) {
					UserDataDTO userDTO = this.mapUserToUserDataDTO(itCompUser);
					userDTO.setOwnerTypeDescription(manager
							.getOwnerTypeDescription());
					validManagers.add(userDTO);
					logger.info("IT compliance reviewer ");
				}
			}
		}

		// Sort the IT comp manager list in alpha order before adding to the
		// results list
		Collections.sort(validManagers, new Comparator<UserDataDTO>() {
			public int compare(UserDataDTO o1, UserDataDTO o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});

		results.addAll(validManagers);
	}

	/**
	 * Maps a User to a UserDataDTO.
	 * 
	 * @param user
	 *            the user containing the data to map.
	 * @return
	 */
	private UserDataDTO mapUserToUserDataDTO(User user) {
		getLogger().debug("mapUserToUserDataDTO(User user)--> being executed.");
		UserDataDTO userData = new UserDataDTO();
		Department dept = user.getDepartment();
		if (dept != null) {
			userData.setDepartment(new DepartmentDTO(dept));
		}
		userData.setEmailAddress(user.getEmailAddress());
		UserStatus userStatus = user.getUserStatus();
		if (userStatus != null) {
			userData.setStatus(new UserStatusDTO(userStatus));
		}
		userData.setUserId(user.getUserId().longValue());

		userData.setName(this.buildName(user));

		userData.setSupervisorId(user.getSupervisorId());

		Division division = user.getDivision();
		if (division != null) {
			userData.setDivisionDTO(new DivisionDTO(user.getDivision()));
		}

		return userData;
	}

	private String buildName(User user) {
		// getLogger().debug("buildName(User user)--> being executed.");
		StringBuilder sb = new StringBuilder(64);
		if (user != null) {
			sb.append(user.getLastName());
			sb.append(", ");
			sb.append(user.getFirstName());
			if (StringUtils.isNotBlank(user.getMiddleName())) {
				sb.append(' ');
				sb.append(user.getMiddleName());
			}
			return sb.toString();
		} else {
			return "";
		}
	}

	/**
	 * Builds the reviewer dto objects from the provided list of reviewer domain
	 * objects.
	 * 
	 * @param reviewers
	 * @return
	 */
	private List<ReviewerDTO> buildReviewerDTOList(List<Reviewer> reviewers,
			boolean loadNumberOfDepts) {
		getLogger().debug(
				"buildReviewerDtoList(List<Reviewer>) --> being executed.");

		List<ReviewerDTO> dtos = new ArrayList<ReviewerDTO>(reviewers.size());
		if (!reviewers.isEmpty()) {

			String bundleName = getReviewBundleService().retrieveBundleName(
					reviewers.get(0).getReviewBundleId());

			HashMap<Long, User> cachedEscalationMgr = new HashMap<Long, User>();
			for (Reviewer reviewer : reviewers) {
				/*
				 * flag to mark record summary needs to be save. should only
				 * need to be saved the first time the reviewer summary is
				 * pulled
				 */
				boolean saveFlag = false;
				CodeDTO rejectCode = null;
				CodeDTO statusCode = null;
				if (reviewer.getRejectCode() != null) {
					rejectCode = this.codeService.retrieveCodeByValueFromCache(
							CodeSet.REVIEWER_REJECT_REASON, reviewer
									.getRejectCode());
				}
				if (reviewer.getReviewerLastStatusCd() != null) {
					statusCode = this.codeService.retrieveCodeByValueFromCache(
							CodeSet.REVIEWER_STATUS, reviewer
									.getReviewerLastStatusCd());
				}
				ReviewerDTO dto = new ReviewerDTO(reviewer, rejectCode,
						statusCode, bundleName);

				// set the extra fields
				if (dto.getNumberOfReviewedUsers() == null
						|| dto.getNumberOfReviewedUsers().longValue() == 0) {
					dto.setNumberOfReviewedUsers(this.reviewUserDao
							.findUserCountForReviewer(reviewer.getId()));
					/*
					 * mark record as needed for save
					 */
					saveFlag = true;
				}

				if (dto.getDistinctEmployeeStatuses() == null) {
					dto
							.setDistinctEmployeeStatuses(buildDistinctUserStatuses(dto
									.getReviewerId()));
					/*
					 * mark record as needed for save
					 */
					saveFlag = true;
				}

				if (loadNumberOfDepts) {
					dto.setNumberOfDepartments(this.reviewerDao
							.findDistinctDepartments(reviewer.getId()).size());
				}

				Application application = reviewer.getApplication();
				if (application != null) {
					Long appId = application.getId();
					if (appId.longValue() > 0) {
						List<ReviewOwner> dataOwners = reviewOwnerDao
								.findDataOwnerOwnersByApplicationId(appId);
						if (dataOwners.size() > 0) {
							// Modified code to fix CR#6
							// User dataOwner =
							// userDao.findByUserId(dataOwners.get(0).getUserId());
							User dataOwner = userDao.findByMgrUserId(dataOwners
									.get(0).getUserId());
							dto.setOwnerName(this.buildName(dataOwner));
						}
					}
				}

				Conflict conflict = reviewer.getConflict();
				if (conflict != null) {
					dto.setConflict(new ConflictDTO(conflict));
					List<ReviewOwner> sodOwners = this.reviewOwnerDao
							.findSODOwnersByConflictTypeId(conflict.getId());
					if (sodOwners.size() > 0) {
						StringBuilder sb = new StringBuilder(128);
						for (ReviewOwner owner : sodOwners) {
							// Modified code to fix CR#6
							// User sodOwner =
							// userDao.findByUserId(owner.getUserId());
							User sodOwner = userDao.findByMgrUserId(owner
									.getUserId());
							sb.append(this.buildName(sodOwner));
							sb.append(" / ");
						}
						dto.setOwnerName(sb.substring(0, sb.length() - 2));
					}

				}

				// set the escalation manager name
				Long userId = dto.getEscalationMgrId();
				if (userId != null && userId.longValue() > 0) {
					/*
					 * Try and see if the manager/supervisor is already gotten
					 * from another user, if so get it from the temp cache
					 */
					User escalationMgr = cachedEscalationMgr.get(userId);
					if (escalationMgr == null) {
						/*
						 * if escalation manager is not found in cache then get
						 * it from the database
						 */
						// Modified code to fix CR#6
						// escalationMgr = this.userDao.findByUserId(userId);
						escalationMgr = this.userDao.findByMgrUserId(userId);
						if (escalationMgr != null) {
							/*
							 * if a escalation manager was found then add it to
							 * the cache
							 */
							cachedEscalationMgr.put(escalationMgr.getUserId(),
									escalationMgr);
						}
					}
					dto.setEscalationMgrName(this.buildName(escalationMgr));
				}

				dtos.add(dto);

				/*
				 * save reviewer summary info
				 */
				if (saveFlag) {

					getReviewerDao().save(dto.getReviewer());
				}
			}
		}
		return dtos;
	}

	/**
	 * Builds the reviewer dto objects from the provided list of reviewer domain
	 * objects. This is similar to the buildReviewerDTOList but provides a slim
	 * down version that does not load as much data from the database for
	 * performace reasons.
	 * 
	 * @param reviewers
	 * @return
	 */
	private List<ReviewerDTO> buildReviewerDTOListSlim(List<Reviewer> reviewers) {
		getLogger().debug(
				"buildReviewerDTOListSlim(List<Reviewer>) --> being executed.");

		List<ReviewerDTO> dtos = new ArrayList<ReviewerDTO>(reviewers.size());
		if (!reviewers.isEmpty()) {

			String bundleName = getReviewBundleService().retrieveBundleName(
					reviewers.get(0).getReviewBundleId());

			for (Reviewer reviewer : reviewers) {

				ReviewerDTO dto = new ReviewerDTO(reviewer, bundleName);
				Conflict conflict = reviewer.getConflict();
				if (conflict != null) {
					dto.setConflict(new ConflictDTO(conflict));
				}

				// set the extra fields
				if (dto.getNumberOfReviewedUsers() == null) {
					dto.setNumberOfReviewedUsers(0);
				}

				dtos.add(dto);

			}
		}
		return dtos;
	}

	// private String buildDistinctSoxValues(Long reviewerId) {
	// List<String> distSoxValues =
	// getReviewUserAccessDao().findDistinctSoxValuesByReviewerId(reviewerId);
	// return this.buildCommaDelimitedList(distSoxValues);
	// }

	private String buildDistinctUserStatuses(Long reviewerId) {
		getLogger()
				.debug(
						"buildDistinctUserStatuses(Long reviewerId)--> being executed.");
		List<String> distStatuses = getReviewUserDao()
				.findDistinctUserStatusesByReviewerId(reviewerId);
		return DisplayStringBuilder.buildCommaDelimitedList(distStatuses);
	}

	public boolean isReviewDetailCompleted(Long reviewBundleId) {
		getLogger().debug(
				"isReviewDetailCompleted(reviewBundleId) --> being executed.");
		List<Reviewer> pending = this.reviewerDao.findByStatus(reviewBundleId,
				ReviewerStatusCode.PENDING.getCode());
		List<Reviewer> approved = this.reviewerDao.findByStatus(reviewBundleId,
				ReviewerStatusCode.APPROVED.getCode());

		return (pending.isEmpty() && approved.isEmpty());
	}

	/**
	 * TO reassign the reviewer.
	 * 
	 * @param reviewer
	 *            the reviewer.
	 * @param reasonCodeValue
	 *            the reason for reassignment.
	 * @param comments
	 *            the comments for reassignment.
	 */
	private void saveReassignmentData(Reviewer reviewer,
			String reasonCodeValue, String comments) {
		getLogger()
				.debug(
						"saveReassignmentData(Reviewer, String, String) --> being executed.");
		// get reassignments already added to review.
		List<ReviewerReassignment> reassignments = this.reviewReassignmentDao
				.findByReviewerId(reviewer.getId());

		long newSeqNum;
		Date beginDate;
		Long previousReviewerId;
		if (reassignments.isEmpty()) {
			newSeqNum = 1;

			// the begin date was the date the reviewers review was loaded if
			// first
			// reassignment.
			beginDate = this.reviewBundleDao.findById(
					reviewer.getReviewBundleId()).getEtlLoadDate();
			previousReviewerId = null;
		} else {

			ReviewerReassignment maxSeqReassignment = reassignments.get(0);
			for (ReviewerReassignment reassignment : reassignments) {
				if (maxSeqReassignment.getReviewReassignSeqNumber() < reassignment
						.getReviewReassignSeqNumber()) {
					maxSeqReassignment = reassignment;
				}
			}

			newSeqNum = maxSeqReassignment.getReviewReassignSeqNumber() + 1;
			beginDate = maxSeqReassignment.getReviewReassignEndDate();
			previousReviewerId = maxSeqReassignment
					.getReviewReassignNewUserId();
		}

		// add the new reassignment to the reviewer.
		ReviewerReassignment newReviewReassignment = new ReviewerReassignment();
		newReviewReassignment.setReviewerId(reviewer.getId());
		newReviewReassignment.setReviewReassignBeginDate(beginDate);
		newReviewReassignment.setReviewReassignPrevUserId(previousReviewerId);
		newReviewReassignment.setReviewReassignNewUserId(reviewer.getUserId());
		newReviewReassignment.setReassignmentCode(reasonCodeValue);
		newReviewReassignment.setReassignmentText(comments);
		newReviewReassignment.setReviewReassignSeqNumber(newSeqNum);
		this.reviewReassignmentDao.save(newReviewReassignment);

	}

	/**
	 * To create a savvion task for the reviewer
	 * 
	 * @param reviewers
	 *            the reviewer.
	 * @param reviewName
	 *            the name of review.
	 */
	private List<Reviewer> beginReviewerSavvionProcess(
			List<Reviewer> reviewers, String reviewName) {
		getLogger().debug(
				"beginReviewerSavvionProcess(Reviewer) --> being executed.");
		List<Reviewer> notFoundUsers = new ArrayList<Reviewer>();
		
		
		for (Reviewer reviewer : reviewers) {
			/*
			 * get reviewer info
			 */
			User userInfo = getUserDao().findByUserId(reviewer.getUserId());
			List<HashMap<String, Object>> workflowReviewers = new ArrayList<HashMap<String, Object>>();
			if (userInfo != null && userInfo.getPk() != null
					&& userInfo.getPk() != null) {

				String emailAddress = reviewer.getReviewerEmailAddress();
				if (emailAddress.equals("-1")) {
					logger
							.warn("The task can not be reassigned to the provided user due to an invalid email address.  User Name: "
									+ reviewer.getReviewerName()
									+ " email address: " + emailAddress);
					notFoundUsers.add(reviewer);
					continue;
				}

				HashMap<String, Object> dataSlots = buildVerifyAccessDataSlots(
						reviewer.getReviewerEmailAddress(),
						getFromEmailAddress(), reviewName, reviewer
								.getReviewerName(),
						reviewer.getId().toString(), getAppURL(), reviewer
								.getDistributionTargetCompleteDate(), reviewer
								.getDistributionInstructions(),
						ITaskValues.REASSIGNED_FALSE, userInfo.getPk()
								.getKeyId());
				workflowReviewers.add(dataSlots);
				long time1 = System.currentTimeMillis();
				getWorkflowService().createBulkProcess(
						WorkflowTemplateCode.createBulkProcess,
						ITaskValues.PROCESS_TEMPLATE_NAME_SUMMARY,
						ITaskValues.PRIORITY_LOW,
						workflowReviewers);
				
				EmailService.sendEmail(dataSlots);
						
				getLogger().debug(
						"time to create savvion task list is (ms): "
								+ (System.currentTimeMillis() - time1) + " for "
								+ workflowReviewers.size() + " tasks");
				
			} else {
				getLogger().debug(
						"No reviewer " + reviewer.getReviewerName() + "-"
								+ reviewer.getUserId());
				notFoundUsers.add(reviewer);
			}
		}

		
		

		return notFoundUsers;
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewerService#retrieveById(Long)
	 */
	public ReviewerDTO retrieveById(Long id) {
		getLogger().debug("retrieveById(Long id)--> being executed.");
		Reviewer reviewer = this.reviewerDao.findById(id);
		if (reviewer == null) {
			return null;
		}

		return this.buildReviewerDTOList(
				Collections.singletonList(reviewer),
				this
						.loadReviewerDistinctDeptCount(reviewer
								.getReviewBundleId())).get(0);
	}

	public ReviewerDTO retrieveByIdWithSlim(Long id) {
		getLogger().debug("retrieveById(Long id)--> being executed.");
		Reviewer reviewer = this.reviewerDao.findById(id);
		if (reviewer == null) {
			
			return null;
		}

		return this.buildReviewerDTOListSlim(
				Collections.singletonList(reviewer)).get(0);
	}

	private HashMap<String, Object> buildVerifyAccessDataSlots(String emailTo,
			String emailFrom, String emailSubject, String reviewerName,
			String reviewerId, String url, Date targetDueDate,
			String instructions, boolean reAssigned, String assignee) {
		getLogger().debug("buildVerifyAccessDataSlots --> being executed.");

		SimpleDateFormat formatter = new SimpleDateFormat("EEE, MMM dd yyyy");
		String formattedDate = formatter.format(targetDueDate);

		HashMap<String, Object> dataSlots = new HashMap<String, Object>();
		dataSlots.put(ITaskValues.DATASLOTS_EMAIL_TO, emailTo);
		dataSlots.put(ITaskValues.DATASLOTS_EMAIL_FROM, emailFrom);
		dataSlots.put(ITaskValues.DATASLOTS_EMAIL_SUBJECT, emailSubject);
		dataSlots.put(ITaskValues.DATASLOTS_REVIEWER_NAME, reviewerName);
		dataSlots.put(ITaskValues.DATASLOTS_REVIEWER_ID, reviewerId);
		dataSlots.put(ITaskValues.DATASLOTS_URL, url);
		dataSlots.put(ITaskValues.DATASLOTS_TARGET_DUE_DATE, formattedDate
				.toString());
		dataSlots.put(ITaskValues.DATASLOTS_INSTRUCTIONS, instructions);
		dataSlots.put(ITaskValues.DATASLOTS_REASSIGNED, (reAssigned));
		dataSlots.put(ITaskValues.DATASLOTS_ASSIGNEE, assignee);
		
		dataSlots.put(ITaskValues.DATASLOTS_ASSIGNEDTO, assignee);
		

		return dataSlots;
	}

	private void reassignSavvionTask(Reviewer reviewer, String taskId) {
		getLogger().debug(
				"reassignSavvionTask(Reviewer, String) --> being executed.");
		/*
		 * get reviewer info
		 */
		HashMap<String, Object> oldDataSlots = new HashMap<String, Object>();
		oldDataSlots.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX,ITaskValues.ALL_INSTANCE_NAME_PREFIX_VERIFY);
		getWorkflowService().updateProcessDataSlots(taskId, oldDataSlots);
		User userInfo = getUserDao().findByUserId(reviewer.getUserId());
		String reviewName = getReviewBundleService().retrieveReviewName(
				reviewer.getReviewBundleId());
		HashMap<String, Object> dataSlots = buildVerifyAccessDataSlots(reviewer
				.getReviewerEmailAddress(), getFromEmailAddress(), reviewName,
				reviewer.getReviewerName(), reviewer.getId().toString(),
				getAppURL(), reviewer.getDistributionTargetCompleteDate(),
				reviewer.getDistributionInstructions(),
				ITaskValues.REASSIGNED_TRUE, userInfo.getPk().getKeyId());
		dataSlots.put(ITaskValues.TEMPLATE_CODE, TaskTypeCode.REVIEWER_TASK);
		dataSlots.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX, ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY);
		dataSlots.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, "test");
		dataSlots.put(ITaskValues.DATASLOTS_TEMPLATECODE, DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY);
		String workflowId = WorkflowUtil.createInstance(WorkflowTemplateCode.createProcess, dataSlots);
		String taskid=WorkflowUtil.getTaskId(workflowId);
		WorkflowUtil.startTask(taskid);
		
		EmailService.sendEmail(dataSlots);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewerService#retrieveById(Long)
	 */
	public void attestReview(ReviewerDTO reviewer, String taskProcessId,
			List<ReviewUserDTO> reviewUsers) {
		getLogger().debug(
				"attestReview(ReviewerDTO, String)--> being executed.");

		if (reviewUsers.size() > 0) {

			// create the tasks for it compliance
			List<Long> reviewUserIds = new ArrayList<Long>(reviewUsers.size());
			for (ReviewUserDTO reviewUser : reviewUsers) {
				reviewUserIds.add(reviewUser.getReviewUserId());
			}

			// build a set of id of the applications that have either a rejected
			// access || comment
			Set<Long> rejectedApplicationSet = new HashSet<Long>();
			List<ReviewUserAccess> rejectedAccesses = this.reviewUserAccessDao
					.findRejectedByReviewUserIds(reviewUserIds);
			for (ReviewUserAccess rejectedAccess : rejectedAccesses) {
				rejectedApplicationSet.add(rejectedAccess
						.getApplicationSystem().getApplication().getId());
			}

			List<ReviewApplication> appComments = this.reviewApplicationDao
					.findRejectedByReviewUserIds(reviewUserIds);
			for (ReviewApplication appComment : appComments) {
				rejectedApplicationSet.add(appComment.getApplication().getId());
			}

			String reviewerIdStr = reviewer.getReviewerId().toString();
			for (Long appId : rejectedApplicationSet) {
				HashMap<String, Object> dataSlots = new HashMap<String, Object>(
						5);
				dataSlots.put(ITaskValues.DATASLOTS_ASSIGNEE,
						this.savvionITComplianceUserId);
				dataSlots.put(ITaskValues.DATASLOTS_VALIDATE_REVIEWER_ID,
						reviewerIdStr);
				dataSlots.put(ITaskValues.DATASLOTS_VALIDATE_APPLICATION_ID,
						appId.toString());

				this.workflowService
						.createProcess(WorkflowTemplateCode.verifyAccessWF,
								DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VALIDATE_ACCESS,
								ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY,
								ITaskValues.PRIORITY_LOW,
								this.savvionITComplianceUserId, dataSlots);
			}

			// Set the attested info on the reviewer and save it.
			Reviewer reviewerDomain = reviewer.getReviewer();
			if (rejectedApplicationSet.size() > 0) {
				reviewerDomain
						.setActionsRequired(Reviewer.ACTION_REQUIRED_FLAG);
			}

			reviewerDomain.setAttestedByID(getSessionSystemUser().getUserId());
			reviewerDomain.setAttestedOnDate(new Date());
			this.reviewerDao.save(reviewerDomain);

		} else {
			// Set the attested info on the reviewer and save it enven though
			// not really attesting to anything.
			Reviewer reviewerDomain = reviewer.getReviewer();
			reviewerDomain.setAttestedByID(getSessionSystemUser().getUserId());
			reviewerDomain.setAttestedOnDate(new Date());
			this.reviewerDao.save(reviewerDomain);
		}

		// complete the reviewer's task
		// Time being change added variables
		Map<String, Object> variables = new HashMap<String, Object>(1);	        
		variables.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, "test");
		
		//Added by shiv Start
		//variables.put("templateCode", TaskTypeCode.REVIEWER_TASK);
		variables.put("processInstanceNamePrefix", ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_VERIFY);
		this.workflowService.updateProcessDataSlots(taskProcessId, variables);
		//Added by shiv End
		//Commented by Shiv Start
		/*this.workflowService.completeProcess(savvionProcessId, variables);*/
		//Commented by Shiv End
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * retrieveByReviewIdForDashboard(java.lang.Long)
	 */
	public List<ReviewerDTO> retrieveByReviewIdForDashboard(Long reviewId) {
		List<ReviewBundleDTO> bundleDtos = getReviewBundleService()
				.retrieveByReviewId(reviewId);
		List<ReviewerDTO> results = new ArrayList<ReviewerDTO>();
		for (ReviewBundleDTO bundleDto : bundleDtos) {
			/*
			 * build the slim down version of the reviewer dto for performance
			 * b/c we don't need all the extra meta data of the reviewers
			 */
			List<ReviewerDTO> dtosFromBundle = buildReviewerDTOListSlim(this.reviewerDao
					.findByReviewBundleId(bundleDto.getReviewBundleId()));

			for (ReviewerDTO dto : dtosFromBundle) {
				if (!ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(
						dto.getReviewerLastStatusCd())) {
					results.add(dto);
				}
			}
		}
		return results;
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * populateReviewerNumberOfDepts(com.assurant.inc.sox.ar.dto.ReviewerDTO)
	 */
	public void populateReviewerNumberOfDepts(ReviewerDTO dto) {
		getLogger()
				.debug(
						"populateReviewerNumberOfDepts(ReviewerDTO dto)--> being executed.");
		dto.setNumberOfDepartments(this.reviewerDao.findDistinctDepartments(
				dto.getReviewerId()).size());
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * populateReviewerEscalationMgrName
	 * (com.assurant.inc.sox.ar.dto.ReviewerDTO)
	 */
	public void populateReviewerEscalationMgrName(ReviewerDTO dto) {
		getLogger()
				.debug(
						"populateReviewerEscalationMgrName(ReviewerDTO dto)--> being executed.");
		Long userId = dto.getEscalationMgrId();
		if (userId != null && userId.longValue() > 0) {
			// Modified code to fix CR#6
			// User escalationMgr = this.userDao.findByUserId(userId);
			User escalationMgr = this.userDao.findByMgrUserId(userId);
			dto.setEscalationMgrName(this.buildName(escalationMgr));
		}
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * populateReviewerDataOwnerName(com.assurant.inc.sox.ar.dto.ReviewerDTO)
	 */
	public void populateReviewerDataOwnerName(ReviewerDTO dto) {
		getLogger()
				.debug(
						"populateReviewerDataOwnerName(ReviewerDTO dto)--> being executed.");
		Application application = dto.getReviewer().getApplication();
		if (application != null) {
			Long appId = application.getId();
			if (appId.longValue() > 0) {
				List<ReviewOwner> dataOwners = reviewOwnerDao
						.findDataOwnerOwnersByApplicationId(appId);
				if (dataOwners.size() > 0) {
					// Modified code to fix CR#6
					// User dataOwner =
					// userDao.findByUserId(dataOwners.get(0).getUserId());
					User dataOwner = userDao.findByMgrUserId(dataOwners.get(0)
							.getUserId());
					dto.setOwnerName(this.buildName(dataOwner));
				}
			}
		}
	}

	/*
	 * @seecom.assurant.inc.sox.ar.service.IReviewerService#
	 * populateReviewerDataOwnerName(com.assurant.inc.sox.ar.dto.ReviewerDTO)
	 */
	public void populateReviewerSODValues(ReviewerDTO dto) {
		getLogger()
				.debug(
						"populateReviewerSODValues(ReviewerDTO dto)--> being executed.");
		Conflict conflict = dto.getReviewer().getConflict();
		if (conflict != null) {
			dto.setConflict(new ConflictDTO(conflict));
			List<ReviewOwner> sodOwners = this.reviewOwnerDao
					.findSODOwnersByConflictTypeId(conflict.getId());
			if (sodOwners.size() > 0) {
				StringBuilder sb = new StringBuilder(128);
				for (ReviewOwner owner : sodOwners) {
					// Modified code to fix CR#6
					// User sodOwner = userDao.findByUserId(owner.getUserId());
					User sodOwner = userDao.findByMgrUserId(owner.getUserId());
					sb.append(this.buildName(sodOwner));
					sb.append(" / ");
				}
				dto.setOwnerName(sb.substring(0, sb.length() - 2));
			}

		}
	}
}
