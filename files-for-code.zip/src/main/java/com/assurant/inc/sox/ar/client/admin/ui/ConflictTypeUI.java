package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.ConflictType;
import java.util.Date;

public class ConflictTypeUI {
	private final ConflictType conflictType;
	private boolean checked;

	public ConflictTypeUI(ConflictType conflictType) {
		this.conflictType = conflictType;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.conflictType.getId();
	}
	
	public String getConflictTypeText() {
		return this.conflictType.getConflictTypeText();
	}
	
	public String getConflictCode() {
		return this.conflictType.getConflictCode();
	}

	public String getCreatedBy() {
		return this.conflictType.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.conflictType.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.conflictType.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.conflictType.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.conflictType.getDeleteFlag();
	}

	public ConflictType getConflictType() {
		return conflictType;
	}
	

}
