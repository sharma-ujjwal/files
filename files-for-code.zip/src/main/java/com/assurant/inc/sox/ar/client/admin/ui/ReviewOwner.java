package com.assurant.inc.sox.ar.client.admin.ui;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Conflict;

public class ReviewOwner {
	private final Conflict conflict;
	private boolean checked;

	public ReviewOwner(Conflict conflict) {
		this.conflict = conflict;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.conflict.getId();
	}

	//public Long getConflictTypeId() {
	//	return this.conflict.getConflictType().getId();
	//}


	public String getConflictType() {
		return this.conflict.getConflictType().getConflictTypeText();
 	}

//	public ConflictType getConflictType() {
//		return this.conflict.getConflictType();
// 	}

	public Long getLeftConflictId() {
		return this.conflict.getLeftConflictId();
	}
	
	public String getLeftConflictName() {
		return this.conflict.getLeftConflictName();
	}
	
	public Long getLeftFunctionDutyId() {
		return this.conflict.getLeftFunctionDutyId();
	}
	
	public Long getRightConflictId() {
		return this.conflict.getRightConflictId();
	}
	
	public String getRightConflictName() {
		return this.conflict.getRightConflictName();
	}
	
	public Long getRightFunctionDutyId() {
		return this.conflict.getRightFunctionDutyId();
	}
	
	public String getCreatedBy() {
		return this.conflict.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.conflict.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.conflict.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.conflict.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.conflict.getDeleteFlag();
	}

	public Conflict getConflict() {
		return conflict;
	}

}
