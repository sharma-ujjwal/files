package com.assurant.inc.sox.ar.client.bean.reviewerreport;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.el.ExpressionFactory;
import javax.el.MethodExpression;
import javax.faces.application.Application;
import javax.faces.component.UIComponent;
import javax.faces.component.UISelectItems;
import javax.faces.component.html.*;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUserAccessUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUserUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserApplicationAccessesDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.enums.AccessListMode;
import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessKeepRemoveFlag;
import com.assurant.inc.sox.ar.service.IReviewUserAccessService;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandbutton.CommandButton;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.component.panel.Panel;
import org.primefaces.component.toolbar.Toolbar;
import org.primefaces.component.toolbar.ToolbarGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Class to manage the list of accesses for the UI. This class is session scoped and will be used for viewing the employee's
 * details.
 *
 * @author BB68602
 *
 */
@Component("accessListBean")
@Scope("session")
public class AccessListBean {
	private static class CommentListener implements ValueChangeListener, Serializable {
		private static final long serialVersionUID = 1L;
		private ReviewUserApplicationAccessesDTO accessesDTO;

		public CommentListener(ReviewUserApplicationAccessesDTO accessesDTO) {
			this.accessesDTO = accessesDTO;
		}

		public void processValueChange(ValueChangeEvent vce) throws AbortProcessingException {
			this.accessesDTO.setComment((String) vce.getNewValue());
		}
	}

	/**
	 * Attach this listener to a button, giving it the DTO to add all the keep remove flags for that DTO.
	 *
	 */
	private static class KeepButtonListener implements ActionListener, Serializable {
		private static final long serialVersionUID = 1L;
		private ReviewUserApplicationAccessesDTO accessesDTO;

		public KeepButtonListener(ReviewUserApplicationAccessesDTO accessesDTO) {
			this.accessesDTO = accessesDTO;
		}

		@SuppressWarnings("unused")
		public void processAction(ActionEvent event) throws AbortProcessingException {
			for (ReviewUserAccessDTO userAccess : this.accessesDTO.getAccesses()) {
				userAccess.setKeepRemoveFlag(ReviewUserAccessKeepRemoveFlag.KEEP);
			}
		}
	}

	/**
	 * Attach this listener to a button, giving it the DTO to remove all the keep remove flags for that DTO.
	 *
	 */
	private static class RemoveButtonListener implements ActionListener, Serializable {
		private static final long serialVersionUID = 1L;
		private ReviewUserApplicationAccessesDTO accessesDTO;

		public RemoveButtonListener(ReviewUserApplicationAccessesDTO accessesDTO) {
			this.accessesDTO = accessesDTO;
		}

		@SuppressWarnings("unused")
		public void processAction(ActionEvent event) throws AbortProcessingException {
			for (ReviewUserAccessDTO userAccess : this.accessesDTO.getAccesses()) {
				userAccess.setKeepRemoveFlag(ReviewUserAccessKeepRemoveFlag.REMOVE);
			}
		}
	}

	private static final Logger logger = LoggerFactory.getLogger(AccessListBean.class);
	private static final int MAX_REJECT_COMMENT_LENGTH = 250;
	@Autowired
	@Qualifier("reviewUserAccessService")
	private IReviewUserAccessService reviewUserAccessService = null;
	@Autowired
	@Qualifier("reviewUserService")
	private IReviewUserService reviewUserService;
	private Panel panel;
	private Panel printPanel;
	private AccessListMode mode = AccessListMode.REVIEW;
	private List<ReviewUserApplicationAccessesDTO> dtos;
	private ReviewUI review;
	private List<? extends ReviewUserUI> reviewUsers;
	private ReviewUserUI reviewUser;
	private ReviewerUI reviewer;
	private ReviewBundleUI reviewBundle;
	private boolean renderRejectReviewUsersModalPanel;
	private String commentsInput;
	private String selectReasonInput;
	// to display review user on reject page
	private List<ReviewUserUI> selectedReviewUsers;
	private String returnPage;
	private boolean printDisplayFlag;
	private boolean fromDashboard;
	private boolean renderEscalationMgr;
	private AccessListMode modeBeforePrint;
	/**
	 * Wrap a list of ReviewUserAccessDTO with ReviewUserAccessUI objects
	 *
	 * @param accesses the List of ReviewUserAccessDTO to wrap
	 * @return a List of ReviewUserAccessUI
	 */
	private List<ReviewUserAccessUI> asUI(List<ReviewUserAccessDTO> accesses) {
		List<ReviewUserAccessUI> result = new ArrayList<>(accesses.size());
		for (ReviewUserAccessDTO dto : accesses) {
			result.add(new ReviewUserAccessUI(dto));
		}
		return result;
	}

	/**
	 * Build a HtmlDataTable for given ReviewUserApplicationAccessDTO, use the given id to create an ID for the table.
	 *
	 * //@param accessesDTO
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private DataTable buildAccessTable(List<ReviewUserAccessUI> accesses, int id, ReviewUserApplicationAccessesDTO dto) {
		logger.debug("buildAccessTable() --> being executed.");
		logger.debug("user id = " + getReviewUser().getUserId() + " reviewUserId = " + getReviewUser().getReviewUserId() + " Application = " + dto.getApplicationName());

		/*
		 * Create new data table
		 */
		List<ReviewUserAccessUI> accesses1 = accesses;
		DataTable table = new DataTable();
		table.setId("Application" + id + "Table");
		table.setValue(accesses1);
		table.setVar("accesses1");
		if (this.review.isSODReview()) {
			table.setStyleClass("applicationTableHeaderSOD");
			table.setRowStyleClass("oddRowSOD, evenRowSOD");
		} else {
			table.setStyleClass("applicationTableHeader");
		}
		table.setStyle("width:100%");
		/*
		 * build table columns
		 */

		table.getChildren().add(buildTextColumn("Source Name", "#{accesses1.sourceName}", 10));
		table.getChildren().add(buildTextColumn("Privilege Description", "#{accesses1.privilegeDescription}", 20));
		table.getChildren().add(buildTextColumn("Privilege Value", "#{accesses1.privilegeValue}", 20));
		table.getChildren().add(buildTextColumn("Privilege Comment", "#{accesses1.privilegeComment}", 50));
		if (this.review.isNotManagerReview()) {
			table.getChildren().add(buildTextColumn("SOX Concern", "#{accesses1.soxConcern}", 10));
		}
		if (isEditMode()) {
			table.getChildren().add(buildKeepRemoveRadioColumn("Review Status", "#{accesses1.keepRemoveString}", 10, dto, id));
		}
		if (isViewEdits() || isPrintMode()) {
			table.getChildren().add(
					buildKeepRemoveColumn("Review Status", "#{accesses1.keepRemoveDisplay}", "#{accesses1.keepRemoveClass}", 10));
		}

		return table;
	}

	/**
	 * Build a data table column
	 *
	 * @param header
	 * @param detail
	 * @return
	 */
	private Column buildColumn(UIComponent header, UIComponent detail, int width) {
        Column col = HtmlTableBuilderUtil.buildColumn(header, detail);

		col.setStyle("width:" + width + "%");
		return col;
	}

	/**
	 * Build a data table header of type text
	 *
	 * @param value
	 * @return
	 */
	private HtmlOutputText buildHeaderText(String value) {
		HtmlOutputText text = new HtmlOutputText();
		text.setValue(value);
		text.setStyleClass("undecoratedLink");
		return text;
	}

	/**
	 * Build the keep/remove column for display
	 *
	 * @param columnLabel The label for the column
	 * @param dataBinding the binding for the data
	 * @param styleBinding the binding for the style
	 * @return the Column that was built
	 */
	private Column buildKeepRemoveColumn(String columnLabel, String dataBinding, String styleBinding, int width) {
		HtmlOutputText header = new HtmlOutputText();
		header.setValue(columnLabel);
		HtmlOutputText data = new HtmlOutputText();
		JSFUtils.setValueBinding(data, "value", dataBinding);
		JSFUtils.setValueBinding(data, "styleClass", styleBinding);
		return buildColumn(header, data, width);
	}

	/**
	 * Build the keep/remove column for edit with radio buttons
	 *
	 * @param columnLabel The label for the column
	 * @param dataBinding the binding for the data
	 * @return the Column that was built
	 */
	private Column buildKeepRemoveRadioColumn(String columnLabel, String dataBinding, int width,
												ReviewUserApplicationAccessesDTO dto, int id) {
		// Create the radio button, won't work without id
		HtmlSelectOneRadio radio = new HtmlSelectOneRadio();
		radio.setId("keepRemoveRadio");
		// Build an array of SelectItem
		ArrayList<SelectItem> optionsList = new ArrayList<SelectItem>();
		optionsList.add(new SelectItem("K", "Keep"));
		optionsList.add(new SelectItem("R", "Remove"));
		// Create SelectItems from array of SelectItem
		UISelectItems selectItems = new UISelectItems();
		selectItems.setValue(optionsList);
		// Add the SelectItems to the radio
		radio.getChildren().add(selectItems);
		// Set the binding for the radio button
		JSFUtils.setValueBinding(radio, "value", dataBinding);
		// build the buttons and put them in a group
		Panel panelGroup = new Panel();
		panelGroup.getChildren().add(buildKeepButton(dto, id));
		panelGroup.getChildren().add(buildRemoveButton(dto, id));
		// build the header text
		HtmlOutputText text = new HtmlOutputText();
		text.setValue(columnLabel);
		text.setStyleClass("undecoratedLink");
		// build a panel grid and add the button group and header text to it
		Panel headerPanelGrid = new Panel();
		headerPanelGrid.getChildren().add(text);
		headerPanelGrid.getChildren().add(panelGroup);
		// build the column
		return buildColumn(headerPanelGrid, radio, width);
	}

	/**
	 * @param id to build components with unique ID
	 * @param applicationName the name of the application
	 * @return the HtmlToolBarGroup built
	 */
	private ToolbarGroup buildToolBarGroup(int id, String applicationName, String applicationUserId) {
		// toolBarGroup to display the application name
		ToolbarGroup toolBarGroupLeft = new ToolbarGroup();
		toolBarGroupLeft.setId("Application" + id + "toolBarGroupLeft");
		toolBarGroupLeft.setStyle("width: 100%; justify-content: inherit;");
		// create output text to be attached to the tool bar group
		HtmlOutputText appHeader = new HtmlOutputText();
		appHeader.setId("Application" + id + "Header");
		if (this.review.isSODReview()) {
			appHeader.setValue("Conflict Application: " + applicationName);
		} else {
			appHeader.setValue("Application Name: " + applicationName);
		}
		// put the output text in the tool bar group
		toolBarGroupLeft.getChildren().add(appHeader);

		HtmlOutputText appUserIdHeader = new HtmlOutputText();
		appUserIdHeader.setId("appUserId" + id + "Header");
		appUserIdHeader.setValue("User ID: " + applicationUserId);
		toolBarGroupLeft.getChildren().add(appUserIdHeader);
		return toolBarGroupLeft;
	}

	/**
	 * Build an output text object
	 *
	 * @param valueBinding
	 * @return
	 */
	private HtmlOutputText buildOutputText(String valueBinding) {
		HtmlOutputText text = new HtmlOutputText();
		JSFUtils.setValueBinding(text, "value", valueBinding);
		return text;
	}

	/**
	 * Build the remove button, attach a listener to it.
	 *
	 * @param accessesDTO the DTO the listener attaches to
	 * @param id to generate a unique id for the component
	 * @return the HtmlAjaxCommandButton built
	 */
	private HtmlCommandButton buildRemoveButton(ReviewUserApplicationAccessesDTO accessesDTO, int id) {
		HtmlCommandButton removeButton = new HtmlCommandButton();
		removeButton.setId("Application" + id + "removeButton");
		removeButton.setValue("None");
		removeButton.setOnclick("setRadios('bodyForm:Application" + id + "Table', 'R'); callSelectOrRejectAllEmployeesReject(); return false;");
		//removeButton.addActionListener(new RemoveButtonListener(accessesDTO));
//		MethodExpression expression = createMethodExpression("#{employeeListBean.rejectAllEmployees}", null);
//		keepButton.setActionExpression(expression);
		return removeButton;
	}

	/**
	 * Build the keep button, attach a listener to it.
	 *
	 * @param accessesDTO the DTO the listener attaches to
	 * @param id to generate a unique id for the component
	 * @return the HtmlAjaxCommandButton built
	 */
	private HtmlCommandButton buildKeepButton(ReviewUserApplicationAccessesDTO accessesDTO, int id) {
		HtmlCommandButton keepButton = new HtmlCommandButton();
		keepButton.setId("Application" + id + "keepButton");
		keepButton.setValue("All");
		keepButton.setOnclick("setRadios('bodyForm:Application" + id + "Table', 'K'); callSelectOrRejectAllEmployeesAccept(); return false;");
		//keepButton.addActionListener(new KeepButtonListener(accessesDTO));
//		MethodExpression expression = createMethodExpression("#{employeeListBean.selectAllEmployees}", null);
//		keepButton.setActionExpression(expression);
		return keepButton;
	}

	/**
	 * Build a data table column of type text
	 *
	 * @param columnLabel The label for the column
	 * @param dataBinding the binding for the data
	 * @return the Column that was built
	 */
	private Column buildTextColumn(String columnLabel, String dataBinding, int width) {
		return buildColumn(buildHeaderText(columnLabel), buildOutputText(dataBinding), width);
	}

	/**
	 * @return
	 */
	public String doRejectEmployee() {
		logger.debug("doRejectEmployee() --> being executed.");
		/*
		 * clear session
		 */

		resetVariables();

		return "reportSummary";
	}

	/**
	 * Prepares the reject review user page.
	 * @return null to return to same page.
	 */
	public String doPrepareRejectUserPanel() {
		logger.debug("doPrepareRejectUserPanel() --> being executed.");
		List<ReviewUserUI> ruserUI = new ArrayList<ReviewUserUI>(1);
		ruserUI.add(reviewUser);
		this.selectedReviewUsers = ruserUI;
		this.commentsInput = null;
		this.selectReasonInput = null;
		this.renderRejectReviewUsersModalPanel = true;
		return null;
	}

	/**
	 * To reject the review user on report details page.
	 *
	 * @return null return to the same page.
	 */
	public String doSaveRejectReviewUsersPanel() {
		logger.debug("doSaveRejectReviewUsersPanel() --> being executed.");
		// Displays error message if reason not provided
		if (StringUtils.isBlank(this.selectReasonInput)) {
			JSFUtils.addFacesErrorMessage("A reason must be selected to perform a rejection.");
		}
		// Displays error message if comment invalid
		else if (StringUtils.isNotBlank(this.commentsInput) && this.commentsInput.length() > MAX_REJECT_COMMENT_LENGTH) {
			JSFUtils.addFacesErrorMessage("The maximum length of a reassignment comment is " + MAX_REJECT_COMMENT_LENGTH);
		} else {
			// reject the review user
			this.reviewUserService.rejectReviewUsers(this.unWrapReviewUsers(this.selectedReviewUsers), this.reviewer.getReviewer(),
					this.selectReasonInput, this.commentsInput);
			this.renderRejectReviewUsersModalPanel = false;
			EmployeeListBean bean = (EmployeeListBean) JSFUtils.lookupBean("employeeListBean");
			bean.refreshEmployeeList();
			return "employeeList";
		}
		return null;

	}

	/**
	 * To unwrap review users list to get review user transfer objects.
	 * @param reviewUsersToUnwrap the review user list.
	 * @return review users transfer object.
	 */
	private List<ReviewUserDTO> unWrapReviewUsers(List<ReviewUserUI> reviewUsersToUnwrap) {
		logger.debug("unWrapReviewUsers() --> being executed.");
		List<ReviewUserDTO> results = new ArrayList<ReviewUserDTO>(reviewUsersToUnwrap.size());
		for (ReviewUserUI wrappedReviewUser : reviewUsersToUnwrap) {
			results.add(wrappedReviewUser.getReviewUserDTO());
		}
		return results;
	}

	/**
	 * Cancels the rejection process.
	 *
	 * @return null to return to the same page.
	 */
	public String doCancelRejectReviewUsersPanel() {
		logger.debug("doCancelRejectReviewUsersPanel() --> being executed.");
		this.renderRejectReviewUsersModalPanel = false;
		return null;
	}

	/**
	 * Get the next employee. If last employee in list then do nothing.
	 *
	 * @return String(navigation another page)
	 */
	public String doRetrieveNextEmployee() {
		logger.debug("doRetrieveNextEmployee() --> being executed.");
		int recordNumber = this.getReviewUser().getRecordNumber();
		/*
		 * if not last item in list then get next record
		 */
		if (recordNumber < this.reviewUsers.size()) {

			if (isEditMode()) {
				this.commitChanges();
			}

			this.setReviewUser(findReviewUserByRecordNumber(recordNumber + 1));
		}
		return "accessList";
	}

	/**
	 * Get the previous employee. If first employee in list then do nothing.
	 *
	 * @return String(navigation another page)
	 */
	public String doRetrievePreviousEmployee() {
		logger.debug("doRetrievePreviousEmployee() --> being executed.");
		int recordNumber = this.getReviewUser().getRecordNumber();

		/*
		 * if not first item in list then get previous record
		 */
		if (recordNumber > 1) {

			if (isEditMode()) {
				this.commitChanges();
			}

			this.setReviewUser(findReviewUserByRecordNumber(recordNumber - 1));
		}

		return "accessList";
	}

	/**
	 * Return back to the list of employees for the reviewer
	 *
	 * @return
	 */
	public String doReturnToEmployeeList() {
		logger.debug("doReturnToEmployeeList() --> being executed.");

		if (isEditMode()) {
			this.commitChanges();
		}

		/*
		 * clear session
		 */

		if (this.returnPage.equals("ReviewUserDashboard")) {
			return "reviewUserDashboard";
		}
		resetVariables();
		EmployeeListBean bean = (EmployeeListBean) JSFUtils.lookupBean("employeeListBean");
		bean.refreshEmployeeList();
		return "employeeList";

	}

	/**
	 * Find the Review user from the list of users.
	 *
	 * @param recordNumber
	 * @return
	 */
	private ReviewUserUI findReviewUserByRecordNumber(int recordNumber) {
		logger.debug("findReviewUserByRecordNumber() --> being executed.");
		for (ReviewUserUI userUI : this.reviewUsers) {
			if (userUI.getRecordNumber() == recordNumber) {
				return userUI;
			}
		}
		logger.error("Review User not found for record number = " + recordNumber);
		return null;
	}

	public ReviewUI getReview() {
		return this.review;
	}

	/**
	 * Get the employee Manager
	 *
	 * @return
	 */
	public String getEmployeeManager() {
		return this.reviewUser.getManagerName();
	}

	public AccessListMode getMode() {
		return mode;
	}

	/**
	 * Get number of employees there are for the reviewer.
	 *
	 * @return String(number of reports)
	 */
	public String getNumberOfRecords() {
		logger.debug("getNumberOfRecords() --> being executed.");
		int employeeListSize = this.reviewUsers.size();
		int recNumber = this.reviewUser.getRecordNumber();
		return recNumber + " of " + employeeListSize;
	}

	/**
	 * Build the dynamic HTML panel that is bound by the accessList.xhtml. This is a panel that contains multiple data tables based
	 * on how many applications an employee has. For each application there will be one table with 1..x rows.
	 *
	 * @return the HtmlPanel built
	 */
	public Panel getPanel() {
		logger.debug("getPanel() --> being executed.");
		/*
		 * Create a new panel
		 */
		panel = new Panel();
		panel.setId("accessListMainPanel");
		panel.setStyle("padding:0");
		panel.setStyleClass("outpanelHeader");
		/*
		 * then, for each application...
		 */
		int id = 0;
		logger.debug("Number of Applications for user = " + getReviewUserApplicationAccessesDTOs().size());
		for (ReviewUserApplicationAccessesDTO applicationDTO : getReviewUserApplicationAccessesDTOs()) {
			id++;
			String applicationName = applicationDTO.getApplicationName();

			String applicationUserId = applicationDTO.getAccesses().get(0).getApplicationUserId();
			/*
			 * create a tool bar to be displayed above the data table representing the application "group" (e.i. Compass, Solar
			 * ..)
			 *
			 * ToolBar creates a holder for the bar, it must have toolBarGroups to display items in the tool bar.
			 */
			Toolbar toolBar = new Toolbar();
			toolBar.setId("Application" + id + "toolBar");
			if (this.review.isSODReview()) {
				toolBar.setStyleClass("defaultTableHeaderSOD");
			} else {
				toolBar.setStyleClass("apptitle");
			}
			/*
			 * add ToolBarGroup to the ToolBar
			 */
			toolBar.getChildren().add(buildToolBarGroup(id, applicationName, applicationUserId));
			/*
			 * add the ToolBar for the application to the panel
			 */
			panel.getChildren().add(toolBar);
			/*
			 * add the data table for the application that has the applications accesses for the user
			 */
			panel.getChildren().add(buildAccessTable(asUI(applicationDTO.getAccesses()), id, applicationDTO));

			if (isEditMode()) {
				HtmlOutputLabel label = new HtmlOutputLabel();
				label.setId("Application" + id + "commentLabel");
				label.setValue("Comments: ");

				panel.getChildren().add(label);

				HtmlInputText input = new HtmlInputText();
				input.setId("Application" + id + "commentText");
				input.setSize(80);
				input.setValue(applicationDTO.getComment());
				input.addValueChangeListener(new CommentListener(applicationDTO));

				panel.getChildren().add(input);
			} else if (isViewEdits()|| isPrintMode()) {
				HtmlOutputLabel label = new HtmlOutputLabel();
				label.setId("Application" + id + "commentLabel");
				label.setValue("Comments: ");

				panel.getChildren().add(label);

				HtmlOutputText output = new HtmlOutputText();
				output.setId("Application" + id + "commentText");
				output.setValue(applicationDTO.getComment());

				panel.getChildren().add(output);
			}

			HtmlGraphicImage spacer = new HtmlGraphicImage();
			spacer.setId("Application" + id + "spacer");
			spacer.setHeight("15px");
			spacer.setWidth("15px");
			spacer.setStyle("display: none"); // not inline

			panel.getChildren().add(spacer);
		}
		//set the mode back to the one before that was before the clicking the print.
		if(isPrintMode()){
			this.mode = this.modeBeforePrint;
		}
		return panel;
	}

	/**
	 * Prints the access list page
	 * @return String navigate to print access list page.
	 */
	public String doPrintAccessList(){
		this.modeBeforePrint = this.mode;
		this.mode = AccessListMode.PRINT;
		return "printAccessList";
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public ReviewerUI getReviewer() {
		return reviewer;
	}

	public ReviewUserUI getReviewUser() {
		return this.reviewUser;
	}

	public IReviewUserAccessService getReviewUserAccessService() {
		return reviewUserAccessService;
	}

	public List<ReviewUserApplicationAccessesDTO> getReviewUserApplicationAccessesDTOs() {
		return dtos;
	}

	public List<? extends ReviewUserUI> getReviewUsers() {
		return reviewUsers;
	}

	/**
	 * Get the user's department
	 *
	 * @return
	 */
	public String getUserDepartment() {
		return this.reviewUser.getDepartmentName();
	}

	/**
	 * Get the user's division
	 *
	 * @return
	 */
	public String getUserDivision() {
		return this.reviewUser.getDivisionName();
	}

	/**
	 * Get the user name
	 *
	 * @return
	 */
	public String getUserName() {
		return this.reviewUser.getUserName();
	}

	/**
	 * Get the user status (Status is the status from the std025_user table)
	 *
	 * @return
	 */
	public String getUserStatus() {
		return this.reviewUser.getUserStatus();
	}

	/**
	 * @return true, if editing the keep/remove status
	 */
	public boolean isEditMode() {
		return getMode().equals(AccessListMode.EDIT);
	}

	public boolean isReviewMode() {
		return getMode().equals(AccessListMode.REVIEW);
	}

	/**
	 * @return true, if viewing the keep/remove status
	 */
	public boolean isViewEdits() {
		return getMode().equals(AccessListMode.VIEW_EDITS);
	}

	/**
	 * @return true, if viewing the keep/remove status
	 */
	public boolean isPrintMode() {
		return getMode().equals(AccessListMode.PRINT);
	}

	/**
	 * Reset variables
	 */
	private void resetVariables() {
		this.reviewUser = null;
		this.reviewUsers = null;
		this.dtos = null;
	}

	public void setReview(ReviewUI aReview) {
		this.review = aReview;
	}

	public void setMode(AccessListMode mode) {
		this.mode = mode;
	}

	/**
	 * Setter for the panel
	 */
	public void setPanel(Panel panel) {
		this.panel = panel;
	}

	public void setReviewBundle(ReviewBundleUI reviewBundle) {
		this.reviewBundle = reviewBundle;
	}

	public void setReviewer(ReviewerUI reviewer) {
		this.reviewer = reviewer;
	}

	public void setReviewUser(ReviewUserUI aReviewUser) {
		this.reviewUser = aReviewUser;
		dtos = getReviewUserAccessService().retrieveByReviewUserId(reviewUser.getReviewUserId());
	}

	/**
	 * Set the ReviewUserAccessService Bean. Injected from faces-config.xml
	 *
	 * @param
	 */
	public void setReviewUserAccessService(IReviewUserAccessService reviewUserAccessService) {
		this.reviewUserAccessService = reviewUserAccessService;
	}

	public void setReviewUsers(List<? extends ReviewUserUI> reviewUsers) {
		int count = 0;
		for (ReviewUserUI user : reviewUsers) {
			user.setRecordNumber(++count);
		}
		this.reviewUsers = reviewUsers;
	}

	private void commitChanges() {
		List<ReviewUserApplicationAccessesDTO> appDTOs = getReviewUserApplicationAccessesDTOs();
		getReviewUserAccessService().save(appDTOs, this.reviewer.getReviewer());

		boolean completed = true;
		for (ReviewUserApplicationAccessesDTO appDTO : appDTOs) {
			for (ReviewUserAccessDTO accessDTO : appDTO.getAccesses()) {
				if (StringUtils.isBlank(accessDTO.getKeepRemoveString())) {
					completed = false;
				}
			}
		}

		if (completed && !this.reviewUser.getCompleted()) {
			// complete the user. Don't really need to reload the user since this pages dosn't care about completeness.
			this.reviewUserService.completeReviewUser(this.reviewUser.getReviewUserDTO());
		}
	}

	/**
	 * To get the review user service.
	 * @return reviewUserService
	 */
	public IReviewUserService getReviewUserService() {
		return reviewUserService;
	}

	/**
	 * Sets the review user service.
	 * @param reviewUserService
	 */
	public void setReviewUserService(IReviewUserService reviewUserService) {
		this.reviewUserService = reviewUserService;
	}

	/**
	 * Gets comment input.
	 * @return commentsInput
	 */
	public String getCommentsInput() {
		return commentsInput;
	}

	/**
	 * Sets comments input.
	 * @param commentsInput
	 */
	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	/**
	 * Gets Select reason input
	 * @return selectReasonInput
	 */
	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	/**
	 * Sets the select reason input.
	 * @param selectReasonInput
	 */
	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	/**
	 * Gets the selected review users list.
	 * @return selectedReviewUsers
	 */
	public List<ReviewUserUI> getSelectedReviewUsers() {
		return selectedReviewUsers;
	}

	/**
	 * Sets the selected review users list.
	 * @param selectedReviewUsers
	 */
	public void setSelectedReviewUsers(List<ReviewUserUI> selectedReviewUsers) {
		this.selectedReviewUsers = selectedReviewUsers;
	}

	/**
	 * To render reject review user page or not.
	 * @return true renders reject review user page.
	 */
	public boolean isRenderRejectReviewUsersModalPanel() {
		return renderRejectReviewUsersModalPanel;
	}

	/**
	 * Sets whether to display reject review user modal panel.
	 * @param renderRejectReviewUsersModalPanel
	 */
	public void setRenderRejectReviewUsersModalPanel(boolean renderRejectReviewUsersModalPanel) {
		this.renderRejectReviewUsersModalPanel = renderRejectReviewUsersModalPanel;
	}

	public String getReturnPage() {
		return returnPage;
	}

	public void setReturnPage(String returnPage) {
		this.returnPage = returnPage;
	}

	public void setPrintPanel(Panel printPanel) {
		this.printPanel = printPanel;
	}

	public boolean isPrintDisplayFlag() {
		if (this.review.isNotManagerReview() || isFromDashboard()) {
			return false;
		}
		return true;
	}

	public void setPrintDisplayFlag(boolean printDisplayFlag) {
		this.printDisplayFlag = printDisplayFlag;
	}

	public boolean isFromDashboard() {
		return fromDashboard;
	}

	public void setFromDashboard(boolean fromDashboard) {
		this.fromDashboard = fromDashboard;
	}

	public boolean isRenderEscalationMgr() {
		return false;
	}

	public void setRenderEscalationMgr(boolean renderEscalationMgr) {
		this.renderEscalationMgr = renderEscalationMgr;
	}

	public void setModeBeforePrint(AccessListMode modeBeforePrint) {
		this.modeBeforePrint = modeBeforePrint;
	}

	public AccessListMode getModeBeforePrint() {
		return modeBeforePrint;
	}

	public boolean getShowApplicationName(){
		return (this.review.isDataOwnerReview() || this.review.isPrivilegedAccessReview());
	}

	private MethodExpression createMethodExpression(String action, Class<?> returnType) {
		FacesContext context = FacesContext.getCurrentInstance();
		Application application = context.getApplication();
		ExpressionFactory expressionFactory = application.getExpressionFactory();
		return expressionFactory.createMethodExpression(context.getELContext(), action, returnType, new Class<?>[0]);
	}
}
