package com.assurant.inc.sox.ar.client.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.RejectSodBundleDTO;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;

public class RejectSodBundleUI {

	private RejectSodBundleDTO rejectSodBundleDTO = null;
	private List<FilterCriteriaUI> filterCriterias = null;
	
	public RejectSodBundleUI(RejectSodBundleDTO rejectSodBundleDTO) {
		super();
		this.rejectSodBundleDTO = rejectSodBundleDTO;
		filterCriterias = new ArrayList<FilterCriteriaUI>(rejectSodBundleDTO.getFilterCriteriaDtos().size());
		for (FilterCriteriaDTO filter : rejectSodBundleDTO.getFilterCriteriaDtos()) {
			filterCriterias.add(new FilterCriteriaUI(filter));
		}
	}

	public Date getBundleCreatedDate() {
		return rejectSodBundleDTO.getBundleCreatedDate();
	}

	public String getBunldeName() {
		return rejectSodBundleDTO.getBunldeName();
	}
	
	public String getFilterCriteriaText(){
		return DisplayStringBuilder.buildFilterCriteriaText(this.filterCriterias);
	}

	public String getSodConflictTypeText() {
		return rejectSodBundleDTO.getSodConflictTypeText();
	}
	
	
}
