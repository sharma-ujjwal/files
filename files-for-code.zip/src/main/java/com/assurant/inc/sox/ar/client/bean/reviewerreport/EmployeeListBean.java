package com.assurant.inc.sox.ar.client.bean.reviewerreport;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlCommandLink;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;

import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUserUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.AccessListMode;
import com.assurant.inc.sox.ar.dto.enums.EmployeeListMode;
import com.assurant.inc.sox.ar.dto.enums.reviewUser.ReviewUserField;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("employeeListBean")
@Scope("session")
public class EmployeeListBean {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeListBean.class);
	private static final String SORT_ACTION_PARAM_NAME = "sortActionParam";
	private static final String WORK_EMPLOYEE_ACTION_PARAM_NAME = "workEmployeeActionParam";
	private static final int MAX_REJECT_COMMENT_LENGTH = 250;
	@Autowired
	@Qualifier("reviewUserService")
	private IReviewUserService reviewUserService;
	private DataTable employeeTable;
	private String previousSortFieldCodeValue;
	private ReviewUI review;
	private ReviewerUI reviewer;
	private ReviewBundleUI reviewBundle;
	private EmployeeListMode mode;
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	private List<ReviewUserUI> selectedReviewUsers;
	private boolean renderRejectReviewUsersModalPanel;
	private boolean renderAttestConfirmationModalPanel;
	private String commentsInput;
	private String selectReasonInput;
	private boolean completeDisplayFlag;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private boolean rejectDisplayFlag;
	private String taskId;
	private DataTable printEmployeeTable;
	private boolean printDisplayFlag;
	private boolean renderEscalationMgr;
	private Long reviewerId;
	private boolean printModeFlag;
	List<ReviewUserUI> resultForProcess;

	private List<ReviewUserUI> selectedEmployeeList = new ArrayList<>();


	// ------------------------- Faces injected props -------------------------
	/**
	 * Get the ReviewUserService Bean.
	 * 
	 * @return SessionDataBean
	 */
	public IReviewUserService getReviewUserService() {
		return reviewUserService;
	}

	/**
	 * Set the ReviewUserService Bean. Injected from faces-config.xml
	 * 
	 * @param reviewUserService
	 */
	public void setReviewUserService(IReviewUserService reviewUserService) {
		this.reviewUserService = reviewUserService;
	}

	/**
	 * Get the ReviewerService Bean.
	 * 
	 * @return SessionDataBean
	 */
	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	/**
	 * Sets the ReviewerService Bean.
	 * 
	 * @param reviewerService
	 */
	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	// --------------------------- Page properties ----------------------------
	public DataTable getEmployeeTable() {
		return this.employeeTable;
	}

	public void setEmployeeTable(DataTable employeeTable) {
		if (employeeTable != null) {
			this.employeeTable = employeeTable;
		}
	}

	public String getDisplayAmount() {
		return String.valueOf(this.getEmployeeTable().getRows());
	}

	public void setDisplayAmount(String displayAmount) {
		this.getEmployeeTable().setRows(Integer.valueOf(displayAmount).intValue());
	}

	public ReviewUI getReview() {
		return review;
	}

	public ReviewerUI getReviewer() {
		return reviewer;
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public boolean getRenderReturnToReviewDetailsLink() {
		return EmployeeListMode.SCHEDULE_REVIEWS.equals(this.mode);
	}

	public List<ReviewUserUI> getSelectedReviewUsers() {
		return selectedReviewUsers;
	}

	public void setSelectedReviewUsers(List<ReviewUserUI> selectedReviewUsers) {
		this.selectedReviewUsers = selectedReviewUsers;
	}

	public boolean isRenderRejectReviewUsersModalPanel() {
		return renderRejectReviewUsersModalPanel;
	}

	public void setRenderRejectReviewUsersModalPanel(boolean renderRejectReviewUsersModalPanel) {
		this.renderRejectReviewUsersModalPanel = renderRejectReviewUsersModalPanel;
	}

	public String getCommentsInput() {
		return commentsInput;
	}

	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	public boolean isRenderAttestConfirmationModalPanel() {
		return renderAttestConfirmationModalPanel;
	}

	public void setRenderAttestConfirmationModalPanel(boolean renderAttestConfirmationModalPanel) {
		this.renderAttestConfirmationModalPanel = renderAttestConfirmationModalPanel;
	}

	public boolean isCompleteDisplayFlag() {
		return checkCompleteDisplayFlag();
	}

	public void setCompleteDisplayFlag(boolean completeDisplayFlag) {
		this.completeDisplayFlag = completeDisplayFlag;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public boolean isRejectDisplayFlag() {
		return checkRejectDisplayFlag();
	}

	public void setRejectDisplayFlag(boolean rejectDisplayFlag) {
		this.rejectDisplayFlag = rejectDisplayFlag;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	// ----------------------------- Page Actions -----------------------------
	/**
	 * Navigation to get to the review details page
	 * 
	 * @return String
	 */
	public String doReturnToReviewDetails() {
		logger.debug("doReturnToReviewDetails() --> being executed.");
		return "reviewDetails";
	}

	@SuppressWarnings("unchecked")
	public String doSortByField() {
		logger.debug("doSortByField -- enter");
		String sortFieldCodeValue = JSFUtils.getParameter(SORT_ACTION_PARAM_NAME);
		CommonPageActionHelper.sortListByField(this.employeeTable, sortFieldCodeValue, this.previousSortFieldCodeValue);
		this.previousSortFieldCodeValue = sortFieldCodeValue;

		return null;
	}

	/**
	 * Selects current page of reviewers and cancels any selected item.
	 * @return String
	 */
	public String doSelectedToggle() {
		logger.debug("doSelectedToggle() --> being executed.");
		CommonPageActionHelper.selectPagedTableAllToggle(this.employeeTable);
		return null;
	}

	/**
	 * Loads the access list bean.
	 * @return String to navigate to the access list page.
	 */
	@SuppressWarnings("unchecked")
	public String doWorkEmployee(ReviewUserUI employee) {
		logger.debug("doWorkEmployee() --> being executed.");
		List<ReviewUserUI> employees = resultForProcess;

        AccessListBean bean = (AccessListBean) JSFUtils.lookupBean("accessListBean");

		bean.setReview(this.review);
		bean.setReviewUser(employee);
		bean.setReviewUsers(employees);
		bean.setReviewer(this.reviewer);
		bean.setReviewBundle(this.reviewBundle);
		AccessListMode accessMode;
		switch (this.mode) {
		case REVIEWER_VERIFY:
			accessMode = AccessListMode.EDIT;
			break;
		case SCHEDULE_REVIEWS:
			accessMode = AccessListMode.REVIEW;
			break;
		case BIG_BROTHER_VERIFY:
			accessMode = AccessListMode.VIEW_EDITS;
			break;
		default:
			throw new RuntimeException("An invalid mode was found: " + this.mode);
		}
		bean.setMode(accessMode);
		bean.setReturnPage("Employee");
		bean.setFromDashboard(false);
		return "accessList";
	}

	/**
	 * Prepares the reject review user panel.
	 * 
	 * @return null return to same page.
	 */
	public String doPrepareRejectReviewUserPanel() {
		logger.debug("doPrepareRejectReviewUserPanel() --> being executed.");
		try {
			this.selectedReviewUsers = this.extractSelectedReviewUsers();
			this.commentsInput = null;
			this.selectReasonInput = null;
			this.renderRejectReviewUsersModalPanel = true;
		} catch (InvalidReviewUserSelectionException e) {
			JSFUtils
			    .addFacesErrorMessage("An invalid number of review users were selected.  At least one review user must be selected to preform a rejection.");
			this.renderRejectReviewUsersModalPanel = false;
		}
		return null;
	}

	/**
	 * Rejects the review user and perform input data validation.
	 * 
	 * @return null return to the same page.
	 */
	public String doSaveRejectReviewUsersPanel() {
		logger.debug("doSaveRejectReviewUsersPanel() --> being executed.");
		// Displays error message if reason not provided
		if (StringUtils.isBlank(this.selectReasonInput)) {
			JSFUtils.addFacesErrorMessage("A reason must be selected to perform a rejection.");
		}
		// Displays error message if comment invalid
		else if (StringUtils.isNotBlank(this.commentsInput) && this.commentsInput.length() > MAX_REJECT_COMMENT_LENGTH) {
			JSFUtils.addFacesErrorMessage("The maximum length of a reassignment comment is " + MAX_REJECT_COMMENT_LENGTH);
		} else {
			// Gets the selected review users for rejection from the list
			List<ReviewUserDTO> selectedReviewUserDTOs = new ArrayList<ReviewUserDTO>(this.selectedReviewUsers.size());
			for (ReviewUserUI reviewUser : this.selectedReviewUsers) {
				selectedReviewUserDTOs.add(reviewUser.getReviewUserDTO());
			}
			this.reviewUserService.rejectReviewUsers(this.unWrapReviewUsers(this.selectedReviewUsers), this.reviewer.getReviewer(),
			    this.selectReasonInput, this.commentsInput);
			this.removeFromTable(this.resultForProcess, this.selectedReviewUsers);
			this.renderRejectReviewUsersModalPanel = false;
		}
		return null;

	}

	/**
	 * Cancels the review user rejection process.
	 * 
	 * @return null to return to the same page.
	 */
	public String doCancelRejectReviewUsersPanel() {
		logger.debug("doCancelRejectReviewUsersPanel() --> being executed.");
		this.renderRejectReviewUsersModalPanel = false;
		return null;
	}

	/**
	 * Prepares the attest review panel.
	 * @return null return to same page.
	 */
	public String doPrepareAttest() {
		logger.debug("doPrepareAttest() --> being executed.");
		this.renderAttestConfirmationModalPanel = true;
		return null;
	}

	/**
	 * Cancels the attest process.
	 * 
	 * @return null to return to the same page.
	 */
	public String doCancelAttestConfirmationPanel() {
		logger.debug("doCancelAttestConfirmationPanel() --> being executed.");
		this.renderAttestConfirmationModalPanel = false;
		return null;
	}

	/**
	 * Attests the review.
	 * 
	 * @return null return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doSaveAttestConfirmationPanel() {
		logger.debug("doSaveAttestConfirmationPanel() --> being executed.");
		ReviewerDTO reviewerDTO = this.reviewer.getReviewer();

		List<ReviewUserUI> reviewUsers = (List<ReviewUserUI>) this.employeeTable.getValue();
		List<ReviewUserDTO> reviewUserDTOs = new ArrayList<ReviewUserDTO>(reviewUsers.size());
		for (ReviewUserUI reviewUser : reviewUsers) {
			reviewUserDTOs.add(reviewUser.getReviewUserDTO());
		}

		this.reviewerService.attestReview(reviewerDTO, taskId, reviewUserDTOs);
		// return to the task list page after attestation process is complete.
		this.sessionDataBean.initSelectedTasklistBean();
		this.renderAttestConfirmationModalPanel = false;
		return "taskList";
	}

	// ------------------------------ Helper methods --------------------------

	@SuppressWarnings("unchecked")
	private DataTable buildTable(Long buildReviewerId) {
		logger.debug("buildTable(Long reviewerId) --> being executed.");
		DataTable table = new DataTable();
		table.setVar("employee");
		table.setStyleClass("defaultTableHeader");
		if(!isPrintModeFlag()){
			table.setRows(10);
		}
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		table.setValue(this.retrieveEmployees(buildReviewerId));

		// add columns
		List tableChildren = table.getChildren();
		switch (this.mode) {
		case SCHEDULE_REVIEWS:
			if(isPrintModeFlag()){
				tableChildren.add(this.buildPrintableEmployeeNameColumn());
			} else {
				tableChildren.add(this.buildEmployeeNameColumn());
			}
			
			if (this.review.isNotManagerReview()) {
				tableChildren.add(this.buildEmployeeManagerNameColumn());
			}
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			break;
		case REVIEWER_VERIFY:
			if(isPrintModeFlag()){
				tableChildren.add(this.buildPrintableEmployeeNameColumn());
			} else {
				tableChildren.add(this.buildSelectColumn());
				tableChildren.add(this.buildEmployeeNameColumn());
			}
			if (this.review.isNotManagerReview()) {
				tableChildren.add(this.buildEmployeeManagerNameColumn());
			}
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			tableChildren.add(this.buildCompletedColumn());
			break;
		case BIG_BROTHER_VERIFY:
			if(isPrintModeFlag()){
				tableChildren.add(this.buildPrintableEmployeeNameColumn());
			} else {
				tableChildren.add(this.buildEmployeeNameColumn());
			}
			
			if (this.review.isNotManagerReview()) {
				tableChildren.add(this.buildEmployeeManagerNameColumn());
			}
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			tableChildren.add(this.buildCompletedColumn());
			break;
		default:
			throw new RuntimeException("An invalid employee list mode was found.  " + this.mode);
		}

		return table;
	}

	private Object buildEmployeeManagerNameColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Manager Name", ReviewUserField.MANAGER_NAME.getFieldName(),
		    "sortByManagerNameLink"), HtmlTableBuilderUtil.buildOutputText("#{employee.managerName}"));
	}

	private Object buildCompletedColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Review Complete?", ReviewUserField.COMPLETED.getFieldName(),
		    "sortByCompletedLink"), HtmlTableBuilderUtil.buildOutputText("#{employee.completedDisplay}"));
	}

	private Object buildDepartmentColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Department", ReviewUserField.DEPT.getFieldName(),
		    "sortByDepartmentLink"), HtmlTableBuilderUtil.buildOutputText("#{employee.departmentName}"));
	}

	private Object buildDivisionColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Division", ReviewUserField.DIVISION.getFieldName(),
		    "sortByDivisionLink"), HtmlTableBuilderUtil.buildOutputText("#{employee.divisionName}"));
	}

	private Object buildEmployeeNameColumn() {
		HtmlCommandLink link = new HtmlCommandLink();
		link.setId("selectEmployeeLink");
		JSFUtils.setValueBinding(link, "value", "#{employee.userName}");
		JSFUtils.setActionBinding(link, "#{employeeListBean.doWorkEmployee}");

		UIParameter param = new UIParameter();
		JSFUtils.setValueBinding(param, "value", "#{employee.reviewUserId}");
		param.setName(WORK_EMPLOYEE_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Employee List", ReviewUserField.NAME.getFieldName(),
		    "sortByEmployeeNameLink"), link);
	}

	private Object buildPrintableEmployeeNameColumn() {
		HtmlOutputText text = new HtmlOutputText();
		text.setId("selectEmployeeLink");
		JSFUtils.setValueBinding(text, "value", "#{employee.userName}");
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Employee List", ReviewUserField.NAME.getFieldName(),
		    "sortByEmployeeNameLink"), text);
	}

	private Object buildSelectColumn() {
		HtmlSelectBooleanCheckbox checkBox = new HtmlSelectBooleanCheckbox();
		checkBox.setId("reviewUserCheckBox");
		JSFUtils.setValueBinding(checkBox, "value", "#{employee.selected}");

		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink("All/None", "#{employeeListBean.doSelectedToggle}",
		    "selectAllLink");
		return HtmlTableBuilderUtil.buildColumn(link, checkBox);
	}

	// must use deprecated method until websphere dies
	private CommandLink buildHeaderLink(String value, String paramValue, String id) {
		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink(value, "#{employeeListBean.doSortByField}", id);

		UIParameter param = new UIParameter();
		param.setValue(paramValue);
		param.setName(SORT_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		return link;
	}

	@SuppressWarnings("unchecked")
	private List<ReviewUserUI> retrieveEmployees(Long retrieveReviewerId) {
		logger.debug("retrieveEmployees - enter");

		List<ReviewUserDTO> dtos = null;
		/*
		 * For review details (part of Schedule reviews), they need to see even the rejected
		 * users at this part of the workflow
		 */
		if(EmployeeListMode.SCHEDULE_REVIEWS.equals(this.mode)){
			dtos = this.reviewUserService.retrieveByReviewerId(retrieveReviewerId, this.review.getReview()
				    .getReviewTypeCd());
		}else{
			/*
			 * otherwise the UI won't show rejected users to the reviewers
			 */
			dtos = this.reviewUserService.retrieveByReviewerIdNonRejected(retrieveReviewerId, this.review.getReview()
					.getReviewTypeCd());
		}

		// sort the dto so when we build the UI object the employees show up in the same order each time
		Collections.sort(dtos, new GenericComparator("userName", true));

		List<ReviewUserUI> result = new ArrayList<ReviewUserUI>(dtos.size());

		// counter to assign each user a record number for the UI purpose to next
		// and pervious employee will have state
		int count = 0;
		for (ReviewUserDTO userDTO : dtos) {
			ReviewUserUI ui = new ReviewUserUI(userDTO);
			ui.setRecordNumber(++count);
			result.add(ui);
		}
		if (resultForProcess == null)
			resultForProcess = result;
		return result;
	}

	public void onRowSelect() {
		selectedEmployeeList.clear();
		for (ReviewUserUI reviewUser : resultForProcess) {
			if (reviewUser.isSelected()) {
				selectedEmployeeList.add(reviewUser);
			}
		}
	}

	/**
	 * Loads the Employee list bean and builds the employee table.
	 * @param selectedReview the selected review.
	 * @param selectedBundle the review bundle.
	 * @param selectedReviewer the Reviewer.
	 * @param selectedMode the mode for employee list.
	 * //@param savvionProcessId the Savvion process Id for completion process.
	 */
	public void initEmployeeList(ReviewUI selectedReview, ReviewBundleUI selectedBundle, ReviewerUI selectedReviewer,
	    EmployeeListMode selectedMode, String taskProcessId) {
		logger.debug("initEmployeeList() --> being executed.");
		this.mode = selectedMode;
		this.review = selectedReview;
		this.reviewBundle = selectedBundle;
		this.reviewer = selectedReviewer;
		/*
		 * reset this session variable
		 */
		this.previousSortFieldCodeValue = "userName";
		
		//Check the review type and set the additional header details
		if (this.review.isManagerReview()) {
			getReviewerService().populateReviewerEscalationMgrName(reviewer.getReviewer());
		} else if (this.review.isShowDataOwner()) {
			getReviewerService().populateReviewerDataOwnerName(reviewer.getReviewer());
		} else if (this.review.isSODReview()) {
			getReviewerService().populateReviewerSODValues(reviewer.getReviewer());
		}
		
		getReviewerService().populateReviewerDistinctEnvName(reviewer.getReviewer());

		this.taskId = taskProcessId;
		this.reviewerId = reviewer.getReviewerId();
		this.retrieveEmployees(reviewerId);

	}

	/**
	 * checks whether to display the complete button on employee list page.
	 * @return true complete will be displayed.
	 */
	private boolean checkCompleteDisplayFlag() {
		boolean result = true;
		List<ReviewUserUI> reviewUsers = resultForProcess;
		// check for each review user in the list
		for (ReviewUserUI reviewUser : reviewUsers) {
			// if review incomplete or invalid mode
			if (!reviewUser.getCompleted() || !EmployeeListMode.REVIEWER_VERIFY.equals(this.mode)) {
				// complete button not displayed
				result = false;
				break;
			}
		}
		return result;
	}

	/**
	 * checks whether to display the reject button on employee list page.
	 * @return true reject will be displayed.
	 */
	private boolean checkRejectDisplayFlag() {
		boolean result = false;
		// check if valid mode to reject review user
		if (EmployeeListMode.REVIEWER_VERIFY.equals(this.mode)) {
			result = true;
		}
		return result;
	}

	/**
	 * Removes the rejected review users from the employee table.
	 * @param table the employee table
	 * @param reviewUsersToRemove the selected review users to be removed.
	 */
	@SuppressWarnings("unchecked")
	private void removeFromTable(List<ReviewUserUI> resultForProcess, List<ReviewUserUI> reviewUsersToRemove) {
		List<ReviewUserUI> reviewUsers = resultForProcess;
		reviewUsers.removeAll(reviewUsersToRemove);
	}

	/**
	 * Extracts the selected review users from the provided list of review users.
	 * @param table the review users to search for selected review users.
	 * @return a list of the selected review users.
	 * @throws InvalidReviewUserSelectionException if no review users are selected.
	 */
	private List<ReviewUserUI> extractSelectedReviewUsers() throws InvalidReviewUserSelectionException {

		List<ReviewUserUI> reviewUsers = selectedEmployeeList;
		List<ReviewUserUI> results = new ArrayList<ReviewUserUI>(5);
		for (ReviewUserUI reviewUser : reviewUsers) {
			if (reviewUser.isSelected()) {
				results.add(reviewUser);
			}
		}
		if (results.isEmpty()) {
			throw new InvalidReviewUserSelectionException();
		}
		return results;
	}

	public void selectOrRejectAllEmployees(boolean isSelected) {
		logger.debug("selectOrRejectAllEmployees() --> being executed.");
		for (ReviewUserUI reviewUser : resultForProcess) {
			reviewUser.setSelected(isSelected);
		}
		selectedEmployeeList = resultForProcess;
	}


	/**
	 * Extracts review user list from the employee table.
	 * @param table the employee table.
	 * @return the review user list.
	 */
	@SuppressWarnings("unchecked")
	private List<ReviewUserUI> extractReviewUserList(List<ReviewUserUI> resultForProcess) {
		return resultForProcess;
	}

	/**
	 * To unwrap review users list to get review user transfer objects.
	 * @param reviewUsers the review user list.
	 * @return review users transfer object.
	 */
	private List<ReviewUserDTO> unWrapReviewUsers(List<ReviewUserUI> reviewUsers) {
		List<ReviewUserDTO> results = new ArrayList<ReviewUserDTO>(reviewUsers.size());
		for (ReviewUserUI reviewUser : reviewUsers) {
			results.add(reviewUser.getReviewUserDTO());
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public void refreshEmployeeList() {
		logger.debug("refreshEmployeeList() --> being executed.");
		List values = new ArrayList();
		values.clear();
		values.addAll(this.retrieveEmployees(this.reviewer.getReviewerId()));
	}

	/**
	 * Invalid review user selection exception, if no review users are selected.
	 */
	private class InvalidReviewUserSelectionException extends Exception {
		private static final long serialVersionUID = 1L;

		public InvalidReviewUserSelectionException() {
			super();
		}
	}

	/**
	 * Prints the employee list page
	 * @return String navigate to print employee list page.
	 */
	public String doPrintEmployeeList(){
		this.printModeFlag = true;
		this.printEmployeeTable = buildTable(reviewer.getReviewerId());
		this.printModeFlag = false;
		return "printEmployeeList";
	}
	
	public void setPrintEmployeeTable(DataTable printEmployeeTable) {
		this.printEmployeeTable = printEmployeeTable;
	}

	public boolean isPrintDisplayFlag() {
		return (this.review.isNotManagerReview()) ? false : true;
	}

	public void setPrintDisplayFlag(boolean printDisplayFlag) {
		this.printDisplayFlag = printDisplayFlag;
	}

	public boolean isRenderEscalationMgr() {
		return (!this.review.isNotManagerReview()) ? true : false;
	}

	public void setRenderEscalationMgr(boolean renderEscalationMgr) {
		this.renderEscalationMgr = renderEscalationMgr;
	}

	public Long getReviewerId() {
		return reviewerId;
	}

	public void setReviewerId(Long reviewerId) {
		this.reviewerId = reviewerId;
	}

	public boolean isPrintModeFlag() {
		return printModeFlag;
	}

	public void setPrintModeFlag(boolean printModeFlag) {
		this.printModeFlag = printModeFlag;
	}

	public DataTable getPrintEmployeeTable() {
		return printEmployeeTable;
	}
	
	public boolean getShowApplicationName(){
		return (this.review.isDataOwnerReview() || this.review.isPrivilegedAccessReview());
	}

	public List<ReviewUserUI> getResultForProcess() {
		return resultForProcess;
	}

	public void setResultForProcess(List<ReviewUserUI> resultForProcess) {
		this.resultForProcess = resultForProcess;
	}

	public void selectAllEmployees() {
		selectOrRejectAllEmployees(true);
	}

	public void rejectAllEmployees() {
		selectOrRejectAllEmployees(false);
	}
}
