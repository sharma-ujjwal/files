package com.assurant.inc.sox.ar.dto.enums.reviewer;

import com.assurant.inc.sox.domain.ar.Reviewer;

public enum ReviewerStatusCode {
    PENDING(Reviewer.PENDING_REVIEWER_STATUS_CD), RELEASED(
    		Reviewer.RELEASED_REVIEWER_STATUS_CD ), APPROVED(
    		Reviewer.APPROVED_REVIEWER_STATUS_CD), REJECTED(
    		Reviewer.REJECTED_REVIEWER_STATUS_CD);

    private final String code;

    private ReviewerStatusCode(String code) {
    	
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
