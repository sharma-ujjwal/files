package com.assurant.inc.sox.ar.client.ui;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.Reviewer;

public class ReviewerUI implements ISelectableUI {

	public static final String WEEK_DUE_IMAGE = "/images/sox7days.gif";
	public static final String DAYS_DUE_IMAGE = "/images/sox3days.gif";
	public static final String OVERDUE_IMAGE = "/images/soxoverdue.gif";

	private final ReviewerDTO reviewerDTO;
	private boolean selected;

	public ReviewerUI() {
		this.reviewerDTO = new ReviewerDTO(new Reviewer(), new CodeDTO(new Code()), new CodeDTO(new Code()), "");
	}

	public ReviewerUI(ReviewerDTO aReviewerDTO) {
		this.reviewerDTO = aReviewerDTO;
	}

	public ReviewerDTO getReviewer() {
		return this.reviewerDTO;
	}

	public boolean isSelected() {
		return this.selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getBundleName() {
		return this.reviewerDTO.getBundleName();
	}

	public String getCurrentReviewerName() {
		return this.reviewerDTO.getReviewerName();
	}

	public Long getReviewBundleId() {
		return reviewerDTO.getReviewBundleId();
	}

	public String getDepartment() {
		return this.reviewerDTO.getReviewerDepartment();
	}

	public String getDivision() {
		return this.reviewerDTO.getDivision();
	}

	public Date getDistributionTargetCompleteDate() {
		return this.reviewerDTO.getDistributionTargetCompleteDate();
	}

	/**
	 * This is a count of the number of users returned for the given criteria for the bundle.For reviewers this will be the count of
	 * users that report to the reviewer. For data owner reviews this will be the count of users with access to the (derived)
	 * associated application.
	 * 
	 * @return the count.
	 */
	public Long getNumberOfReviewedUsers() {
		return this.reviewerDTO.getNumberOfReviewedUsers();
	}

	public Date getCreatedDate() {
		return this.reviewerDTO.getCreatedDate();
	}

	public Date getSentDate() {
		return this.reviewerDTO.getReleaseDate();
	}

	public String getSentBy() {
		return this.reviewerDTO.getReleaseById();
	}

	public Date getRejectDate() {
		return this.reviewerDTO.getRejectDate();
	}

	public String getRejectedBy() {
		return this.reviewerDTO.getRejectBy();
	}

	public String getRejectCode() {
		return this.reviewerDTO.getRejectCode().getValue();
	}

	public String getRejectCodeDisplay() {
		return this.reviewerDTO.getRejectCode().getDisplay();
	}

	public String getRejectComment() {
		return this.reviewerDTO.getRejectText();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.ar.dto.ReviewerDTO#getApplicationName()
	 */
	public String getApplication() {
		return this.reviewerDTO.getApplicationName();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.ar.dto.ReviewerDTO#getNumberOfDepartments()
	 */
	public int getNumberOfDepartments() {
		return this.reviewerDTO.getNumberOfDepartments();
	}

	public String getReviewerStatus() {
		return this.reviewerDTO.getReviewerStatus();
	}

	public String getOwnerName() {
		return this.reviewerDTO.getOwnerName();
	}

	/**
	 * @return the valid
	 */
	public boolean isInvalidUser() {
		return this.reviewerDTO.isInvalidUser();
	}

	public Long getReviewerId() {
		return this.reviewerDTO.getReviewerId();
	}

	public String getDistinctEmployeeStatuses() {
		return reviewerDTO.getDistinctEmployeeStatuses();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.ar.dto.ReviewerDTO#getUserId()
	 */
	public Long getUserId() {
		return this.reviewerDTO.getUserId();
	}

	public String getDistinctEnvName() {
		return this.reviewerDTO.getDistinctEnvName();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.ar.dto.ReviewerDTO#toString()
	 */
	@Override
	public String toString() {
		return this.reviewerDTO.toString();
	}

	public Date getAttestedOnDate() {
		return this.reviewerDTO.getAttestedOnDate();
	}

	public Date getDueDate() {
		return this.reviewerDTO.getDistributionTargetCompleteDate();
	}

	public Date getLastModifiedDate() {
		return this.reviewerDTO.getLastChangedDate();
	}

	public Date getReviewCompletedDate() {
		return reviewerDTO.getAttestedOnDate();
	}

	public boolean isActionRequired() {
		return this.reviewerDTO.isActionRequired();
	}

	public int getSortActionRequired() {
		return this.reviewerDTO.isActionRequired() ? 1 : 0;
	}

	public String getDaysWarningImage() {
		final String warning = reviewerDTO.calculateDaysWarning();
		if (warning.equals(ReviewerDTO.WEEK_DUE)) {
			return WEEK_DUE_IMAGE;
		} else if (warning.equals(ReviewerDTO.DAYS_DUE)) {
			return DAYS_DUE_IMAGE;
		} else if (warning.equals(ReviewerDTO.OVERDUE)) {
			return OVERDUE_IMAGE;
		} else {
			return "";
		}
	}

	public String getDaysWarningOrder() {
		final String warning = reviewerDTO.calculateDaysWarning();
		if (warning.equals(ReviewerDTO.WEEK_DUE)) {
			return "order-3";
		} else if (warning.equals(ReviewerDTO.DAYS_DUE)) {
			return "order-2";
		} else if (warning.equals(ReviewerDTO.OVERDUE)) {
			return "order-1";
		} else {
			return "order-4";
		}
	}

	public boolean isDaysWarningRendered() {
		return !reviewerDTO.calculateDaysWarning().equals("");
	}

	public String getEscalationMgrName() {
		return this.reviewerDTO.getEscalationMgrName();
	}

	public String getConflictType() {
		return this.reviewerDTO.getConflictType();
	}

	public String getConflictTypeDisplayName() {
		ConflictDTO conflict = this.reviewerDTO.getConflict();
		if (conflict == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		sb.append(this.reviewerDTO.getConflictType());
		sb.append(": ");

		sb.append(conflict.getLeftConflictName());
		sb.append(" / ");
		sb.append(conflict.getRightConflictName());
		return sb.toString();
	}

	public Date getLast250AccessChangedDate() {
		return reviewerDTO.getLast250AccessChangedDate();
	}

	public boolean isHasAccessToApplication() {
		return reviewerDTO.isHasAccessToApplication();
	}

}
