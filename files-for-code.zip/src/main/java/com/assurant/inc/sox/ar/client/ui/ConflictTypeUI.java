package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;

public class ConflictTypeUI {

	private final ConflictTypeDTO conflictType;

	public ConflictTypeUI(ConflictTypeDTO conflictType) {
		super();
		this.conflictType = conflictType;
	}
	
	public String getConflictTypeDisplay() {
		return this.conflictType.getName();
	}
}
