package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;


import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.admin.ui.SodOwnerSummaryUI;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.ISodOwnerSummaryService;
import com.assurant.inc.sox.domain.admin.SodOwnerSummary;
import com.assurant.inc.sox.domain.ar.ConflictType;
import com.assurant.inc.sox.domain.searchable.SodOwnerSummarySearchCriteria;
import org.primefaces.component.datascroller.DataScroller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("sodOwnerSummaryBean")
@Scope("session")
public class SodOwnerSummaryBean {
	//injected resources
	@Autowired
	@Qualifier("sodOwnerSummaryService")
	private ISodOwnerSummaryService sodOwnerSummaryService;
	
	private List<SodOwnerSummaryUI> sodOwnerSummaryList;
	private SodOwnerSummarySearchCriteria criteria;
	private String displayAmount = "10";
	private String oldSortColumn;
	
	DataScroller dataScroller;
	
	public ISodOwnerSummaryService getSodOwnerSummaryService() {
		return sodOwnerSummaryService;
	}

	public void setSodOwnerSummaryService(
			ISodOwnerSummaryService reviewOwnerSummaryService) {
		this.sodOwnerSummaryService = reviewOwnerSummaryService;
	}

	public Long getSearchConflictTypeId() {
		return this.criteria.getConflictTypeId();
	}

	public void setSearchConflictTypeId(Long conflictTypeId) {
		this.criteria.setConflictTypeId(conflictTypeId);
	}

	public String getSearchConflictCode() {
		return this.criteria.getConflictCode();
	}

	public void setSearchConflictCode(String conflictCode) {
		this.criteria.setConflictCode(conflictCode);
	}

	public String getSearchLeftConflictName() {
		return this.criteria.getLeftConflictName();
	}

	public void setSearchLeftConflictName(String leftConflictName) {
		this.criteria.setLeftConflictName(leftConflictName);
	}

	public String getSearchRightConflictName() {
		return this.criteria.getRightConflictName();
	}

	public void setSearchRightConflictName(String rightConflictName) {
		this.criteria.setRightConflictName(rightConflictName);
	}

	public String getSearchSodOwnerName() {
		return this.criteria.getSodOwnerName();
	}

	public void setSearchSodOwnerName(String sodOwnerName) {
		this.criteria.setSodOwnerName(sodOwnerName);
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getOldSortColumn() {
		return oldSortColumn;
	}

	public void setOldSortColumn(String oldSortColumn) {
		this.oldSortColumn = oldSortColumn;
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

	public void setSodOwnerSummaryList(List<SodOwnerSummaryUI> reviewOwnerSummaryList) {
		this.sodOwnerSummaryList = reviewOwnerSummaryList;
	}

	public List<SodOwnerSummaryUI> getSodOwnerSummaryList() {
		if (sodOwnerSummaryList == null) {
			this.resetCriteria();
			this.criteria.setActiveOnly(Boolean.TRUE);
			this.refreshList();
		}
		return sodOwnerSummaryList;
	}

	private void resetCriteria() {
		this.criteria = new SodOwnerSummarySearchCriteria();
	}
	
	public void refreshList() {
		System.out.println("**** In SODOwner Sumamr Bean class before service call***");
		List<SodOwnerSummary> summaryList = this.sodOwnerSummaryService
				.retrieveSodOwnerSummariesByCriteria(this.criteria);
		System.out.println("**** In SODOwner Sumamr Bean class after service call***");

		this.sodOwnerSummaryList = new ArrayList<SodOwnerSummaryUI>();
		for (SodOwnerSummary summary : summaryList) {
			this.sodOwnerSummaryList.add(new SodOwnerSummaryUI(summary));
		}
		this.doSort();
	}

	public String doSearch() {
		this.refreshList();
		return "";
	}
	
	public String resetSearch() {
		this.sodOwnerSummaryList = null;
		resetCriteria();
		this.oldSortColumn = null;
		this.refreshList();
		return "";
	}
	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "conflictType";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(sodOwnerSummaryList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));

		return availableFilters;
	}
	
	public List<SelectItem> getAvailableConflictCodes() {
		List<SelectItem> availableConflictCodes = new ArrayList<SelectItem>(3);
		availableConflictCodes.add(new SelectItem("", ""));
		availableConflictCodes.add(new SelectItem(ConflictType.CONFLICT_CODE_APP_APP, "App to App"));
		availableConflictCodes.add(new SelectItem(ConflictType.CONFLICT_CODE_APP_DIV, "App to Div"));
	
		return availableConflictCodes;
	}
	
	public void init() {
		this.sodOwnerSummaryList = null;
		this.oldSortColumn = null;
		resetCriteria();
		this.displayAmount = "10";
	}
}

