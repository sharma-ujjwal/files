package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.FunctionDuty;

public interface IFunctionDutyService {
	public List<FunctionDuty> retrieveAll();
	public List<FunctionDuty> retrieveAllByDescription(String description);
	public List<FunctionDuty> retrieveDeleted();
	public List<FunctionDuty> retrieveDeletedByDescription(String description); 
	public List<FunctionDuty> retrieveUnassigned();
	public List<FunctionDuty> retrieveUnassignedByDescription(String description); 
	
	public FunctionDuty findDuplicate(String description);
	public void add(String description);
	public void delete(FunctionDuty functionDuty);
	public boolean canFunctionDutyBeDeleted(Long id);
}
