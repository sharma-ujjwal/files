package com.assurant.inc.sox.ar.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.service.IInternalIdentifierTypeService;
import com.assurant.inc.sox.dao.ar.IInternalIdentifierTypeDAO;
import com.assurant.inc.sox.domain.luad.InternalIdentifierType;
 
@Service
public class InternalIdentifierTypeService implements IInternalIdentifierTypeService{

	@Autowired
	IInternalIdentifierTypeDAO internalIdentifierTypeDAO;
	 
	public List<InternalIdentifierType> findAll() {
		return this.internalIdentifierTypeDAO.findAll();
	}
	public InternalIdentifierType findById(Long idTypId){
		return this.internalIdentifierTypeDAO.findById(idTypId);
	}
	
	public Long getTypeIdByTypeCD(String typeCD){
		Long typeId = -1L;
		InternalIdentifierType internalType = this.internalIdentifierTypeDAO.findByTypeCD(typeCD);
		if (internalType!= null){
			if (typeCD.equalsIgnoreCase(internalType.getIntrnlIdntfyrTypCd()))
				typeId = internalType.getIdTypId();
		}
		return typeId;
	}
}
