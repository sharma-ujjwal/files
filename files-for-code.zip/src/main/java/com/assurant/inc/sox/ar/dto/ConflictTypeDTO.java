package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.ar.ConflictType;

public class ConflictTypeDTO {

	private final ConflictType domain;
	private String name;
	private String id;
	

	public ConflictTypeDTO(ConflictType domain) {
		super();
		this.domain = domain;
	}

	public ConflictTypeDTO() {
		super();
		domain = new ConflictType();
	}

	public Long getId() {
		return this.domain.getId();
	}

	public String getName() {
		return this.domain.getConflictTypeText();
	}

	public void setId(Long id) {
		this.domain.setId(id);
	}

	public void setName(String name) {
		this.domain.setConflictTypeText(name);
	}
}
