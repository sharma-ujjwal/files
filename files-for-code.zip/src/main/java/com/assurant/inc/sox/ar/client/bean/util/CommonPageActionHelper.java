package com.assurant.inc.sox.ar.client.bean.util;

import java.util.Collections;
import java.util.List;

import org.primefaces.component.datatable.DataTable;

import com.assurant.inc.sox.ar.client.ui.ISelectableUI;
import com.assurant.inc.sox.ar.comparators.GenericComparator;

public abstract class CommonPageActionHelper {

	@SuppressWarnings("unchecked")
	public static void selectPagedTableAllToggle(DataTable table) {

		List<ISelectableUI> values = ((List<ISelectableUI>) table.getValue());

		// detect to see if there are any selected items.
		boolean hasSelected = false;
		for(ISelectableUI value : values){
			if(value.isSelected()){
				hasSelected = true;
				break;
			}
		}

		if(hasSelected){
			// if any are selected then unselect all.
			for(ISelectableUI value : values){
				value.setSelected(false);
			}
		}
		else{
			// if none are selected then select only the current page of reviewers.
			int firstRow = table.getFirst();
			int lastRow = Math.min((firstRow + table.getRows()), values.size());
			for(int currRow = firstRow; currRow < lastRow; currRow++){
				values.get(currRow).setSelected(true);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static void sortListByField(DataTable table, String sortFieldCodeValue, String previousSortFieldCodeValue) {
		List list = ((List) table.getValue());
		sortListByField(list, sortFieldCodeValue, previousSortFieldCodeValue);
	}
	
	@SuppressWarnings("unchecked")
    public static void sortListByField(List list,String sortFieldCodeValue, String previousSortFieldCodeValue) {
		if(sortFieldCodeValue.equals(previousSortFieldCodeValue)){
			Collections.reverse(list);
		}
		else{
			Collections.sort(list, new GenericComparator(sortFieldCodeValue));
		}
	}
}
