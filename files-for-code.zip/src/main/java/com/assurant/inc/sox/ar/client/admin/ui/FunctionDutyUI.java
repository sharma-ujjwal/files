package com.assurant.inc.sox.ar.client.admin.ui;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.FunctionDuty;

public class FunctionDutyUI {
	private final FunctionDuty functionDuty;
	private boolean checked;

	public FunctionDutyUI(FunctionDuty functionDuty) {
		this.functionDuty = functionDuty;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.functionDuty.getId();
	}

	public String getDescription() {
		return this.functionDuty.getDescription();
	}

	public String getDeleteFlag() {
		return this.functionDuty.getDeleteFlag();
	}

	public String getCreatedBy() {
		return this.functionDuty.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.functionDuty.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.functionDuty.getLastChangedBy();
	}
	
	public Date getLastChangedDate() {
		return this.functionDuty.getLastChangedDate();
	}

	public Date getActiveFromDate() {
		return this.functionDuty.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.functionDuty.getActiveToDate();
	}

	public FunctionDuty getFunctionDuty() {
		return functionDuty;
	}
}
