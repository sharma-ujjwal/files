package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.RejectSodBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.utils.exceptions.TaskException;

/**
 * The service used to retrieve bundle data and perform actions on the bundle.
 */
public interface IReviewBundleService {
	/**
	 * Retrieves the bundle for the given bundle id.
	 * 
	 * @param reviewBundleSummaryId the id of the bundle to retrieve.
	 * @return the bundle that matches the given id. If no bundle is found then a null will be returned.
	 */
	public ReviewBundleDTO retrieveById(Long reviewBundleSummaryId);

	/**
	 * Retrieves the bundle with the given savvion id.
	 * 
	 * @param taskId the task id of the bundle to retrieve.
	 * @return the bundle with the given savvion id. If no bundle is found then a null will be returned.
	 */
	public ReviewBundleDTO retrieveBySavvionId(String taskId);

	/**
	 * Retrieves the bundles that are associated with the review with the given id.
	 * 
	 * @param reviewId the id of the review to find the associated bundles for.
	 * @return the bundles associated with the given review. If no bundles are found then an empty list will be returned.
	 */
	public List<ReviewBundleDTO> retrieveByReviewId(Long reviewId);

	/**
	 * Persists the review bundle.
	 * 
	 * @param reviewBundleDto the review bundle template to persist.
	 * @param filterCriteriaDtos the filter criteria objects to associate with the bundle.
	 * @return the persisted review bundle.
	 * @throws TaskException if a savvion failure occurs.
	 */
	public ReviewBundleDTO createReviewBundle(Long reviewId, List<FilterCriteriaDTO> filterCriteriaDtos) throws TaskException;

	/**
	 * Retrieves the filter criteria that is associated with the bundle with the given bundle id.
	 * 
	 * @param reviewBundleId the id of the bundle to find associated filter criteria for.
	 * @return the filter criteria associated with the bundle.
	 */
	public List<FilterCriteriaDTO> retrieveFilterCriteria(Long reviewBundleId);

	/**
	 * Marks the review bundle as being accepted.
	 * 
	 * @param reviewBundleId the id of the review bundle to accept.
	 * @throws TaskException if a savvion failure occurs.
	 */
	public void acceptBundleSummary(Long reviewBundleId) throws TaskException;

	/**
	 * Marks the review bundle as being rejected. All child data of the review bundle may be purged.
	 * 
	 * @param reviewBundleId the id of the review bundle to accept.
	 * @throws TaskException if a savvion failure occurs.
	 */
	public void rejectBundleSummary(Long reviewBundleId) throws TaskException;

	/**
	 * Retrieves the number of reports that are associated with the bundle.
	 * 
	 * @param reviewBundleIds the id of the bundle to retrieve the number of reports for.
	 * @return the count of the number of reports to find.
	 */
	public Integer retrieveNumberOfReports(List<Long> reviewBundleIds);

	/**
	 * Get the bundle name, which is a combination of Review Type and bundle create date
	 * 
	 * @param reviewBundleId
	 * @return
	 */
	public String retrieveBundleName(Long reviewBundleId);

	/**
	 * Get the review name, which is a combination of Review Type and bundle create date
	 * 
	 * @param reviewBundleId
	 * @return
	 */
	public String retrieveReviewName(Long reviewBundleId);
	
	/**
	 * Marks the review bundle as being rejected for SOD with no conflicts. 
	 * This is different from the normal reject b/c ITCompliance needs to show the
	 * auditors that there were not SOD conflicts for there criteria versus the regular
	 * reject where it is saying this bundle is not wanted or is incorrect.
	 * 
	 * @param reviewBundleId the id of the review bundle to accept.
	 * @throws TaskException if a savvion failure occurs.
	 */	
	public void rejectSODBundleSummaryWithNoConflict(Long reviewBundleId) throws TaskException;
	
	/**
	 * Retrieves the bundles that are associated with the review with the given id
	 * that have been rejected b/c there are no conflicts for the SOD review.
	 * 
	 * @param reviewId the id of the review to find the associated bundles for.
	 * @return the bundles associated with the given review. If no bundles are found then an empty list will be returned.
	 */
	public List<RejectSodBundleDTO> retrieveRejectedWithNoConflictsByReviewId(Long reviewId);	
}
