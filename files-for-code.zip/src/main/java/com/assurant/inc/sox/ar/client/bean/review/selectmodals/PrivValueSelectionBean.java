package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.PrivValueDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the priv value selection modal panel
 * 
 */
@Component("privValueSelectionBean")
@Scope("session")
public class PrivValueSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(PrivValueSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("PrivValueSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> privValues = createBundleBean.getPrivValues();
        privValues.clear();
        for (SelectAdapter item : chosen) {
            privValues.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("PrivValueSelectionBean.retrieve(...) -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (PrivValueDTO privValue : metaDataService.retrievePrivValues(searchString)) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.PRIV_VALUE);
            dto.setFilterValueName(privValue.getName());
            dto.setFilterValueKey(privValue.getId());
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        
        if (results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}        
        
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        logger.debug("PrivValueSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getPrivValues()) {
            results.add(adapter);
        }
        return results;
    }
}
