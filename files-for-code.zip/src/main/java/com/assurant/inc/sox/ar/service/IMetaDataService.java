package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.dto.ApplicationDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;
import com.assurant.inc.sox.ar.dto.CostCenterDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.EnvironmentDTO;
import com.assurant.inc.sox.ar.dto.IndividualDTO;
import com.assurant.inc.sox.ar.dto.ManagerDTO;
import com.assurant.inc.sox.ar.dto.PrivDescriptionDTO;
import com.assurant.inc.sox.ar.dto.PrivValueDTO;
import com.assurant.inc.sox.ar.dto.SourceNameDTO;
import com.assurant.inc.sox.ar.dto.SoxConcernDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.UserTypeDTO;
import com.assurant.inc.sox.domain.ar.FilterType;

/**
 * A service used to accessing meta/reference data such as the data needed for doing criteria selections.
 */
public interface IMetaDataService {

    /**
     * Retrieves the filter type by the filter value.
     * @param value the value of the filter type to lookup.
     * @return the filter type for the given filter.
     */
    public FilterType getFilterTypeByValue(String value);
    
    
    /**
     * Retrieves all of the divisions where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the divisions that match the searchString.
     */
    public List<DivisionDTO> retrieveDivisions(String searchString);

    /**
     * Retrieves all of the departments where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the department that match the searchString.
     */
    public List<DepartmentDTO> retrieveDepartments(String searchString);

    /**
     * Retrieves all of the source names where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the source names that match the searchString.
     */
    public List<SourceNameDTO> retrieveSourceNames(String searchString);

    /**
     * Retrieves all of the applications where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the applications that match the searchString.
     */
    public List<ApplicationDTO> retrieveApplications(String searchString);

    /**
     * Retrieves all of the managers where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the managers that match the searchString.
     */
    public List<ManagerDTO> retrieveManagers(String searchString);

    /**
     * Retrieves all of the sox concerns.
     * @return all of the sox concerns.
     */
    public List<SoxConcernDTO> retrieveSoxConcerns();

    /**
     * Retrieves all of the user statuses.
     * @return all the users statuses.
     */
    public List<UserStatusDTO> retrieveUserStatuses();

    /**
     * Retrieves all of the user types.
     * @return all the users types.
     */
    public List<UserTypeDTO> retrieveUserTypes();

    /**
     * Retrieves all of the environments.
     * @return all the users environments.
     */
    public List<EnvironmentDTO> retrieveEnvironments();

    /**
     * Retrieves all of the individuals where the name matches the provided searchString.
     * @param searchString the name to search for.
     * @return the individuals that match the searchString.
     */
    public List<IndividualDTO> retrieveIndividuals(String searchString);

    /**
     * Retrieves all of the priv descriptions that matches the provided searchString.
     * @param searchString the priv desc to search for.
     * @return the priv descriptions that match the searchString.
     */
    public List<PrivDescriptionDTO> retrievePrivDescriptions(String searchString);

    /**
     * Retrieves all of the priv values that matches the provided searchString.
     * @param searchString the priv value to search for.
     * @return the managers that match the searchString.
     */
    public List<PrivValueDTO> retrievePrivValues(String searchString);

    /**
     * Retrieves all of the cost centers that matches the provided searchString.
     * @param searchString the cost center to search for.
     * @return the cost centers that match the searchString.
     */
    public List<CostCenterDTO> retrieveCostCenters(String searchString);
    
    public List<ConflictTypeDTO> retrieveConflictTypes();
    
    public List<ConflictDTO> retreiveConflicts(Long conflictTypeId);
    
}
