package com.assurant.inc.sox.ar.client.ui;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;

import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;

public class ReviewDashboardUI extends ReviewUI {
	private ReviewDashboardDTO dto;

	public ReviewDashboardUI(ReviewDashboardDTO dto) {
		super(dto);
		this.dto = dto;
	}

	/**
	 * Format given float to a percentage, e.g. "92.0 %"
	 * 
	 * @param f the float to format
	 * @return the formatted String
	 */
	private String formatPercentage(float f) {
		NumberFormat nf2 = new DecimalFormat("##0.0");
		return nf2.format(f) + "%";
	}

	public String getComments() {
		return dto.getReviewComments();
	}

	public String getCreatedBy() {
		return dto.getCreatedBy();
	}

	public Date getDateReviewCompleted() {
		return dto.getReviewCompletedDate();
	}

	public Date getDateReviewCreated() {
		return dto.getCreatedDate();
	}

	public String getName() {
		return dto.getReviewName();
	}

	public int getNumberOfReports() {
		return dto.getNumberOfReports();
	}

	public int getNumberOfReportsAttested() {
		return dto.getNumberOfReportsAttested();
	}

	public int getNumberOfReportsDistributed() {
		return dto.getNumberOfReportsDistributed();
	}

	public int getNumberOfUsersAttested() {
		return dto.getNumberOfUsersAttested();
	}

	public int getNumberOfUsersIncluded() {
		return dto.getNumberOfUsersIncluded();
	}

	public String getPercentageOfReportsAttested() {
		return formatPercentage(dto.getPercentageOfReportsAttested());
	}

	public String getPercentageOfUsersAttested() {
		return formatPercentage(dto.getPercentageOfUsersAttested());
	}

	public ReviewDashboardDTO getReviewDashboardDTO() {
		return dto;
	}

	public String getStatus() {
		return dto.getReviewStatusCd().getDisplay();
	}

	public String getType() {
		return dto.getReviewTypeCd().getDisplay();
	}
	
	public int getNumberOfNonRejectedReports() {
		return dto.getNumberOfNonRejectedReports();
	}
	
	public int getNumberOfOverdueReports() {
		return dto.getNumberOfOverdueReports();
	}
	
	public String getPercentageOfOverdueReports() {
		return formatPercentage(dto.getPercentageOfOverdueReports());
	}
}
