/**
 * 
 */
package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.ar.client.admin.ui.ExceptionSummaryUI;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IDepartmentService;
import com.assurant.inc.sox.ar.service.IDivisionService;
import com.assurant.inc.sox.ar.service.IExceptionService;
import com.assurant.inc.sox.ar.service.IUserService;
import com.assurant.inc.sox.ar.service.IUserStatusService;
import com.assurant.inc.sox.ar.service.IUserTypeService;
import com.assurant.inc.sox.domain.admin.ExceptionSummary;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * @author Brian Olson
 * 
 */
@Component("exceptionSummaryBean")
@Scope("session")
public class ExceptionSummaryBean {
	//injected fields
	@Autowired
	@Qualifier("exceptionService")
	private IExceptionService exceptionService;
	@Autowired
	@Qualifier("divisionService")
	private IDivisionService divisionService;
	@Autowired
	@Qualifier("departmentService")
	private IDepartmentService departmentService;
	@Autowired
	@Qualifier("userTypeService")
	private IUserTypeService userTypeService;
	@Autowired
	@Qualifier("userStatusService")
	private IUserStatusService userStatusService;
	@Autowired
	@Qualifier("userService")
	private IUserService userService;

	private List<ExceptionSummaryUI> exceptionList;
	private List<ExceptionSummaryUI> directReportsList;
	private ExceptionSummaryUI selectedException;

	private Integer displayAmount = 10;
	private String oldSortColumn;
	private String oldDirectReportsSortColumn;
	private boolean renderEditExceptionPanel;
	private boolean renderSearchSupervisorModalPanel;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private List<User> supervisorSearchList;
	private String supervisorSearchKeyId;
	private String supervisorSearchFirstName;
	private String supervisorSearchLastName;
	
	private boolean supervisorChanged;
	
	public IExceptionService getExceptionService() {
		return exceptionService;
	}
	
	public void setExceptionService(IExceptionService exceptionService) {
		this.exceptionService = exceptionService;
	}
	
	public IDivisionService getDivisionService() {
		return divisionService;
	}

	public void setDivisionService(IDivisionService divisionService) {
		this.divisionService = divisionService;
	}

	public IDepartmentService getDepartmentService() {
		return departmentService;
	}

	public void setDepartmentService(IDepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public IUserTypeService getUserTypeService() {
		return userTypeService;
	}

	public void setUserTypeService(IUserTypeService userTypeService) {
		this.userTypeService = userTypeService;
	}

	public IUserStatusService getUserStatusService() {
		return userStatusService;
	}

	public void setUserStatusService(IUserStatusService userStatusService) {
		this.userStatusService = userStatusService;
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public synchronized List<ExceptionSummaryUI> getExceptionList() {
		if (exceptionList == null) {
			refreshList();
			CommonPageActionHelper.sortListByField(this.exceptionList, "formattedFullName", null);
			this.oldSortColumn = "formattedFullName";
		}
		
		return exceptionList;
	}
	
	public List<ExceptionSummaryUI> getDirectReportsList() {
		return directReportsList;
	}

	public ExceptionSummaryUI getSelectedException() {
		return selectedException;
	}

	public Long getSelectedDepartmentId() {
		return this.selectedException.getDepartmentId();
	}

	public void setSelectedDepartmentId(Long selectedDepartmentId) {
		this.selectedException.setDepartmentId(selectedDepartmentId);
	}

	public Long getSelectedDivisionId() {
		return this.selectedException.getDivisionId();
	}

	public void setSelectedDivisionId(Long selectedDivisionId) {
		this.selectedException.setDivisionId(selectedDivisionId);
	}

	public Long getSelectedUserTypeId() {
		return this.selectedException.getUserTypeId();
	}

	public void setSelectedUserTypeId(Long selectedUserTypeId) {
		this.selectedException.setUserTypeId(selectedUserTypeId);
	}

	public Long getSelectedUserStatusId() {
		return this.selectedException.getUserStatusId();
	}

	public void setSelectedUserStatusId(Long selectedUserStatusId) {
		this.selectedException.setUserStatusId(selectedUserStatusId);
	}

	public List<User> getSupervisorSearchList() {
		return supervisorSearchList;
	}

	public void setSupervisorSearchList(List<User> supervisorSearchList) {
		this.supervisorSearchList = supervisorSearchList;
	}

	public String getSupervisorSearchKeyId() {
		return supervisorSearchKeyId;
	}

	public void setSupervisorSearchKeyId(String supervisorSearchKeyId) {
		this.supervisorSearchKeyId = supervisorSearchKeyId;
	}

	public String getSupervisorSearchFirstName() {
		return supervisorSearchFirstName;
	}

	public void setSupervisorSearchFirstName(String supervisorSearchFirstName) {
		this.supervisorSearchFirstName = supervisorSearchFirstName;
	}

	public String getSupervisorSearchLastName() {
		return supervisorSearchLastName;
	}

	public void setSupervisorSearchLastName(String supervisorSearchLastName) {
		this.supervisorSearchLastName = supervisorSearchLastName;
	}

	public boolean isSupervisorChanged() {
		return supervisorChanged;
	}

	public void setSupervisorChanged(boolean supervisorChanged) {
		this.supervisorChanged = supervisorChanged;
	}

	public String getEmail() {
		return this.selectedException.getEmail();
	}
	
	public void setEmail(String email) {
		this.selectedException.setEmail(email);
	}
	
	public Long getSelectedSupervisorId() {
		return this.selectedException.getSupervisorId();
	}

	public void setSelectedSupervisorId(Long selectedSupervisorId) {
		this.selectedException.setSupervisorId(selectedSupervisorId);
	}

	public Integer getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getOldSortColumn() {
		return oldSortColumn;
	}

	public void setOldSortColumn(String oldSortColumn) {
		this.oldSortColumn = oldSortColumn;
	}

	public boolean isRenderEditExceptionPanel() {
		return renderEditExceptionPanel;
	}
	
	public void setRenderEditExceptionPanel(boolean renderEditExceptionPanel) {
		this.renderEditExceptionPanel = renderEditExceptionPanel;
	}
	
	public boolean isRenderSearchSupervisorModalPanel() {
		return renderSearchSupervisorModalPanel;
	}

	public void setRenderSearchSupervisorModalPanel(
			boolean renderSearchSupervisorModalPanel) {
		this.renderSearchSupervisorModalPanel = renderSearchSupervisorModalPanel;
	}

	public void refreshList() {
		this.exceptionList = new ArrayList<ExceptionSummaryUI>();
		
		List<ExceptionSummary> exceptionSummaryList = new ArrayList<ExceptionSummary>();
		if (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.ACTIVE_ROWS) {
			exceptionSummaryList = this.exceptionService.retrieveActiveExceptions();
		} else if (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.INACTIVE_ROWS) {
			exceptionSummaryList = this.exceptionService.retrieveInactiveExceptions();
		}
		
		for (ExceptionSummary exceptionSummary : exceptionSummaryList) {
			this.exceptionList.add(new ExceptionSummaryUI(exceptionSummary));
		}
	}

	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "formattedFullName";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(this.exceptionList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}
	
	public void doSortDirectReports() {
		final String column = (JSFUtils.getParameter("directReportColumn") == null ? "formattedFullName"
				: JSFUtils.getParameter("directReportColumn"));
		CommonPageActionHelper.sortListByField(this.directReportsList, column,
				this.oldDirectReportsSortColumn);
		this.oldDirectReportsSortColumn = column;
	}

	public String showExceptionEditPanel() {
		this.supervisorChanged = false;
		cancelEditException();
		
		Long userId = Long.valueOf(JSFUtils.getParameter("editId"));
		ExceptionSummary selectedExceptionSummary = this.exceptionService.getExceptionSummaryByUserId(userId);
		this.selectedException = new ExceptionSummaryUI(selectedExceptionSummary); 
		
		if (!Long.valueOf(-1).equals(this.selectedException.getSupervisorId())) {
			populateDirectReports();
		}
		
		this.renderEditExceptionPanel = true;
		return null;
	}

	public String cancelEditException() {
		this.renderEditExceptionPanel = false;
		this.supervisorChanged = false;
		this.directReportsList = null;
		this.selectedException = null;
		return null;
	}

	public List<SelectItem> getDepartmentNameCostCenterSelectItems() {
		List<Department> departments = this.departmentService.retrieveAllDepartments();
		Collections.sort(departments, new Comparator<Department>() {
			public int compare(Department d1, Department d2) {
				if (d1.getDepartmentNmCostCenter() == null) {
					return -1;
				}
				return d1.getDepartmentNmCostCenter().compareTo(d2.getDepartmentNmCostCenter());
			}
		});

		List<SelectItem> items = new ArrayList<SelectItem>(departments.size() + 1);
		
		items.add(new SelectItem("", ""));
		for (Department department : departments) {
			StringBuilder departmentNameCostCenter = new StringBuilder(department.getName());
			if (department.getCostCenter() != null) {
				departmentNameCostCenter.append("-").append(department.getCostCenter());
			}
			items.add(new SelectItem(department.getId(), departmentNameCostCenter.toString()));
		}
		
		return items;
	}
	
	public List<SelectItem> getDivisionSelectItems() {
		List<Division> divisions = this.divisionService.retrieveAllDivisions();
		Collections.sort(divisions, new Comparator<Division>() {
			public int compare(Division d1, Division d2) {
				if (d1.getName() == null) {
					return -1;
				}
				return d1.getName().compareTo(d2.getName());
			}
		});

		List<SelectItem> items = new ArrayList<SelectItem>(divisions.size() + 1);
		
		items.add(new SelectItem("", ""));
		for (Division division : divisions) {
			items.add(new SelectItem(division.getId(), division.getName()));
		}
		
		return items;
	}

	public List<SelectItem> getUserTypeSelectItems() {
		List<UserType> userTypes = this.userTypeService.retrieveAllUserTypes();
		Collections.sort(userTypes, new Comparator<UserType>() {
			public int compare(UserType userType1, UserType userType2) {
				if (userType1.getUserTypeDescription() == null) {
					return -1;
				}
				return userType1.getUserTypeDescription().compareTo(userType2.getUserTypeDescription());
			}
		});
		
		List<SelectItem> items = new ArrayList<SelectItem>(userTypes.size() + 1);
		
		items.add(new SelectItem("", ""));
		for (UserType userType : userTypes) {
			items.add(new SelectItem(userType.getId(), userType.getUserTypeDescription()));
		}
		
		return items;
	}
	
	public List<SelectItem> getUserStatusSelectItems() {
		List<UserStatus> userStatuses = this.userStatusService.retrieveAllUserStatuss();
		Collections.sort(userStatuses, new Comparator<UserStatus>() {
			public int compare(UserStatus userStatus1, UserStatus userStatus2) {
				if (userStatus1.getUserStatusDescription() == null) {
					return -1;
				}
				return userStatus1.getUserStatusDescription().compareTo(userStatus2.getUserStatusDescription());
			}
		});
		
		List<SelectItem> items = new ArrayList<SelectItem>(userStatuses.size() + 1);
		
		items.add(new SelectItem("", ""));
		for (UserStatus userStatus : userStatuses) {
			items.add(new SelectItem(userStatus.getId(), userStatus.getUserStatusDescription()));
		}
		
		return items;
	}

	public void clearMessages() {
		FacesContext context = FacesContext.getCurrentInstance();
		if (context != null && context.getMessages().hasNext()) {
			context.getMessages().remove();
		}
	}
	
	public String saveException() {
		this.exceptionService.updateUser(this.selectedException);
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_INFO,
						"",
						"Exception updates saved successfully."));

		refreshList();
		doSort();
		
		this.selectedException = null;
		this.renderEditExceptionPanel = false;
		
		return null;
	}
	
	public void init() {
		this.exceptionList = null;
		this.selectedException = null;
		this.directReportsList = null;
		this.supervisorSearchList = null;
		clearSupervisorSearch();
		this.renderEditExceptionPanel = false;
		this.renderSearchSupervisorModalPanel = false;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = 10;
	}
	
	public void selectDivisionByDirectReport() {
		Long divisionId = Long.valueOf(JSFUtils.getParameter("directReportDivisionId"));
		this.selectedException.setDivisionId(divisionId);
	}

	public void selectDepartmentByDirectReport() {
		Long departmentId = Long.valueOf(JSFUtils.getParameter("directReportDepartmentId"));
		this.selectedException.setDepartmentId(departmentId);
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<>(2);
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.INACTIVE_ROWS
				.name(), FilterTableCode.INACTIVE_ROWS.filterName()));
		
		return availableFilters;
	}
	
	public String switchFilter() {
		refreshList();
		
		this.oldSortColumn = null;
		doSort();
		
		return null;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public void doShowSearchSupervisorPanel() {
		this.supervisorSearchList = new ArrayList<>();
		clearSupervisorSearch();
		this.renderSearchSupervisorModalPanel = true;
	}
	
	public String doCancelSearchSupervisor() {
		clearSupervisorSearch();
		this.renderSearchSupervisorModalPanel = false;
		return null;
	}

	private void clearSupervisorSearch() {
		this.supervisorSearchKeyId = null;
		this.supervisorSearchFirstName = null;
		this.supervisorSearchLastName = null;
	}
	
	public void doSupervisorSort() {
		final String column = (JSFUtils.getParameter("supervisorColumn") == null ? "lastName"
				: JSFUtils.getParameter("supervisorColumn"));
		CommonPageActionHelper.sortListByField(supervisorSearchList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
	}
	
	public String doSupervisorSearch() {
		String keyId = null;
		String firstName = null;
		String lastName = null;
		
		if (StringUtils.isNotBlank(this.supervisorSearchKeyId)) {
			keyId = this.supervisorSearchKeyId.trim();
		}

		if (StringUtils.isNotBlank(this.supervisorSearchFirstName)) {
			firstName = this.supervisorSearchFirstName.trim();
		}

		if (StringUtils.isNotBlank(this.supervisorSearchLastName)) {
			lastName = this.supervisorSearchLastName.trim();
		}
		
		this.supervisorSearchList = this.userService.findPotentialSupervisors(keyId, 
				firstName, lastName);
		
		doSupervisorSort();
		
		return null;
	}
	
	public String resetSupervisorSearch() {
		clearSupervisorSearch();
		return null;
	}

	public String doAssignSelectedSupervisor() {
		Long supervisorId = Long.valueOf(JSFUtils.getParameter("selectedSupervisorId"));
		this.selectedException.setSupervisorId(supervisorId);

		User supervisor = this.userService.findById(supervisorId);
		
		StringBuilder supervisorName = new StringBuilder();
		if (StringUtils.isNotEmpty(supervisor.getLastName())) {
			supervisorName.append(supervisor.getLastName());
			
			if (StringUtils.isNotEmpty(supervisor.getFirstName())) {
				supervisorName.append(", ");
			}
		}
		
		if (StringUtils.isNotEmpty(supervisor.getFirstName())) {
			supervisorName.append(supervisor.getFirstName());
			
			if (StringUtils.isNotEmpty(supervisor.getMiddleName())) {
				supervisorName.append(" ").append(supervisor.getMiddleName().substring(0, 1));
			}
		}
		
		this.selectedException.setSupervisorName(supervisorName.toString());

		this.renderSearchSupervisorModalPanel = false;
		this.supervisorChanged = true;
		
		populateDirectReports();
		
		return null;
	}

	private void populateDirectReports() {
		this.directReportsList = new ArrayList<ExceptionSummaryUI>();
		
		List<ExceptionSummary> directReportSummaryList = 
			this.exceptionService.retrieveDirectReportsBySupervisorId(
					this.selectedException.getUserId(), 
					this.selectedException.getSupervisorId()); 
		
		for (ExceptionSummary directReportSummary : directReportSummaryList) {
			this.directReportsList.add(new ExceptionSummaryUI(directReportSummary)); 
		}
		
		this.doSortDirectReports();
	}
}
