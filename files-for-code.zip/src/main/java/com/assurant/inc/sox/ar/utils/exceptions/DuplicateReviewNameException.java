package com.assurant.inc.sox.ar.utils.exceptions;

public class DuplicateReviewNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String errorMessage = null;
	
	public DuplicateReviewNameException(String errorMessage){
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
