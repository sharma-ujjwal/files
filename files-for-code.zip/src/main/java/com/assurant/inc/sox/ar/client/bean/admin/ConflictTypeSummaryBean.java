	package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import org.primefaces.component.datascroller.DataScroller;

import com.assurant.inc.sox.ar.client.admin.ui.ConflictTypeUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IConflictTypeService;
import com.assurant.inc.sox.domain.ar.ConflictType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("conflictTypeSummaryBean")
@Scope("session")
public class ConflictTypeSummaryBean {
	// injected resources
	@Autowired
	@Qualifier("conflictTypeService")
	private IConflictTypeService conflictTypeService;
	private SessionDataBean sessionDataBean;
	
	private List<ConflictTypeUI> conflictTypeList;
	private String displayAmount = "10";
	private String oldSortColumn;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String conflictTypeNameSearchText;
	private DataScroller dataScroller;
	
	public List<ConflictTypeUI> getConflictTypeList() {
		if (conflictTypeList == null) {
			refreshList();
		}
		return conflictTypeList;
	}
	
	public void refreshList() {
		this.conflictTypeList = new ArrayList<ConflictTypeUI>();
		List<ConflictType> conflictTypesRetrieved = new ArrayList<ConflictType>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.conflictTypeNameSearchText)) {
				conflictTypesRetrieved = this.conflictTypeService.retrieveAllConflictTypesByName(this.conflictTypeNameSearchText);
			} else {
				conflictTypesRetrieved = this.conflictTypeService.retrieveAllConflictTypes();
			}
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.conflictTypeNameSearchText)) {
				conflictTypesRetrieved = this.conflictTypeService.retrieveDeletedConflictTypesByName(this.conflictTypeNameSearchText);
			} else {
				conflictTypesRetrieved = this.conflictTypeService.retrieveDeletedConflictTypes();
			}

		}
		
		for (ConflictType conflictType : conflictTypesRetrieved) {
			this.conflictTypeList.add(new ConflictTypeUI(conflictType));
		}
		this.doSort();
	}

	// ******* GO button *******	
	public String goSearch() {
		refreshList();
		return "";
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		this.conflictTypeList = null;
		this.conflictTypeNameSearchText = null;
		this.oldSortColumn = null;
		
		refreshList();
		return "";
	}
	
	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		return "";
	}

	// *******  List Headers *******	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "conflictTypeText";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(conflictTypeList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}
	
	public boolean validConflictTypeName() {
		return (StringUtils.isNotEmpty(conflictTypeNameSearchText));
	}
	
	public void setConflictTypeTextSearchText(String conflictTypeText) {
		this.conflictTypeNameSearchText = conflictTypeText;
	}
	
	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getConflictTypeNameSearchText() {
		return conflictTypeNameSearchText;
	}

	public void setConflictTypeNameSearchText(String conflictTypeNameSearchText) {
		this.conflictTypeNameSearchText = conflictTypeNameSearchText;
	}

	public void setConflictTypeList(List<ConflictTypeUI> conflictTypeList) {
		this.conflictTypeList = conflictTypeList;
	}

	public IConflictTypeService getConflictTypeService() {
		return conflictTypeService;
	}

	public void setConflictTypeService(IConflictTypeService conflictTypeService) {
		this.conflictTypeService = conflictTypeService;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.conflictTypeList = null;
		this.conflictTypeNameSearchText = null;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}
