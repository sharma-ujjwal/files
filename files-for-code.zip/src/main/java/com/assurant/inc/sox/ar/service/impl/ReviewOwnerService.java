/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.service.IReviewOwnerService;
import com.assurant.inc.sox.dao.ar.IReviewOwnerDao;
import com.assurant.inc.sox.domain.ar.ReviewOwner;

/**
 * @author RuthSchmalz
 */
@Service
public class ReviewOwnerService implements IReviewOwnerService {

	@Autowired
	private IReviewOwnerDao reviewOwnerDao;

	public List<ReviewOwner> findActiveSodOwners() {
		return this.reviewOwnerDao.findActiveSodOwners();
		
	}
	
}
