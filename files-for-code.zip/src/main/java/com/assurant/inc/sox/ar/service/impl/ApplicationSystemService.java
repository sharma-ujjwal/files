/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IApplicationSystemService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IApplicationSystemDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ApplicationSystem;
import com.assurant.inc.sox.domain.ar.Environment;

/**
 * @author RuthSchmalz
 * 
 */
@Service
// spring
public class ApplicationSystemService implements IApplicationSystemService {

	@Autowired
	// for spring
	private IApplicationSystemDao applicationSystemDao;
	@Autowired
	private SystemUserDTO systemUser;

	//****************        Constructor   ***********
	public ApplicationSystemService() {
	}
	
	
	//****************  Add New Application System  083 ***********		
	public void addNewApplicationSystem(Environment environment, Application application, Date currentDate) {
		//Create a Environment record.
		ApplicationSystem applicationSystem = new ApplicationSystem();
		
		applicationSystem.setApplication(application); 
		applicationSystem.setEnvironment(environment); 
		applicationSystem.setName(application.getName() + " - " + environment.getName());
		applicationSystem.setDeleteFlag(IFlags.NOT_DELETED);
		applicationSystem.setCreatedBy(this.systemUser.getUserId());
		applicationSystem.setCreatedDate(currentDate);

		applicationSystem.setActiveFromDate(currentDate);
		applicationSystem.setActiveToDate(DateUtil.END_OF_TIME);
		this.applicationSystemDao.save(applicationSystem);
	}
	

	//**                 DELETE      ByEnvironmentId             ******
	public void deleteAllApplicationSystemByEnvironmentId(Environment environment, Date currentDate){
		//Get a list of all 83ApplctnSystem records by EnvironmentID 
		List<ApplicationSystem> applicationSystemList = 
			this.applicationSystemDao.retrieveAllApplicationSystemsByEnvrn(environment);

		//Delete Application Systems attached to the Environment. 
		for (ApplicationSystem applicationSystem   : applicationSystemList) {

			//Create an audit trail record using the Existing record.
			//This will generate a new ID and a new record will be added. 
			//(Delete Flag = N)
			ApplicationSystem currentApplicationSystem = new ApplicationSystem();
			
			currentApplicationSystem.setApplication(applicationSystem.getApplication()); 
			currentApplicationSystem.setEnvironment(applicationSystem.getEnvironment()); 
			currentApplicationSystem.setName(applicationSystem.getName());
			currentApplicationSystem.setDeleteFlag(IFlags.NOT_DELETED);
			currentApplicationSystem.setCreatedBy(applicationSystem.getCreatedBy());
			currentApplicationSystem.setCreatedDate(applicationSystem.getCreatedDate());
			currentApplicationSystem.setLastChangedBy(this.systemUser.getUserId());
			currentApplicationSystem.setLastChangedDate(currentDate);
			
			currentApplicationSystem.setActiveFromDate(applicationSystem.getActiveFromDate());
		 	currentApplicationSystem.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		 	this.applicationSystemDao.save(currentApplicationSystem);
	
			
			//Create a Deleted Environment record using the Existing record.
			//Using the existing ID, update the record. 
			//(Delete Flag = Y)
			applicationSystem.setDeleteFlag(IFlags.DELETED);
			applicationSystem.setActiveFromDate(currentDate);
			applicationSystem.setActiveToDate(currentDate);
			this.applicationSystemDao.save(applicationSystem);
		}
	} //end of deleteAllApplicationSystemByEnvironmentId

	
	
	//**                 DELETE      ByApplicationId             ******
	public void deleteAllApplicationSystemByApplicationId(Application application, Date currentDate){
		//Get a list of all 83ApplctnSystem records by EnvironmentID 
		List<ApplicationSystem> applicationSystemList = 
			this.applicationSystemDao.retrieveAllApplicationSystemsByApplication(application);

		//Delete Application Systems attached to the Application. 
		for (ApplicationSystem applicationSystem   : applicationSystemList) {

			//Create an audit trail record using the Existing record.
			//This will generate a new ID and a new record will be added. 
			//(Delete Flag = N)
			ApplicationSystem currentApplicationSystem = new ApplicationSystem();
			
			currentApplicationSystem.setApplication(applicationSystem.getApplication()); 
			currentApplicationSystem.setEnvironment(applicationSystem.getEnvironment()); 
			currentApplicationSystem.setName(applicationSystem.getName());
			currentApplicationSystem.setDeleteFlag(IFlags.NOT_DELETED);
			currentApplicationSystem.setCreatedBy(applicationSystem.getCreatedBy());
			currentApplicationSystem.setCreatedDate(applicationSystem.getCreatedDate());
			currentApplicationSystem.setLastChangedBy(this.systemUser.getUserId());
			currentApplicationSystem.setLastChangedDate(currentDate);
			
			currentApplicationSystem.setActiveFromDate(applicationSystem.getActiveFromDate());
		 	currentApplicationSystem.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		 	this.applicationSystemDao.save(currentApplicationSystem);
	
			
			//Create a Deleted Environment record using the Existing record.
			//Using the existing ID, update the record. 
			//(Delete Flag = Y)
			applicationSystem.setDeleteFlag(IFlags.DELETED);
			applicationSystem.setActiveFromDate(currentDate);
			applicationSystem.setActiveToDate(currentDate);
			this.applicationSystemDao.save(applicationSystem);
		}
	} //end of deleteAllApplicationSystemByApplicationId

	
	
}  //end of ApplicationSystemService.java
