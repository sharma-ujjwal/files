package com.assurant.inc.sox.ar.dto;

import java.util.Date;

public class UserDataDTO {
    private long userId;
    private String name;
    private UserStatusDTO status;
    private DepartmentDTO department;
    private String emailAddress;
    private Date reassignedTargetCompleteDate;
    private String reassignedInstructions;
    private Long supervisorId;
    private DivisionDTO division;
	private String ownerTypeDescription;
    
    /**
     * @return the department
     */
    public DepartmentDTO getDepartment() {
        return this.department;
    }

    /**
     * @param department
     *            the department to set
     */
    public void setDepartment(DepartmentDTO department) {
        this.department = department;
    }

    /**
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return this.emailAddress;
    }

    /**
     * @param emailAddress
     *            the emailAddress to set
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the status
     */
    public UserStatusDTO getStatus() {
        return this.status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(UserStatusDTO status) {
        this.status = status;
    }

    /**
     * @return the userId
     */
    public long getUserId() {
        return this.userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(long userId) {
        this.userId = userId;
    }

	public Date getReassignedTargetCompleteDate() {
		return reassignedTargetCompleteDate;
	}

	public void setReassignedTargetCompleteDate(Date reassignedTargetCompleteDate) {
		this.reassignedTargetCompleteDate = reassignedTargetCompleteDate;
	}

	public String getReassignedInstructions() {
		return reassignedInstructions;
	}

	public void setReassignedInstructions(String reassignedInstructions) {
		this.reassignedInstructions = reassignedInstructions;
	}

	public Long getSupervisorId() {
		return supervisorId;
	}

	public void setSupervisorId(Long supervisorId) {
		this.supervisorId = supervisorId;
	}

	public DivisionDTO getDivisionDTO() {
		return division;
	}

	public void setDivisionDTO(DivisionDTO division) {
		this.division = division;
	}

	public String getOwnerTypeDescription() {
		return ownerTypeDescription;
	}

	public void setOwnerTypeDescription(String ownerTypeDescription) {
		this.ownerTypeDescription = ownerTypeDescription;
	}

}
