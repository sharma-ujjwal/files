package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.ExtractSystem;

public interface IExtractSystemService {
	
	public List<ExtractSystem> findAll();
}
