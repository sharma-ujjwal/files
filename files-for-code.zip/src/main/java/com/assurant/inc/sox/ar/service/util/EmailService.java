package com.assurant.inc.sox.ar.service.util;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.consts.ITaskValues;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.jsf.FacesContextUtils;
import javax.annotation.Resource;
import javax.faces.context.FacesContext;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.HashMap;
import java.util.Properties;

@Component
public class EmailService {
	
	@Resource(name = "soxSuportNames")
	@Autowired
	public static String soxSuportNames;
    
	public SessionDataBean sessionDataBean;
	
    public static String getSoxSuportNames() {
    	String names = 	(String) FacesContextUtils
		.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean("soxSuportNames");

		return names;
	}

	/*
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
	
		
	public static void sendEmail(HashMap<String, Object> dataSlots) {
		logger.debug("sendEmail()");

		// Get system properties
		Properties properties = System.getProperties();

		// Setup mail server
		properties.setProperty("mail.smtp.host", "smtp.ca.sunlife");

		// Get the default Session object.
		Session session = Session.getInstance(properties, null);
		session.setDebug(false);


		/*
		 * create a message
		 */
		MimeMessage  message = new MimeMessage(session);

		// Set From: header field of the header.
		try {
			message.setFrom(new InternetAddress(dataSlots.get(
					ITaskValues.DATASLOTS_EMAIL_FROM).toString()));
		

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					dataSlots.get(ITaskValues.DATASLOTS_EMAIL_TO).toString()));
			
			
			// Adding SoxITCompliance@assurant.com to CC, As I could not find how it is getting added in Savion workflow. 
			message.addRecipient(Message.RecipientType.CC, new InternetAddress(
					dataSlots.get(ITaskValues.DATASLOTS_EMAIL_FROM).toString()));
			
			logger.debug("Send email to " +dataSlots.get(ITaskValues.DATASLOTS_EMAIL_TO).toString());
	
			// Set Subject: header field
			message.setSubject(dataSlots.get(ITaskValues.DATASLOTS_EMAIL_SUBJECT)
					.toString());
	
			
			// Now set the actual message
			
			
			message.setContent(populateEmailBody(dataSlots), "text/html");
	
			/*
			 * Send message
			 */
			Transport.send(message);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.debug("sendEmail() end");
		
	}
	
	private static String populateEmailBody(HashMap<String, Object> dataSlots){
		
		String finalEmail = "";
		
		
        finalEmail = finalEmail.concat("<br><br> Reviewer:&nbsp;");
        
        finalEmail = finalEmail.concat(dataSlots.get(ITaskValues.DATASLOTS_REVIEWER_NAME).toString());
        
        finalEmail = finalEmail.concat("<br><br> Review Due Date:&nbsp;");
        
        finalEmail = finalEmail.concat(dataSlots.get(ITaskValues.DATASLOTS_TARGET_DUE_DATE).toString());
        
        finalEmail = finalEmail.concat("<br><br> Review Location:&nbsp;");
        
        finalEmail = finalEmail.concat(dataSlots.get(ITaskValues.DATASLOTS_URL).toString());
        
        finalEmail = finalEmail.concat("<br><br>");
        finalEmail = finalEmail.concat(dataSlots.get(ITaskValues.DATASLOTS_INSTRUCTIONS).toString());
        
        finalEmail = finalEmail.concat("<br><br><br><br>");
        
        finalEmail = finalEmail.concat("***This is an automated email. Please do not respond directly to this email. If you have any questions or concerns, please contact "+getSoxSuportNames()+". ***");
        
       		
		return  finalEmail;
	}

}
