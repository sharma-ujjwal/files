package com.assurant.inc.sox.ar.dto.tasklist;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.Reviewer;

public class RejectedUserTasklistDTO extends AbstractTaskListDTO {

	private Long rejectedReviewUserId;
	private final ReviewerDTO reviewer;
	private final ReviewBundleDTO reviewBundle;

	public RejectedUserTasklistDTO(ReviewDTO review, ReviewBundleDTO reviewBundle, ReviewerDTO reviewer) {
		super((review != null) ? review : new ReviewDTO(new Review(), new CodeDTO(new Code()), new CodeDTO(new Code()))); // Safe ReviewDTO
		this.reviewBundle = (reviewBundle != null) ? reviewBundle : new ReviewBundleDTO(new ReviewBundle(), new CodeDTO(new Code())); // Safe default
		this.reviewer = (reviewer != null) ? reviewer : new ReviewerDTO(new Reviewer(), new CodeDTO(new Code()), new CodeDTO(new Code()), ""); // Safe default
		this.rejectedReviewUserId = 0L; // Default ID
	}

	@Override
	public String getStatus() {
		return "Incomplete";
	}

	public Long getRejectedReviewUserId() {
		return rejectedReviewUserId;
	}

	public void setRejectedReviewUserId(Long rejectedReviewUserId) {
		this.rejectedReviewUserId = rejectedReviewUserId;
	}

	public ReviewBundleDTO getReviewBundle() {
		return reviewBundle;
	}

	public ReviewerDTO getReviewer() {
  	return reviewer;
  }

}
