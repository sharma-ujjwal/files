package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.CostCenterDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the cost center selection modal panel
 * 
 */
@Component("costCenterSelectionBean")
@Scope("session")
public class CostCenterSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(CostCenterSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("CostCenterSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> costCenters = createBundleBean.getCostCenters();
        costCenters.clear();
        for (SelectAdapter item : chosen) {
            costCenters.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("CostCenterSelectionBean.retrieve(...) -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (CostCenterDTO cc : metaDataService.retrieveCostCenters(searchString)) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.COST_CENTER);
            dto.setFilterValueName(cc.getName());
            dto.setFilterValueKey(String.valueOf(cc.getId()));
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        
        if ( results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}        
        
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        logger.debug("CostCenterSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getCostCenters()) {
            results.add(adapter);
        }
        return results;
    }
}
