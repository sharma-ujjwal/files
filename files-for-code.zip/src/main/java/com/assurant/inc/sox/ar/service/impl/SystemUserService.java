package com.assurant.inc.sox.ar.service.impl;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.base.SystemUserServiceBase;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * Service to look up the roles permissions, to determine what accesses a give user has
 * based on there roles.  Loads the permissions into the session system user.
 * 
 * @author BB68602
 *
 */
@Service
public class SystemUserService extends SystemUserServiceBase{

	public SystemUserDTO getSystemUserAccesses(List<String> ldapRoles){
		System.out.println("in System user DTO1");
		getLogger().debug("getSystemUserAccesses(ldapRoles) --> being executed.");
		getLogger().debug("User Roles = " + ldapRoles);
		System.out.println("in System user DTO2" + ldapRoles );
		if(ldapRoles == null || ldapRoles.isEmpty()){
			getLogger().error("ldapRoles list is empty");
			return getSessionSystemUser();
			
		}
		try {
			getSessionSystemUser().setFunctionAccessCodes(getSecurityFunctionAccessDao().listFunctionCodeByRoles(ldapRoles));
			
			return getSessionSystemUser();
			
		} catch (Exception e) {
			getLogger().error("Get Function Access Codes thru an error: ", e);
			return getSessionSystemUser();
		}	
	}
}


