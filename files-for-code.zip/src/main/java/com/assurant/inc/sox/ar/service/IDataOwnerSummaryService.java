package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.admin.DataOwnerSummary;
import com.assurant.inc.sox.domain.searchable.DataOwnerSummarySearchCriteria;

public interface IDataOwnerSummaryService {

	public List<DataOwnerSummary> retrieveDataOwnerSummariesByCriteria(
			
			DataOwnerSummarySearchCriteria criteria);

}