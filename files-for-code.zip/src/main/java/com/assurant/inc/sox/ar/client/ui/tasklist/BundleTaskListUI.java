package com.assurant.inc.sox.ar.client.ui.tasklist;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewBundleStatusCode;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.BundleTaskListDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BundleTaskListUI extends AbstractTaskListUI {

	public BundleTaskListUI() {
		super(); // Calls the no-args constructor of AbstractTaskListUI
	}

	@Override
	protected AbstractTaskListDTO createDefaultTaskListDTO() {
		return new BundleTaskListDTO(null, null);
	}

	@Autowired
	public BundleTaskListUI(BundleTaskListDTO taskList) {
		super(taskList);
	}

	public CodeDTO getBundleStatus() {
		return ((BundleTaskListDTO) this.taskList).getBundleStatus();
	}

	@Override
	public boolean isClickable() {
		String codeValue = this.getBundleStatus().getValue();
		return !(ReviewBundleStatusCode.SUBMITTED.getCode().equalsIgnoreCase(codeValue) ||
				ReviewBundleStatusCode.IN_PROCESS.getCode().equalsIgnoreCase(codeValue));
	}

	@Override
	public Long getBackingEntiyId() {
		return ((BundleTaskListDTO) this.taskList).getReviewBundle().getReviewBundleId();
	}

	@Override
	public String getBackingEntityName() {
		return "Bundle Id";
	}
}