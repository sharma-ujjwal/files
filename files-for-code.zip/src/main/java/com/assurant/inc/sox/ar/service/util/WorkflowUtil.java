package com.assurant.inc.sox.ar.service.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.faces.context.FacesContext;

import org.primefaces.shaded.json.JSONArray;
import org.primefaces.shaded.json.JSONException;
import org.primefaces.shaded.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.jsf.FacesContextUtils;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.dto.TaskDTO;

@Component
public class WorkflowUtil {
	@Resource(name = "baseURL")
	@Autowired
	protected static String baseURL;
    
	public SessionDataBean sessionDataBean;
	
    public static String getBaseURL() {
    	String baseURL = 	(String) FacesContextUtils
		.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean("baseURL");

		return baseURL;
	}

     public static String getLoggedInUser(){
    	 SessionDataBean sessionDataBean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
    	 return sessionDataBean.getLoggedInUserId();
     }
	
	protected static final Logger logger = LoggerFactory.getLogger(WorkflowUtil.class);
    
    public static final Logger getLogger() {
    	
        return logger;
    }
	
	//TODO: Move this to an environment based switch
	//private static final String baseURL = "https://d8.assurantemployeebenefits.com/WAMService/rs/workflow";
	//private static final String baseURL = "http://localhost:8089/WAMService/rs/workflow";
	
	//public static final String username = "rz7830";// rz7830 TB42140
	
	public static final String createInstance(WorkflowTemplateCode workflowCode, Map<String, Object> variables) {
		String url = new StringBuffer().append("/").append(workflowCode.getWorkflowId()).append("/newInstance").toString();

		String workflowId = createRequest(url, HttpMethod.POST, variables);
		workflowId = workflowId.replace("\"", "");
		getLogger().debug("workflowId: " + workflowId);
		return workflowId;
	}
	
	public static final String createInstances(WorkflowTemplateCode workflowCode, List<Map<String, Object>> variables) {
		String url = new StringBuffer().append("/").append(workflowCode.getWorkflowId()).append("/newInstance").toString();

		String workflowId = createRequest(url, HttpMethod.POST, variables);
		workflowId = workflowId.replace("\"", "");
		getLogger().debug("workflowId: " + workflowId);
		return workflowId;
	}
	
	/**
	 * Since sometimes the item isn't a properly formatted JSONObject and is a JSONArray we return the String value,
	 * this allows us to handle it if it's a JSONArray or JSONObject or if the return type changes all together to 
	 * something like xml, or new common type N.
	 * @param urlExt
	 * @param method
	 * @return Typically JSON in String format
	 */
	public static final String createRequest(String urlExt, HttpMethod method){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info("Logged in User " +getLoggedInUser());
		headers.add("username", getLoggedInUser());
	
		headers.add("status", "New");
		logger.info(" WAM Url " +getBaseURL());
		
	
		
		String url = new StringBuffer().append(getBaseURL()).append(urlExt).toString();
		ResponseEntity<String> response = restTemplate.exchange(url, method, new HttpEntity<byte[]>(headers), String.class);
		return response.getBody();
	}
	
	public static final String createRequest(String urlExt, HttpMethod method, Map<String, Object> variables){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("username", getLoggedInUser());
		
		
		HttpEntity<Map<String, Object>> request = new HttpEntity<Map<String, Object>>(variables, headers);
		String url = new StringBuffer().append(getBaseURL()).append(urlExt).toString();
		try{
		 ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
		 return response.getBody();
		}catch (Exception e){
		  return " test";
		}
		
	}
	
	public static final String createRequest(String urlExt, HttpMethod method, List<Map<String, Object>> variables){
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("username", getLoggedInUser());
		
		
		HttpEntity<List<Map<String, Object>>> request = new HttpEntity<List<Map<String, Object>>>(variables, headers);
		String url = new StringBuffer().append(getBaseURL()).append(urlExt).toString();
		
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
		return response.getBody();
	}
	
	public static final String createPostRequest(String urlExt, Map<String, Object> variables) {
		RestTemplate template = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("username", getLoggedInUser());
		

		StringBuffer url = new StringBuffer().append(getBaseURL()).append(urlExt);
		final HttpEntity<String> wineRequest = new HttpEntity<String>(headers);
		
		JSONObject object = new JSONObject(variables);
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("caseId", object);
		String workflowId = "";
		try{
			workflowId = template.postForObject(url.toString(), wineRequest, String.class, variables);
		}catch(Exception e){
			getLogger().error(e.getMessage());
		}
//		getLogger().error("template: " + template.p);
		workflowId = workflowId.replace("\"", "");
		getLogger().debug("workflowId: " + workflowId);
		return workflowId;
	}
	
	/**
	 * TODO: Heavily commented out at the moment till we see the actual results of what is stored in the tables. 
	 * @param array
	 * @return List of TaskDTO objects, these objects are the transformation of the returned JSON to the Objects.
	 * @throws JSONException
	 */
	public static final List<TaskDTO> createDTOs(JSONArray array) throws JSONException {
		List<TaskDTO> results = new ArrayList<TaskDTO>();
		for (int i = 0; i < array.length(); i++) {
			JSONObject json = array.getJSONObject(i);
			getLogger().debug("JSON: " + json);
			TaskDTO dto = new TaskDTO();
//			dto.setAssignedTo(json.getString("assignedTo"));
			dto.setProcessId(((JSONObject) json.get("workflowInstanceId")).getString("id"));
//			dto.setTaskCode(TaskTypeCode.valueOf(json.getString("taskCode")));
//			dto.setTaskCreatedDate(new Date(json.getLong("created")));
//			dto.setTaskDescription(json.getString("taskDescription"));
//			Map<String, Object> dataSlots = new HashMap<String, Object>();
//			for (DataSlotsTemplateCode savvionTemplateCode : DataSlotsTemplateCode.values()) {
//				dataSlots.put(savvionTemplateCode.getCode(), json.get(savvionTemplateCode.getCode()));
//			}
//			dto.setDataSlots(dataSlots);
			results.add(dto);
		}
		return results;
	}
	
	private static final List<String> getTaskIds(JSONArray array) throws JSONException{
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < array.length(); i++) {
			JSONObject json = array.getJSONObject(i);
			getLogger().debug("JSON: " + json);
			//results.add(((JSONObject) json.get("workflowInstanceId")).getString("id"));
			results.add(String.valueOf(((JSONObject) json.get("id")).getInt("id")));
			
		}
		return results;
	}
	
	public static final String getTaskId(String workflowId) {
		String body = createRequest("/tasks/byWorkflowId/" + workflowId, HttpMethod.GET);
		try {
			JSONArray array = new JSONArray(body);
			getLogger().debug("Array: "+array);
			return getTaskIds(array).get(0);
		} catch (JSONException e) {
			getLogger().error("JSON Error:", e);
		}
		return null;
	}
	
	public static final List<TaskDTO> getTasks(String workflowId) {
		String body = createRequest("/tasks/byWorkflowId/" + workflowId, HttpMethod.GET);
		try {
			JSONArray array = new JSONArray(body);
			getLogger().debug("Array: "+array);
			return createDTOs(array);
		} catch (JSONException e) {
			getLogger().error("JSON Error:", e);
		}
		return null;
	}
	
	public static final String startTask(String taskID){
		String results = createRequest(new StringBuffer().append("/task/").append(taskID).append("/start").append("?status=New").toString(), HttpMethod.POST);
		getLogger().debug("results: " + results);
		return results;
	}
	
	public static final String reassignTask(String taskID, String username) {
		String results = WorkflowUtil.createRequest(new StringBuffer().append("/task/").append(taskID).append("/reassign?user=").append(username).toString(), HttpMethod.GET);
		getLogger().debug("results: " + results);
		return results;
	}
	
	public static final String completeTask(String taskID, Map<String, Object> variables){
		String results = WorkflowUtil.createRequest(new StringBuffer().append("/task/").append(taskID).append("/complete").toString(), HttpMethod.POST, variables);
		getLogger().debug("results: " + results);
		return results;
	}
	
	public static final String completeTask(String taskID){
		String results = WorkflowUtil.createRequest(new StringBuffer().append("/task/").append(taskID).append("/complete").toString(), HttpMethod.POST);
		getLogger().debug("results: " + results);
		return results;
	}
	
	public static final String updateTask(String taskID, Map<String, Object> variables){
		String results = WorkflowUtil.createRequest(new StringBuffer().append("/workflowInstance/").append(taskID).append("/variables").toString(), HttpMethod.POST, variables);
		getLogger().debug("results: " + results);
		return results;
	}
	
	/**
	 * TEST: https://d8.assurantemployeebenefits.com/WAMService/rs/workflow/workflowInstance/byVariable?name=enrollmentType&value=electronic
	 * TEST: https://d8.assurantemployeebenefits.com/WAMService/rs/workflow/workflowInstance/byVariable?name=processInstanceNamePrefix&value=SoxVerifyReviews_V1
	 * TODO: It appears my variables are not being stored, talk to BC about this.
	 * @return
	 */
	public static final String retrieveProcesses(){
		String ext = new StringBuffer()
				.append("/workflowInstance/byVariable?name=processInstanceNamePrefix")
				.append("&value=").append(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY).toString();
		String results = WorkflowUtil.createRequest(ext, HttpMethod.GET);
		getLogger().debug("enrollment results: " + results);
		
		return results;
	}
}
