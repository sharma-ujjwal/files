package com.assurant.inc.sox.ar.client.bean.dashboard;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.reviewerreport.AccessListBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewDashboardUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUserDashboardUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDashboardDTO;
import com.assurant.inc.sox.ar.dto.enums.AccessListMode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.utils.NavigationUtility;

import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;

@Component("reviewUserDashboardBean")
@Scope("session")
public class ReviewUserDashboardBean {

	private static final Logger logger = LoggerFactory.getLogger(ReviewUserDashboardBean.class);
	
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewUserService")
	private IReviewUserService reviewUserService;
	@Autowired
	@Qualifier("reviewBundleService")
	private IReviewBundleService reviewBundleService;
	private String oldSortColumn = "";
	private ReviewerUI reviewer;
	private ReviewDashboardUI reviewDashboard;
	private ReviewBundleUI reviewBundle;
	private List<ReviewUserDashboardUI> users;
	private String displayAmount = "10";
	private DataTable reviewUsersTable;
	private boolean renderEscalationMgr;
	private boolean renderDataOwner;
	private boolean renderSOD;
	private boolean renderApplication;
	
	public ReviewUserDashboardBean() {
		super();
	}

	public void initReviewers(ReviewerUI reviewerUI, ReviewDashboardUI reviewDashboardUI) {
		logger.debug("initReviewers(ReviewerUI, ReviewDashboardUI) --> being executed.");
		/*
		 * reset default value
		 */
		this.renderEscalationMgr = false;
		this.renderDataOwner = false;
		this.renderSOD = false;
		this.renderApplication = false;
		
		this.reviewer = reviewerUI;
		this.reviewDashboard = reviewDashboardUI;
		// Populate the distinct environment
		reviewerService.populateReviewerDistinctEnvName(reviewer.getReviewer());
		// retrieve DTOs from service
		final Long id = reviewerUI.getReviewerId();
		final CodeDTO code = reviewDashboardUI.getReviewDashboardDTO().getReviewTypeCd();
		
		if(code.getValue().equals(ReviewTypeCode.MANAGER.getCode())){
			this.renderEscalationMgr = true;
			this.reviewerService.populateReviewerEscalationMgrName(reviewer.getReviewer());
		}else if(code.getValue().equals(ReviewTypeCode.DATA_OWNER.getCode())
				|| code.getValue().equals(ReviewTypeCode.PRIVILEGED_ACCESS.getCode())){
			this.renderDataOwner = true;
			this.renderApplication = true;
			this.reviewerService.populateReviewerDataOwnerName(reviewer.getReviewer());
		}else if (code.getValue().equals(ReviewTypeCode.SEGREGATION_OF_DUTIES.getCode())){
			/*
			 * populate the sod conflict type b/c at this point we do not have it
			 */
			reviewerService.populateReviewerSODValues(reviewer.getReviewer());
			this.renderSOD = true;
		}
		
		List<ReviewUserDashboardDTO> dtos = reviewUserService.retrieveByReviewerIdDashboard(id, code);
		// build list of UIs from DTOs
		List<ReviewUserDashboardUI> uis = new ArrayList<ReviewUserDashboardUI>(dtos.size());
		for (ReviewUserDashboardDTO dto : dtos) {
			uis.add(new ReviewUserDashboardUI(dto));
		}
		// sort and set users
		CommonPageActionHelper.sortListByField(uis, "name", "");
		this.oldSortColumn = "name";
		this.users = uis;
		// load bundle
		ReviewBundleDTO reviewBundleDTO = reviewBundleService.retrieveById(reviewer.getReviewBundleId());
		this.reviewBundle = new ReviewBundleUI(reviewBundleDTO);
	}
	
	public String doReturnToReviewDashboard() {
		return "reviewDashboard";	
	}
	
	public void doSelectUser(ActionEvent event) {
		logger.debug("doSelectUser() --> being executed.");

		// Get the DataTable component from the event.
		UIComponent component = event.getComponent();

		DataTable dataTable = component.findComponent("completedReviewsTable") != null ?
				(DataTable)component.findComponent("completedReviewsTable") :
				(DataTable)component.findComponent("reviewUsersTable");

		setReviewUsersTable(dataTable);

		ReviewUserDashboardUI selectedUser = (ReviewUserDashboardUI) reviewUsersTable.getRowData();
		AccessListBean bean = (AccessListBean) JSFUtils.lookupBean("accessListBean");
		bean.setReview(reviewDashboard);
		bean.setReviewUser(selectedUser);
		bean.setReviewUsers(users);
		bean.setReviewer(reviewer);
		bean.setReviewBundle(reviewBundle);
		bean.setMode(AccessListMode.VIEW_EDITS);
        bean.setReturnPage("ReviewUserDashboard");
        bean.setFromDashboard(true);

		var navigationHandler = NavigationUtility.getNavigationHandlerInstance();
		navigationHandler.handleNavigation(NavigationUtility.getFacesContextInstance(), null, "accessList");
	}

	public void doSort() {
		logger.debug("doSort() --> being executed.");
		final String column = JSFUtils.getParameter("column");
		CommonPageActionHelper.sortListByField(users, column, oldSortColumn);
		oldSortColumn = column;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public ReviewDashboardUI getReviewDashboard() {
		return reviewDashboard;
	}

	public ReviewerUI getReviewer() {
		return reviewer;
	}

	public IReviewUserService getReviewUserService() {
		return reviewUserService;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public void setReviewDashboard(ReviewDashboardUI reviewDashboard) {
		this.reviewDashboard = reviewDashboard;
	}

	public void setReviewer(ReviewerUI reviewer) {
		this.reviewer = reviewer;
	}

	public void setReviewUserService(IReviewUserService reviewUserService) {
		this.reviewUserService = reviewUserService;
	}

	public List<ReviewUserDashboardUI> getUsers() {
		return users;
	}

	public void setUsers(List<ReviewUserDashboardUI> users) {
		this.users = users;
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public void setReviewBundle(ReviewBundleUI reviewBundle) {
		this.reviewBundle = reviewBundle;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public DataTable getReviewUsersTable() {
		return reviewUsersTable;
	}

	public void setReviewUsersTable(DataTable reviewUsersTable) {
		this.reviewUsersTable = reviewUsersTable;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public boolean isRenderEscalationMgr() {
		return renderEscalationMgr;
	}

	public void setRenderEscalationMgr(boolean renderEscalationMgr) {
		this.renderEscalationMgr = renderEscalationMgr;
	}
	
	public boolean getShowManagerColumn() {
		return this.reviewDashboard.isNotManagerReview();
	}

	public boolean isRenderDataOwner() {
		return renderDataOwner;
	}

	public void setRenderDataOwner(boolean renderDataOwner) {
		this.renderDataOwner = renderDataOwner;
	}

	public boolean isRenderSOD() {
		return renderSOD;
	}

	public void setRenderSOD(boolean renderSOD) {
		this.renderSOD = renderSOD;
	}

	public boolean isRenderApplication() {
		return renderApplication;
	}

	public void setRenderApplication(boolean renderApplication) {
		this.renderApplication = renderApplication;
	}
	
}
