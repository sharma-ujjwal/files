package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.assurant.inc.sox.ar.utils.DateUtil;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewDashboardDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.enums.ReviewBundleStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.base.ReviewServiceBase;
import com.assurant.inc.sox.ar.utils.exceptions.DuplicateReviewNameException;
import com.assurant.inc.sox.ar.utils.exceptions.NonClosableReview;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.dto.TaskDTO;

/**
 * Review Service handles the creation, update, and retrieval of a review
 * 
 * @author BB68602
 * 
 */
@Service
public class ReviewService extends ReviewServiceBase implements IReviewService {

	/**
	 * Create a review
	 * 
	 * //@param ReviewDTO
	 */
	public ReviewDTO createReview(String name, ReviewTypeCode typeCode, String comments, Date targetDate, boolean adHoc)
	    throws DuplicateReviewNameException {
		getLogger().debug("createReview(ReviewDTO) --> being executed.");

		Review review = getReviewDao().findByName(name);
		if (review != null) {
			throw new DuplicateReviewNameException("Review name already exists - " + name);
		}

		review = new Review();
		review.setReviewName(name);
		review.setReviewTypeCd(typeCode.getCode());
		review.setReviewComments(comments);
		review.setReviewTargetDate(targetDate);
		review.setAdHoc((adHoc) ? "Y" : "N");
		review.setReviewCreatedDate(new Date());
		review.setReviewCreatedName(getSessionSystemUser().getUserId());
		review.setReviewStatus(ReviewStatusCode.OUTSTANDING.getCode());
		review = getReviewDao().save(review);
		return this.buildDTO(review);
	}

	private ReviewDTO buildDTO(Review review) {
		return new ReviewDTO(review, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_TYPE, review.getReviewTypeCd()),
		    this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_STATUS, review.getReviewStatus()));
	}

	/**
	 * Retrieve review by reviewId
	 * 
	 * @return ReviewDTO
	 * @param reviewId
	 */
	public ReviewDTO retrieveReviewById(Long reviewId) {
		getLogger().debug("retrieveReviewById(Long) --> being executed.");

		Review reviewFound = getReviewDao().findById(reviewId);
		return (reviewFound == null) ? null : this.buildDTO(reviewFound);
	}

	/**
	 * Retrieve all reviews
	 * 
	 * @return List<ReviewDTO>
	 */
	public List<ReviewDTO> retrieveReviews() {
		getLogger().debug("retrieveReviews() --> being executed.");

		return buildReviewDTOList(getReviewDao().findAll());
	}

	/**
	 * Retrieve review by status
	 * 
	 * @return List<ReviewDTO>
	 * @param ReviewStatusCode
	 */
	public List<ReviewDTO> retrieveReviewsByStatus(ReviewStatusCode status) {
		getLogger().debug("retrieveReviewsByStatus(String) --> being executed.");
		return buildReviewDTOList(this.retrieveReviewDomainsByStatus(status));
	}

	private List<Review> retrieveReviewDomainsByStatus(ReviewStatusCode status) {
		return getReviewDao().findByStatus(status.getCode());
	}

	/**
	 * Update a review
	 * 
	 * @return ReviewDTO
	 * @param ReviewDTO
	 */
	public ReviewDTO updateReview(ReviewDTO reviewDto) {
		getLogger().debug("updateReview(ReviewDTO) --> being executed.");

		Review review = getReviewDao().save(reviewDto.getReview());
		return this.buildDTO(review);
	}

	/**
	 * Build a list of reivew dto
	 * 
	 * @param reviews
	 * @return
	 */
	private List<ReviewDTO> buildReviewDTOList(List<Review> reviews) {
		getLogger().debug("buildReviewDTOList(List<Review> reviews)--> being executed.");
		List<ReviewDTO> dtos = new ArrayList<ReviewDTO>(reviews.size());
		for (Review review : reviews) {
			dtos.add(this.buildDTO(review));
		}
		return dtos;
	}

	/**
	 * Calculate the statistics for a review dashboard object. This will calculate the # of reports distributed, # of reports
	 * attested to % of non rejected reports attested to # of non rejected users for this review # of users attested to % of non
	 * rejected users attested to
	 */
	/* (non-Javadoc)
	 * @see com.assurant.inc.sox.ar.service.IReviewService#calculateStatistics(com.assurant.inc.sox.ar.dto.ReviewDashboardDTO)
	 */
	public void calculateStatistics(ReviewDashboardDTO reviewDashboardDTO) {
		/*
		 * get all reviewers for all bundles of this reviews
		 */
		List<ReviewerDTO> reviewerDTOs = getReviewerService().retrieveByReviewIdForDashboard(reviewDashboardDTO.getReviewId());

		if (reviewerDTOs != null && !reviewerDTOs.isEmpty()) {
			int reportsDistributed = 0;
			int reportsAttested = 0;
			int usersIncluded = 0;
			int usersAttested = 0;
			int nonRejectedReviewers = 0;
			int overdueReviewers = 0;

			for (ReviewerDTO reviewerDTO : reviewerDTOs) {
				final String lastStatusCode = reviewerDTO.getReviewerLastStatusCd();
				final int reviewedUsers = reviewerDTO.getNumberOfReviewedUsers().intValue();
				/*
				 * do not keep statistics for rejected reviewers
				 */
				if (!ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(lastStatusCode)) {
					/*
					 * keep a count of all non rejected reviewers
					 */
					nonRejectedReviewers += 1;
					/*
					 * keep a count of all reviewers that have been distributed/released
					 */
					reportsDistributed += ReviewerStatusCode.RELEASED.getCode().equalsIgnoreCase(lastStatusCode) ? 1 : 0;
					/*
					 * keep a count of all reviewers that have attested to their review, this is done by setting
					 * the attest date 
					 */
					reportsAttested += (reviewerDTO.getAttestedOnDate() != null) ? 1 : 0;
					/*
					 * keep a count of reviewer's users, this is only a kept for non rejected reviewers
					 */
					usersIncluded += reviewedUsers;
					/*
					 * keep a count of the number of users attested, this is done by if a reviewer has
					 * attested to their review then all there users have been attested to
					 */
					usersAttested += (reviewerDTO.getAttestedOnDate() != null) ? reviewedUsers : 0;
					/*
					 * keep a count over overdue reports. 
					 */
					overdueReviewers += reviewerDTO.isOverdue() ? 1 : 0;
				}
			}

			reviewDashboardDTO.setNumberOfReportsDistributed(reportsDistributed);
			reviewDashboardDTO.setNumberOfReportsAttested(reportsAttested);
			/*
			 * calculate the percentage of reports attested by the count of reviewers attested / the total 
			 * count of non-rejected reviewers 
			 */
			reviewDashboardDTO.setPercentageOfReportsAttested(nonRejectedReviewers == 0 ? 0
			    : ((float) reportsAttested / (float) nonRejectedReviewers) * 100);

			reviewDashboardDTO.setNumberOfUsersIncluded(usersIncluded);
			reviewDashboardDTO.setNumberOfUsersAttested(usersAttested);
			/*
			 * calculate the percentage of users attested by the count of users attested / the total 
			 * count of non-rejected reviewers users 
			 */
			reviewDashboardDTO.setPercentageOfUsersAttested(usersIncluded == 0 ? 0
			    : ((float) usersAttested / (float) usersIncluded) * 100);
			reviewDashboardDTO.setNumberOfNonRejectedReports(nonRejectedReviewers);
			/*
			 * calculate percentage of overdue reviewers
			 */
			reviewDashboardDTO.setNumberOfOverdueReports(overdueReviewers);
			reviewDashboardDTO.setPercentageOfOverdueReports(((float) overdueReviewers / (float) nonRejectedReviewers) * 100);
		}
	}

	/**
	 * This method will return all the reviews with a completed status. It will not calculate the statistics on these for
	 * performance concerns. If need the UI will call the service separately to get them.
	 */
	public List<ReviewDashboardDTO> retrieveCompletedDashboardReviews() {
		List<Review> reviews = retrieveReviewDomainsByStatus(ReviewStatusCode.COMPLETED)
				.stream()
				.filter(taskDTO -> taskDTO.getReviewCompletedDate().before(DateUtil.getDateDaysAgo(0)))
				.sorted((task1, task2) -> task2.getReviewCompletedDate().compareTo(task1.getReviewCompletedDate())) // Sort by latest date first
				.limit(20)
				.toList();
		List<ReviewDashboardDTO> reviewDashboardDTOs = new ArrayList<ReviewDashboardDTO>(reviews.size());

		for (Review review : reviews) {
			reviewDashboardDTOs.add(this.buildDashboardDTO(review));
		}
		return reviewDashboardDTOs;
	}

	private ReviewDashboardDTO buildDashboardDTO(Review review) {
		return new ReviewDashboardDTO(review, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_TYPE, review.getReviewTypeCd()),
		    this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_STATUS, review.getReviewStatus()));
	}

	/**
	 * This method will return all the reviews with a outstanding status. It will calculate the statistics for the dashboard
	 * objects.
	 */
	public List<ReviewDashboardDTO> retrieveOutstandingDashboardReviews() {
		List<Review> reviews = retrieveReviewDomainsByStatus(ReviewStatusCode.OUTSTANDING)
				.stream()
				.filter(taskDTO -> taskDTO.getReviewCreatedDate().before(DateUtil.getDateDaysAgo(3678)))
				.sorted((task1, task2) -> task2.getCreatedDate().compareTo(task1.getCreatedDate())) // Sort by latest date first
				.limit(50)
				.toList();
		List<ReviewDashboardDTO> reviewDashboardDTOs = new ArrayList<ReviewDashboardDTO>(reviews.size());

		for (Review review : reviews) {
			ReviewDashboardDTO dashboardDTO = this.buildDashboardDTO(review);
			calculateStatistics(dashboardDTO);
			reviewDashboardDTOs.add(dashboardDTO);
		}

		return reviewDashboardDTOs;
	}

	public void closeReview(Long reviewId) throws NonClosableReview {
		List<ReviewBundle> bundles = this.reviewBundleDao.findByReviewId(reviewId);

		// check to see that all of the bundles are closed.
		for (ReviewBundle bundle : bundles) {
			String bundleStatusCode = bundle.getBundleStatusCode();
			if (!((ReviewBundleStatusCode.COMPLETED.getCode().equalsIgnoreCase(bundleStatusCode)) || (ReviewBundleStatusCode.REJECTED
			    .getCode().equalsIgnoreCase(bundleStatusCode)) || (ReviewBundleStatusCode.REJECTED_W_NO_CONFLICTS
					    .getCode().equalsIgnoreCase(bundleStatusCode)))) {
				String bundleName = this.reviewBundleService.retrieveBundleName(bundle.getId());
				throw new NonClosableReview("An open bundle was found for the review with a status of: " + bundleStatusCode
				    + " and a name of: " + bundleName);
			}
		}

		// check to see that all reviewers for the review have been either attested or rejected.
		for (ReviewBundle bundle : bundles) {
			// ignore rejected bundles
			if (!(ReviewBundleStatusCode.REJECTED.getCode().equalsIgnoreCase(bundle.getBundleStatusCode()))) {
				for (Reviewer reviewer : this.reviewerDao.findByReviewBundleId(bundle.getId())) {
					String reviewerStatus = reviewer.getReviewerLastStatusCd();
					if (!((ReviewerStatusCode.REJECTED.getCode().equalsIgnoreCase(reviewerStatus)) || (reviewer.getAttestedOnDate() != null))) {
						throw new NonClosableReview("A reviewer was found that was not attested or rejected.  Reviewer name: "
						    + reviewer.getReviewerName());
					}
				}
			}
		}

		// check to see that there are no savvion validate tasks out for this review.
		List<TaskDTO> rejectUserTasks = this.workflowService.retrieveProcessesByTemplateName(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_REJECT_USER);
		Set<Long> reviewerIdsWithTasks = new HashSet<Long>();
		for (TaskDTO dto : rejectUserTasks) {
			Long reviewUserId = Long.parseLong((String) dto.getDataSlots().get(ITaskValues.DATASLOTS_VALIDATE_REJECTED_USER_ID));
			ReviewUser reviewUser = this.reviewUserDao.findById(reviewUserId);
			if (reviewUser == null) {
				logger.warn("An invalid rejected user id was found for savvion task: " + dto.getProcessId() + " review user id: "
				    + reviewUserId);
				continue;
			}
			reviewerIdsWithTasks.add(reviewUser.getReviewerId());
		}

		List<TaskDTO> rejectedAccesses = this.workflowService
		    .retrieveProcessesByTemplateName(DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VALIDATE_ACCESS);
		for (TaskDTO dto : rejectedAccesses) {
			reviewerIdsWithTasks.add(Long.parseLong((String) dto.getDataSlots().get(ITaskValues.DATASLOTS_VALIDATE_REVIEWER_ID)));
		}

		Set<Long> reviewBundleIds = new HashSet<Long>(reviewerIdsWithTasks);
		for (Long reviewerId : reviewerIdsWithTasks) {
			Reviewer reviewer = this.reviewerDao.findById(reviewerId);
			if (reviewer == null) {
				logger.warn("An invalid reviewer id was found reviewer id: " + reviewerId);
				continue;
			}
			reviewBundleIds.add(reviewer.getReviewBundleId());
		}

		for (ReviewBundle bundle : bundles) {
			if (reviewBundleIds.contains(bundle.getId())) {
				throw new NonClosableReview("A non completed task was found for the reivew");
			}
		}

		// We now have a closable review.
		Review review = this.reviewDao.findById(reviewId);
		review.setReviewCompletedDate(new Date());
		review.setReviewStatus(Review.COMPLETED_STATUS_CODE);
		this.reviewDao.save(review);

	}

}
