//**
//
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IEnvironmentDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Environment;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.ar.service.IApplicationSystemService;
import com.assurant.inc.sox.ar.service.IEnvironmentService;

/**
 * @author RuthSchmalz
 * 
 */
@Service
public class EnvironmentService implements IEnvironmentService {
	// for spring
	@Autowired
	private IEnvironmentDao environmentDao;
	@Autowired
	private IApplicationService applicationService;
	@Autowired
	private IApplicationSystemService applicationSystemService;	
	@Autowired
	private SystemUserDTO systemUser;

	public EnvironmentService() {
	}

	public List<Environment> retrieveAllEnvironments() {
		return this.environmentDao.findAll();
	}
	
	public List<Environment> retrieveAllEnvironmentsByName(String environmentNameSearchText) {
		return this.environmentDao.findAllByName(environmentNameSearchText);
	}
	
	public List<Environment> retrieveDeletedEnvironments() {
		return this.environmentDao.findDeleted();
	}

	public List<Environment> retrieveDeletedEnvironmentsByName(String environmentNameSearchText) {
		return this.environmentDao.findDeletedByName(environmentNameSearchText);
	}

	public List<Environment> retrieveUnassignedEnvironments() {
		return this.environmentDao.findUnassigned();
	}

	public List<Environment> retrieveUnassignedByName(String searchString) {
		return this.environmentDao.findUnassignedByName(searchString);
	}

	public IEnvironmentDao getEnvironmentDao() {
		return environmentDao;
	}

	public void setEnvironmentDao(IEnvironmentDao environmentDao) {
		this.environmentDao = environmentDao;
	}
	
	public Environment findById(Long id) {
		return this.environmentDao.findById(id);
	}

	public Environment  findDuplicate(String name) {
		return this.environmentDao.findDuplicate(name);
	}
	
	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String environmentName) {
		Date currentDate = new Date();

		//Create a Environment record.
		Environment environment = new Environment();
		environment.setName(environmentName);
		environment.setDeleteFlag(IFlags.NOT_DELETED);
		environment.setCreatedBy(this.systemUser.getUserId());
		environment.setCreatedDate(currentDate);
		
		environment.setActiveFromDate(currentDate);
		environment.setActiveToDate(DateUtil.END_OF_TIME);
		this.environmentDao.save(environment);

		//Get a list of all 86_Applctn 
		List<Application> applicationList = this.applicationService.retrieveAllApplications();

		//Join the new 81Environment record to each 86Application records
        // and create new 83ApplicationSystem record for each.   
		for (Application application   : applicationList) {
			this.applicationSystemService.addNewApplicationSystem(environment, application,  currentDate);
		}
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(Environment environment) {
		Date currentDate = new Date();
		// id, setCreatedBy, setCreatedDate, setLastChangedBy, setLastChangedDate
		// are populated in  AuditInterceptor.java

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		Environment currentEnvironment = new Environment();
		currentEnvironment.setName(environment.getName());
		currentEnvironment.setDeleteFlag(IFlags.NOT_DELETED);
		currentEnvironment.setCreatedBy(environment.getCreatedBy());
		currentEnvironment.setCreatedDate(environment.getCreatedDate());
		currentEnvironment.setLastChangedBy(this.systemUser.getUserId());
		currentEnvironment.setLastChangedDate(currentDate);
		
		currentEnvironment.setActiveFromDate(environment.getActiveFromDate());
     	currentEnvironment.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.environmentDao.save(currentEnvironment);

		
		//Create a Deleted Environment record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		environment.setDeleteFlag(IFlags.DELETED);
		environment.setActiveFromDate(currentDate);
		environment.setActiveToDate(currentDate);
		this.environmentDao.save(environment);
		
		
		//Delete Application Systems that are attached to this Environment. 
		this.applicationSystemService.deleteAllApplicationSystemByEnvironmentId(environment, currentDate);

	}

	public void setApplicationService(IApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public void setApplicationSystemService(
			IApplicationSystemService applicationSystemService) {
		this.applicationSystemService = applicationSystemService;
	}
}
