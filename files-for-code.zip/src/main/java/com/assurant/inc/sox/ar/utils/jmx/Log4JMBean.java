package com.assurant.inc.sox.ar.utils.jmx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource("soxservices:type=LogMBean")
public class Log4JMBean {

	public static String ASSURANT_LOGGER = "com.assurant";

	@ManagedOperation
	public void activateLoggerToDEBUG() {
		Logger logger = LoggerFactory.getLogger(ASSURANT_LOGGER);
		logger.atLevel(Level.DEBUG);
	}

	@ManagedOperation
	public void activateLoggerToERROR() {
		Logger logger = LoggerFactory.getLogger(ASSURANT_LOGGER);
		logger.atLevel(Level.ERROR);
	}
}