package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.ManagerDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the manager selection modal panel
 * 
 */
@Component("managerSelectionBean")
@Scope("session")
public class ManagerSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(ManagerSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("ManagerSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> managers = createBundleBean.getManagers();
        managers.clear();
        for (SelectAdapter item : chosen) {
            managers.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("ManagerSelectionBean.retrieve(...) -> Being executed.");

        List<SelectAdapter> results = new ArrayList<SelectAdapter>();

        if (searchString.length() < 2) {
            JSFUtils.addFacesErrorMessage("Enter at least 2 characters.");
        } else {
            for (ManagerDTO mgr : metaDataService.retrieveManagers(searchString)) {
                FilterCriteriaDTO dto = new FilterCriteriaDTO();
                dto.setFilterCriteriaType(FilterCriteriaType.MANAGER);
                dto.setFilterValueName(mgr.getName());
                dto.setFilterValueKey(mgr.getId());
                FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
                results.add(adapter);
            }
            if (results.isEmpty()) {
                JSFUtils.addFacesErrorMessage("No results found for search.");
            }
        }
        return results;
    }
    
    @Override
    public List<SelectAdapter> restore() {
        logger.debug("ManagerSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getManagers()) {
            results.add(adapter);
        }
        return results;
    }
}
