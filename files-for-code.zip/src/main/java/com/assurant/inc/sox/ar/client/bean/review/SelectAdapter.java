package com.assurant.inc.sox.ar.client.bean.review;

/**
 * Adapt a business object for the section modal panel.
 * 
 */
public abstract class SelectAdapter {
    /**
     * @return the String to display in the list
     */
    public abstract String getDisplayString();

    /**
     * And id to use for equals comparison required for ensuring no duplicates in the lists
     * 
     */
    public abstract String getId();

    public abstract Object getObject();

    private boolean selected;

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((getId() == null) ? 0 : getId().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final SelectAdapter other = (SelectAdapter) obj;
        if (getId() == null) {
            if (other.getId() != null)
                return false;
        } else if (!getId().equals(other.getId()))
            return false;
        return true;
    }
}
