/**
 * 
 */
package com.assurant.inc.sox.ar.client.ui;

import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.domain.luad.User;

/**
 * @author EU74777
 *
 */
public class ExceptionUI {

	private final User user;
	
	public ExceptionUI(User user) {
		this.user = user;
	}
	
	public String getName() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.user.getLastName());
		sb.append(this.user.getFirstName() != null ? ", " + this.user.getFirstName() : "");
		sb.append(StringUtils.isNotBlank(this.user.getMiddleName()) ? this.user.getMiddleName() : "");
		
		return sb.toString();
	}
	
	public String getDivision() {
		return this.user.getDivisionName();
	}
	
	public String getDepartment() {
		return this.user.getDepartment().getName();
	}
}
