//**
//
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IDepartmentDao;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IDepartmentService;

/**
 * @author RuthSchmalz
 * 
 */
@Service
public class DepartmentService implements IDepartmentService {

	@Autowired
	private IDepartmentDao departmentDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public DepartmentService() {
	}

	public List<Department> retrieveAllDepartments() {
		return this.departmentDao.findAll();
	}
	
	public List<Department> retrieveAllDepartmentsByDepartmentNameCostCenter(String searchText) {
		return this.departmentDao.findAllByDepartmentNameCostCenter(searchText);
	}
	
	public List<Department> retrieveDeletedDepartments() {
		return this.departmentDao.findDeleted();
	}
	
	public List<Department> retrieveDeletedDepartmentsByDepartmentNameCostCenter(String searchText) {
		return this.departmentDao.findDeletedByDepartmentNameCostCenter(searchText);
	}


	public List<Department> retrieveUnassignedDepartments() {
		return this.departmentDao.findUnassigned();
	}

	public List<Department> retrieveUnassignedDepartmentsByDepartmentNameCostCenter(String searchText) {
		return this.departmentDao.findUnassignedByDepartmentNameCostCenter(searchText);
	}

	public IDepartmentDao getDepartmentDao() {
		return departmentDao;
	}

	public void setDepartmentDao(IDepartmentDao departmentDao) {
		this.departmentDao = departmentDao;
	}
	
	public Department findById(Long id) {
		return this.departmentDao.findById(id);
	}

	public Department findDuplicate(String departmentName, String costCenter) {
		return this.departmentDao.findDuplicate(departmentName, costCenter);
	}
	
	//**                 ADD                     ******
	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String departmentName, String costCenter) {
		Date currentDate = new Date();
		// id, setCreatedBy, setCreatedDate, setLastChangedBy, setLastChangedDate
		// are populated in  AuditInterceptor.java
		//Create a Department record.
		Department department = new Department();
		
		department.setName(departmentName);
		department.setCostCenter(costCenter);
		department.setDepartmentNmCostCenter(departmentName + "-" + costCenter);
		department.setDeleteFlag(IFlags.NOT_DELETED);
		department.setCreatedBy(this.systemUser.getUserId());
		department.setCreatedDate(currentDate);

		department.setActiveFromDate(currentDate);
		department.setActiveToDate(DateUtil.END_OF_TIME);
		this.departmentDao.save(department);
	}

	//**                 DELETE                   ******
	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(Department department) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		Department currentDepartment = new Department();
		currentDepartment.setName(department.getName());
		currentDepartment.setCostCenter(department.getCostCenter());
		currentDepartment.setDepartmentNmCostCenter(department.getDepartmentNmCostCenter());
		currentDepartment.setDeleteFlag(IFlags.NOT_DELETED);
		currentDepartment.setCreatedBy(department.getCreatedBy());
		currentDepartment.setCreatedDate(department.getCreatedDate());
		currentDepartment.setLastChangedBy(this.systemUser.getUserId());
		currentDepartment.setLastChangedDate(currentDate);

		currentDepartment.setActiveFromDate(department.getActiveFromDate());
		currentDepartment.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.departmentDao.save(currentDepartment);
			
		//Create a Deleted Department record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		// Val says we need to add one sec to the TimeDateStamp 
		department.setDeleteFlag(IFlags.DELETED);
		department.setActiveFromDate(currentDate);
		department.setActiveToDate(currentDate);
		this.departmentDao.save(department);
	}

	public boolean canDepartmentBeDeleted(Long id) {
		return this.departmentDao.canDepartmentBeDeleted(id);
	}
}
