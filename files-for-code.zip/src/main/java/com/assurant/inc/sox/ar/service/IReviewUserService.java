package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDashboardDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;

/**
 * Service for retrieving review user data.
 */
public interface IReviewUserService {

    /**
     * Retrieves all of the review users that are associated with the given reviewer id.
     * 
     * @param reviewerId the id of the reviewer to retrieve the review users for.
     * @param reviewTypeCode the type code of the review that the reviewer is associated with. This type
     *        code is used to determine what data to load.
     * @return a list of the associated review users.
     */
    public List<ReviewUserDTO> retrieveByReviewerId(Long reviewerId, CodeDTO reviewTypeCode);
    
    /**
     * Retrieves all of the non rejected review users that are associated with the given reviewer id.
     * 
     * @param reviewerId the id of the reviewer to retrieve the review users for.
     * @param reviewTypeCode the type code of the review that the reviewer is associated with. This type
     *        code is used to determine what data to load.
     * @return a list of the associated non rejected review users.
     */
    public List<ReviewUserDTO> retrieveByReviewerIdNonRejected(Long reviewerId, CodeDTO reviewTypeCode);
        
    
    /**
     * Reject the reviewer's employee.  Will mark them as rejected and why they were rejected and
     * create a task for ITCompliance so they know that the employee was rejected.
     * @param reviewUsers 
     * @param reasonCode
     * @param rejectComments
     */
    public void rejectReviewUsers(List<ReviewUserDTO> reviewUsers, ReviewerDTO reviewer, String reasonCode, String rejectComment);
    
    /**
     * Completes the review for the given review user.
     * @param reviewUser The review user for whom review is being completed.
     */
    public void completeReviewUser(ReviewUserDTO reviewUser);

    public List<ReviewUserDashboardDTO> retrieveByReviewerIdDashboard(Long reviewerId, CodeDTO reviewTypeCode);
    
    public ReviewUserDTO retrieveById(Long reviewUserId);
}
