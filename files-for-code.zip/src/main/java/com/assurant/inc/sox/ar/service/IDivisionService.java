package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Division;

public interface IDivisionService {
	
	public void add(String divisionName); 	
	public void delete(Division division); 	
	public List<Division> retrieveAllDivisions();
	public Division findById(Long id); 
	public Division findDuplicate(String name); 
	public List<Division> retrieveDeletedDivisions();
	public List<Division> retrieveUnassignedDivisions();
	public List<Division> retrieveAllDivisionsByName(String divisionNameSearchText); 
	public List<Division> retrieveDeletedDivisionsByName(String divisionNameSearchText); 
	public List<Division> retrieveUnassignedDivisionsByName(String divisionNameSearchText);
	public boolean canDivisionBeDeleted(Long id); 


}
