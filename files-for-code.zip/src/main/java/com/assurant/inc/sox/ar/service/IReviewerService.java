package com.assurant.inc.sox.ar.service;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.ar.service.impl.InactiveReassignReviewerException;
import com.assurant.inc.sox.ar.utils.exceptions.UnReassignableException;

/**
 * The service for retrieving reviewer data and performing actions on reviewers.
 */
public interface IReviewerService {

	/**
	 * Retrieves all of the reviewers for the given bundle id.
	 * 
	 * @param reviewBundleId the id of the bundle to retrieve reviewer for.
	 * @return the reviewers associated with the provided review bundle id.
	 */
	public List<ReviewerDTO> retrieveByBundleId(Long reviewBundleId);

	/**
	 * Retrieves all of the reviewers for the given bundle id and status.
	 * 
	 * @param reviewBundleId the id of the bundle to retrieve reviewers for.
	 * @param status the status of the reviewers to retrieve.
	 * @return the reviewers associated with the provided review bundle id and have a status equal to the given status.
	 */
	public List<ReviewerDTO> retrieveByStatus(Long reviewBundleId, ReviewerStatusCode status);

	/**
	 * Approves the provided reviewers.
	 * 
	 * @param reviewers to approve.
	 */
	public void approveReviewers(List<ReviewerDTO> reviewers);

	/**
	 * Reassigns the provided reviewer to the provided new user. If the reviewer has been released then the existing savvion process
	 * will be canceled and a new savvion process will be created for the new user.
	 * 
	 * @param reviewer the reviewer to reassign.
	 * @param reasonCode the reason code for the reassignment.
	 * @param comments the comments for the reassignment.
	 * @param newUser the user to reassign the review to.
	 */
	public void reassignReviewer(ReviewerDTO reviewer, String reasonCode, String comments, UserDataDTO newUser);

	public void reassignReviewers(List<ReviewerDTO> reviewerDTOs, String reasonCode, String comments, UserDataDTO newUser);

	/**
	 * Rejects the provided reviewers.
	 * 
	 * @param reviewers the reviewer's to reject.
	 * @param reasonCode the reason code for the rejection.
	 * @param comments the comments for the rejection.
	 */
	public void rejectReviewers(List<ReviewerDTO> reviewers, String reasonCode, String comments);

	/**
	 * Releases the provided reviewers.
	 * 
	 * @param reviewers the reviewers to release.
	 * @param targetCompleteDate the targeted date for the reviewer to complete the review.
	 * @param instructions the instructions to be tacked onto the message sent to the reviewer.
	 * @return returns a list of not found reviewers if any.
	 */
	public List<ReviewerDTO> distributeReviewers(List<ReviewerDTO> reviewers, Date targetCompleteDate, String instructions);

	/**
	 * Retrieves a count of the reviewers associated to the provided bundle ids.
	 * 
	 * @param reviewBundleIds the bundle ids to retrieve a count for.
	 * @return the number of reviewers associated with the bundle ids provided.
	 */
	public int retrieveNumberOfReviewers(List<Long> reviewBundleIds);

	/**
	 * Retrieves the user data for all of the users that are authorized to be assigned the review. The manager reviews' authorized
	 * reviewer will be the supervisor of the current reviewer.
	 * 
	 * @param userId the id of the current reviewer.
	 * @return a list of the reviewers that are able to be assigned the review. If none are found then an empty list will be
	 *         returned.
	 */
	public List<UserDataDTO> getManagerReviewAvailableReassignReviewers(Long userId);

	/**
	 * Retrieves the user data for all of the users that are authorized to be assigned the review. The data reviews' authorized
	 * reviewer will be the reviewers setup for the provided application.
	 * 
	 * @param applicationId the id the application being reviewed.
	 * @return a list of the reviewers that are able to be assigned the review. If none are found then an empty list will be
	 *         returned.
	 */
	public List<UserDataDTO> getDataOwnerReviewAvailableReassignReviewers(Long applicationId, Long currentAssignedUserId)throws InactiveReassignReviewerException;

	/**
	 * Retrieves the user data for all of the users that are authorized to be assigned the review. The segregation of duties
	 * reviews' authorized reviewer will be the reviewers setup for the provided application.
	 * 
	 * @param conflictType the conflict type to find the reviewers for.
	 * @return a list of the reviewers that are able to be assigned the review. If none are found then an empty list will be
	 *         returned.
	 */
	public List<UserDataDTO> getSODAvailableReassignReviewers(ConflictDTO conflictType, Long currentAssignedUserId)  throws InactiveReassignReviewerException;

	/**
	 * Populates the distinct environment name needed when viewing the reviewer details.
	 * 
	 * @param reviewer the reviewer to populate the distinct environment name.
	 */
	public void populateReviewerDistinctEnvName(ReviewerDTO reviewer);

	/**
	 * Retrieves the reviewer with the given Id.
	 * @param id the reviewer Id.
	 * @return ReviewerDTO the reviewer.
	 */
	public ReviewerDTO retrieveById(Long id);

	/**
	 * Reassigns the provided reviewer to the provided new user and cancels the savvion task for the previous reviewer.
	 * @param reviewerDTO the reviewer to reassign.
	 * @param reasonCode the reason code for the reassignment.
	 * @param comments the comments for the reassignment.
	 * @param newUser the user to reassign the review to.
	 * @param savvionProcessId the savvion process id.
	 * @throws UnReassignableException
	 */
	public void reassignReleasedReviewer(ReviewerDTO reviewerDTO, String reasonCode, String comments, UserDataDTO newUser,
	    String taskProcessId) throws UnReassignableException;

	/**
	 * Attests the completed review for the given reviewer.
	 * @param reviewUserDTOs
	 * @param ReviewerDTO the reviewer.
	 * @param String the savvion process Id.
	 */
	public void attestReview(ReviewerDTO reviewer, String taskProcessId, List<ReviewUserDTO> reviewUserDTOs);

	public List<ReviewerDTO> retrieveByReviewIdForDashboard(Long reviewId);

	public void completeSavvionProcess(Set<Long> reviewBundleIds);

	public boolean isReviewDetailCompleted(Long reviewBundleId);

	public void populateHasManagerAccessToApplication(List<ReviewerDTO> reviewers);
	
	public ReviewerDTO retrieveByIdWithSlim(Long id);
	
	public void populateReviewerNumberOfDepts(ReviewerDTO dto);	
	
	public void populateReviewerEscalationMgrName(ReviewerDTO dto);
	
	public void populateReviewerDataOwnerName(ReviewerDTO dto);
	
	public void populateReviewerSODValues(ReviewerDTO dto);
	
}
