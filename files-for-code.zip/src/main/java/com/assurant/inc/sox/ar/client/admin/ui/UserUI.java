package com.assurant.inc.sox.ar.client.admin.ui;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;

public class UserUI {

	private final User user;

	private boolean checked;

	public UserUI(User user) {
		this.user = user;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return this.user;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getDepartment() {
		Department department = this.user.getDepartment();
		return (department == null) ? null : department.getName();

	}

	public String getDivision() {
		Division division = this.user.getDivision();
		return (division == null) ? null : division.getName();

	}

	public String getDeptDivisionBusinessSeg() {
		StringBuffer deptDivsnBussSeg = new StringBuffer();
		Department department = this.user.getDepartment();
		Division division = this.user.getDivision();

		deptDivsnBussSeg.append((department == null) ? "" : department
				.getName());
		deptDivsnBussSeg.append(" / ");
		deptDivsnBussSeg.append((division == null) ? "" : division.getName());
		deptDivsnBussSeg.append(" / ");
		deptDivsnBussSeg.append((this.user.getBusinessSegment() == null) ? ""
				: this.user.getBusinessSegment());
		return deptDivsnBussSeg.toString();
	}

	public String getUserStatusDescription() {
		UserStatus status = this.user.getUserStatus();
		return (status == null) ? null : status.getUserStatusDescription();
	}

	public String getEmailAddress() {
		return this.user.getEmailAddress();
	}

	public String getFirstName() {
		return this.user.getFirstName();
	}

	public String getLastName() {
		return this.user.getLastName();
	}


	public String getMiddleName() {
		return this.user.getMiddleName();
	}

	public String getName() {
		String firstName = this.user.getFirstName();
		String lastName = this.user.getLastName();
		String middleName = (this.user.getMiddleName()==null)?"":(", " + this.user.getMiddleName());
		String name = lastName + ", " + firstName + middleName;
		return name;
	}

	public String getStatus() {
		UserStatus status = this.user.getUserStatus();
		return (status == null) ? null : status.getUserStatusDescription();
	}

	public long getUserId() {
		return this.user.getUserId();
	}

	public Long getSupervisorId() {
		return this.user.getSupervisorId();
	}

	public String getCostCenter() {
		return this.user.getCostCenter();
	}

	public String getKeyId() {
		return (user == null) ? null : this.user.getPk().getKeyId();
	}


	public String getType() {
		UserType userType = this.user.getUserType();
		return (userType == null) ? null : userType.getUserTypeDescription();
	}
	
	public String getDeleteFlag() {
		return this.user.getDeleteFlag();
	}
	
	public String getUserType() {
		UserType userType = this.user.getUserType();
		return (userType == null) ? null : userType.getUserTypeDescription();
	}
	
	public String getSatMFId() {
		return this.user.getSatMfId();
	}
	
	public String getSatCFId() {
		return this.user.getSatCfId();
	}
	
	public String getSatGFId() {
		return this.user.getSatGfId();
	}
	
	public String getSatLCSId() {
		return this.user.getSatLcsId();
	}
	
	public String getSatFDMSId() {
		return this.user.getSatFdmsId();
	}
	
	public String getSatSiteMinderId() {
		return this.user.getSatSiteminderId();
	}
	
	public String getSatAltId1() {
		return this.user.getSatAltId1();
	}
	
	public String getSatAltId2() {
		return this.user.getSatAltId2();
	}
	
	public String getSatAltId3() {
		return this.user.getSatAltId3();
	}
	
	public String getSatJobRole() {
		return this.user.getSatJobRole();
	}
	public String getJobTitle() {
		return this.user.getJobTitle();
	}
	
	public String getSupervisorName() {
		return this.user.getSupervisor();
	}
	
	public String getSatStatus() {
		return this.user.getSatStatus();
	}
	
	public String getLocation() {
		return this.user.getLocation();
	}
	
	public String getPhone() {
		return this.user.getPhone();
	}
	
	public String getSatComment() {
		return this.user.getSatComment();
	}
	
	public Date getActiveToDate() {
		return this.user.getPk().getEffectiveToDate();
	}
	
	public Date getActiveFromDate() {
		return this.user.getPk().getEffectiveFromDate();
	}
	
	public String getLastUpdatedBy() {
		return this.user.getLastChngdBy();
	}
	
	public Date getLastUpdatedDate() {
		return this.user.getLastChngdDt();
	}

	public Date getCreatedDate() {
		return this.user.getCrtdDt();
	}
	
	public String getCreatedBy() {
		return this.user.getCrtdBy();
	}
	
	public Date getExtractDate() {
		return this.user.getExtractDate();
	}
	
	public Long getDeptID(){
		Department dep = this.user.getDepartment();
		return (dep == null) ? -1L : dep.getId();
	}
	
	public Long getUserTypeID()	{
		UserType userType = this.user.getUserType();
		return (userType == null) ? -1L : userType.getId();
	}
	
	public Long getUserStatusID(){
		UserStatus userStatus = this.user.getUserStatus(); 
		return (userStatus == null) ? -1L : userStatus.getId();
	}
	
	public Long getDivisionID(){
		Division div = this.user.getDivision(); 
		return (div == null) ? -1L : div.getId();
	}

	public String getBusinessSeg() {
		return ((this.user.getBusinessSegment() == null) ? ""
				: this.user.getBusinessSegment());
	}
	
	public String getDepartmentNmCostCenter() {
		Department department = this.user.getDepartment();
		return (department == null) ? null : department.getDepartmentNmCostCenter();
	}
}
