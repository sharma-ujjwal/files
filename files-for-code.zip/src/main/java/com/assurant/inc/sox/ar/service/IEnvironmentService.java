package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Environment;

public interface IEnvironmentService {
	
	public List<Environment> retrieveAllEnvironments();
	public Environment findById(Long id);
	public List<Environment> retrieveDeletedEnvironments(); 
	public List<Environment> retrieveAllEnvironmentsByName(String environmentNameSearchText); 
	public List<Environment> retrieveDeletedEnvironmentsByName(String environmentNameSearchText);
	public List<Environment> retrieveUnassignedEnvironments();
	public List<Environment> retrieveUnassignedByName(String searchString);
	public Environment findDuplicate(String name);
	public void add(String environmentName);
	public void delete(Environment environment); 

}
