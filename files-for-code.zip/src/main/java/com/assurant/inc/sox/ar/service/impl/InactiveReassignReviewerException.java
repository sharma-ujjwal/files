package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import com.assurant.inc.sox.ar.dto.UserDataDTO;

public class InactiveReassignReviewerException extends Exception {

	/**
   * 
   */
  private static final long serialVersionUID = 1L;
	private List<UserDataDTO> inactiveUsers;
	
	public InactiveReassignReviewerException(List<UserDataDTO> inactiveUsers) {
		this.inactiveUsers = inactiveUsers;
	}
	
	public List<UserDataDTO> getInactiveUsers(){
		return this.inactiveUsers;
	}
}
