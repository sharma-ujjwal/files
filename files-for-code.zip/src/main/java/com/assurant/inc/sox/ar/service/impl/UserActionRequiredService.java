package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewApplicationDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.UserActionRequiredDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.enums.reviewUserAccess.ReviewUserAccessStatusCode;
import com.assurant.inc.sox.ar.service.IUserActionRequiredService;
import com.assurant.inc.sox.ar.service.base.UserActionRequiredServiceBase;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.domain.ar.ReviewApplication;
import com.assurant.inc.sox.domain.ar.ReviewApplicationWO;
import com.assurant.inc.sox.domain.ar.ReviewApplicationWOPk;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.ReviewUserAccessWO;
import com.assurant.inc.sox.domain.ar.ReviewUserAccessWOPk;
import com.assurant.inc.sox.domain.ar.ReviewUserWO;
import com.assurant.inc.sox.domain.ar.ReviewUserWOPk;
import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;

@Service
public class UserActionRequiredService extends UserActionRequiredServiceBase implements IUserActionRequiredService {

	private static final int REVIEW_APPLICATION_ENTITY_TYPE = 0;
	private static final int REVIEW_USER_ENTITY_TYPE = 1;
	private static final int REVIEW_USER_ACCESS_ENTITY_TYPE = 2;
	private static final UserActionRequiredComparator COMPARATOR = new UserActionRequiredComparator();

	private ReviewUserDTO getCachedReviewUser(HashMap<Long, ReviewUserDTO> reviewUserCache, Long reviewUserId) {
		ReviewUserDTO reviewUser = reviewUserCache.get(reviewUserId);
		if (reviewUser == null) {
			ReviewUser reviewUserDomain = this.reviewUserDao.findById(reviewUserId);
			if (reviewUserDomain == null) {
				return null;
			}

			CodeDTO completeCode = null;
			CodeDTO rejectCode = null;
			if(reviewUserDomain.getReviewUserStatusCd() != null){
				rejectCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_REJECT_REASON, reviewUserDomain
						.getReviewUserStatusCd());
			}
			if(reviewUserDomain.getReviewCompletedFlag() != null){
				completeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_COMPLETE, reviewUserDomain
						.getReviewCompletedFlag());
			}

			reviewUser = new ReviewUserDTO(reviewUserDomain, rejectCode, completeCode);
			reviewUserCache.put(reviewUserId, reviewUser);
		}
		return reviewUser;
	}

	private List<WorkOrderDTO> retrieveWorkOrders(Long entityId, int entityType) {

		List<WorkOrderDTO> results = new ArrayList<WorkOrderDTO>();
		if (entityType == REVIEW_USER_ACCESS_ENTITY_TYPE) {
			List<ReviewUserAccessWO> accessWOList = this.workOrderDao.findByReviewUserAccessId(entityId);
			for (ReviewUserAccessWO accessWO : accessWOList) {

				ReviewWorkOrder workOrder = accessWO.getPk().getWorkOrder();
				CodeDTO reasonCode = null;
				if( workOrder.getReasonCode() != null){
					reasonCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.WORK_ORDER_REASON, workOrder.getReasonCode());	
				}
				results.add(new WorkOrderDTO(workOrder, reasonCode));
			}
		} else if (entityType == REVIEW_APPLICATION_ENTITY_TYPE) {
			List<ReviewApplicationWO> applicationWOList = this.workOrderDao.findByReviewApplicationId(entityId);
			for (ReviewApplicationWO appWO : applicationWOList) {
				ReviewWorkOrder workOrder = appWO.getPk().getWorkOrder();
				CodeDTO reasonCode = null;
				if( workOrder.getReasonCode() != null){
					reasonCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.WORK_ORDER_REASON, workOrder.getReasonCode());	
				}				
				results.add(new WorkOrderDTO(workOrder, reasonCode));
			}
		} else if (entityType == REVIEW_USER_ENTITY_TYPE) {
			List<ReviewUserWO> userWOList = this.workOrderDao.findByReviewUserId(entityId);
			for (ReviewUserWO userWO : userWOList) {
				ReviewWorkOrder workOrder = userWO.getPk().getWorkOrder();
				CodeDTO reasonCode = null;
				if( workOrder.getReasonCode() != null){
					reasonCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.WORK_ORDER_REASON, workOrder.getReasonCode());	
				}
				results.add(new WorkOrderDTO(workOrder, reasonCode));
			}
		}
		return results;
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#retrieveActionItems(java.util.List, java.util.List)
	 */
	public List<UserActionRequiredDTO> retrieveActionItems(Long reviewerId, Long applicationId) {

		HashMap<Long, ReviewUserDTO> reviewUserCache = new HashMap<Long, ReviewUserDTO>();

		// retrieve rejected accesses.
		List<ReviewUserAccess> reviewUserAccesses = this.reviewUserAccessDao.findRejectedByReviewerAndApplication(reviewerId,
		    applicationId);
		List<UserActionRequiredDTO> accessResults = new ArrayList<UserActionRequiredDTO>(reviewUserAccesses.size());
		for (ReviewUserAccess access : reviewUserAccesses) {

			Long reviewUserId = access.getReviewUserId();
			ReviewUserDTO reviewUser = this.getCachedReviewUser(reviewUserCache, reviewUserId);

			Long accessId = access.getId();
			if (reviewUser == null) {
				logger.warn("Review user for access not found.  ReviewUserAccessId: " + accessId + " reviewUserId: " + reviewUserId);
				continue;
			}

			UserActionRequiredDTO arDTO = new UserActionRequiredDTO(this.retrieveWorkOrders(accessId, REVIEW_USER_ACCESS_ENTITY_TYPE),
			    reviewUser);
			
			CodeDTO codeDTO =null;
			if(access.getValidationStatusCode() != null){
				codeDTO = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS, access.getValidationStatusCode());
			}
			arDTO.setReviewUserAccessDTO(new ReviewUserAccessDTO(access, codeDTO));
			accessResults.add(arDTO);
		}
		Collections.sort(accessResults, COMPARATOR);

		List<ReviewApplication> applications = this.reviewApplicationDao.findRejectedByReviewerAndApplication(reviewerId,
		    applicationId);
		List<UserActionRequiredDTO> appResults = new ArrayList<UserActionRequiredDTO>(applications.size());
		for (ReviewApplication application : applications) {
			Long reviewUserId = application.getReviewUserId();
			ReviewUserDTO reviewUser = this.getCachedReviewUser(reviewUserCache, reviewUserId);

			if (reviewUser == null) {
				logger
				    .warn("Review user for access not found.  ReviewApplicationId: " + applicationId + " reviewUserId: " + reviewUserId);
				continue;
			}

			UserActionRequiredDTO arDTO = new UserActionRequiredDTO(this.retrieveWorkOrders(application.getId(),
			    REVIEW_APPLICATION_ENTITY_TYPE), reviewUser);
			arDTO.setReviewApplicationDTO(new ReviewApplicationDTO(application));
			appResults.add(arDTO);
		}
		Collections.sort(appResults, COMPARATOR);

		List<UserActionRequiredDTO> results = new ArrayList<UserActionRequiredDTO>(accessResults.size() + appResults.size());
		results.addAll(accessResults);
		results.addAll(appResults);

		return results;
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#retrieveWorkOrdersByReviewUser(java.lang.Long)
	 */
	public List<WorkOrderDTO> retrieveWorkOrdersByReviewUser(Long reviewUserId) {
		return this.retrieveWorkOrders(reviewUserId, REVIEW_USER_ENTITY_TYPE);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#addWorkOrder(com.assurant.inc.sox.ar.dto.WorkOrderDTO,
	 *      java.util.List)
	 */
	public void addWorkOrder(List<UserActionRequiredDTO> userActionRequiredDTOs, String reasonCode, String taskId,
	    Long workOrderNumber, String comments) {

		// save work order
		ReviewWorkOrder wo = new ReviewWorkOrder();
		wo.setReasonCode(reasonCode);
		wo.setTaskProcessId(taskId);
		wo.setWorkOrderComment(comments);
		wo.setWorkOrderNo(workOrderNumber);
		wo = this.workOrderDao.save(wo);

		for (UserActionRequiredDTO dto : userActionRequiredDTOs) {
			ReviewApplicationDTO appDTO = dto.getReviewApplicationDTO();
			if (appDTO == null) {
				ReviewUserAccessDTO accessDTO = dto.getReviewUserAccessDTO();
				ReviewUserAccess access = accessDTO.getReviewUserAccess();
				ReviewUserAccessWO accessWorkOrder = new ReviewUserAccessWO();
				ReviewUserAccessWOPk pk = new ReviewUserAccessWOPk();
				pk.setReviewUserAccessId(access.getId());
				pk.setWorkOrder(wo);
				accessWorkOrder.setPk(pk);

				// save review user access work order xref
				this.workOrderDao.saveAccessWO(accessWorkOrder);
			} else {
				ReviewApplication reviewApp = appDTO.getReviewApplication();
				ReviewApplicationWO appWorkOrder = new ReviewApplicationWO();
				ReviewApplicationWOPk pk = new ReviewApplicationWOPk();
				pk.setReviewApplicationId(reviewApp.getId());
				pk.setWorkOrder(wo);
				appWorkOrder.setPk(pk);
				// save review application work order xref
				this.workOrderDao.saveApplicationWO(appWorkOrder);

			}

		}

	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#addWorkOrder(com.assurant.inc.sox.ar.dto.WorkOrderDTO,
	 *      com.assurant.inc.sox.ar.dto.ReviewUserDTO)
	 */
	public void addWorkOrder(ReviewUserDTO reviewUserDTO, String reasonCode, String taskId, Long workOrderNumber, String comments) {

		// save work order
		ReviewWorkOrder wo = new ReviewWorkOrder();
		wo.setReasonCode(reasonCode);
		wo.setTaskProcessId(taskId);
		wo.setWorkOrderComment(comments);
		wo.setWorkOrderNo(workOrderNumber);
		wo = this.workOrderDao.save(wo);
		ReviewUserWO userWO = new ReviewUserWO();
		ReviewUserWOPk pk = new ReviewUserWOPk();
		pk.setReviewUserId(reviewUserDTO.getReviewUser().getId());
		pk.setWorkOrder(wo);
		userWO.setPk(pk);
		// save review user work order xref
		this.workOrderDao.saveReviewUserWO(userWO);
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#completeActionItem(com.assurant.inc.sox.ar.dto.UserActionRequiredDTO,
	 *      java.util.Date)
	 */
	public void completeActionItem(UserActionRequiredDTO userActionRequiredDTO, Date validateDate) {
		ReviewApplicationDTO appDTO = userActionRequiredDTO.getReviewApplicationDTO();
		if (appDTO == null) {
			ReviewUserAccessDTO accessDTO = userActionRequiredDTO.getReviewUserAccessDTO();
			ReviewUserAccess access = accessDTO.getReviewUserAccess();
			access.setValidationStatusCode(accessDTO.getStatus().getValue());
			access.setValidationCompleteDate(validateDate);
			access = this.reviewUserAccessDao.save(access);
			CodeDTO codeDTO = null;
			if(access.getValidationStatusCode() != null){
				codeDTO = this.codeService.retrieveCodeByValueFromCache(
					    CodeSet.REVIEW_USER_ACCESS_STATUS, access.getValidationStatusCode());
			}
			userActionRequiredDTO.setReviewUserAccessDTO(new ReviewUserAccessDTO(access, codeDTO));
		} else {
			ReviewApplication app = appDTO.getReviewApplication();
			app.setValidationCompleteDate(validateDate);
			app = this.reviewApplicationDao.save(app);
			userActionRequiredDTO.setReviewApplicationDTO(new ReviewApplicationDTO(app));
		}
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#completeActionRequiredTask(java.lang.String)
	 */
	public void completeActionRequiredTask(String taskId) {
		// Time being change added variables
				Map<String, Object> variables = new HashMap<String, Object>(1);	        
				variables.put(ITaskValues.DATASLOTS_SUMMARY_APPROVED, "test");
				// Added by Shiv Start
				//variables.put("templateCode", TaskTypeCode.VALIDATE_REJECT_USER);
				variables.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX, ITaskValues.PROCESS_TEMPLATE_NAME_REJECT_USER);
				this.workflowService.updateProcessDataSlots(taskId, variables);
				//// Added by Shiv End
				// Commented by Shiv Start
		/*this.workflowService.completeProcess(taskId, variables);*/
				// Commented by Shiv End
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#validateInvalidUsersAccesses(java.util.List)
	 */
	public void validateInvalidUsersAccesses(List<UserActionRequiredDTO> userActionRequiredDTOs) {
		List<UserActionRequiredDTO> validatedDTOs = new ArrayList<UserActionRequiredDTO>();
		CodeDTO activeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS,
		    ReviewUserAccessStatusCode.ACTIVE.getCode());
		CodeDTO inactiveCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS,
		    ReviewUserAccessStatusCode.INACTIVE.getCode());

		for (UserActionRequiredDTO arDTO : userActionRequiredDTOs) {
			ReviewUserAccessDTO accessDTO = null;
			if(arDTO != null ) {
				accessDTO = arDTO.getReviewUserAccessDTO();
				// only set the validation if the line represents an access and the access is not completed.
				if (accessDTO != null && accessDTO.getCompleteDate() == null) {
					ReviewUserAccess access = accessDTO.getReviewUserAccess();
					boolean active = this.userAccessDao.isAccessActive(access.getUserKeyId(), access.getUserId(), access.getSourceName(),
					    access.getPrivilegeValue(), access.getPrivilegeDescription());
					if(! active){ 
						accessDTO.setStatus(inactiveCode);
						arDTO.setReviewUserAccessDTO(accessDTO);
						validatedDTOs.add(arDTO);
					}
				}
			}
		}

	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IUserActionRequiredService#validateUsersAccesses(java.util.List)
	 */
	public void validateUsersAccesses(List<UserActionRequiredDTO> userActionRequiredDTOs) {
		List<UserActionRequiredDTO> validatedDTOs = new ArrayList<UserActionRequiredDTO>();
		CodeDTO activeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS,
		    ReviewUserAccessStatusCode.ACTIVE.getCode());
		CodeDTO inactiveCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS,
		    ReviewUserAccessStatusCode.INACTIVE.getCode());

		for (UserActionRequiredDTO arDTO : userActionRequiredDTOs) {
			ReviewUserAccessDTO accessDTO = arDTO.getReviewUserAccessDTO();
			// only set the validation if the line represents an access and the access is not completed.
			if (accessDTO != null && accessDTO.getCompleteDate() == null) {
				ReviewUserAccess access = accessDTO.getReviewUserAccess();
				boolean active = this.userAccessDao.isAccessActive(access.getUserKeyId(), access.getUserId(), access.getSourceName(),
				    access.getPrivilegeValue(), access.getPrivilegeDescription());
				accessDTO.setStatus((active) ? activeCode : inactiveCode);
				arDTO.setReviewUserAccessDTO(accessDTO);
				validatedDTOs.add(arDTO);
			}
		}

	}

	public static class UserActionRequiredComparator implements Comparator<UserActionRequiredDTO> {

		UserActionRequiredComparator() {
			// override constructor to reduce visibility
		}

		public int compare(UserActionRequiredDTO uar1, UserActionRequiredDTO uar2) {

			String userName1 = uar1.getReviewUser().getUserName();
			String userName2 = uar2.getReviewUser().getUserName();

			int result;
			if (userName1 == userName2) {
				result = 0;
			} else if (userName1 == null) {
				result = -1;
			} else if (userName2 == null) {
				result = 1;
			} else {
				result = userName1.compareTo(userName2);
			}
			return result;
		}

	}

}
