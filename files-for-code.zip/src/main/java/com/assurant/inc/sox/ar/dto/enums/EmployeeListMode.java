package com.assurant.inc.sox.ar.dto.enums;

public enum EmployeeListMode {
	SCHEDULE_REVIEWS, REVIEWER_VERIFY, BIG_BROTHER_VERIFY;
}
