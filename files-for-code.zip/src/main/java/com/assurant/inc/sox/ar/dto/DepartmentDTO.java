package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Department;

public class DepartmentDTO {

	private final Department department;
    
    public DepartmentDTO() {
        this(new Department());
        
    }
    
    public DepartmentDTO(Department department) {
        this.department = department;
    }

	public Department getDepartment() {
		return this.department;
	}

	public long getId() {
		Long id = this.department.getId();
        return (id == null) ? 0 : id.longValue();
	}

	public String getName() {
		return this.department.getName();
	}

	
//	public void setId(long id) {
//		this.department.setId((id == 0)  ? null : new Long(id));
//	}

//	public void setName(String name) {
//		this.department.setName(name);
//	}

	public String getDepartmentNmCostCenter() {
		return department.getDepartmentNmCostCenter();
	}

	@Override
    public String toString() {
		return this.department.toString();
	}
	
	public Date getActiveFromDate() {
		return this.department.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.department.getActiveToDate();
	}
}
