package com.assurant.inc.sox.ar.dto.tasklist;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.domain.ar.*;

public class ActionRequiredTasklistDTO extends AbstractTaskListDTO {

	private final Application application;
	private final ReviewBundleDTO reviewBundle;
	private final ReviewerDTO reviewer;
	private List<String> workOrderNumbers;

	public ActionRequiredTasklistDTO(ReviewDTO review, ReviewBundleDTO reviewBundle, ReviewerDTO reviewer, Application application) {
		super((review != null) ? review : new ReviewDTO(new Review(), new CodeDTO(new Code()), new CodeDTO(new Code()))); // Safe default review
		this.reviewBundle = (reviewBundle != null) ? reviewBundle : new ReviewBundleDTO(new ReviewBundle(), new CodeDTO(new Code())); // Avoids NPE
		this.reviewer = (reviewer != null) ? reviewer : new ReviewerDTO(new Reviewer(), new CodeDTO(new Code()), new CodeDTO(new Code()), ""); // Safe reviewer object
		this.application = (application != null) ? application : new Application(); // Default application
		this.workOrderNumbers = new ArrayList<>(); // Ensures workOrderNumbers is never null
	}


	@Override
	public String getStatus() {
		return "Incomplete";
	}

	public ReviewerDTO getReviewer() {
		return this.reviewer;
	}

	public void setWorkOrderNumbers(List<String> workOrderNumbers) {
		// this.workOrderNumbers = DisplayStringBuilder.buildCommaDelimitedList(workOrderNumbers);
		this.workOrderNumbers = workOrderNumbers;
	}

	public List<String> getWorkOrderNumbers() {
		return this.workOrderNumbers;
	}

	public Application getApplication() {
		return application;
	}

	public ReviewBundleDTO getReviewBundle() {
		return reviewBundle;
	}

}
