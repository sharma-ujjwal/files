/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IConflictTypeService;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IConflictTypeDao;
import com.assurant.inc.sox.domain.ar.ConflictType;

 /**
 * @author RuthSchmalz
 * 
 */
@Service
public class ConflictTypeService implements IConflictTypeService {

	@Autowired
	private IConflictTypeDao conflictTypeDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public ConflictTypeService() {
	}

	public List<ConflictType> retrieveAllConflictTypes() {
		return this.conflictTypeDao.findAll();
	}
	
	public List<ConflictType> retrieveAllConflictTypesByName(String conflictTypeNameSearchText) {
		return this.conflictTypeDao.findAllByName(conflictTypeNameSearchText);
	}
	
	public List<ConflictType> retrieveDeletedConflictTypes() {
		return this.conflictTypeDao.findDeleted();
	}
	
	public List<ConflictType> retrieveDeletedConflictTypesByName(String conflictTypeNameSearchText) {
		return this.conflictTypeDao.findDeletedByName(conflictTypeNameSearchText);
	}

	@Transactional
	public Long add(String conflictTypeName, String conflictTypeCode) {
		Date date = new Date();
		
		ConflictType conflictType = new ConflictType();
		conflictType.setConflictTypeText(conflictTypeName);
		conflictType.setConflictCode(conflictTypeCode);
		conflictType.setDeleteFlag(IFlags.NOT_DELETED);
		conflictType.setCreatedBy(this.systemUser.getUserId());
		conflictType.setCreatedDate(date);
		
		return this.conflictTypeDao.save(conflictType);
	}

	public ConflictType getById(Long id) {
		return this.conflictTypeDao.getById(id);
	}
}
