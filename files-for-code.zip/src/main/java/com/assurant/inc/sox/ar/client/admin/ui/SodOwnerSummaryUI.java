/**
 * 
 */
package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.admin.SodOwnerSummary;

import java.util.Date;

/**
 * @author Brian Olson
 *
 */
public class SodOwnerSummaryUI {
	private final SodOwnerSummary sodOwnerSummary;
	
	public SodOwnerSummaryUI(SodOwnerSummary sodOwnerSummary) {
		this.sodOwnerSummary = sodOwnerSummary;
	}
	
	public Long getConflictId() {
		return this.sodOwnerSummary.getConflictId();
	}
	
	public String getConflictType() {
		return this.sodOwnerSummary.getConflictType();
	}

	public String getConflictCode() {
		return this.sodOwnerSummary.getConflictCode();
	}

	public Long getLeftFunctionDutyId() {
		return this.sodOwnerSummary.getLeftFunctionDutyId();
	}

	public String getLeftApplicationName() {
		return this.sodOwnerSummary.getLeftApplicationName();
	}

	public Long getRightFunctionDutyId() {
		return this.sodOwnerSummary.getRightFunctionDutyId();
	}

	public String getRightApplicationName() {
		return this.sodOwnerSummary.getRightApplicationName();
	}

	public String getCreatedBy() {
		return this.sodOwnerSummary.getCreatedBy();
	}

	public Date getCreatedDate() {
		return this.sodOwnerSummary.getCreatedDate();
	}

	public String getLastChangedBy() {
		return this.sodOwnerSummary.getLastChangedBy();
	}

	public Date getLastChangedDate() {
		return this.sodOwnerSummary.getLastChangedDate();
	}

	public String getDisplayConflictCode() {
		String conflictCode = "";
		
		if ("ATOA".equals(this.sodOwnerSummary.getConflictCode())) {
			conflictCode = "App To App";
		}

		if ("ATOD".equals(this.sodOwnerSummary.getConflictCode())) {
			conflictCode = "App To Div";
		}
		
		return conflictCode;
	}

	public String getOwnerNamesList() {
		StringBuilder sb = new StringBuilder();
		sb.append("<ul class=\"reviewOwnerList\">");
		
		for (int i = 0; i < this.sodOwnerSummary.getOwnerNames().size(); i++) {
			sb.append("<li>");
			if (i == 0) {
				sb.append("<img src=\"/soxautoreviews/images/treeCheck.gif\" />");
			}
			sb.append(this.sodOwnerSummary.getOwnerNames().get(i));
			sb.append("</li>");
		}
		
		sb.append("</ul>");
		return sb.toString();
	}
	
	public String getReviewerNamesList() {
		StringBuilder sb = new StringBuilder();
		sb.append("<ul class=\"reviewOwnerList\">");
		
		for (int i = 0; i < this.sodOwnerSummary.getReviewerNames().size(); i++) {
			sb.append("<li>");
			if (i == 0) {
				sb.append("<img src=\"/soxautoreviews/images/treeCheck.gif\" />");
			}
			sb.append(this.sodOwnerSummary.getReviewerNames().get(i));
			sb.append("</li>");
		}
		
		sb.append("</ul>");
		return sb.toString();
	}

}
