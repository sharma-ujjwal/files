package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.Environment;

import java.util.Date;

public class EnvironmentUI {
	private final Environment environment;
	private boolean checked;

	public EnvironmentUI(Environment environment) {
		this.environment = environment;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public Long getId() {
		return this.environment.getId();
	}
	
	public String getName() {
		return this.environment.getName();
	}
	
	public String getCreatedBy() {
		return this.environment.getCreatedBy();
	}
		
	public Date getCreatedDate() {
		return this.environment.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.environment.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.environment.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.environment.getDeleteFlag();
	}

	public Date getActiveFromDate() {
		return this.environment.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.environment.getActiveToDate();
	}
	
	public Environment getEnvironment() {
		return environment;
	}

}
