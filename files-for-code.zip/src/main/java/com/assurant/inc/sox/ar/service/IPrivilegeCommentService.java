package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ExtractSystem;
import com.assurant.inc.sox.domain.ar.FunctionDuty;
import com.assurant.inc.sox.domain.luad.PrivilegeComment;;

public interface IPrivilegeCommentService {
	public List<PrivilegeComment> retrieveAll();

	public void add(String privDescription,String privValue,Long functionDutyId,
			String comment,String soxConcern,String applicationName);
	public void delete(PrivilegeComment privilegeComment);	
	public List<String> retrieveDistinctSOXConcerns();
//	public List<Long> retrieveDistinctFunctionDuties();
//	public List<String> retrieveDistinctApplicationNames();
	public List<PrivilegeComment> retrieveByValue(String soxConcern,
			String privDescription,String privValue,Long functionDutyId,String applicationName,
			String comment,Long extractSystemId,boolean searchForDuplicate);
	public List<ExtractSystem> retrieveExtractSystems();
	public boolean isDuplicate(String privDescription,String privValue, boolean searchInDelete);
	public void updateAll(List<PrivilegeComment> privilegeCommentList);
	public void update(PrivilegeComment privilegeComment);
	public List<FunctionDuty> retrieveFunctionDuties();
	public List<Application> retrieveApplications();
    public List<PrivilegeComment> findByFilters(boolean isActive, String soxConcern,String applicationName,
			String privDescription,String privValue,Long functionDutyId,Long extractSystemId);
	public List<PrivilegeComment> findDeleted();
	public boolean isAccessActive(String privValue, String privDescription);

    public void updatePrivComment(PrivilegeComment privilegeComment, String privValue, String privDesc, 
    		String privComment, Long functionDutyId, String soxConcern, String applicationName);
    public boolean isActivePrivilegeComment(PrivilegeComment privComment);
}
