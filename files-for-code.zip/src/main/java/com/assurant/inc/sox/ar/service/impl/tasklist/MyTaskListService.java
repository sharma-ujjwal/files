package com.assurant.inc.sox.ar.service.impl.tasklist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.assurant.inc.sox.ar.utils.DateUtil;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.dto.tasklist.BundleTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.RejectedUserTasklistDTO;
import com.assurant.inc.sox.ar.service.impl.ReviewBundleService;
import com.assurant.inc.sox.ar.service.tasklist.IMyTaskListService;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.dto.TaskDTO;

@Service
public class MyTaskListService extends MyTaskListServiceBase implements IMyTaskListService,Serializable {
	private static final long serialVersionUID = 10275539472837495L;


	@SuppressWarnings("unchecked")
	public List<ActionRequiredTasklistDTO> retrieveActionRequiredTasks() {
		return (List<ActionRequiredTasklistDTO>) this.retrieveItComplianceTasks(false);
	}

	@SuppressWarnings("unchecked")
	public List<AbstractTaskListDTO> retrieveItComplianceTasks() {
		return (List<AbstractTaskListDTO>) this.retrieveItComplianceTasks(true);
	}

	private List<? extends AbstractTaskListDTO> retrieveItComplianceTasks(boolean retrieveAll) {

		HashMap<Long, ReviewDTO> reviewCache = new HashMap<>(3);
		HashMap<Long, ReviewerDTO> reviewerCache = new HashMap<>(3);
		HashMap<Long, ReviewUserDTO> reviewUserCache = new HashMap<>(3);
		HashMap<Long, ReviewBundleDTO> reviewBundleCache = new HashMap<>(3);
		List<TaskDTO> taskDTOs = this.workflowService.retrieveProcessesByAssignedTo(this.savvionITComplianceUserId).stream()
				.filter(taskDTO -> taskDTO.getTaskCreatedDate().before(DateUtil.getDateDaysAgo(0)))
				.limit(20)
				.toList();
		List<AbstractTaskListDTO> results = new ArrayList<>(taskDTOs.size());
		StringBuilder sb = new StringBuilder(32);
		for (TaskDTO taskDTO : taskDTOs) {
			String taskProcessId = taskDTO.getProcessId();
			sb.setLength(0);
			TaskTypeCode taskCode = taskDTO.getTaskCode();
			AbstractTaskListDTO tasklist;
			// Bundle type tasks (details and summary)
			if (taskCode == null) {
				continue;
			}
			if (taskCode.equals(TaskTypeCode.REVIEW_SUMMARY) || taskCode.equals(TaskTypeCode.REVIEW_DETAILS)) {
				if (!retrieveAll) {
					continue;
				}
				ReviewBundleDTO reviewBundle = this.getCachedReviewBundleBySavvionId(reviewBundleCache, taskProcessId);
				if (reviewBundle == null) {
					sb.setLength(0);
					logger.warn(sb.append("Review Bundle not found taskProcessIdId: ").append(taskProcessId).toString());
					continue;
				}

				Long reviewId = reviewBundle.getReviewId();
				ReviewDTO review = this.getCachedReview(reviewCache, reviewId);
				if (review == null) {
					sb.setLength(0);
					logger.warn(sb.append("Review not found.  ReviewId: ").append(reviewId).append(" taskProcessIdId: ").append(taskProcessId)
					    .toString());
					continue;
				}

				BundleTaskListDTO bundleTasklist = new BundleTaskListDTO(review, reviewBundle);

				String bundleName = ReviewBundleService.buildBundleName(review.getReviewTypeCd(), reviewBundle.getCreatedDate());
				sb.setLength(0);
				bundleTasklist.setName(sb.append(taskDTO.getTaskDescription()).append(" - ").append(bundleName).toString());
				tasklist = bundleTasklist;
				tasklist.setTaskStatus(reviewBundle.getStatus().getDisplay());
				// UserActionRequiredTypeTasks (rejected access and comments)
			} else if (taskCode.equals(TaskTypeCode.VALIDATE_ACTION_REQUIERED)) {

				Map<String, Object> dataSlots = taskDTO.getDataSlots();

				Long appId = Long.parseLong((String) dataSlots.get(ITaskValues.DATASLOTS_VALIDATE_APPLICATION_ID));
				Application app = this.applicationDao.findById(appId);

				Long reviewerId = Long.parseLong((String) dataSlots.get(ITaskValues.DATASLOTS_VALIDATE_REVIEWER_ID));
				ReviewerDTO reviewer = this.getCachedReviewer(reviewerCache, reviewerId);
				if (reviewer == null) {
					logger.warn("Reviewer not found.  ReviewerId: " + reviewerId + " taskId: " + taskProcessId);
					continue;
				}

				Long reviewBundleId = reviewer.getReviewBundleId();
				ReviewBundleDTO reviewBundle = this.getCachedReviewBundle(reviewBundleCache, reviewBundleId);
				if (reviewBundle == null) {
					sb.setLength(0);
					logger.warn(sb.append("Review Bundle not found.  ReviewBundleId: ").append(reviewBundleId).append(" taskId: ")
					    .append(taskProcessId).toString());
					continue;
				}

				Long reviewId = reviewBundle.getReviewId();
				ReviewDTO review = this.getCachedReview(reviewCache, reviewId);
				if (review == null) {
					sb.setLength(0);
					logger
					    .warn(String.valueOf(sb.append("Review not found.  ReviewId: ").append(reviewId).append(" taskId: ").append(taskProcessId)));
					continue;
				}

				ActionRequiredTasklistDTO value = new ActionRequiredTasklistDTO(review, reviewBundle, reviewer, app);
				value.setName(taskDTO.getTaskDescription());

				List<ReviewWorkOrder> workOrders = this.workOrderDao.findBySavvionId(taskDTO.getProcessId());
				List<String> workOrderNumbers = new ArrayList<String>(workOrders.size());
				for (ReviewWorkOrder workOrder : workOrders) {
					if (workOrder.getWorkOrderNo() != null) {
						workOrderNumbers.add(workOrder.getWorkOrderNo().toString());
					}
				}
				value.setWorkOrderNumbers(workOrderNumbers);
				tasklist = value;
				tasklist.setTaskStatus(reviewBundle.getStatus().getDisplay());
				// RejectedUserTaskList for ReviewUsers that have been rejected.
			} else if (TaskTypeCode.VALIDATE_REJECT_USER.equals(taskCode)) {
				if (!retrieveAll) {
					continue;
				}
				Map<String, Object> dataSlots = taskDTO.getDataSlots();
				String rejectReviewUserIdString = (String) dataSlots.get(ITaskValues.DATASLOTS_VALIDATE_REJECTED_USER_ID);
				Long rejectReviewUserId;
				if (rejectReviewUserIdString == null) {

					sb.setLength(0);
					logger.warn(sb.append("No reviewUser id found for task task id: ").append(taskProcessId).toString());
					continue;
				}
				try {
					rejectReviewUserId = Long.parseLong(rejectReviewUserIdString);
				} catch (NumberFormatException e) {
					sb.setLength(0);
					logger.warn(sb.append("Invalid id found for task task id: ").append(taskProcessId).append(" invalid id: ")
					    .append(rejectReviewUserIdString).toString(), e);
					continue;
				}

				ReviewUserDTO reviewUser = this.getCachedReviewUser(reviewUserCache, rejectReviewUserId);
				if (reviewUser == null) {
					sb.setLength(0);
					logger.warn(String.valueOf(sb.append("Review user not found.  ReviewUserId: ").append(rejectReviewUserId).append(" taskId: ")
					    .append(taskProcessId)));
					continue;
				}

				Long reviewerId = reviewUser.getReviewerId();
				ReviewerDTO reviewer = this.getCachedReviewer(reviewerCache, reviewerId);
				if (reviewer == null) {
					sb.setLength(0);
					logger.warn(sb.append("Reviewer not found.  ReviewerId: ").append(reviewerId).append(" taskId: ").append(
							taskProcessId).toString());
					continue;
				}

				Long reviewBundleId = reviewer.getReviewBundleId();
				ReviewBundleDTO reviewBundle = this.getCachedReviewBundle(reviewBundleCache, reviewBundleId);
				if (reviewBundle == null) {
					sb.setLength(0);
					logger.warn("Review Bundle not found.  ReviewBundleId: " + reviewBundleId + " taskId: " + taskProcessId);
					continue;
				}

				Long reviewId = reviewBundle.getReviewId();
				ReviewDTO review = this.getCachedReview(reviewCache, reviewId);
				if (review == null) {
					sb.setLength(0);
					logger.warn(sb.append("Review not found.  ReviewId: ").append(reviewId).append(" taskId: ").append(taskProcessId)
					    .toString());
					continue;
				}

				RejectedUserTasklistDTO value = new RejectedUserTasklistDTO(review, reviewBundle, reviewer);
				value.setName(taskDTO.getTaskDescription() + " - " + reviewUser.getUserName());
				value.setRejectedReviewUserId(rejectReviewUserId);
				tasklist = value;
				tasklist.setTaskStatus(reviewBundle.getStatus().getDisplay());
			} else if (TaskTypeCode.REVIEWER_TASK.equals(taskCode)) {
				if (!retrieveAll) {
					continue;
				}
				sb.setLength(0);
				logger.warn(sb.append("Reviewer task found assigned to it compliance.  Skipping task with id of: ").append(
						taskProcessId).toString());
				continue;
			} else {
				sb.setLength(0);
				throw new RuntimeException(sb.append("Task found with invalid task type of: ").append(taskCode.getCode()).append(
				    " and id of: ").append(taskProcessId).toString());
			}

			tasklist.setAssignedTo(taskDTO.getAssignedTo());
			tasklist.setCreateDate(taskDTO.getTaskCreatedDate());
			tasklist.setTypeCode(taskCode);
			tasklist.setTaskId(taskProcessId);
			results.add(tasklist);
			//myTaskResults = results;
		}
		return results;
	}

	private ReviewDTO getCachedReview(HashMap<Long, ReviewDTO> reviewCache, Long reviewId) {
		ReviewDTO review = reviewCache.get(reviewId);
		if (review == null) {
			Review reviewDomain = this.reviewDao.findById(reviewId);
			if (reviewDomain == null) {
				return null;
			}

			review = new ReviewDTO(reviewDomain, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_TYPE, reviewDomain
			    .getReviewTypeCd()), this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_STATUS, reviewDomain.getReviewStatus()));
			reviewCache.put(reviewId, review);
		}
		return review;
	}

	private ReviewerDTO getCachedReviewer(HashMap<Long, ReviewerDTO> reviewerCache, Long reviewerId) {
		ReviewerDTO reviewer = reviewerCache.get(reviewerId);
		if (reviewer == null) {
			Reviewer reviewerDomain = this.reviewerDao.findById(reviewerId);
			if (reviewerDomain == null) {
				return null;
			}

			String bundleName = this.reviewBundleService.retrieveBundleName(reviewerDomain.getReviewBundleId());
			
			CodeDTO rejectCodeDTO = null;
			if(reviewerDomain.getRejectCode() != null){
				rejectCodeDTO = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEWER_REJECT_REASON, reviewerDomain.getRejectCode());
			}
			
			CodeDTO statusCodeDTO = null;
			if(reviewerDomain.getReviewerLastStatusCd() != null){
				statusCodeDTO = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEWER_STATUS, reviewerDomain.getReviewerLastStatusCd());
			}
			
			reviewer = new ReviewerDTO(reviewerDomain, rejectCodeDTO, statusCodeDTO, bundleName);
			reviewerCache.put(reviewerId, reviewer);
		}
		return reviewer;
	}

	private ReviewUserDTO getCachedReviewUser(HashMap<Long, ReviewUserDTO> reviewUserCache, Long reviewUserId) {
		ReviewUserDTO reviewUser = reviewUserCache.get(reviewUserId);
		if (reviewUser == null) {
			ReviewUser reviewUserDomain = this.reviewUserDao.findById(reviewUserId);
			if (reviewUserDomain == null) {
				return null;
			}

			CodeDTO completeCode = null;
			CodeDTO rejectCode = null;
			if(reviewUserDomain.getReviewUserStatusCd() != null){
				rejectCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_REJECT_REASON, reviewUserDomain
						.getReviewUserStatusCd());
			}
			if(reviewUserDomain.getReviewCompletedFlag() != null){
				completeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_COMPLETE, reviewUserDomain
						.getReviewCompletedFlag());
			}
			reviewUser = new ReviewUserDTO(reviewUserDomain, rejectCode, completeCode);
			reviewUserCache.put(reviewUserId, reviewUser);
		}
		return reviewUser;
	}

	private ReviewBundleDTO getCachedReviewBundleBySavvionId(HashMap<Long, ReviewBundleDTO> reviewBundleCache, String taskId) {

		ReviewBundleDTO reviewBundle = null;

		// check the cache to see if there is a bundle
		for (ReviewBundleDTO reviewBundleDTO : reviewBundleCache.values()) {
			if (taskId.equals(reviewBundleDTO.getTaskProcessId())) {
				reviewBundle = reviewBundleDTO;
				break;
			}
		}

		if (reviewBundle == null) {
			ReviewBundle reviewBundleDomain = this.reviewBundleDao.findBySavvionId(taskId);
			if (reviewBundleDomain == null) {
				return null;
			}

			reviewBundle = new ReviewBundleDTO(reviewBundleDomain, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_BUNDLE_STATUS,
			    reviewBundleDomain.getBundleStatusCode()));
			reviewBundleCache.put(reviewBundle.getReviewBundleId(), reviewBundle);
		}
		return reviewBundle;
	}

	private ReviewBundleDTO getCachedReviewBundle(HashMap<Long, ReviewBundleDTO> reviewBundleCache, Long reviewBundleId) {
		ReviewBundleDTO reviewBundle = reviewBundleCache.get(reviewBundleId);
		if (reviewBundle == null) {
			ReviewBundle reviewBundleDomain = this.reviewBundleDao.findById(reviewBundleId);
			if (reviewBundleDomain == null) {
				return null;
			}

			reviewBundle = new ReviewBundleDTO(reviewBundleDomain, this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_BUNDLE_STATUS,
			    reviewBundleDomain.getBundleStatusCode()));
			reviewBundleCache.put(reviewBundleId, reviewBundle);
		}
		return reviewBundle;
	}
}
