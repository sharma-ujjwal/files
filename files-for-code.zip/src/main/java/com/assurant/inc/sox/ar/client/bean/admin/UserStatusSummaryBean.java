package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;

import com.assurant.inc.sox.ar.client.admin.ui.UserStatusUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IUserStatusService;
import com.assurant.inc.sox.domain.ar.UserStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("userStatusSummaryBean")
@Scope("session")
public class UserStatusSummaryBean {
	private static final Logger logger = LoggerFactory.getLogger(UserStatusSummaryBean.class);

	//injected resources
	@Autowired
	@Qualifier("userStatusService")
	private IUserStatusService userStatusService;
	private SessionDataBean sessionDataBean;
	
	private List<UserStatusUI> userStatusList;
	private List<UserStatusUI> deletedUserStatusList = new ArrayList<UserStatusUI>();
	private String displayAmount = "10";
	private String oldSortColumn;
	private String userStatusName;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String userStatusNameSearchText;
	
	private boolean renderAddUserStatusModalPanel;
	private boolean renderDeleteUserStatusModalPanel;
	private boolean allChecked;
	private String pageNumber = "1";
	private String 	lastPageNumber= "1";
	private DataScroller dataScroller;
	   
	public List<UserStatusUI> getUserStatusList() {
		if (userStatusList == null) {
			refreshList();
		}
		return userStatusList;
	}
	
	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.userStatusList = new ArrayList<UserStatusUI>();
		List<UserStatus> userStatussRetrieved = new ArrayList<UserStatus>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userStatusNameSearchText)) {
				userStatussRetrieved = this.userStatusService
					.retrieveAllUserStatusByCode(this.userStatusNameSearchText);
			} else {
				userStatussRetrieved = this.userStatusService.retrieveAllUserStatuss();
			}
			
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userStatusNameSearchText)) {
				userStatussRetrieved = this.userStatusService
					.retrieveDeletedUserStatussByName(this.userStatusNameSearchText);
			} else {
				userStatussRetrieved = this.userStatusService.retrieveDeletedUserStatuss();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(
				this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.userStatusNameSearchText)) {
				userStatussRetrieved = this.userStatusService.retrieveUnassignedUserStatussByName(this.userStatusNameSearchText);
			} else {
				userStatussRetrieved = this.userStatusService.retrieveUnassignedUserStatuss(); // constructor JSF call
			}
		}
		for (UserStatus userStatus : userStatussRetrieved) {
			this.userStatusList.add(new UserStatusUI(userStatus));
		}
		doSort();
	}

	// ******* GO button *******	
	public String goSearch() {
		refreshList();
		return "";
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		this.userStatusList = null;
		this.userStatusNameSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}
	
	
	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		refreshList();
		clearSelections();
		return "";
	}

	// *******  List Headers *******	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "userStatusDescription";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(userStatusList, column, this.oldSortColumn);
		this.oldSortColumn = column;
		clearSelections();
	}
	
	// ******* Add UserStatus Panel  *******
	public String showAddUserStatusPanel() {
		this.renderAddUserStatusModalPanel = true;
		this.userStatusName = "";
		clearSelections();
		return null;
	}

	// *******  Add UserStatus Panel  CANCEL  *******
	public String doCancelAdd() {
		logger.debug("doCancelAddUserStatusPanel() --> being executed.");
		this.renderAddUserStatusModalPanel = false;
		clearSelections();
		return null;
	}

	// ******* Add UserStatus Panel  SAVE *******
	public String doAddUserStatus() {
		logger.debug("doAddUserStatus() --> being executed.");

		if (!validUserStatusName()) {
			String message = "UserStatus name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserStatusModalPanel = true;
			return null;
		}
		
		this.userStatusName = this.userStatusName.toUpperCase(); 

		UserStatus duplicate = this.userStatusService.findDuplicate(userStatusName);		
		if (duplicate != null) {
			String message = "User status " + userStatusName 
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}

		userStatusService.add(userStatusName);   

		String message = "Added UserStatus " + userStatusName;
		JSFUtils.addFacesMessage(message);
		refreshList();

		this.renderAddUserStatusModalPanel = false;
		return "";
	}

	public String showDeleteUserStatusPanel() {
		populateDeletedUserStatusList();
		if (this.deletedUserStatusList.isEmpty()) {
			String message = "Please select at least one userStatus.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteUserStatusModalPanel = true;
		}

		return null;
	}

	private void populateDeletedUserStatusList() {
		this.deletedUserStatusList = new ArrayList<UserStatusUI>();
		
		for (UserStatusUI ui : this.userStatusList) {
			if (ui.isChecked()) {
				this.deletedUserStatusList.add(ui);
			}
		}
	}
	
	public void doDisplayRowListener() {
		logger.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
	/*	pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = Integer.parseInt(displayAmount);
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)userStatusList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), userStatusList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				userStatusList.get(currRow).setChecked(true);
			}
		} else {
			for (UserStatusUI userStatusUI : this.userStatusList) {
				userStatusUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (UserStatusUI userStatusUI : this.userStatusList) {
			userStatusUI.setChecked(false);
		}
	}

	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (UserStatusUI ui : this.deletedUserStatusList) {
			// first perform a check to ensure that no user record has the
			// current user status assigned
			if (this.userStatusService.canUserStatusBeDeleted(ui.getId())) {
				this.userStatusService.delete(ui.getUserStatus()); 
			} else {
				unableToDelete.add(ui.getUserStatusDescription() + " (" + ui.getId() + ")");
			}
		}

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected user statuses were deleted " +
					"except for the following, which are assigned to at least one " +
					"user record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected user statuses");
		}

		refreshList();
		
		this.deletedUserStatusList = new ArrayList<UserStatusUI>();
		this.renderDeleteUserStatusModalPanel = false;
		return null;
	}
	
	public String doCancelDelete() {
		this.deletedUserStatusList = new ArrayList<UserStatusUI>();
		this.renderDeleteUserStatusModalPanel = false;
		return null;
	}
	
	public boolean validUserStatusName() {
		return (StringUtils.isNotEmpty(userStatusName));
	}
	
	public boolean isRenderAddUserStatusModalPanel() {
		return renderAddUserStatusModalPanel;
	}

	public void setRenderAddUserStatusModalPanel(
			boolean renderAddUserStatusModalPanel) {
		this.renderAddUserStatusModalPanel = renderAddUserStatusModalPanel;
	}

	public boolean isRenderDeleteUserStatusModalPanel() {
		return renderDeleteUserStatusModalPanel;
	}

	public void setRenderDeleteUserStatusModalPanel(
			boolean renderDeleteUserStatusModalPanel) {
		this.renderDeleteUserStatusModalPanel = renderDeleteUserStatusModalPanel;
	}

	public List<UserStatusUI> getDeletedUserStatusList() {
		return deletedUserStatusList;
	}

	public void setDeletedUserStatusList(List<UserStatusUI> deletedUserStatusList) {
		this.deletedUserStatusList = deletedUserStatusList;
	}
	
	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}
	public String getUserStatusName() {
		return this.userStatusName;
	}

	public void setUserStatusName(String name) {
		this.userStatusName = name;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getUserStatusNameSearchText() {
		return userStatusNameSearchText;
	}

	public void setUserStatusNameSearchText(String userStatusNameSearchText) {
		this.userStatusNameSearchText = userStatusNameSearchText;
	}

	public void setUserStatusList(List<UserStatusUI> userStatusList) {
		this.userStatusList = userStatusList;
	}

	public IUserStatusService getUserStatusService() {
		return userStatusService;
	}

	public void setUserStatusService(IUserStatusService userStatusService) {
		this.userStatusService = userStatusService;
	}


	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.userStatusList = null;
		this.deletedUserStatusList = null;
		this.userStatusNameSearchText = null;
		this.allChecked = false;
		this.oldSortColumn = null;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}

