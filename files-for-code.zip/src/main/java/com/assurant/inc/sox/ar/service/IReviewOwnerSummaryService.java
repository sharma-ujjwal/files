package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.admin.ReviewOwnerSummary;
import com.assurant.inc.sox.domain.searchable.ReviewOwnerSummarySearchCriteria;

public interface IReviewOwnerSummaryService {

	public List<ReviewOwnerSummary> retrieveReviewOwnerSummariesByCriteria(
			ReviewOwnerSummarySearchCriteria criteria);
	

}