package com.assurant.inc.sox.ar.client.ui.tasklist;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;

import org.springframework.stereotype.Component;

@Component
public class ActionRequiredTasklistUI extends AbstractTaskListUI {

	public ActionRequiredTasklistUI() {
		super(); // Calls the no-args constructor of AbstractTaskListUI
	}

	@Override
	protected AbstractTaskListDTO createDefaultTaskListDTO() {
		return new ActionRequiredTasklistDTO(null, null, null, null);
	}

	public ActionRequiredTasklistUI(ActionRequiredTasklistDTO taskList) {
		super(taskList);
	}

	@Override
	public String getBackingEntityName() {
		return "No Entity";
	}

	@Override
	public Long getBackingEntiyId() {
		return 0L;
	}

	public String getReviewerName() {
		return ((ActionRequiredTasklistDTO) this.taskList).getReviewer().getReviewerName();

	}

	public String getApplicationName() {
		return ((ActionRequiredTasklistDTO) this.taskList).getApplication().getName();
	}

	public String getWorkOrderNumbers() {
		StringBuffer sb = new StringBuffer();
		for (String st : ((ActionRequiredTasklistDTO) this.taskList).getWorkOrderNumbers()) {
			sb.append(st).append("<br>");
		}
		return sb.toString();
		
	}

	public ReviewerDTO getReviewer() {
		return ((ActionRequiredTasklistDTO) this.taskList).getReviewer();
	}

	@Override
	public String getStatus() {
		return ((ActionRequiredTasklistDTO) this.taskList).getStatus();
	}
}
