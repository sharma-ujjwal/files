package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.Conflict;

public interface IConflictService {
	
	public List<Conflict> retrieveAllConflicts();
	public List<Conflict> retrieveAllConflictsByName(String leftConflictSearchText, String rightConflictSearchText);
	public List<Conflict> retrieveDeletedConflicts();
	public List<Conflict> retrieveDeletedConflictsByName(String leftConflictSearchText, String rightConflictSearchText);
}
