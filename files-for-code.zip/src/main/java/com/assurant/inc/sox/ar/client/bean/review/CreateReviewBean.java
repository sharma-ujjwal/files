package com.assurant.inc.sox.ar.client.bean.review;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.utils.exceptions.DuplicateReviewNameException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * JSF bean used to control the createReviewPage.xhtml.
 */
@Component("createReviewBean")
@Scope("request")
public class CreateReviewBean {
	private static final Logger log = LoggerFactory.getLogger(CreateReviewBean.class);
	public static final int UPDATE_NAME_MAXSIZE = 30;
	public static final int COMMENT_MAXSIZE = 200;

	private String updateName;
	private String updateComments;
	private String updateReviewType;
	private boolean adHoc;
	private Date updateTargetDate;
	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;

	/**
	 * Returns the review service that can be called to create a new review.
	 * 
	 * @return the review service.
	 */
	public IReviewService getReviewService() {
		return this.reviewService;
	}

	/**
	 * Sets the review service that can be called to create a new review.
	 * 
	 * @param the review service.
	 */
	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	/**
	 * Returns the session data bean for the current session.
	 * 
	 * @return the sessionDataBean.
	 */
	public SessionDataBean getSessionDataBean() {
		return this.sessionDataBean;
	}

	/**
	 * Sets the session data bean for the current session.
	 * 
	 * @param sessionDataBean the sessionDataBean to set.
	 */
	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	/**
	 * Returns the target complete date for the new review.
	 * 
	 * @return the target complete date for the new review.
	 */
	public Date getUpdateTargetDate() {
		return this.updateTargetDate;
	}

	/**
	 * Sets the target complete date for the new review.
	 * 
	 * @param updateTargetDate the updateTargetDate to set.
	 */
	public void setUpdateTargetDate(Date updateTargetDate) {
		this.updateTargetDate = updateTargetDate;
	}

	/**
	 * Returns the comments for the new review.
	 * 
	 * @return the updateComments.
	 */
	public String getUpdateComments() {
		return this.updateComments;
	}

	/**
	 * Sets the comments for the new review.
	 * 
	 * @param updateComments the updateComments to set
	 */
	public void setUpdateComments(String updateComments) {
		this.updateComments = updateComments;
	}

	/**
	 * Returns the name for the new review.
	 * 
	 * @return the updateName.
	 */
	public String getUpdateName() {
		return this.updateName;
	}

	/**
	 * Sets the name for the new review.
	 * 
	 * @param updateName the updateName to set
	 */
	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}

	/**
	 * Returns the review type.
	 * 
	 * @return the updateReviewType
	 */
	public String getUpdateReviewType() {
		return this.updateReviewType;
	}

	/**
	 * Sets the review type.
	 * 
	 * @param updateReviewType the updateReviewType to set
	 */
	public void setUpdateReviewType(String updateReviewType) {
		this.updateReviewType = updateReviewType;
	}

	/**
	 * Cancels the create review and will navigate the user back to the default page (task list).
	 * 
	 * @return the navigation "taskList";
	 */
	public String doCancel() {
		log.debug("doCancel -- enter");

		this.sessionDataBean.initSelectedTasklistBean();

		return "taskList";
	}

	/**
	 * Takes the provided input and creates a new review based on the criteria. On successful creation the user will be navigated to
	 * "createBundle". If an exception flow is hit then the user will be navigated back to the current page and an error message
	 * will be displayed.</br></br> Exception Flows:</br>
	 * <ul>
	 * <li>Type code not provided.</li>
	 * <li>Name not provided</li>
	 * <li>The provided name is in use.</li>
	 * </ul>
	 * 
	 * @return if the creation is successful a navigation of "createBundle" else null.
	 */
	public String doCreate() {
		if (getSessionDataBean().getSystemUser().isPerformReviewActions()) {
			log.debug("doCreate -- enter");
			ReviewTypeCode typeCode = ReviewTypeCode.getByCodeValue(this.updateReviewType);
			if (typeCode == null) {
				JSFUtils.addFacesErrorMessage("A review type must be selected.");
				log.debug("doCreate -- exception flow no type code.");
				return null;
			}
			if (StringUtils.isBlank(this.updateName)) {
				JSFUtils.addFacesErrorMessage("A review name must be provided.");
				log.debug("doCreate -- exception flow no name.");
				return null;
			}
			if ((this.updateName != null) && (this.updateName.length() > UPDATE_NAME_MAXSIZE)) {
				JSFUtils.addFacesErrorMessage("Name may not be longer than " + UPDATE_NAME_MAXSIZE + "characters, is currently "
				    + this.updateName.length() + "characters.");
				log.debug("doCreate -- exception flow no name.");
				return null;
			}
			if (this.updateTargetDate == null) {
				JSFUtils.addFacesErrorMessage("A target date must be provided.");
				log.debug("doCreate -- exception flow no target date.");
				return null;
			}
			if ((this.updateComments != null) && (this.updateComments.length() > COMMENT_MAXSIZE)) {
				JSFUtils.addFacesErrorMessage("Commment may not be longer than " + COMMENT_MAXSIZE + "characters, is currently "
				    + this.updateComments.length() + "characters.");
				log.debug("doCreate -- exception flow commment length.");
				return null;
			}

			try {
				CreateBundleBean bean = (CreateBundleBean) JSFUtils.lookupBean("createBundleBean");
				bean.receive(null, new ReviewUI(this.reviewService.createReview(this.updateName, typeCode, this.updateComments,
				    this.updateTargetDate, this.adHoc)));
				log.debug("doCreate -- review created.");
				return "createBundle";
			} catch (DuplicateReviewNameException e) {
				JSFUtils.addFacesErrorMessage("The selected review name is already in use please enter another name.");
				log.debug("doCreate -- exception flow duplicate name.");
				return null;
			}
		}

		JSFUtils.addFacesErrorMessage("No permissions to perform current action.");
		return "";
	}

	/**
	 * @return true, if ad hoc
	 */
	public boolean isAdHoc() {
		return adHoc;
	}

	/**
	 * @param adHoc the boolean to set ad hoc
	 */
	public void setAdHoc(boolean adHoc) {
		this.adHoc = adHoc;
	}

	public int getUpdateNameMaxsize() {
		return UPDATE_NAME_MAXSIZE;
	}
}
