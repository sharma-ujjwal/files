package com.assurant.inc.sox.ar.utils.exceptions;

public class UnReassignableException extends Exception {

	private static final long serialVersionUID = 1L;

	public UnReassignableException(String errorMessage) {
		super(errorMessage);
	}
}