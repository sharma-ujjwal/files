package com.assurant.inc.sox.ar.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.impl.SystemUserService;
import com.assurant.inc.sox.dao.security.ISecurityFunctionAccessDao;
import org.springframework.stereotype.Component;

@Component
public class SystemUserServiceBase {
    /*
     * logger
     */
    private static final Logger logger= LoggerFactory.getLogger(SystemUserService.class);

	@Autowired
	private SystemUserDTO sessionSystemUser = null;

	@Autowired
	private ISecurityFunctionAccessDao securityFunctionAccessDao;
	

	public ISecurityFunctionAccessDao getSecurityFunctionAccessDao() {
		return securityFunctionAccessDao;
	}

	public void setSecurityFunctionAccessDao(
			ISecurityFunctionAccessDao securityFunctionAccessDao) {
		this.securityFunctionAccessDao = securityFunctionAccessDao;
	}

	public SystemUserDTO getSessionSystemUser() {
		return sessionSystemUser;
	}

	public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
		this.sessionSystemUser = sessionSystemUser;
	}

	public static Logger getLogger() {
		return logger;
	}

}
