package com.assurant.inc.sox.ar.utils.http;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HttpHelper {

	public static final List<String> parseHttpHeaderGroups(String sm_group) {
		List<String> result = new ArrayList<String>();

		if (sm_group != null) {
			Pattern p = Pattern.compile("CN=([^^, ]*)");
			Matcher m = p.matcher(sm_group);

			boolean test = m.find();
			while (test) {
				result.add((m.group(1)));
				test = m.find();
			}
		}
		return result;
	}
}
