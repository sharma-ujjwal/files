package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.ReviewOwner;

public interface IReviewOwnerService {
	public List<ReviewOwner> findActiveSodOwners();
	
}
