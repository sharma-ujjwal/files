package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.ar.FilterType;

public class FilterTypeDTO {

    private final FilterType filterType;

    public FilterTypeDTO(FilterType filterType) {
        this.filterType = filterType;
        
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterType#getFilterTypeValue()
     */
    public String getFilterTypeValue() {
        return this.filterType.getFilterTypeValue();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.domain.ar.FilterType#getId()
     */
    public long getId() {
        Long id = this.filterType.getId();
        return (id == null) ? 0 : id.longValue();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((this.filterType == null) ? 0 : this.filterType.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if(this == obj)
            return true;
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        final FilterTypeDTO other = (FilterTypeDTO) obj;
        if(this.filterType == null){
            if(other.filterType != null)
                return false;
        }
        else if(this.filterType.getId() != other.filterType.getId())
            return false;
        return true;
    }
}
