package com.assurant.inc.sox.ar.dto;

import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.ConflictType;

public class ConflictDTO {

	private Conflict conflict;
	

	public ConflictDTO(Conflict aConflict) {
		super();
		this.conflict = aConflict;
	}

	public ConflictDTO() {
		super();
		conflict = new Conflict();
		conflict.setConflictType(new ConflictType());
	}

	public String getConflictTypeText() {
		return this.conflict.getConflictType().getConflictTypeText();
	}
	
	public Long getId() {
		return this.conflict.getId();
	}

	public Long getLeftConflictId() {
		return this.conflict.getLeftConflictId();
	}

	public String getLeftConflictName() {
		return this.conflict.getLeftConflictName();
	}

	public Long getRightApplicationId() {
		return (ConflictType.CONFLICT_CODE_APP_APP.equals(this.conflict.getConflictType().getConflictCode())) ? this.conflict
		    .getRightConflictId() : null;
	}

	public Long getRightDivisionId() {
		return (ConflictType.CONFLICT_CODE_APP_DIV.equals(this.conflict.getConflictType().getConflictCode())) ? this.conflict
		    .getRightConflictId() : null;
	}

	public String getRightConflictName() {
		return this.conflict.getRightConflictName();
	}

	public void setConflictTypeText(String text) {
		this.conflict.getConflictType().setConflictTypeText(text);
	}

	public void setId(Long id) {
		this.conflict.setId(id);
	}

	public void setLeftConflictId(Long id) {
		this.conflict.setLeftConflictId(id);
	}

	public void setLeftConflictName(String leftConflictName) {
		this.conflict.setLeftConflictName(leftConflictName);
	}

	public void setRightConflictId(Long id) {
		this.conflict.setRightConflictId(id);
	}

	public void setRightConflictName(String rightConflictName) {
		this.conflict.setRightConflictName(rightConflictName);
	}
}
