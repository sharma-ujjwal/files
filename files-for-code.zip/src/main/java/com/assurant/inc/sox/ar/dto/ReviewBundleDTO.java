package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.ReviewBundle;

public class ReviewBundleDTO {

	private final ReviewBundle reviewBundle;
	private final CodeDTO status;

	public ReviewBundleDTO(ReviewBundle reviewBundle, CodeDTO status) {
		this.reviewBundle = reviewBundle;
		this.status = status;
	}

	public ReviewBundle getReviewBundle() {
		return this.reviewBundle;
		
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#getReviewBundleId()
	 */
	public Long getReviewBundleId() {
		return this.reviewBundle.getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#getCreatedDate()
	 */
	public Date getCreatedDate() {
		return this.reviewBundle.getCreatedDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#getReviewId()
	 */
	public Long getReviewId() {
		return this.reviewBundle.getReviewId();
	}

	/**
	 * @param review
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#setReviewId(Long)
	 */
	public void setReviewId(Long reviewId) {
		this.reviewBundle.setReviewId(reviewId);
	}

	public Date getEtlLoadDate() {
		return reviewBundle.getEtlLoadDate();
	}

	public Date getLuadCycleDate() {
		return reviewBundle.getLuadCycleDate();
	}

	public String getTaskProcessId() {
		return reviewBundle.getTaskProcessId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#getStatusCd()
	 */
	public CodeDTO getStatus() {
		return this.status;
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#toString()
	 */
	@Override
	public String toString() {
		return this.reviewBundle.toString();
	}

	public String getCreatedBy() {
		return reviewBundle.getCreatedBy();
	}
	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewBundle#getConflictTypeId()
	 */
	public Long getConflictId() {
		return this.reviewBundle.getConflict().getId();
	}

}
