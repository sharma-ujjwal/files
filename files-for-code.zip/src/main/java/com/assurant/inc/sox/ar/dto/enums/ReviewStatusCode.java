package com.assurant.inc.sox.ar.dto.enums;

import com.assurant.inc.sox.domain.ar.Review;

public enum ReviewStatusCode {
    OUTSTANDING(Review.OUTSTANDING_STATUS_CODE), COMPLETED(
            Review.COMPLETED_STATUS_CODE);

    private final String code;

    private ReviewStatusCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
        
    }
}
