package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the department selection modal panel
 * 
 */
@Component("departmentSelectionBean")
@Scope("session")
public class DepartmentSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(DepartmentSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("DepartmentSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> departments = createBundleBean.getDepartments();
        departments.clear();
        for (SelectAdapter item : chosen) {
            departments.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (DepartmentDTO dept : metaDataService.retrieveDepartments(searchString)) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.DEPARTMENT);
            dto.setFilterValueName(dept.getDepartmentNmCostCenter());
            dto.setFilterValueKey(String.valueOf(dept.getId()));
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        
        if (results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}        
        
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getDepartments()) {
            results.add(adapter);
        }
        return results;
    }
}
