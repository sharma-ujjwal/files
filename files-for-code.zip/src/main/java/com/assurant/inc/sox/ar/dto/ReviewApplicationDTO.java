package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ReviewApplication;

public class ReviewApplicationDTO {
	private final ReviewApplication reviewApplication;

	public ReviewApplicationDTO() {
		super();
		reviewApplication = new ReviewApplication();
	}
	
	public ReviewApplicationDTO(ReviewApplication ra) {
		super();
		reviewApplication = ra;
		
	}

	public ReviewApplication getReviewApplication() {
		return this.reviewApplication;
	}

	public Application getApplication() {
		return reviewApplication.getApplication();
	}

	public String getComment() {
		return reviewApplication.getComment();
	}

	public Long getId() {
		return reviewApplication.getId();
	}

	public String getApplicationUserId() {
		return reviewApplication.getAccessUserId();
	}

	public void setApplication(Application application) {
		reviewApplication.setApplication(application);
	}

	public void setComment(String comment) {
		reviewApplication.setComment(comment);
	}

	public void setId(Long id) {
		reviewApplication.setId(id);
	}

	public void setReviewUserId(Long reviewUserId) {
		reviewApplication.setReviewUserId(reviewUserId);
	}

	public Date getCompleteDate() {
  	return reviewApplication.getValidationCompleteDate();
  }

	
}
