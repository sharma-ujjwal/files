/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.*;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IPrivilegeCommentService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IApplicationDao;
import com.assurant.inc.sox.dao.ar.IExtractSystemDAO;
import com.assurant.inc.sox.dao.ar.IFunctionDutyDao;
import com.assurant.inc.sox.dao.ar.ISoxConcernDao;
import com.assurant.inc.sox.dao.luad.IPrivilegeCommentDao;
import com.assurant.inc.sox.dao.luad.IUserAccessDao;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.ExtractSystem;
import com.assurant.inc.sox.domain.ar.FunctionDuty;
import com.assurant.inc.sox.domain.ar.SoxConcern;
import com.assurant.inc.sox.domain.luad.PrivilegeComment;
import com.assurant.inc.sox.domain.luad.PrivilegeCommentPk;

/**
 * @author Patni
 */  
@Service
// spring
public class PrivilegeCommentService implements IPrivilegeCommentService {

	@Autowired
	private IPrivilegeCommentDao privilegeCommentDao;
	
	
	@Autowired
	private IExtractSystemDAO extractSystemDao;
	
	@Autowired
	private ISoxConcernDao soxConcernDao;

	@Autowired
	private IFunctionDutyDao functionDutyDao;

	@Autowired
	private IApplicationDao applicationDao;

	@Autowired
	private SystemUserDTO systemUser;

	@Autowired
	private IUserAccessDao userAccessDao;

	public PrivilegeCommentService() {
	}

	@Transactional
	public void add(String privDescription,String privValue,Long functionDutyId,
			String comment,String soxConcern,String applicationName){
		Date currentDate = new Date();
		PrivilegeComment privilegeComment= new PrivilegeComment();
		
		PrivilegeCommentPk pkPrivilegeComment = new PrivilegeCommentPk();
		pkPrivilegeComment.setDescription(privDescription);
		pkPrivilegeComment.setValue(privValue);
		pkPrivilegeComment.setFunctionDutyId(functionDutyId);
		pkPrivilegeComment.setEffectiveFromDate(currentDate);
		pkPrivilegeComment.setEffectiveToDate(DateUtil.END_OF_TIME);
		privilegeComment.setPk(pkPrivilegeComment);
		
		
		privilegeComment.setExtractDate(currentDate);
		privilegeComment.setComment(comment);
		privilegeComment.setExtractSystemId(0);
		privilegeComment.setSoxConcern(soxConcern);
		privilegeComment.setApplicationName(applicationName);
		privilegeComment.setDeleteFlag(IFlags.NOT_DELETED);
		privilegeComment.setCreatedBy(this.systemUser.getUserId());
		privilegeComment.setCreatedDate(currentDate);
		
		this.privilegeCommentDao.save(privilegeComment);
		
	}
	@Transactional
	public void delete(PrivilegeComment privilegeComment){
		// create Audit record before any modifications.
		this.createAuditRecord(privilegeComment);

		// Mark existing row with deleted flag as Y, with active from and to as sysdate
		privilegeComment.setLastChangedBy(this.systemUser.getUserId());
		this.privilegeCommentDao.markAsDelete(privilegeComment);
	}

	@Transactional
	public void updateAll(List<PrivilegeComment> privilegeCommentList){
		Date currentDate = new Date();
		for (PrivilegeComment pc:privilegeCommentList){
			// create Audit record before any modifications.
			this.createAuditRecord(pc);

			pc.setLastChangedBy(this.systemUser.getUserId());
			pc.setLastChangedDate(currentDate);
			this.privilegeCommentDao.update(pc);
		}
	}
	
	@Transactional
	public void update(PrivilegeComment privilegeComment){
		// create Audit record before any modifications.
		this.createAuditRecord(privilegeComment);

		privilegeComment.setLastChangedBy(this.systemUser.getUserId());
		privilegeComment.setLastChangedDate(new Date());
		// update method uses query
		//this.privilegeCommentDao.update(privilegeComment); 
		this.privilegeCommentDao.save(privilegeComment);
	}
	
	@Transactional
    public void updatePrivComment(PrivilegeComment privilegeComment, String privValue, String privDesc, 
    		String privComment, Long functionDutyId, String soxConcern, String applicationName){

		// create Audit record before any modifications.
		this.createAuditRecord(privilegeComment);

		this.privilegeCommentDao.updatePrivComment(privValue, privDesc, privComment,
				functionDutyId, soxConcern, applicationName, this.systemUser.getUserId(),
				privilegeComment.getPk().getEffectiveFromDate(), privilegeComment.getPk().getEffectiveToDate());
	}

	public List<PrivilegeComment> retrieveAll() {
		return this.privilegeCommentDao.findAll();
	}
	
	public List<PrivilegeComment> retrieveByValue(String soxConcern,
					String privDescription,String privValue,Long functionDutyId,String applicationName,
					String comment,Long extractSystemId,boolean searchForDuplicate){
		return this.privilegeCommentDao.findByValue(soxConcern, privDescription, privValue,
				functionDutyId, applicationName, comment,extractSystemId,searchForDuplicate);
	}

	public List<String> retrieveDistinctSOXConcerns(){
		List<SoxConcern> scList = this.soxConcernDao.findAll();
		//Sort 
		Collections.sort(scList, new Comparator<SoxConcern>() {
			public int compare(SoxConcern sc1, SoxConcern sc2) {
				return sc1.getSoxConcernCode().compareTo(sc2.getSoxConcernCode());
			}
		});
		List<String> soxList = new ArrayList<String>();
		for (SoxConcern sc:scList){
			if(sc.getSoxConcernCode() !=null)
				soxList.add(sc.getSoxConcernCode());
		}
		return soxList;
	}

	public boolean isDuplicate(String privDescription,String privValue, boolean searchInDelete){
		return this.privilegeCommentDao.doesPrivCommentExists(privDescription,privValue, searchInDelete);
	}

	public List<ExtractSystem> retrieveExtractSystems(){
		return this.extractSystemDao.findAll();
	}
	
	public IPrivilegeCommentDao getPrivilegeCommentDao() {
		return privilegeCommentDao;
	}

	public void setUserDao(IPrivilegeCommentDao privilegeCommentDao) {
		this.privilegeCommentDao = privilegeCommentDao;
	}

	public List<FunctionDuty> retrieveFunctionDuties(){
		return this.functionDutyDao.findAll();
	}

	public List<Application> retrieveApplications(){
		return this.applicationDao.findAll();
	}
    public List<PrivilegeComment> findByFilters(boolean isActive, String soxConcern,
    		String applicationName,String privDescription,String privValue,
    		Long functionDutyId,Long extractSystemId){
    	return this.privilegeCommentDao.findByFilters(isActive, soxConcern, 
    			applicationName, privDescription, privValue, functionDutyId, extractSystemId);
    }
    
	public List<PrivilegeComment> findDeleted(){
		return this.privilegeCommentDao.findDeleted();
	}

	public boolean isAccessActive(String privValue, String privDescription){
		return this.userAccessDao.isPrivCommentAccessActive(privValue, privDescription);
	}

	public void createAuditRecord(PrivilegeComment existingRow){
		Date currentDate = new Date();
		PrivilegeComment auditRow = new PrivilegeComment();
		
		PrivilegeCommentPk auditRowPk = new PrivilegeCommentPk();
		auditRowPk.setDescription(existingRow.getPk().getDescription());
		auditRowPk.setValue(existingRow.getPk().getValue());
		auditRowPk.setFunctionDutyId(existingRow.getPk().getFunctionDutyId());
		auditRowPk.setEffectiveFromDate(existingRow.getPk().getEffectiveFromDate());
		auditRowPk.setEffectiveToDate(DateUtils.addSeconds(currentDate, -1));
		auditRow.setPk(auditRowPk);
		
		auditRow.setSoxConcern(existingRow.getSoxConcern());
		auditRow.setApplicationName(existingRow.getApplicationName());
		auditRow.setExtractDate(existingRow.getExtractDate());
		auditRow.setExtractSystemId(existingRow.getExtractSystemId());

		auditRow.setCreatedDate(existingRow.getCreatedDate());
		auditRow.setCreatedBy(existingRow.getCreatedBy());
		auditRow.setLastChangedDate(existingRow.getLastChangedDate());
		auditRow.setLastChangedBy(existingRow.getLastChangedBy());
		auditRow.setDeleteFlag(existingRow.getDeleteFlag());
		auditRow.setComment(existingRow.getComment());
		
		this.privilegeCommentDao.save(auditRow);
	}
	
    public boolean isActivePrivilegeComment(PrivilegeComment privComment){
    	return this.privilegeCommentDao.isActivePrivilegeComment(privComment);
    	
    }
}  
