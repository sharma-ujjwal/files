package com.assurant.inc.sox.ar.client.ui.tasklist;

import com.assurant.inc.sox.ar.client.ui.ISelectableUI;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.domain.ar.Review;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ReviewerTaskListUI extends AbstractTaskListUI implements ISelectableUI {
	
	private boolean selected;

	public ReviewerTaskListUI() {
		super(); // Calls the no-args constructor of AbstractTaskListUI
	}

	@Override
	protected AbstractTaskListDTO createDefaultTaskListDTO() {
		return new ReviewerTaskListDTO(null, null);
	}

	@Autowired
	public ReviewerTaskListUI(ReviewerTaskListDTO taskList) {
		super(taskList);
	}

	@Override
	public Long getBackingEntiyId() {
		if(((ReviewerTaskListDTO)this.taskList).getReviewer() == null){
			return null;
		}
		return ((ReviewerTaskListDTO)this.taskList).getReviewer().getReviewerId();
	}

	public boolean isSelected() {
    	return selected;
    }

	public void setSelected(boolean selected) {
    	this.selected = selected;
    }
	
	@Override
  public String getBackingEntityName() {
		return "Reviewer Id";
	}
}
