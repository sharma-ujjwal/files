package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Division;

public class DivisionDTO {

    private final Division division;

    public DivisionDTO() {
        this(new Division());
    }
    

    public DivisionDTO(Division division) {
        this.division = division;
    }

    public Division getDivision() {
        return this.division;
    }

    public long getId() {
        Long id = this.division.getId();
        return (id == null) ? 0 : id.longValue();
    }

    public String getName() {
        return this.division.getName();
    }

    public void setId(long id) {
        this.division.setId((id == 0)  ? null : (id));
    }

    public void setName(String name) {
        this.division.setName(name);
    }

    @Override
    public String toString() {
        return this.division.toString();
    }

    public Date getActiveFromDate() {
		return this.division.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.division.getActiveToDate();
	}
}
