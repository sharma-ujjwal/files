package com.assurant.inc.sox.ar.client.ui;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.UserDataDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;

public class UserDataUI {

    private final UserDataDTO userData;

    public UserDataUI() {
        this.userData = new UserDataDTO();
    }

    public UserDataUI(UserDataDTO userData) {
        this.userData = userData;
    }

    /**
     * @return the userData
     */
    public UserDataDTO getUserData() {
        return this.userData;
    }

    /**
     * @return
     * @see com.assurant.inc.sox.ar.dto.UserDataDTO#getDepartment()
     */
    public String getDepartment() {
        DepartmentDTO department = this.userData.getDepartment();
        return (department == null) ? null : department.getName();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.ar.dto.UserDataDTO#getEmailAddress()
     */
    public String getEmailAddress() {
        return this.userData.getEmailAddress();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.ar.dto.UserDataDTO#getName()
     */
    public String getName() {
        return this.userData.getName();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.ar.dto.UserDataDTO#getStatus()
     */
    public String getStatus() {
        UserStatusDTO status = this.userData.getStatus();
        return (status == null) ? null : status.getUserStatusDescription();
    }

    /**
     * @return
     * @see com.assurant.inc.sox.ar.dto.UserDataDTO#getUserId()
     */
    public long getUserId() {
        return this.userData.getUserId();
    }

	public void setReassignedInstructions(String reassignedInstructions) {
		userData.setReassignedInstructions(reassignedInstructions);
	}

	public void setReassignedTargetCompleteDate(
			Date reassignedTargetCompleteDate) {
		userData.setReassignedTargetCompleteDate(reassignedTargetCompleteDate);
	}

	public String getOwnerTypeDescription() {
		return this.userData.getOwnerTypeDescription();
	}
}
