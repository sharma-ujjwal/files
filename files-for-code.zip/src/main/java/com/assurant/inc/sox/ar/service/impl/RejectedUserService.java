package com.assurant.inc.sox.ar.service.impl;

import com.assurant.inc.sox.ar.client.admin.ui.RejectedUserUI;
import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.*;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IRejectedUserDAO;
import com.assurant.inc.sox.dao.ar.ISupervisorDao;
import com.assurant.inc.sox.domain.ar.*;
import com.assurant.inc.sox.domain.luad.InternalIdentifierType;
import com.assurant.inc.sox.domain.luad.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class RejectedUserService implements IRejectedUserService {

	@Autowired
	private IRejectedUserDAO rejectedUserDAO;
	@Autowired
	private IUserService userService;
	@Autowired
	private IInternalIdentifierTypeService internalIdentifierTypeService;
	@Autowired
	private IUserAkaService userAkaService;	
	
	@Autowired
	private IExtractSystemService extractSystemService;
	@Autowired
	private IDepartmentService departmentService;
	@Autowired
	private IDivisionService divisionService;
	@Autowired
	private IUserTypeService userTypeService;
	@Autowired
	private IUserStatusService userStatusService;
	
	@Autowired
	private ISupervisorDao supervisorDao;

	@Autowired
	private SystemUserDTO systemUser;

	public IRejectedUserDAO getRejectedUserDAO() {
		return rejectedUserDAO;
	}

	public void setRejectedUserDAO(IRejectedUserDAO rejectedUserDAO) {
		this.rejectedUserDAO = rejectedUserDAO;
	}

	private List<SelectItem> availableUserType;
	private List<SelectItem> availableDepartment;
	private List<SelectItem> availableDivision;

	public List<RejectedUserUI> findAll() {
		List<RejectedUser> rejectedUserRetrieved;
		List<RejectedUserUI> rejectedUserList;
		rejectedUserRetrieved = this.rejectedUserDAO.findAll();
		rejectedUserList = convertToUI(rejectedUserRetrieved);
		return rejectedUserList;
	}

	public List<RejectedUserUI> findByValue(String srcUserId,
			Long extrctSysId, String selectedDateCriteria,
			Date createdDateCriteria) {
		List<RejectedUser> rejectedUserRetrieved;
		List<RejectedUserUI> rejectedUserList;
		rejectedUserRetrieved = this.rejectedUserDAO.findByValue(srcUserId,
				extrctSysId, selectedDateCriteria, createdDateCriteria);
		rejectedUserList = convertToUI(rejectedUserRetrieved);
		return rejectedUserList;
	}

	public List<RejectedUserUI> convertToUI(
			List<RejectedUser> rejectedUserRetrieved) {
		List<RejectedUserUI> rejectedUserList = new ArrayList<RejectedUserUI>();
		for (RejectedUser rejectedUser : rejectedUserRetrieved) {
			RejectedUserUI rejectedUserUI = new RejectedUserUI(rejectedUser);
			if (rejectedUser.getSrcUserName() == null
					|| "".equals(rejectedUser.getSrcUserName())) {
				rejectedUserUI.setShowAddUser(true);

			} else {
				rejectedUserUI.setShowSearchUser(true);
			}

			rejectedUserList.add(rejectedUserUI);
		}
		return rejectedUserList;
	}

	@Transactional
	public void addUser(String keyId, String firstName, String middleName,
			String lastName, Long userTypeId, Long departmentId,
			Long divisionId, String location, String jobTitle,
			Long supervisorId, String bsnssSgmnt,
			String phone, String emailAddress, Long userStatusId,
			String satStatus, String satJobRole, String satComment,
			Long rejectedUserId, Long extractSysId, Date extractSysDate) {

		// Add user in SDT025
		this.userService.addUser(keyId, firstName, middleName, lastName, userTypeId,
				departmentId, divisionId, location, jobTitle, supervisorId,
				bsnssSgmnt, phone, emailAddress, userStatusId,
				satStatus, satJobRole, satComment, extractSysId, extractSysDate);

		// Delete userfrom SDT199_RJCTD_USR
		if(rejectedUserId!=null){
			RejectedUser rejectedUser = this.rejectedUserDAO.findByRejectedUserId(rejectedUserId);
			//there could be multiple rejected users existing with same keyId/AltId(srcUserId)
			// need to reconcile all ids.
			List<RejectedUser> rejectedList = this.rejectedUserDAO.findBySrcUserId(rejectedUser.getSrcUserId());
			for (RejectedUser rjct: rejectedList){
				rjct.setDeleteFlag(IFlags.DELETED);
				rjct.setLastChangedBy(systemUser.getUserId());
				rjct.setLastChangedDate(new Date());
				this.rejectedUserDAO.save(rjct);
			}
		}
	}

	public List<SelectItem> getAvailableInternalIdentifierType() {
		List<InternalIdentifierType> iList = this.internalIdentifierTypeService
				.findAll();
		ArrayList<SelectItem> availableInternalIdentifierType = new ArrayList<SelectItem>();
		for (InternalIdentifierType iType : iList) {
			if(iType.getIntrnlIdntfyrDescr()!=null)
				availableInternalIdentifierType.add(new SelectItem(iType.getIntrnlIdntfyrTypCd(), 
						iType.getIntrnlIdntfyrDescr()));
		}
		return availableInternalIdentifierType;
	}

	public String getAlternateIds(String keyId) {

		//List<UserLookup> userLookupList = userLookupService.findByKeyId(keyId);
		StringBuffer alternateIds = new StringBuffer();
		//int i = 1;
		//for (UserLookup userLookup : userLookupList) {
		//	alternateIds.append(i + ". " + userLookup.getId().getAltId() + " ");
		//	i++;
		//}
		return alternateIds.toString();
	}
/*
	// @Transactional
	public void saveAlternateId(String keyId, String lookUpAltId,
			Long rejectedUserId, Long userId, Long internalIdentifierType) {

		// testing remve comment
		// userLookupService.save(keyId, lookUpAltId);
		// rejectedUserDAO.update(rejectedUserId);
		this.userAkaService.save(userId, internalIdentifierType, lookUpAltId);
		this.userService.addAlternateId(keyId, lookUpAltId, userId,
				internalIdentifierType);

	}
*/	
	@Transactional
	public void updateUser(Long rejectedUserId, Long userId, String keyId, 
			String firstNm, String mddlNm, String lastNm, Long userTypeId, 
			Long departmentId, Long divisionId, String location, String jobTitle,
			Long supervisorId, String costCenter, String bsnssSgmnt,
			String phone, String emailAddress, Long userStatusId,
			String satStatus, String satJobRole, String satComment) {

		this.userService.updateRejectedUser(userId, firstNm, mddlNm, lastNm, userTypeId, 
				departmentId, divisionId, location, jobTitle, supervisorId, 
				costCenter, bsnssSgmnt, phone, emailAddress, userStatusId, satStatus, satJobRole, satComment);
		
		//this.rejectedUserDAO.update(rejectedUserId);
		if(rejectedUserId != null){
			RejectedUser rejectedUser = this.rejectedUserDAO.findByRejectedUserId(rejectedUserId);
			//this.rejectedUserDAO.delete(rejectedUser);
			//there could be multiple rejected users existing with same keyId/AltId(srcUserId)
			// need to reconcile all ids.
			List<RejectedUser> rejectedList = this.rejectedUserDAO.findBySrcUserId(rejectedUser.getSrcUserId());
			for (RejectedUser rjct: rejectedList){
				rjct.setDeleteFlag(IFlags.DELETED);
				rjct.setLastChangedBy(systemUser.getUserId());
				rjct.setLastChangedDate(new Date());
				this.rejectedUserDAO.save(rjct);
				//this.rejectedUserDAO.delete(rjct);
			}
		}

	}
	public void updateAltIdsForUser(Long userId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3){
		this.userService.updateAltIdsForUser(userId, satMFId, satGFId, 
				satCFId, satLCSId, satFDMSId, satSiteminderId, satAltId1, satAltId2, satAltId3);
	}

	public void updateAltIds(Long rejectedUserId, Long userId, String keyId, String emailAddress,
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3) {
		this.userService.updateAltIds(userId, keyId, emailAddress, satMFId, satGFId, satCFId, 
				satLCSId, satFDMSId, satSiteminderId, satAltId1, satAltId2, satAltId3);
		if(rejectedUserId != null){
			RejectedUser rejectedUser = this.rejectedUserDAO.findByRejectedUserId(rejectedUserId);
			//there could be multiple rejected users existing with same keyId/AltId(srcUserId)
			// need to reconcile all ids.
			List<RejectedUser> rejectedList = this.rejectedUserDAO.findBySrcUserId(rejectedUser.getSrcUserId());
			for (RejectedUser rjct: rejectedList){
				rjct.setDeleteFlag(IFlags.DELETED);
				rjct.setLastChangedBy(systemUser.getUserId());
				rjct.setLastChangedDate(new Date());
				this.rejectedUserDAO.save(rjct);
			}
		}
		
	}

	public List<User> findByUserName(String searchFirstName,String searchLastName){
		return this.userService.findByUserName(searchFirstName,
				searchLastName);
	}

	public List<UserStatus> findUserStatusList() {
		return this.userService.findUserStatusList();
	}

	public void populatSupevisorData(Long supervisor) {
		this.userService.populatSupevisorData(supervisor);
	}

	public List<SelectItem> populateSupevisorBusinessSegments(Long supervisor) {
		return this.userService.populateSupevisorBusinessSegments(supervisor);
	}

	public List<SelectItem> populateSupevisorCostCenters(Long supervisor) {
		return this.userService.populateSupevisorCostCenters(supervisor);
	}

	public List<SelectItem> populateSupevisorDepartments(Long supervisor) {
		return this.userService.populateSupevisorDepartments(supervisor);
	}

	public List<SelectItem> populateSupevisorDivisions(Long supervisor) {
		return this.userService.populateSupevisorDivisions(supervisor);
	}

	public List<SelectItem> populateSupevisorJobTitles(Long supervisor,
			String existingJobTitle) {
		return this.userService.populateSupevisorJobTitles(supervisor, existingJobTitle);
	}

	public List<SelectItem> populateSupevisorLocations(Long supervisor,
			String existingLocation) {
		return this.userService.populateSupevisorLocations(supervisor, existingLocation);
	}

	public List<String> retrieveAllBusinessSeg() {
		return this.userService.retrieveAllBusinessSeg();
	}

	public List<String> retrieveAllCostCenter() {
		return this.userService.retrieveAllCostCenter();
	}

	public List<Department> retrieveAllDepartments() {
		return this.userService.retrieveAllDepartments();
	}

	public List<Division> retrieveAllDivisions() {
		return this.userService.retrieveAllDivisions();
	}

	public List<UserType> retrieveAllUserTypes() {
		return this.userService.retrieveAllUserTypes();
	}

	public List<ExtractSystem> retrieveExtractSystems() {
		return this.extractSystemService.findAll();
	}
	
	public List<Supervisor> retrieveAllSupervisors() {
		return this.supervisorDao.findAll();
	}

	public String findUserExist(Long excludeUserId, String searchKeyId, String satMFId, String satGFId, 
			String satCFId, String satLCSId,String satFDMSId, String satSiteminderId, 
			String searchSatAltId1,	String searchSatAltId2, String searchSatAltId3) {

		return this.userService.findUserExist(excludeUserId, searchKeyId, satMFId, satGFId, 
				satCFId, satLCSId, satFDMSId, satSiteminderId, 
				searchSatAltId1, searchSatAltId2, searchSatAltId3);
		
	}

	public boolean isAltIdExists(String altId){
		return this.userService.isAltIdExists(altId);
	}

	public List<UserUI> searchAssociatedUser(String searchFirstNm,
			String searchLastNm, String keyId, Long supervisorId,
			List userStatuses, List userTypes,
			List departments, List divisions, String location) {
		return this.userService.searchAssociatedUser(searchFirstNm, searchLastNm, keyId,
				supervisorId, userStatuses, userTypes, departments, divisions, location);
	}
	
	public List<User> findUsersBySupevisorId(Long supervisorId){
		return this.userService.findUsersBySupevisorId(supervisorId);
	}

	public RejectedUser findByRejectedUserId(Long rejectedUserId){
		return this.rejectedUserDAO.findByRejectedUserId(rejectedUserId);
	}
	
	public List<RejectedUser> findBySrcUserId(String srcUserId){
		return this.rejectedUserDAO.findBySrcUserId(srcUserId);
	}

	public void reconcileRejects(){
		System.out.println("************* reconcileRejects : systemUser.getUserId() : "+systemUser.getUserId());
		this.rejectedUserDAO.reconcileRejects(systemUser.getUserId());
/*		
		List<RejectedUser> rejectedList = this.rejectedUserDAO.findAll();
		//Check against User table for reconciliation
		for (RejectedUser rjct: rejectedList){
			String rejectedUserId = rjct.getSrcUserId();

			String userExistMsg = this.userService.findUserExist(-1L, rejectedUserId,
					rejectedUserId, rejectedUserId, rejectedUserId, rejectedUserId, 
					rejectedUserId, rejectedUserId,	
					rejectedUserId, rejectedUserId, rejectedUserId);
			if (!"".equals(userExistMsg)) {
				rjct.setDeleteFlag(IFlags.DELETED);
				rjct.setLastChangedBy(systemUser.getUserId());
				rjct.setLastChangedDate(new Date());
				this.rejectedUserDAO.save(rjct);
			}
		}
*/
	}
	
}
