package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Review;

public class ReviewDashboardDTO extends ReviewDTO {

	private int numberOfReportsDistributed;
	private int numberOfReportsAttested;
	private float percentageOfReportsAttested;
	private int numberOfUsersIncluded;
	private int numberOfUsersAttested;
	private float percentageOfUsersAttested;
	private int numberOfNonRejectedReports;
	private int numberOfOverdueReports;
	private float percentageOfOverdueReports;
	

	public ReviewDashboardDTO(Review review, CodeDTO typeCode, CodeDTO statusCode) {
		super(review, typeCode, statusCode);
	}

	public String getName() {
		return getReviewName();
	}

	public int getNumberOfReportsDistributed() {
		return numberOfReportsDistributed;
	}

	public void setNumberOfReportsDistributed(int numberOfReportsDistributed) {
		this.numberOfReportsDistributed = numberOfReportsDistributed;
	}

	public int getNumberOfReportsAttested() {
		return numberOfReportsAttested;
	}

	public void setNumberOfReportsAttested(int numberOfReportsAttested) {
		this.numberOfReportsAttested = numberOfReportsAttested;
	}

	public float getPercentageOfReportsAttested() {
		return percentageOfReportsAttested;
	}

	public void setPercentageOfReportsAttested(float percentageOfReportsAttested) {
		this.percentageOfReportsAttested = percentageOfReportsAttested;
	}

	public int getNumberOfUsersIncluded() {
		return numberOfUsersIncluded;
	}

	public void setNumberOfUsersIncluded(int numberOfUsersIncluded) {
		this.numberOfUsersIncluded = numberOfUsersIncluded;
	}

	public int getNumberOfUsersAttested() {
		return numberOfUsersAttested;
	}

	public void setNumberOfUsersAttested(int numberOfUsersAttested) {
		this.numberOfUsersAttested = numberOfUsersAttested;
	}

	public float getPercentageOfUsersAttested() {
		return percentageOfUsersAttested;
	}

	public void setPercentageOfUsersAttested(float percentageOfUsersAttested) {
		this.percentageOfUsersAttested = percentageOfUsersAttested;
	}

	public Date getDateReviewCreated() {
		return this.getCreatedDate();
	}

	@Override
	public Long getReviewId() {
		return super.getReviewId();
	}

	public int getNumberOfNonRejectedReports() {
		return numberOfNonRejectedReports;
	}

	public void setNumberOfNonRejectedReports(int numberOfNonRejectedReports) {
		this.numberOfNonRejectedReports = numberOfNonRejectedReports;
	}

	public int getNumberOfOverdueReports() {
		return numberOfOverdueReports;
	}

	public void setNumberOfOverdueReports(int numberOfOverdueReports) {
		this.numberOfOverdueReports = numberOfOverdueReports;
	}

	public float getPercentageOfOverdueReports() {
		return percentageOfOverdueReports;
	}

	public void setPercentageOfOverdueReports(float percentageOfOverdueReports) {
		this.percentageOfOverdueReports = percentageOfOverdueReports;
	}
}
