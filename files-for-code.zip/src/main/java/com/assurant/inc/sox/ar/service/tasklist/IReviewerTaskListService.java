package com.assurant.inc.sox.ar.service.tasklist;

import java.util.List;

import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.utils.exceptions.TaskException;

public interface IReviewerTaskListService {
	/**
     * Retrieves all of the task list items for a reviewer.
     * 
     * @return the task list items for a reviewer. If no task list items are found then an empty
     *         list will be returned.
     */
	public List<ReviewerTaskListDTO> retrieveTaskListForReviewer()throws TaskException;
	
	/**
	 * Retrieve all of the task list items for all reviewers
     * @return the task list items for all reviewers. If no task list items are found then an empty
     *         list will be returned. 
	 */
	public List<ReviewerTaskListDTO> retrieveTaskListForAllReviewers()throws TaskException;

	
	public List<ReviewerTaskListDTO> retrieveTaskListForReviewersTeam()throws TaskException;
}
