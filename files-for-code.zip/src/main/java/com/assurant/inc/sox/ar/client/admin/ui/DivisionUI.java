package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.Division;
import java.util.Date;

public class DivisionUI {
	private final Division division;
	private boolean checked;

	public DivisionUI(Division division) {
		this.division = division;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.division.getId();
	}

	public String getName() {
		return this.division.getName();
	}

	public String getDeleteFlag() {
		return this.division.getDeleteFlag();
	}

	public Division getDivision() {
		return division;
	}

	public String getCreatedBy() {
		return this.division.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.division.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.division.getLastChangedBy();
	}
	
	public Date getLastChangedDate() {
		return this.division.getLastChangedDate();
	}

	public Date getActiveFromDate() {
		return this.division.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.division.getActiveToDate();
	}
}
