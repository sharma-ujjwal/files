package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Environment;

public class EnvironmentDTO {

    private final Environment environment;

    public EnvironmentDTO() {
        this(new Environment());
    }
    

    public EnvironmentDTO(Environment environment) {
        this.environment = environment;
    }

    public Environment getEnvironment() {
        return this.environment;
    }

    public long getId() {
        Long id = this.environment.getId();
        return (id == null) ? 0 : id.longValue();
    }

    public String getName() {
        return this.environment.getName();
    }

    public void setId(long id) {
        this.environment.setId((id == 0)  ? null : id);
    }

    public void setName(String name) {
        this.environment.setName(name);
    }

    @Override
    public String toString() {
        return this.environment.toString();
    }
    
    public Date getActiveFromDate() {
		return this.environment.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.environment.getActiveToDate();
	}

}
