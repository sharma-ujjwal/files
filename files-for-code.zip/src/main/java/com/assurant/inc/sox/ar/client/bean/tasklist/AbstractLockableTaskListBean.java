package com.assurant.inc.sox.ar.client.bean.tasklist;

import java.util.List;

import javax.faces.component.html.HtmlGraphicImage;
import javax.faces.component.html.HtmlOutputText;

import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.tasklist.AbstractTaskListUI;
import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListField;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListFilterType;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.service.ILockService;
import com.assurant.inc.sox.ar.service.impl.LockService;
import com.assurant.inc.sox.consts.TaskTypeCode;

import org.primefaces.component.column.Column;
import org.primefaces.component.datatable.DataTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.text.SimpleDateFormat;

public abstract class AbstractLockableTaskListBean<T extends AbstractTaskListUI, K extends AbstractTaskListDTO> extends
    AbstractTaskListBean<T, K> {

	@Autowired
	@Qualifier("lockService")
	protected LockService lockService;
	protected boolean renderLockPanel;
	protected String lockPanelMessage;
	protected String typeCodeParam;
	protected String taskProcessId;
	protected AbstractTaskListDTO abstractTaskListDTO;

	// --------------------------- faces injected properties --------------------

	public LockService getLockService() {
		return lockService;
	}

	public void setLockService(LockService lockService) {
		this.lockService = lockService;
	}

	// ------------------------------ page properties ---------------------------
	public boolean isRenderLockPanel() {
		return renderLockPanel;
	}

	public String getLockPanelMessage() {
		return lockPanelMessage;
	}

	// -------------------------
	public AbstractLockableTaskListBean(TaskListFilterType filterType, String beanName, String idPrefix) {
		super(filterType, beanName, idPrefix);
	}

	protected Column buildLockColumn() {
		HtmlGraphicImage image = new HtmlGraphicImage();
		image.setUrl("/images/icon-locked.gif");
		image.setId(this.idPrefix + "LockImage");
		JSFUtils.setValueBinding(image, "title", this.buildFieldBinding(TaskListField.LOCKED_BY.getFieldName()));
		JSFUtils.setValueBinding(image, "rendered", this.buildFieldBinding(TaskListField.IS_LOCKED.getFieldName()));

		return HtmlTableBuilderUtil.buildColumn(new HtmlOutputText(), image);
	}

	protected void prepareLockModalPanel(LockDTO taskLock, String typeCode, String taskId) {
		StringBuilder sb = new StringBuilder();
		sb.append("Task is currently locked by ");
		sb.append(taskLock.getHolder());
		sb.append(" on ");
		sb.append(new SimpleDateFormat("MM/dd/yyyy").format(taskLock.getCreated()));
		sb.append(".  Do you want to break the lock?");
		this.lockPanelMessage = sb.toString();
		this.renderLockPanel = true;

		this.typeCodeParam = typeCode;
		this.taskProcessId = taskId;
	}

	public String doCloseLockPanel() {
		this.renderLockPanel = false;
		return null;
	}

	public boolean isUserHolder(LockDTO taskLock) {
		return  (taskLock.isLockedBy(this.sessionDataBean.getSystemUser().getUserId())); 
	}

	public String doBreakLock() {
		this.renderLockPanel = false;
		this.lockService.breakLock(this.taskProcessId);
		return processTask(this.typeCodeParam, this.taskProcessId, this.getAbstractTaskListDTO());
	}

	@SuppressWarnings("unchecked")
	protected AbstractTaskListDTO extractSelectedTaskListDTO(String taskId, AbstractTaskListDTO taskListDTO) {
		// get the selected bundle and review
		AbstractTaskListDTO selectedTask;
		taskListDTO = taskListDTO == null ? abstractTaskListDTO : taskListDTO;

		if (taskId.equals(getAbstractTaskListDTO().getTaskId())) {
			selectedTask = taskListDTO;
		} else {
			selectedTask = null;
		}

		if (selectedTask == null) {
			throw new RuntimeException("The selected savvion id could not be found.  Id: " + taskId);
		}

		return selectedTask;
	}

	protected boolean isTaksLockable(String taskTypeCode) {
		return TaskTypeCode.REVIEW_SUMMARY.getCode().equals(taskTypeCode)
		    || TaskTypeCode.REVIEW_DETAILS.getCode().equals(taskTypeCode)
		    || TaskTypeCode.VALIDATE_ACTION_REQUIERED.getCode().equals(taskTypeCode)
		    || TaskTypeCode.VALIDATE_REJECT_USER.getCode().equals(taskTypeCode);
	}

	protected abstract String processTask(String typeCode, String taskId, AbstractTaskListDTO taskListDTO);

	public AbstractTaskListDTO getAbstractTaskListDTO() {
		return abstractTaskListDTO;
	}

	public void setAbstractTaskListDTO(AbstractTaskListDTO abstractTaskListDTO) {
		this.abstractTaskListDTO = abstractTaskListDTO;
	}
}
