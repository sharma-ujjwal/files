package com.assurant.inc.sox.ar.dto.enums.reviewer;

public enum ReviewerField {
	BUNDLE_NAME("bundleName"), REVIEWER_NAME("currentReviewerName"), DEPARTMENT(
			"department"), TARGET_DUE_DATE("distributionTargetCompleteDate"), NUMBER_OF_REVIEWED_USERS(
			"numberOfReviewedUsers"), DATE_CREATED("createdDate"), DATE_SENT(
			"sentDate"), SENT_BY("sentBy"), DATE_REJECTED("rejectDate"), REJECTED_BY(
			"rejectedBy"), REJECT_CODE("rejectCode"), REJECT_CODE_DISPLAY(
			"rejectCodeDisplay"), REJECT_COMMENTS("rejectComment"), APPLICATION(
			"application"), NUMBER_OF_DEPARTMENTS("numberOfDepartments"), STATUS(
			"reviewerStatus"), OWNER("ownerName"), DISTINCT_EMP_STATUSES(
			"distinctEmployeeStatuses"), ID("reviewerId"), DIVISION("division"), ESCALATION_MGR(
			"escalationMgrName"), SOD_OWNER("ownerName"), SOD_CONFLICT_TYPE("conflictType"), 
			SOD_CONFLICT_DISPLAY("conflictTypeDisplayName");

	private final String fieldName;

	private ReviewerField(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return this.fieldName;
	}
}
