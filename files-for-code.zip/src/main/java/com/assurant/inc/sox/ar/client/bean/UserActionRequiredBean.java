package com.assurant.inc.sox.ar.client.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandbutton.CommandButton;
import org.primefaces.component.commandlink.CommandLink;

import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewDashboardUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.client.ui.UserActionRequiredUI;
import com.assurant.inc.sox.ar.client.ui.WorkOrderUI;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.UserActionRequiredDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.IUserActionRequiredService;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("userActionRequiredBean")
@Scope("session")
public class UserActionRequiredBean {
	private static final Logger logger = LoggerFactory.getLogger(UserActionRequiredBean.class);
	private static final String COMPLETE_ITEM_PARAM_NAME = "completeItemActionParam";
	private static final String REVIEWER_COMMENT_PARAM_NAME = "reviewerCommentActionParam";
	private static final int MAX_COMMENT_LENGTH = 1000;
	private DataTable workOrderTable;
	private DataTable actionReqListTable;
	private List<UserActionRequiredUI> selectedUserActionReqUIs;
	@Autowired
	@Qualifier("userActionRequiredService")
	private IUserActionRequiredService userActionRequiredService;
	private ReviewUI review;
	private ReviewerUI reviewer;
	private ReviewBundleUI reviewBundle;
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	private String appName;
	private boolean renderReviewerCommentModalPanel;
	private boolean renderAddActivityModalPanel;
	private boolean renderCompleteActionTaskButton;
	private String commentsInput;
	private String selectReasonInput;
	private String workOrderNo;
	private String selectedAccessLineNos;
	private String reviewerComment;
	private String taskProcessId;
	private Date validateDate;
	private ActionRequiredTasklistDTO actionRequiredTasklistDTO;
	private boolean renderAttestConfirmationModalPanel;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private boolean renderWOTable;
	
	// CR#7 pagination
	private Integer displayAmount = 25;
	private List<SelectItem> availableValidateRowDisplayItems;

	/**
	 * The available row counts used for table row display.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableValidateRowDisplayItems() {
		synchronized (this) {
			if (this.availableValidateRowDisplayItems == null) {
				logger.debug("constructor -- row display");
				// init the number of row displays (table rows to display)
				List<SelectItem> availableRowDisplayItemsLoc = new ArrayList<SelectItem>(4);
				availableRowDisplayItemsLoc.add(new SelectItem("25", "25"));
				availableRowDisplayItemsLoc.add(new SelectItem("50", "50"));
				availableRowDisplayItemsLoc.add(new SelectItem("75", "75"));
				availableRowDisplayItemsLoc.add(new SelectItem("100", "100"));
				availableRowDisplayItemsLoc.add(new SelectItem("200", "200"));
				availableRowDisplayItemsLoc.add(new SelectItem("250", "250"));
				availableRowDisplayItemsLoc.add(new SelectItem("300", "300"));
				this.availableValidateRowDisplayItems = Collections.unmodifiableList(availableRowDisplayItemsLoc);
			}
		}
		return this.availableValidateRowDisplayItems;
	}

	public Integer getDisplayAmount() {
		return this.actionReqListTable.getRows();
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.actionReqListTable.setRows(displayAmount);
	}

	// ----------------------------- faces injected properties start ----------------
	public IUserActionRequiredService getUserActionRequiredService() {
		return userActionRequiredService;
	}

	public void setUserActionRequiredService(IUserActionRequiredService userActionRequiredService) {
		this.userActionRequiredService = userActionRequiredService;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	// ----------------------------- faces injected properties end----------------

	/**
	 * Initializes the action required bean.
	 * @param actionRequiredTasklistDTO the action required task list transfer object.
	 * @param taskProcessId the savvion process id for complete task.
	 */
	public void initActionRequired(ActionRequiredTasklistDTO actionRequiredTasklistDTO, String taskProcessId) {
		logger.debug("initActionRequired() --> being executed.");
		this.review = new ReviewUI(actionRequiredTasklistDTO.getReview());
		ReviewerDTO reviewerDTO = actionRequiredTasklistDTO.getReviewer();
		this.reviewerService.populateReviewerDistinctEnvName(reviewerDTO);
		this.reviewer = new ReviewerUI(reviewerDTO);
		this.reviewBundle = new ReviewBundleUI(actionRequiredTasklistDTO.getReviewBundle());
		this.actionReqListTable = buildActionReqListTable(actionRequiredTasklistDTO);
		this.workOrderTable = buildWorkOrderTable();
		this.appName = actionRequiredTasklistDTO.getApplication().getName();
		this.taskProcessId = taskProcessId;
		this.actionRequiredTasklistDTO = actionRequiredTasklistDTO;
		//doInactiveCompleteActionItem();
	}

	// ----------------------------- Page Actions Start -----------------------------
	/**
	 * Adds the work order for the selected action required items.
	 * @return null to return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doAddActivity() {
		logger.debug("doAddActivity() --> being executed.");
		try {
			List<String> accessLineNoList = new ArrayList<String>();
			this.selectedUserActionReqUIs = extractSelectedActionItems((List<UserActionRequiredUI>) this.getActionReqListTable()
			    .getValue());
			for (UserActionRequiredUI actionItem : selectedUserActionReqUIs) {
				accessLineNoList.add(Integer.toString(actionItem.getRowIndex()));
			}
			this.selectedAccessLineNos = DisplayStringBuilder.buildCommaDelimitedList(accessLineNoList);
			this.commentsInput = null;
			this.selectReasonInput = null;
			this.workOrderNo = null;
			this.renderAddActivityModalPanel = true;
		} catch (InvalidActionItemSelectionException e) {
			JSFUtils
			    .addFacesErrorMessage("An invalid number of action items were selected.  At least one action item must be selected to add activity.");
			this.renderAddActivityModalPanel = false;
		}
		return null;
	}

	/**
	 * Cancels the add activity panel.
	 * @return null return to the same page.
	 */
	public String doCancelAddActivityPanel() {
		logger.debug("doCancelAddActivityPanel() --> being executed.");
		this.renderAddActivityModalPanel = false;
		return null;
	}

	/**
	 * Completes all the selected action required items - bulk complete
	 * @return null rerun to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doBulkCompleteActionItem() {
		logger.debug("doBulkCompleteActionItem() --> being executed.");
		synchronized (this.getActionReqListTable()){

			try {
				List<UserActionRequiredUI> currentPageselectedUserActionReqUIs;
				currentPageselectedUserActionReqUIs = extractSelectedActionItems((List<UserActionRequiredUI>) this.getActionReqListTable()
				    .getValue());
				this.userActionRequiredService.validateUsersAccesses(wrapActionItems(currentPageselectedUserActionReqUIs));

				for (UserActionRequiredUI ui : currentPageselectedUserActionReqUIs) {
					ReviewUserAccessDTO accessDTO = ui.getReviewUserAccessDTO();
					ReviewUserAccess access = accessDTO.getReviewUserAccess();
					if(access.getValidationCompleteDate() == null){
						if (ui.getReviewApplicationDTO() != null) {
							this.validateDate = new Date();
						}
						this.userActionRequiredService.completeActionItem(ui.getUserActionReq(), this.validateDate);
					}
				}
			} catch (InvalidActionItemSelectionException e) {
				JSFUtils
				    .addFacesErrorMessage("An invalid number of action items were selected.  At least one action item must be selected to mark complete.");
				this.renderAddActivityModalPanel = false;
			}catch (Exception e) {
				logger.debug("while doValidateUsersAccesses() --> being executed. --> " + e.toString());
				this.renderAddActivityModalPanel = false;
			}
			this.validateDate = new Date();
		}
		return null;
	}

	/**
	 * Completes the action required item.
	 * @return null rerun to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doCompleteActionItem() {
		logger.debug("doCompleteActionItem() --> being executed.");
		synchronized (this.getActionReqListTable()){
			int actionItemRowIndex = Integer.parseInt(JSFUtils.getParameter(COMPLETE_ITEM_PARAM_NAME));
			List<UserActionRequiredUI> actionItems = (List<UserActionRequiredUI>) this.getActionReqListTable().getValue();
			UserActionRequiredUI selectedActionItem = null;
			for (UserActionRequiredUI actionItem : actionItems) {
				if (actionItem.getRowIndex() == actionItemRowIndex) {
					selectedActionItem = actionItem;
				}
			}
			// if the selected action required task is application, set validate date.
			if (selectedActionItem.getReviewApplicationDTO() != null) {
				this.validateDate = new Date();
			}
			this.userActionRequiredService.completeActionItem(selectedActionItem.getUserActionReq(), this.validateDate);
		}
		this.validateDate = new Date();
		return null;
	}

	/**
	 * Saves the work order created for the selected action required items.
	 * @return null return to the same page.
	 */
	public String doSaveAddActivityPanel() {
		logger.debug("doSaveAddActivityPanel() --> being executed.");
		// Displays error message if reason not provided
		if (this.selectReasonInput.equals("")) {
			JSFUtils.addFacesErrorMessage("A reason must be selected to add a activity.");
		} else if (!(StringUtils.isNumeric(this.workOrderNo))) {
			JSFUtils.addFacesErrorMessage("The work order number must be numeric.  Value provided: " + this.workOrderNo);
		} else if (StringUtils.isNotBlank(this.commentsInput) && this.commentsInput.length() > MAX_COMMENT_LENGTH) {
			JSFUtils.addFacesErrorMessage("The maximum length of the comment is " + MAX_COMMENT_LENGTH);
		} else {
			Long workOrderNumber = null;
			if (StringUtils.isNotBlank(this.workOrderNo)) {
				workOrderNumber = Long.parseLong(this.workOrderNo);
			}
			this.userActionRequiredService.addWorkOrder(wrapActionItems(this.selectedUserActionReqUIs), this.selectReasonInput,
			    this.taskProcessId, workOrderNumber, this.commentsInput);
			this.renderAddActivityModalPanel = false;
			refreshTables();
		}

		return null;
	}

	/**
	 * Completes all Inactive action required items - bulk complete
	 */
	@SuppressWarnings("unchecked")
	public void doInactiveCompleteActionItem() {
		logger.debug("doInactiveCompleteActionItem() --> being executed.");
		synchronized (this.getActionReqListTable()){
			try {
				this.userActionRequiredService.validateUsersAccesses(wrapActionItems((List<UserActionRequiredUI>) this
					    .getActionReqListTable().getValue()));
				for (UserActionRequiredUI ui : (List<UserActionRequiredUI>) this.actionReqListTable.getValue()) {
					ReviewUserAccessDTO accessDTO = ui.getReviewUserAccessDTO();
					ReviewUserAccess access = accessDTO.getReviewUserAccess();
					if(ui.getStatus().equalsIgnoreCase("Inactive") && (access.getValidationCompleteDate() == null)){
						if (ui.getReviewApplicationDTO() != null) {
							this.validateDate = new Date();
						}
						this.userActionRequiredService.completeActionItem(ui.getUserActionReq(), this.validateDate);
					}
				}
				this.validateDate = new Date();
				refreshTables();
				this.renderAddActivityModalPanel = false;
			} catch (Exception e) {
				logger.debug("while doInactiveCompleteActionItem() --> being executed. error thrown during initiation" + e.toString());
			}
		}
	}

	/**
	 * Validates all the action required items on the page.
	 * @return null return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doValidateUsersAccesses() {
		logger.debug("doValidateUsersAccesses() --> being executed.");
		// trying to get only selected items form the page
		try {
			List<UserActionRequiredUI> currentPageselectedUserActionReqUIs;
			currentPageselectedUserActionReqUIs = extractSelectedActionItems((List<UserActionRequiredUI>) this.getActionReqListTable()
			    .getValue());
			this.userActionRequiredService.validateUsersAccesses(wrapActionItems(currentPageselectedUserActionReqUIs));

			for (UserActionRequiredUI ui : currentPageselectedUserActionReqUIs) {
				ui.setValidatedFlag(true);
				ReviewUserAccessDTO accessDTO = ui.getReviewUserAccessDTO();
				ReviewUserAccess access = accessDTO.getReviewUserAccess();
				if(ui.getStatus().equalsIgnoreCase("Inactive") && (access.getValidationCompleteDate() == null)){

					if (ui.getReviewApplicationDTO() != null) {
						this.validateDate = new Date();
					}
					this.userActionRequiredService.completeActionItem(ui.getUserActionReq(), this.validateDate);
				}
			}
		} catch (InvalidActionItemSelectionException e) {
			JSFUtils
			    .addFacesErrorMessage("An invalid number of action items were selected.  At least one action item must be selected to Validate.");
			this.renderAddActivityModalPanel = false;
		}catch (Exception e) {
			logger.debug("while doValidateUsersAccesses() --> being executed. error--> " + e.toString());
			this.renderAddActivityModalPanel = false;
		}

		this.validateDate = new Date();
		return null;
	}

/*	changed doValidateUserAccesses method to validate only the current page items.
	/**
	 * Validates all the action required items on the page.
	 * @return null return to the same page.
	 
	@SuppressWarnings("unchecked")
	public String doValidateUsersAccesses() {
		logger.debug("doValidateUsersAccesses() --> being executed.");
		this.userActionRequiredService.validateUsersAccesses(wrapActionItems((List<UserActionRequiredUI>) this
		    .getActionReqListTable().getValue()));
		for (UserActionRequiredUI ui : (List<UserActionRequiredUI>) this.actionReqListTable.getValue()) {
			ui.setValidatedFlag(true);
		}
		this.validateDate = new Date();
		return null;
	}
*/
	/**
	 * Refresh tables to display new pagination data.
	 * @return null return to the same page.
	 */
	public String doRefreshTables() {
		logger.debug("doRefresh() --> being executed.");
		this.refreshTables();
		return null;
	}

	/**
	 * Completes the action required task after all the action items have been completed.
	 * @return null return to the same page.
	 */
	public String doCompleteActionRequiredTask() {
		logger.debug("doCompleteActionRequiredTask() --> being executed.");
		this.renderAttestConfirmationModalPanel = true;
		return null;
	}

	/**
	 * Cancels the complete process.
	 * @return null to return to the same page.
	 */
	public String doCancelAttestConfirmationPanel() {
		logger.debug("doCancelAttestConfirmationPanel() --> being executed.");
		this.renderAttestConfirmationModalPanel = false;
		return null;
	}

	/**
	 * Completes the action required task
	 * @return null return to the same page.
	 */
	public String doSaveAttestConfirmationPanel() {
		logger.debug("doSaveAttestConfirmationPanel() --> being executed.");
		this.userActionRequiredService.completeActionRequiredTask(this.taskProcessId);
		// return to the task list page after complete process.
		this.sessionDataBean.initSelectedTasklistBean();
		this.renderAttestConfirmationModalPanel = false;
		return "taskList";
	}

	/**
	 * Displays the reviewer comments for the review application.
	 * @return null return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doReviewerComment() {
		logger.debug("doReviewerComment() --> being executed.");
		this.renderReviewerCommentModalPanel = true;
		int actionItemRowIndex = Integer.parseInt(JSFUtils.getParameter(REVIEWER_COMMENT_PARAM_NAME));
		List<UserActionRequiredUI> actionItems = (List<UserActionRequiredUI>) this.getActionReqListTable().getValue();
		for (UserActionRequiredUI actionItem : actionItems) {
			if (actionItem.getRowIndex() == actionItemRowIndex) {
				this.reviewerComment = actionItem.getReviewApplicationDTO().getComment();
			}
		}
		return null;
	}

	/**
	 * Cancels the reviewer comment panel.
	 * @return null return to the same page.
	 */
	public String doCancelCommentsPanel() {
		logger.debug("doCancelCommentsPanel() --> being executed.");
		this.renderReviewerCommentModalPanel = false;
		return null;
	}
	
	/**
	 * Selects current page of action required items and cancels any selected item.
	 * @return null return to same page.
	 */
	public String doSelectedToggle() {
		logger.debug("doSelectedToggle() --> being executed.");
		CommonPageActionHelper.selectPagedTableAllToggle(this.actionReqListTable);
		return null;
	}

	// ----------------------------- Page Actions End -----------------------------
	// ----------------------------- Helper Methods Start -----------------------------

  	// Commented to implement CR#7 Pagination
	@SuppressWarnings("unchecked")
	private DataTable buildActionReqListTable(ActionRequiredTasklistDTO selectedActionTask) {
		logger.debug("buildActionReqListTable() --> being executed.");
		// Create action required list data table
		DataTable table = new DataTable();
		table.setVar("actionReq");
		table.setStyleClass("applicationTableHeader");
//		table.setWidth("100%");
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		List<UserActionRequiredUI> actionItems = this.retrieveActionItems(selectedActionTask);
		table.setRows(Integer.valueOf(displayAmount).intValue());
		//table.setRows(actionItems.size());
		table.setValue(actionItems);
		// Build table columns
		table.getChildren().add(buildColumn(buildAllSelectLink(), buildSelectColumn(), 5, "left"));
		table.getChildren().add(
		    buildTextColumnDebug("", "#{actionReq.rowIndex}", 5, "left",
		        "#{actionReq.reviewApplicationId} #{actionReq.reviewUserAccessId}"));
		table.getChildren().add(buildTextColumn("Username", "#{actionReq.userName}", 10, "left"));
		table.getChildren().add(buildTextColumn("User ID", "#{actionReq.appUserId}", 5, "left"));
		table.getChildren().add(buildTextColumn("Source", "#{actionReq.sourceName}", 10, "left"));
		table.getChildren().add(buildTextColumn("Priv Description", "#{actionReq.privilegeDescription}", 20, "left"));
		table.getChildren().add(buildTextColumn("Priv Value", "#{actionReq.privilegeValue}", 10, "left"));
		table.getChildren().add(buildTextColumn("Priv Comment", "#{actionReq.privilegeComment}", 20, "left"));
		table.getChildren().add(buildColumn(buildHeaderText("Reviewer Comments"), buildReviewerCommentColumn(), 5, "center"));
		table.getChildren().add(buildTextColumn("Work Orders", "#{actionReq.workOrderNumbers}", 15, "center"));
		table.getChildren().add(buildTextColumn("Status", "#{actionReq.status}", 10, "center"));
		table.getChildren().add(buildCompleteColumn(buildHeaderText("Complete"), buildCompleteButton(), 10));
		

		return table;
	}


	@SuppressWarnings("unchecked")
	private void refreshTables() {
		logger.debug("refresh() --> being executed.");
		// refresh the action required table
		List actionReqValues = (List) this.actionReqListTable.getValue();
		actionReqValues.clear();
		actionReqValues.addAll(this.retrieveActionItems(this.actionRequiredTasklistDTO));
		// refresh the work order table
		List workOrderValues = (List) this.workOrderTable.getValue();
		workOrderValues.clear();
		workOrderValues.addAll(this.retrieveWorkOrderUIs());
	}

	private Column buildCompleteColumn(UIComponent header, UIComponent detail, int width) {
//		HtmlColumn col = new org.richfaces.component.html.HtmlColumn();
		Column col = new Column();
		col.getFacets().put("header", header);
		col.getChildren().add(detail);
		col.getChildren().add(buildCompleteOutputText());
		col.setStyle("width:" + width + "%");
		return col;
	}

	private HtmlOutputText buildCompleteOutputText() {
		HtmlOutputText text = HtmlTableBuilderUtil.buildDateOutputText("#{actionReq.completeDate}");
		JSFUtils.setValueBinding(text, "rendered", "#{!actionReq.completeRenderFlag}");
		return text;
	}

	private List<UserActionRequiredUI> retrieveActionItems(ActionRequiredTasklistDTO selectedActionTask) {
		logger.debug("retrieveActionItems() --> being executed.");
		List<UserActionRequiredDTO> userActionDTOs = this.userActionRequiredService.retrieveActionItems(selectedActionTask
		    .getReviewer().getReviewerId(), selectedActionTask.getApplication().getId());
		
		List<UserActionRequiredUI> actionReqItemList = new ArrayList<UserActionRequiredUI>(userActionDTOs.size());
		// create list of UI
		for (UserActionRequiredDTO actionDTO : userActionDTOs) {
			UserActionRequiredUI actionUI = new UserActionRequiredUI(actionDTO);
			actionReqItemList.add(actionUI);
		}
		// sort it
		CommonPageActionHelper.sortListByField(actionReqItemList, "sortField", "");
		CommonPageActionHelper.sortListByField(actionReqItemList, "Status", "");
		// Assign a row index to each review user to display on the page (after it is sorted).
		int rowIndex = 0;
		for (UserActionRequiredUI actionUI : actionReqItemList) {
			actionUI.setRowIndex(++rowIndex);
		}
		
		return actionReqItemList;
	}

	@SuppressWarnings("unchecked")
	private List<WorkOrderUI> retrieveWorkOrderUIs() {
		logger.debug("retrieveWorkOrderUIs() --> being executed.");
		List<WorkOrderUI> result = new ArrayList<WorkOrderUI>();
		List<UserActionRequiredUI> actionItems = (List<UserActionRequiredUI>) this.getActionReqListTable().getValue();
		boolean hasWOFlag = false;
		// Traverse through all the user action required items.
		for (UserActionRequiredUI useractionRequiredUI : actionItems) {
			List<WorkOrderUI> workOrderUIs = new ArrayList<WorkOrderUI>(useractionRequiredUI.getWorkOrderDTOs().size());
			for (WorkOrderDTO woDTO : useractionRequiredUI.getWorkOrderDTOs()) {
				workOrderUIs.add(new WorkOrderUI(woDTO));
			}
			// Traverse through all the work orders for current action required item.
			for (WorkOrderUI woUI : workOrderUIs) {
				int rowIndex = useractionRequiredUI.getRowIndex();
				boolean flag = false;
				// check if the task has WO
				if (woUI != null) {
					hasWOFlag = true;

					// if empty list of work orders, add work order
					if (result.isEmpty()) {
						woUI.setAccessLineNos(addAccessLineNo(rowIndex));
						result.add(woUI);
						continue;
					}
					for (WorkOrderUI woTableItem : result) {
						if (woUI.getWorkOrderId().equals(woTableItem.getWorkOrderId())) {
							List<String> list = woTableItem.getAccessLineNos();
							list.add(Integer.toString(rowIndex));
							flag = true;
							break;
						}
					}
					if (!flag) {
						woUI.setAccessLineNos(addAccessLineNo(rowIndex));
						result.add(woUI);
					}
				}

			}
		}
		// if the task has work orders, display the work order table
		if (hasWOFlag) {
			this.renderWOTable = true;
		} else {
			this.renderWOTable = false;
		}
		return result;
	}

	private List<String> addAccessLineNo(int rowIndex) {
		List<String> accessLineNoList = new ArrayList<String>();
		accessLineNoList.add(Integer.toString(rowIndex));
		return accessLineNoList;
	}

	private DataTable buildWorkOrderTable() {
		logger.debug("buildWorkOrderTable() --> being executed.");
		// Create action required list data table
		DataTable table = new DataTable();
		table.setStyleClass("applicationTableHeader");
//		table.setWidth("100%");
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		table.setVar("workOrder");
		table.setValue(this.retrieveWorkOrderUIs());
		// Build table columns
		table.getChildren().add(
		    buildColumn(buildHeaderText("Date"), HtmlTableBuilderUtil.buildDateOutputText("#{workOrder.createDate}"), 10, "left"));
		table.getChildren().add(buildTextColumn("Access Lines", "#{workOrder.displayAccessLineNos}", 10, "center"));
		table.getChildren().add(buildTextColumn("Work Order", "#{workOrder.workOrderNumber}", 10, "center"));
		table.getChildren().add(buildTextColumn("Code", "#{workOrder.reasonCode}", 30, "left"));
		table.getChildren().add(buildTextColumn("Comments", "#{workOrder.comments}", 40, "left"));
		return table;
	}

	private List<UserActionRequiredUI> extractSelectedActionItems(List<UserActionRequiredUI> actionUIs)
	    throws InvalidActionItemSelectionException {
		logger.debug("extractSelectedActionItems() --> being executed.");
		List<UserActionRequiredUI> selectedActionItems = new ArrayList<UserActionRequiredUI>();
		for (UserActionRequiredUI actionItem : actionUIs) {
			if (actionItem.isSelected()) {
				selectedActionItems.add(actionItem);
			}
		}
		if (selectedActionItems.isEmpty()) {
			throw new InvalidActionItemSelectionException();
		}
		return selectedActionItems;
	}

	private class InvalidActionItemSelectionException extends Exception {
		private static final long serialVersionUID = 1L;

		public InvalidActionItemSelectionException() {
			super();
		}
	}

	private Column buildTextColumn(String columnLabel, String dataBinding, int width, String align) {
		return buildColumn(buildHeaderText(columnLabel), buildOutputText(dataBinding), width, align);
	}

	private Column buildTextColumnDebug(String columnLabel, String dataBinding, int width, String align, String debugString) {
		HtmlOutputText outputText = buildOutputText(dataBinding);
		JSFUtils.setValueBinding(outputText, "title", debugString);
		return buildColumn(buildHeaderText(columnLabel), outputText, width, align);
	}

	private HtmlOutputText buildHeaderText(String value) {
		HtmlOutputText text = new HtmlOutputText();
		text.setValue(value);
		text.setStyleClass("undecoratedLink");
		return text;
	}
	
	private CommandLink buildAllSelectLink(){
		CommandLink link = new CommandLink();
		link.setValue("All/None");
		link.setStyleClass("headerSortLink");
		link.setId("selectAllLink");
		link.setOnclick("selectAllCheckBoxes('bodyForm:actionReqListTable'); return false;");
		return link;
	}

	private HtmlOutputText buildOutputText(String valueBinding) {
		HtmlOutputText text = new HtmlOutputText();
		text.setEscape(false);
		JSFUtils.setValueBinding(text, "value", valueBinding);
		return text;
	}

	private Column buildColumn(UIComponent header, UIComponent detail, int width, String align) {
		Column col = new Column();
		col.getFacets().put("header", header);
		col.getChildren().add(detail);

		col.setStyle("width:" + width + "%; text-align:" + align);
		return col;
	}

	private HtmlSelectBooleanCheckbox buildSelectColumn() {
		HtmlSelectBooleanCheckbox checkBox = new HtmlSelectBooleanCheckbox();
		checkBox.setId("reviewUserAccessCheckBox");
		JSFUtils.setValueBinding(checkBox, "value", "#{actionReq.selected}");
		return checkBox;
	}

	private CommandLink buildReviewerCommentColumn() {
		CommandLink link = new CommandLink();
		link.setId("reviewerCommentLink");
		JSFUtils.setValueBinding(link, "rendered", "#{actionReq.commentRenderFlag}");
		link.setStyleClass("undecoratedCommentsLink");
		link.setValue(".");

		UIParameter param = new UIParameter();
		JSFUtils.setValueBinding(param, "value", "#{actionReq.rowIndex}");
		param.setName(REVIEWER_COMMENT_PARAM_NAME);
		link.getChildren().add(param);

		JSFUtils.setActionBinding(link, "#{userActionRequiredBean.doReviewerComment}");
		return link;
	}

	private CommandButton buildCompleteButton() {
		CommandButton completeButton = new CommandButton();
		completeButton.setId("completeButton");
		completeButton.setValue("Complete");
		//completeButton.setReRender("completeButton,actionRequiredTableToolBar");
		completeButton.setUpdate("completeButton,actionRequiredTableToolBar,bottomActionRequiredTableToolBar,actionRequiredTablePanel");
		JSFUtils.setValueBinding(completeButton, "rendered", "#{actionReq.completeRenderFlag}");

		UIParameter param = new UIParameter();
		JSFUtils.setValueBinding(param, "value", "#{actionReq.rowIndex}");
		param.setName(COMPLETE_ITEM_PARAM_NAME);
		completeButton.getChildren().add(param);

		JSFUtils.setActionBinding(completeButton, "#{userActionRequiredBean.doCompleteActionItem}");
		return completeButton;

	}

	/**
	 * To unwrap action items UI list to get action item transfer objects.
	 * @param actionItems the action item UI list.
	 * @return User action required DTOs
	 */
	private List<UserActionRequiredDTO> wrapActionItems(List<UserActionRequiredUI> actionItems) {
		List<UserActionRequiredDTO> results = new ArrayList<UserActionRequiredDTO>(actionItems.size());
		for (UserActionRequiredUI ui : actionItems) {
			results.add(ui.getUserActionReq());
		}
		return results;
	}

	// ----------------------------- Helper Methods End -----------------------------

	public ReviewUI getReview() {
		return review;
	}

	public void setReview(ReviewUI review) {
		this.review = review;
	}

	public ReviewerUI getReviewer() {
		return reviewer;
	}

	public void setReviewer(ReviewerUI reviewer) {
		this.reviewer = reviewer;
	}

	public DataTable getActionReqListTable() {
		return actionReqListTable;
	}

	public void setActionReqListTable(DataTable actionReqListTable) {
		this.actionReqListTable = actionReqListTable;
	}

	public DataTable getWorkOrderTable() {
		return workOrderTable;
	}

	public void setWorkOrderTable(DataTable workOrderTable) {
		this.workOrderTable = workOrderTable;
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public void setReviewBundle(ReviewBundleUI reviewBundle) {
		this.reviewBundle = reviewBundle;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public boolean isRenderReviewerCommentModalPanel() {
		return renderReviewerCommentModalPanel;
	}

	public void setRenderReviewerCommentModalPanel(boolean renderReviewerCommentModalPanel) {
		this.renderReviewerCommentModalPanel = renderReviewerCommentModalPanel;
	}

	public String getCommentsInput() {
		return commentsInput;
	}

	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	public String getSelectedAccessLineNos() {
		return selectedAccessLineNos;
	}

	public void setSelectedAccessLineNos(String selectedAccessLineNos) {
		this.selectedAccessLineNos = selectedAccessLineNos;
	}

	public boolean isRenderAddActivityModalPanel() {
		return renderAddActivityModalPanel;
	}

	public void setRenderAddActivityModalPanel(boolean renderAddActivityModalPanel) {
		this.renderAddActivityModalPanel = renderAddActivityModalPanel;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public List<UserActionRequiredUI> getSelectedUserActionReqUIs() {
		return selectedUserActionReqUIs;
	}

	public void setSelectedUserActionReqUIs(List<UserActionRequiredUI> selectedUserActionReqUIs) {
		this.selectedUserActionReqUIs = selectedUserActionReqUIs;
	}

	@SuppressWarnings("unchecked")
	public boolean isRenderCompleteActionTaskButton() {
		boolean flag = true;
		List<UserActionRequiredUI> actionItems = (List<UserActionRequiredUI>) this.getActionReqListTable().getValue();
		for (UserActionRequiredUI actionItem : actionItems) {
			if (actionItem.getCompleteDate() == null) {
				flag = false;
				break;
			}
		}
		return flag;
	}

	public void setRenderCompleteActionTaskButton(boolean renderCompleteActionTaskButton) {
		this.renderCompleteActionTaskButton = renderCompleteActionTaskButton;
	}

	public String getReviewerComment() {
		return reviewerComment;
	}

	public void setReviewerComment(String reviewerComment) {
		this.reviewerComment = reviewerComment;
	}

	public String getTaskProcessId() {
		return taskProcessId;
	}

	public void setTaskProcessId(String taskProcessId) {
		this.taskProcessId = taskProcessId;
	}

	public ActionRequiredTasklistDTO getActionRequiredTasklistDTO() {
		return actionRequiredTasklistDTO;
	}

	public void setActionRequiredTasklistDTO(ActionRequiredTasklistDTO actionRequiredTasklistDTO) {
		this.actionRequiredTasklistDTO = actionRequiredTasklistDTO;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public boolean isRenderAttestConfirmationModalPanel() {
		return renderAttestConfirmationModalPanel;
	}

	public void setRenderAttestConfirmationModalPanel(boolean renderAttestConfirmationModalPanel) {
		this.renderAttestConfirmationModalPanel = renderAttestConfirmationModalPanel;
	}

	public boolean isRenderWOTable() {
		return renderWOTable;
	}

	public void setRenderWOTable(boolean renderWOTable) {
		this.renderWOTable = renderWOTable;
	}
}
