/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IDivisionService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.IDivisionDao;
import com.assurant.inc.sox.domain.ar.Division;

/**
 * @author RuthSchmalz
 * 
 */
@Service
public class DivisionService implements IDivisionService {

	@Autowired
	private IDivisionDao divisionDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public List<Division> retrieveAllDivisions() {
		return this.divisionDao.findAll();
	}
	
	public List<Division> retrieveAllDivisionsByName(String divisionNameSearchText) {
		return this.divisionDao.findAllByName(divisionNameSearchText);
	}
	
	public List<Division> retrieveDeletedDivisionsByName(String divisionNameSearchText) {
		return this.divisionDao.findDeletedByName(divisionNameSearchText);
	}

	public List<Division> retrieveUnassignedDivisionsByName(String divisionNameSearchText) {
		return this.divisionDao.findUnassignedByName(divisionNameSearchText);
	}

	public List<Division> retrieveDeletedDivisions() {
		return this.divisionDao.findDeleted();
	}

	public List<Division> retrieveUnassignedDivisions() {
		return this.divisionDao.findUnassigned();
	}

	public IDivisionDao getDivisionDao() {
		return divisionDao;
	}

	public void setDivisionDao(IDivisionDao divisionDao) {
		this.divisionDao = divisionDao;
	}
	
	public Division findById(Long id) {
		return this.divisionDao.findById(id);
	}

	public Division findDuplicate(String name) {
		return this.divisionDao.findDuplicate(name);
	}
	
	@Transactional
	public void add(String divisionName) {
		Date currentDate = new Date();

		//Create a Division record.
		Division division = new Division();
		
		division.setName(divisionName);
		division.setDeleteFlag(IFlags.NOT_DELETED);
		division.setCreatedBy(this.systemUser.getUserId());
		division.setCreatedDate(currentDate);

		division.setActiveFromDate(currentDate);
		division.setActiveToDate(DateUtil.END_OF_TIME); 
		this.divisionDao.save(division);
	}

	@Transactional
	public void delete(Division division) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		Division currentDivision = new Division();
		currentDivision.setName(division.getName());
		currentDivision.setDeleteFlag(IFlags.NOT_DELETED);
		currentDivision.setCreatedBy(division.getCreatedBy());
		currentDivision.setCreatedDate(division.getCreatedDate());
		currentDivision.setLastChangedBy(this.systemUser.getUserId());
		currentDivision.setLastChangedDate(currentDate);
		
		currentDivision.setActiveFromDate(division.getActiveFromDate());
	 	currentDivision.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.divisionDao.save(currentDivision);
		
		//Create a Deleted Division record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		division.setDeleteFlag(IFlags.DELETED);
		division.setActiveFromDate(currentDate);
		division.setActiveToDate(currentDate);
		this.divisionDao.save(division);
	}

	public boolean canDivisionBeDeleted(Long id) {
		return this.divisionDao.canDivisionBeDeleted(id);
	}
}
