package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.UserType;
import java.util.Date;

public class UserTypeUI {
	private final UserType userType;
	private boolean checked;

	public UserTypeUI(UserType userType) {
		this.userType = userType;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public Long getId() {
		return this.userType.getId();
	}

	public String getUserTypeDescription() {
		return this.userType.getUserTypeDescription();
	}
	
	public String getCreatedBy() {
		return this.userType.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.userType.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.userType.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.userType.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.userType.getDeleteFlag();
	}

	public UserType getUserType() {
		return userType;
	}
	
	public Date getActiveFromDate() {
		return this.userType.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.userType.getActiveToDate();
	}
	
}  //end of UserTypeUI
