package com.assurant.inc.sox.ar.client.bean.tasklist;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.component.UIParameter;
import javax.faces.component.html.HtmlOutputText;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.service.impl.tasklist.MyTaskListService;
import org.primefaces.PrimeFaces;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.assurant.inc.sox.ar.client.bean.RejectedUserBean;
import com.assurant.inc.sox.ar.client.bean.UserActionRequiredBean;
import com.assurant.inc.sox.ar.client.bean.review.ReviewBundleSummaryBean;
import com.assurant.inc.sox.ar.client.bean.reviewdetails.ReviewDetailsBean;
import com.assurant.inc.sox.ar.client.bean.reviewerreport.EmployeeListBean;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.AbstractTaskListUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.ActionRequiredTasklistUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.BundleTaskListUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.RejectedUserTasklistUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.ReviewerTaskListUI;
import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.EmployeeListMode;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListField;
import com.assurant.inc.sox.ar.dto.enums.tasklist.TaskListFilterType;
import com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ActionRequiredTasklistDTO;
import com.assurant.inc.sox.ar.dto.tasklist.BundleTaskListDTO;
import com.assurant.inc.sox.ar.dto.tasklist.RejectedUserTasklistDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.tasklist.IMyTaskListService;
import com.assurant.inc.sox.ar.service.tasklist.IReviewerTaskListService;
import com.assurant.inc.sox.consts.TaskTypeCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("myTaskListBean")
@Scope("session")
public class MyTaskListBean extends AbstractLockableTaskListBean<AbstractTaskListUI, AbstractTaskListDTO> implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(MyTaskListBean.class);
	@Autowired
	@Qualifier("myTaskListService")
	private IMyTaskListService myTaskListService;
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewerTaskListService")
	private IReviewerTaskListService reviewerTaskListService;
	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;
	@Autowired
	@Qualifier("reviewBundleService")
	private IReviewBundleService reviewBundleService;
	private boolean itCompUser;

    public List<AbstractTaskListDTO> myTaskListBeanResults;

	public MyTaskListBean() {
		super(TaskListFilterType.REVIEW_TYPE, "myTaskListBean", "myTaskList");
	}

	// ----------------------------- faces injected properties ----------------

	public IMyTaskListService getMyTaskListService() {
		return myTaskListService;
	}

	public void setMyTaskListService(IMyTaskListService myTaskListService) {
		this.myTaskListService = myTaskListService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewerTaskListService getReviewerTaskListService() {
		return reviewerTaskListService;
	}

	public void setReviewerTaskListService(IReviewerTaskListService reviewerTaskListService) {
		this.reviewerTaskListService = reviewerTaskListService;
	}

	public void setItCompUser(boolean itCompUser) {
		this.itCompUser = itCompUser;
	}

	public boolean isItCompUser() {
		synchronized (this.lock) {
			if (!(this.beanLoaded)) {
				this.loadBean();
			}
		}
		return itCompUser;
	}

	// ---------------------------- overriden abstract methods ----------------

	@Override
	protected String processTask(String typeCode, String taskId, AbstractTaskListDTO abstractTaskListDTO) {
		String result;
		TaskTypeCode type = TaskTypeCode.getByCodeValue(typeCode);
		AbstractTaskListDTO abstractTaskList = this.extractSelectedTaskListDTO(taskId, abstractTaskListDTO);
		if (TaskTypeCode.REVIEWER_TASK.equals(type)) {

			ReviewerTaskListDTO taskList = (ReviewerTaskListDTO) abstractTaskList;

			// get the selected bundle and review

			ReviewerDTO selectedReviewer = taskList.getReviewer();

			ReviewBundleDTO selectedBundle = this.reviewBundleService.retrieveById(selectedReviewer.getReviewBundleId());
			if (selectedBundle == null) {
				String message = "A bundle could not be found for the selected task.  Bundle id: " + selectedReviewer.getReviewBundleId();
				logger.warn(message);
				JSFUtils.addFacesErrorMessage(message);
				return null;
			}

			EmployeeListBean bean = (EmployeeListBean) JSFUtils.lookupBean("employeeListBean");
			// loads employee list bean. Passed savvion id for review user attest process.
			bean.initEmployeeList(new ReviewUI(taskList.getReview()), new ReviewBundleUI(selectedBundle), new ReviewerUI(
					selectedReviewer), EmployeeListMode.REVIEWER_VERIFY, taskId);

			result = "employeeList";
		} else if (TaskTypeCode.REVIEW_DETAILS.equals(type) || TaskTypeCode.REVIEW_SUMMARY.equals(type)) {
			// get the selected bundle and review
			BundleTaskListDTO taskList = (BundleTaskListDTO) abstractTaskList;
			ReviewBundleDTO selectedBundle = taskList.getReviewBundle();
			ReviewDTO selectedReview = taskList.getReview();

			// get the type code to determine next step.
			if (TaskTypeCode.REVIEW_SUMMARY.equals(type)) {
				result = "bundlePreview";
				ReviewBundleSummaryBean bean = (ReviewBundleSummaryBean) JSFUtils.lookupBean("reviewBundleSummaryBean");
				bean.initBean(new ReviewUI(selectedReview), new ReviewBundleUI(selectedBundle));
			} else {
				ReviewDetailsBean bean = (ReviewDetailsBean) JSFUtils.lookupBean("reviewDetailsBean");
				bean.initBean(new ReviewUI(selectedReview), Collections.singletonList(new ReviewBundleUI(selectedBundle)));
				result = "reviewDetails";
			}
		} else if (TaskTypeCode.VALIDATE_ACTION_REQUIERED.equals(type)) {
			// Get the selected action required task.
			ActionRequiredTasklistDTO selectedActionTask = (ActionRequiredTasklistDTO) abstractTaskList;
			// Load the user action required bean.
			UserActionRequiredBean bean = (UserActionRequiredBean) JSFUtils.lookupBean("userActionRequiredBean");
			bean.initActionRequired(selectedActionTask, taskId);
			// Navigate to the action required page.
			result = "actionRequired";
		} else if (TaskTypeCode.VALIDATE_REJECT_USER.equals(type)) {
			RejectedUserTasklistDTO selectedTask = (RejectedUserTasklistDTO) abstractTaskList;
			RejectedUserBean bean = (RejectedUserBean) JSFUtils.lookupBean("rejectedUserBean");
			bean.initBean(selectedTask);
			result = "rejectedUser";
		} else {
			throw new RuntimeException("An unexpected task type was found with the value of: " + typeCode);
		}
		this.unloadBean();
		return result;
	}

	/**
	 * Loads the respective bean for the task selected on the task list page.
	 * <p>
	 * String navigates to the respective page.
	 */
	public String doWorkTask(AbstractTaskListDTO abstractTaskListDTO) {
		logger.info("doWorkTask -- enter");
		String typeCode = abstractTaskListDTO.getTypeCode().getCode();
		String taskId = abstractTaskListDTO.getTaskId();

		String result;
		setAbstractTaskListDTO(abstractTaskListDTO);
		if (isTaksLockable(typeCode)) {
			LockDTO taskLock = this.lockService.getLock(taskId);
			if (taskLock == null) {
				this.lockService.lock(taskId);
				result = this.processTask(typeCode, taskId, abstractTaskListDTO);
			} else if (this.isUserHolder(taskLock)) {
				result = this.processTask(typeCode, taskId, abstractTaskListDTO);
			} else {
				this.prepareLockModalPanel(taskLock, typeCode, taskId);
				result = null;
			}
		} else {
			result = this.processTask(typeCode, taskId, abstractTaskListDTO);
		}
		return result;
	}

	/*
	 * Overriden to give a more specific tasklist name.
	 *
	 * @see com.assurant.inc.sox.ar.client.bean.tasklist.AbstractTaskListBean#buildTaskNameColumn()
	 */
	@Override
	protected Object buildTaskNameColumn() {

		CommandLink link = new CommandLink();
		link.setId("selectTaskLink");
		StringBuilder sb = new StringBuilder(20).append("#{taskList.").append(TaskListField.TASK_NAME.getFieldName()).append('}');
		String taskNameValueBinding = sb.toString();
		JSFUtils.setValueBinding(link, "value", taskNameValueBinding);
		JSFUtils.setActionBinding(link, "#{" + this.beanName + ".doWorkTask}");

		sb.setLength(0);
		sb.append("#{taskList.").append(TaskListField.IS_CLICKABLE.getFieldName()).append('}');
		JSFUtils.setValueBinding(link, "rendered", sb.toString());

		List<UIComponent> linkChildren = link.getChildren();
		UIParameter param = new UIParameter();
		sb.setLength(0);
		sb.append("#{taskList.").append(TaskListField.TASK_ID.getFieldName()).append('}');
		JSFUtils.setValueBinding(param, "value", sb.toString());
		param.setName(WORK_TASK_ACTION_PARAM_NAME);
		linkChildren.add(param);

		param = new UIParameter();
		sb.setLength(0);
		sb.append("#{taskList.").append(TaskListField.TYPE_CODE_VALUE.getFieldName()).append('}');
		JSFUtils.setValueBinding(param, "value", sb.toString());
		param.setName(WORK_TASK_TYPE_ACTION_PARAM_NAME);
		linkChildren.add(param);

		Column result = HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Task", TaskListField.TASK_NAME.getFieldName(),
				"SortByTaskNameLink"), link);

		// Add a text field to render in the event that the task is not clickable.
		HtmlOutputText text = HtmlTableBuilderUtil.buildOutputText(taskNameValueBinding);
		sb.setLength(0);
		sb.append("#{!taskList.").append(TaskListField.IS_CLICKABLE.getFieldName()).append('}');
		JSFUtils.setValueBinding(text, "rendered", sb.toString());

		result.getChildren().add(text);

		return result;
	}

	/*
	 * The my task list will contain all task for the logged in user so may be of mixed type.
	 *
	 * @see com.assurant.inc.sox.ar.client.bean.tasklist.AbstractTaskListBean#buildClientObject(com.assurant.inc.sox.ar.dto.tasklist.AbstractTaskListDTO)
	 */
	@Override
	protected AbstractTaskListUI buildClientObject(AbstractTaskListDTO dto) {
		AbstractTaskListUI result;
		if (dto instanceof ActionRequiredTasklistDTO) {
			dto.setLock(this.lockService.getLock(dto.getTaskId()));
			dto.setLockResult(dto.isLocked());
			dto.setLockTitle(dto.getLockedBy());
			result = new ActionRequiredTasklistUI((ActionRequiredTasklistDTO) dto);
		} else if (dto instanceof RejectedUserTasklistDTO) {
			dto.setLock(this.lockService.getLock(dto.getTaskId()));
			dto.setLockResult(dto.isLocked());
			dto.setLockTitle(dto.getLockedBy());
			result = new RejectedUserTasklistUI((RejectedUserTasklistDTO) dto);
		} else if (dto instanceof ReviewerTaskListDTO) {
			result = new ReviewerTaskListUI((ReviewerTaskListDTO) dto);
		} else {
			dto.setLock(this.lockService.getLock(dto.getTaskId()));
			dto.setLockResult(dto.isLocked());
			dto.setLockTitle(dto.getLockedBy());
			result = new BundleTaskListUI((BundleTaskListDTO) dto);
		}
		return result;
	}

	/*
	 * The my task list will contain all tasks assigned to the logged in user so may be a mixed type.
	 *
	 * @see com.assurant.inc.sox.ar.client.bean.tasklist.AbstractTaskListBean#retrieveTaskListDTOs()
	 */
	@Override
	protected List<AbstractTaskListDTO> retrieveTaskListDTOs() {
		List<AbstractTaskListDTO> results;
		if (this.sessionDataBean.getSelectedTabId().equals(this.sessionDataBean.getMyTaskTabId())) {
			results = new ArrayList<AbstractTaskListDTO>();
			if (this.itCompUser) {
				results.addAll(this.myTaskListService.retrieveItComplianceTasks());
				// results.addAll(this.actionRequiredTaskListService.retrieveActionRequiredTaskList());
				// results.addAll(this.rejectedUserTasklistService.retreiveRejectedUserTaskList());
			}
			results.addAll(this.reviewerTaskListService.retrieveTaskListForReviewer());
		} else {
			results = new ArrayList<AbstractTaskListDTO>(3);
		}
		/*
		 * There is a jsf richfaces bug where if the richDataTable is empty and an item gets
		 * added to it and it is refreshed via an ajax call a javascript error occurs when
		 * trying to click on a hyperlink in the table (a commandLink).  Pretty much a blank
		 * row needs to be inserted into the table to hold the a place for the javascript variable
		 * that the commandLink needs that is not put in place when the table is build when empty.
		 * This hack below will not actually show a row in the table b/c richfaces is smart enough
		 * when it renders to know that it is an empty row, but by this time the variable is already
		 * but in js and works fine when the table is rerender via ajax. :)
		 */
		if (results.isEmpty()) {
			AbstractTaskListDTO dto = new ReviewerTaskListDTO("");
			dto.setAssignedTo("");
			dto.setCreateDate(null);
			dto.setLock(null);
			dto.setName("");
			dto.setTaskId(null);
			dto.setTypeCode(null);
			results.add(dto);
		}
		for (AbstractTaskListDTO result : results) {
			buildClientObject(result);
		}
		// Sort the results by
		String sortField = TaskListField.CREATE_DATE.getFieldName();
		Collections.sort(results, new GenericComparator(sortField, false));
		this.previousSortFieldCodeValue = sortField;
		myTaskListBeanResults = results;
		return results;
	}

	@Override
	protected void loadBean() {
		this.itCompUser = this.sessionDataBean.getSystemUser().isItComplianceUser();
		super.loadBean();
	}

	@Override
	protected void addTableColumns(DataTable table) {
		table.getChildren().add(this.buildLockColumn());
		super.addTableColumns(table);
	}

	public List<AbstractTaskListDTO> getMyTaskListBeanResults() {
		return myTaskListBeanResults;
	}

	public void setMyTaskListBeanResults(List<AbstractTaskListDTO> myTaskListBeanResults) {
		this.myTaskListBeanResults = myTaskListBeanResults;
	}
}
