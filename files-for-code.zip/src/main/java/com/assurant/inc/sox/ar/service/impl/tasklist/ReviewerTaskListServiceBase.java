package com.assurant.inc.sox.ar.service.impl.tasklist;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.dao.ar.ISupervisorDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import org.springframework.stereotype.Component;

@Component
public class ReviewerTaskListServiceBase {
	protected static final Logger logger = LoggerFactory.getLogger(ReviewerTaskListService.class);
    @Autowired
    private SystemUserDTO sessionSystemUser;
    
	/*@Autowired
	protected ISavvionService savvionService;*/
	
	@Autowired
	protected IWorkflowService workflowService;

	@Autowired
	protected IReviewerService reviewerService;
	

	@Autowired
	protected IReviewService reviewService;

	@Autowired
	protected IReviewBundleService reviewBundleService;
	
	@Autowired
	protected IUserDao userDao;
	
	@Autowired
	protected ISupervisorDao supervisorDao;
	
	/*public ISavvionService getSavvionService() {
		return savvionService;
	}

	public void setSavvionService(ISavvionService savvionService) {
		this.savvionService = savvionService;
	}*/

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	public SystemUserDTO getSessionSystemUser() {
		return sessionSystemUser;
	}

	public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
		this.sessionSystemUser = sessionSystemUser;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public static Logger getLogger() {
		return logger;
	}

	public IUserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	public ISupervisorDao getSupervisorDao() {
		return supervisorDao;
	}

	public void setSupervisorDao(ISupervisorDao supervisorDao) {
		this.supervisorDao = supervisorDao;
	}
	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}

}
