package com.assurant.inc.sox.ar.dto.enums;

public enum FilterTableCode {
	ACTIVE_ROWS("Active Rows"),
	DELETED_ROWS("Deleted Rows"),
	INACTIVE_ROWS("Inactive Rows"),
	UNASSIGNED_ROWS("Unassigned Rows");
	
	private String filterName;
	private FilterTableCode(String filterName){
		this.filterName = filterName;
	}
	public String filterName(){
		return this.filterName;
	}
}
