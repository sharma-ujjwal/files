package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.ApplicationByUserIdDTO;
import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewApplicationDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserApplicationAccessesDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.service.IReviewUserAccessService;
import com.assurant.inc.sox.ar.service.base.ReviewUserAccessServiceBase;
import com.assurant.inc.sox.domain.ar.ReviewApplication;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.Reviewer;

/**
 * Review User Access Service handles the update and retrieval of a user accesses
 * 
 * @author BB68602
 * 
 */
@Service
public class ReviewUserAccessService extends ReviewUserAccessServiceBase implements IReviewUserAccessService {

	/**
	 * Retrieve all user access. Sorts the return list for the ReviewUserApplicationAccessesDTO by Application Name ascending and
	 * then the accesses that are associated with the app are sorted by priv description and priv value.
	 * 
	 * @return List<ReviewUserApplicationAccessesDTO>
	 * //@param userId
	 */
	public List<ReviewUserApplicationAccessesDTO> retrieveByReviewUserId(Long reviewUserId) {
		getLogger().debug("retrieveByReviewUserId(reviewUserId) --> being executed.");

		/*
		 * Get a list of user accesses. The list comes back from the dao 
		 * sorted by priv description and priv value
		 */
		List<ReviewUserAccess> userAccesses = getReviewUserAccessDao().findByReviewUserId(reviewUserId);

		/*
		 * TreeMap will guarantees that the map will be in ascending key order so it will be sorted before.
		 * We will put the object in the Map by the key ApplicationByUserIdDTO which will handle a distinct list
		 * of Applications by user id.  e.i. So if the same application has a different user id then that will
		 * be a new entry into the map.
		 */
		Map<ApplicationByUserIdDTO, List<ReviewUserAccessDTO>> applicationNameMap = new TreeMap<ApplicationByUserIdDTO, List<ReviewUserAccessDTO>>();

		for (ReviewUserAccess userAccess : userAccesses) {
			/*
			 * Get distinct key values. Since we are storing the object by application/application user id.
			 */
			String applicationName = userAccess.getApplicationSystem().getApplication().getName();
			String applicationUserId = userAccess.getUserId();

			/*
			 * build dto
			 */
			ApplicationByUserIdDTO applicationByUserIdDto = new ApplicationByUserIdDTO(applicationName, applicationUserId);

			/*
			 * see if key already exists in the map
			 */
			List<ReviewUserAccessDTO> appAccesses = applicationNameMap.get(applicationByUserIdDto);
			/*
			 * if key not found then create an entry into the map for the key
			 */
			if (appAccesses == null) {
				appAccesses = new ArrayList<ReviewUserAccessDTO>();
				applicationNameMap.put(applicationByUserIdDto, appAccesses);
			}


			CodeDTO codeDTO= null;
			if(userAccess.getValidationStatusCode() != null){
				codeDTO = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_ACCESS_STATUS,
				    userAccess.getValidationStatusCode());
			}
			/*
			 * add accesses to list
			 */
			appAccesses.add(new ReviewUserAccessDTO(userAccess, codeDTO));
		}

		List<ReviewUserApplicationAccessesDTO> results = new ArrayList<ReviewUserApplicationAccessesDTO>(applicationNameMap.size());

		/*
		 * map is sorted so we can just build the list and it is in sorted order
		 */
		for (Map.Entry<ApplicationByUserIdDTO, List<ReviewUserAccessDTO>> entry : applicationNameMap.entrySet()) {
			ReviewUserAccessDTO exampleRUAD = entry.getValue().get(0);
			List<ReviewApplication> reviewApplications = getReviewApplicationDao().findBy(exampleRUAD.getReviewUserId(),
			    exampleRUAD.getReviewUserAccess().getApplicationSystem().getApplication(), exampleRUAD.getApplicationUserId());
			if (reviewApplications.size() > 0) {
				ReviewApplicationDTO raDTO = new ReviewApplicationDTO(reviewApplications.get(0));
				results.add(new ReviewUserApplicationAccessesDTO(entry.getKey(), entry.getValue(), raDTO));
			} else {
				results.add(new ReviewUserApplicationAccessesDTO(entry.getKey(), entry.getValue()));
			}
		}

		return results;
	}

	public void save(List<ReviewUserApplicationAccessesDTO> dtos, ReviewerDTO reviewerDTO) {
		getLogger().debug("save(List<ReviewUserApplicationAccessesDTO>) --> being executed.");

		for (ReviewUserApplicationAccessesDTO dto : dtos) {
			boolean accessChanged = false;
			List<ReviewUserAccessDTO> reviewUserAccessDTOs = dto.getAccesses();
			List<ReviewUserAccess> reviewUserAccesses = new ArrayList<ReviewUserAccess>(reviewUserAccessDTOs.size());
			for (ReviewUserAccessDTO reviewUserAccessDTO : reviewUserAccessDTOs) {
				if (reviewUserAccessDTO.isDirtyFlag()) {
					accessChanged = true;
					reviewUserAccesses.add(reviewUserAccessDTO.getReviewUserAccess());
				}
			}
			getReviewUserAccessDao().save(reviewUserAccesses);

			/*
			 * need to get the access/application user id to be saved for the review application
			 * comment, so there should only be one id for each ReviewUserApplicationAccessesDTO
			 * so get it and set it into the review application object
			 */

			dto.getReviewApplicationDTO().getReviewApplication().setAccessUserId(dto.getApplicationUserId());
			saveIfNecessary(dto.getReviewApplicationDTO().getReviewApplication());
			//if any of the accesses change, update the last 250 access changed date in reviewer.
			if(accessChanged){
				Reviewer reviewer = reviewerDTO.getReviewer();
				reviewer.setLast250AccessChangedDate(new Date());
				getReviewerDao().save(reviewer);
			}
		}
	}

	
	/**
	 * Save the ReviewApplication, if necessary. If the comment is blank, and the ReviewApplication has never been persisted, do not
	 * save.
	 * 
	 * @param reviewApplication the ReviewApplication to maybe save
	 */
	private void saveIfNecessary(ReviewApplication reviewApplication) {
		getLogger().debug("saveIfNecessary(ReviewApplication reviewApplication)--> being executed.");
		final String comment = reviewApplication.getComment();
		final Long id = reviewApplication.getId();
		// Do not save if the comment is empty and object has never been
		// saved before (i.e., when id is null)
		if (isEmptyComment(comment) && (id == null)) {
			return;
		}

		getReviewApplicationDao().save(reviewApplication);

	}

	/**
	 * @param comment
	 * @return true, if comment is blank
	 */
	private boolean isEmptyComment(String comment) {
		getLogger().debug("isEmptyComment(String comment)--> being executed.");
		return (comment == null) || (comment.trim().equals(""));
	}
}
