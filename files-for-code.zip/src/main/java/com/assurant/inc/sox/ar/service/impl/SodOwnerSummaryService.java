/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.service.ISodOwnerSummaryService;
import com.assurant.inc.sox.dao.ar.IReviewOwnerSummaryDao;
import com.assurant.inc.sox.domain.admin.SodOwnerSummary;
import com.assurant.inc.sox.domain.searchable.SodOwnerSummarySearchCriteria;

/**
 * @author Brian Olson
 *
 */
@Service
public class SodOwnerSummaryService implements ISodOwnerSummaryService {

	@Autowired
	private IReviewOwnerSummaryDao sodOwnerSummaryDao;
	
	public IReviewOwnerSummaryDao getSodOwnerSummaryDao() {
		return sodOwnerSummaryDao;
		
	}

	public void setSodOwnerSummaryDao(IReviewOwnerSummaryDao sodOwnerSummaryDao) {
		this.sodOwnerSummaryDao = sodOwnerSummaryDao;
	}

	@Transactional(readOnly = true)
	public List<SodOwnerSummary> retrieveSodOwnerSummariesByCriteria(
			SodOwnerSummarySearchCriteria criteria) {
		System.out.println("**** In SODOwnerSummary service *** :");
		return this.sodOwnerSummaryDao.findSodOwnerSummariesByCriteria(criteria);
	}
}
