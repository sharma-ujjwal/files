package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;

import com.assurant.inc.sox.ar.client.admin.ui.FunctionDutyUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.ar.service.IFunctionDutyService;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.FunctionDuty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("functionDutySummaryBean")
@Scope("session")
public class FunctionDutySummaryBean {
	// injected resources
	@Autowired
	@Qualifier("functionDutyService")
	private IFunctionDutyService functionDutyService;
	@Autowired
	@Qualifier("applicationService")
	private IApplicationService applicationService;
	
	private SessionDataBean sessionDataBean;

	private List<FunctionDutyUI> functionDutyList;
	private List<FunctionDutyUI> deletedFunctionDutyList = new ArrayList<FunctionDutyUI>();

	private String displayAmount = "10";
	private String oldSortColumn;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String functionDutyAddDescription;
	private String functionDutyDescriptionSearchText;

	private boolean allChecked;
	private String pageNumber = "1";
	private String lastPageNumber= "1";
	private boolean renderAddFunctionDutyModalPanel;
	private boolean renderDeleteFunctionDutyModalPanel;

	private DataScroller dataScroller;

	public List<FunctionDutyUI> getFunctionDutyList() {
		if (functionDutyList == null) {
			this.refreshList();
		}
		
		return functionDutyList;
	}
	
	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.functionDutyList = new ArrayList<FunctionDutyUI>();
		List<FunctionDuty> functionDutysRetrieved = new ArrayList<FunctionDuty>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.functionDutyDescriptionSearchText)) {
				functionDutysRetrieved = this.functionDutyService.retrieveAllByDescription(this.functionDutyDescriptionSearchText);
			} else {
				functionDutysRetrieved = this.functionDutyService.retrieveAll();
			}
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.functionDutyDescriptionSearchText)) {
				functionDutysRetrieved = this.functionDutyService.retrieveDeletedByDescription(this.functionDutyDescriptionSearchText);
			} else {
				functionDutysRetrieved = this.functionDutyService.retrieveDeleted();
			}
		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.functionDutyDescriptionSearchText)) {
				functionDutysRetrieved = this.functionDutyService.retrieveUnassignedByDescription(this.functionDutyDescriptionSearchText);
			} else {
				functionDutysRetrieved = this.functionDutyService.retrieveUnassigned();
			}
		}
		
		for (FunctionDuty functionDuty : functionDutysRetrieved) {
			this.functionDutyList.add(new FunctionDutyUI(functionDuty));
		}
	    this.doSort();
	}

	// ******* GO button *******	
	public String goSearch() {
		this.refreshList();
		return "";
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		this.functionDutyList = null;
		this.functionDutyDescriptionSearchText = null;
		this.oldSortColumn = null;
		this.refreshList();
		return "";
	}
	
	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		this.refreshList();
		return null;
	}

	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "description";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(functionDutyList, column, this.oldSortColumn);
		this.oldSortColumn = column;
	}
	
	public void setFunctionDutyTextSearchText(String functionDutyText) {
		this.functionDutyDescriptionSearchText = functionDutyText;
	}
	
	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getFunctionDutyAddDescription() {
		return functionDutyAddDescription;
	}

	public void setFunctionDutyAddDescription(String functionDutyAddDescription) {
		this.functionDutyAddDescription = functionDutyAddDescription;
	}

	public IFunctionDutyService getFunctionDutyService() {
		return functionDutyService;
	}

	public void setFunctionDutyService(IFunctionDutyService functionDutyService) {
		this.functionDutyService = functionDutyService;
	}

	public IApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(IApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	// ******* Add FunctionDuty Panel  *******
	public String showAddFunctionDutyPanel() {
		this.renderAddFunctionDutyModalPanel = true;
		this.functionDutyAddDescription = "";
		this.clearSelections();
		return null;
	}

	// *******  Add FunctionDuty Panel  CANCEL  *******
	public String doCancelAdd() {
		this.renderAddFunctionDutyModalPanel = false;
		this.functionDutyAddDescription = "";
		this.clearSelections();
		return null;
	}

	// ******* Add FunctionDuty Panel  SAVE *******
	public String doAddFunctionDuty() {
		if (!validFunctionDutyDescription()) {
			String message = "Applicaton is required";
			JSFUtils.addFacesErrorMessage(message);
			return null;
		}
		
		FunctionDuty duplicate = this.functionDutyService.findDuplicate(this.functionDutyAddDescription);
		if (duplicate != null) {
			String message = "Function duty " + this.functionDutyAddDescription
					+ " already exists with ID of " + duplicate.getId();
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddFunctionDutyModalPanel = true;
			return null;
		}
 	     	     
		this.functionDutyService.add(this.functionDutyAddDescription);

		// Display Message.
		String message = "Added FunctionDuty " + this.functionDutyAddDescription;
		JSFUtils.addFacesMessage(message);
		this.refreshList();

		this.renderAddFunctionDutyModalPanel = false;
		return "";
	}
	
	// ******* Delete FunctionDuty  Panel *******
	public String showDeleteFunctionDutyPanel() {
		populateDeletedFunctionDutyList();
		
		if (this.deletedFunctionDutyList.isEmpty()) {
			String message = "Please select at least one division.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteFunctionDutyModalPanel = true;
		}
		
		return null;
	}

	private void populateDeletedFunctionDutyList() {
		this.deletedFunctionDutyList = new ArrayList<FunctionDutyUI>();
		
		for (FunctionDutyUI ui : this.functionDutyList) {
			if (ui.isChecked()) {
				this.deletedFunctionDutyList.add(ui);
			}
		}
	}
	

	public void doDisplayRowListener() {
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = Integer.parseInt(displayAmount);
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)functionDutyList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), functionDutyList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				functionDutyList.get(currRow).setChecked(true);
			}
		} else {
			for (FunctionDutyUI divisionUI : this.functionDutyList) {
				divisionUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (FunctionDutyUI divisionUI : this.functionDutyList) {
			divisionUI.setChecked(false);
		}
	}


		
	// ******* Delete FunctionDuty  Panel  DELETE  *******
	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (FunctionDutyUI ui : this.deletedFunctionDutyList) {
			// first perform a check to ensure that no one conflict record has the
			// current function duty assigned
			if (this.functionDutyService.canFunctionDutyBeDeleted(ui.getId())) {
				this.functionDutyService.delete(ui.getFunctionDuty());
			} else {
				unableToDelete.add(ui.getDescription() + " (" + ui.getId() + ")");
			}
		}	

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected function duties were deleted " +
					"except for the following, which are assigned to at least one " +
					"conflict record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected function duties");
		}

		this.refreshList();
		
		this.deletedFunctionDutyList = new ArrayList<FunctionDutyUI>();
		this.renderDeleteFunctionDutyModalPanel = false;
		return null;
	}
	
	// ******* Delete FunctionDuty  Panel  CANCEL  *******
	public String doCancelDelete() {
		this.deletedFunctionDutyList = new ArrayList<FunctionDutyUI>();
		this.renderDeleteFunctionDutyModalPanel = false;
		return null;
	}
	
	public boolean validFunctionDutyDescription() {
		return (StringUtils.isNotEmpty(this.functionDutyAddDescription));
	}
	
	public boolean isRenderAddFunctionDutyModalPanel() {
		return renderAddFunctionDutyModalPanel;
	}

	public void setRenderAddFunctionDutyModalPanel(
			boolean renderAddFunctionDutyModalPanel) {
		this.renderAddFunctionDutyModalPanel = renderAddFunctionDutyModalPanel;
	}

	public boolean isRenderDeleteFunctionDutyModalPanel() {
		return renderDeleteFunctionDutyModalPanel;
	}

	public void setRenderDeleteFunctionDutyModalPanel(
			boolean renderDeleteFunctionDutyModalPanel) {
		this.renderDeleteFunctionDutyModalPanel = renderDeleteFunctionDutyModalPanel;
	}

	public List<FunctionDutyUI> getDeletedFunctionDutyList() {
		return deletedFunctionDutyList;
	}

	public void setDeletedFunctionDutyList(List<FunctionDutyUI> deletedFunctionDutyList) {
		this.deletedFunctionDutyList = deletedFunctionDutyList;
	}
	
	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}
	
	public String getFunctionDutyDescriptionSearchText() {
		return functionDutyDescriptionSearchText;
	}

	public void setFunctionDutyDescriptionSearchText(String functionDutyDescriptionSearchText) {
		this.functionDutyDescriptionSearchText = functionDutyDescriptionSearchText;
	}

	public void setFunctionDutyList(List<FunctionDutyUI> functionDutyList) {
		this.functionDutyList = functionDutyList;
	}

	public boolean isAllChecked() {
		return allChecked;
	}

	public void setAllChecked(boolean allChecked) {
		this.allChecked = allChecked;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.functionDutyList = null;
		this.deletedFunctionDutyList = null;
		this.functionDutyDescriptionSearchText = null;
		this.oldSortColumn = null;
		this.allChecked = false;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
	
	public List<SelectItem> getApplicationSelectItems() {
		List<Application> availableApplications = this.applicationService.retrieveAllApplications();
		Collections.sort(availableApplications, new Comparator<>() {
			public int compare(Application application1, Application application2) {
				return application1.getName().compareTo(application2.getName());
			}
		});
		
		List<SelectItem> applicationSelectItems = new ArrayList<SelectItem>();
		applicationSelectItems.add(new SelectItem("", ""));
		for (Application application : availableApplications) {
			applicationSelectItems.add(new SelectItem(application.getName(), application.getName()));
		}

		return applicationSelectItems;
	}
}


