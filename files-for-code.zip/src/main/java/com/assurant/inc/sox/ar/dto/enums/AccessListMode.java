package com.assurant.inc.sox.ar.dto.enums;

public enum AccessListMode {
	REVIEW, EDIT, VIEW_EDITS, PRINT;
}
