package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.SoxConcern;

public interface ISoxConcernService {
	public void add(String soxConcernCode, String soxConcernDescription); 	
	public void delete(SoxConcern soxConcern);	
	public SoxConcern findDuplicate(String code); 

	public List<SoxConcern> retrieveAllSoxConcerns(); 
	public List<SoxConcern> retrieveAllSoxConcernByCode(String CodeSelect); 
	public List<SoxConcern> retrieveDeletedSoxConcerns() ; 
	public List<SoxConcern> retrieveDeletedSoxConcernsByName(String soxConcernCodeSearchText) ;
	public List<SoxConcern> retrieveUnassignedSoxConcerns() ; 
	public List<SoxConcern> retrieveUnassignedSoxConcernsByCode(String soxConcernCodeSearchText);
	public boolean canSoxConcernBeDeleted(String soxConcernCode); 
	
}
