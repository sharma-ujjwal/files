package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.LockDTO;
import com.assurant.inc.sox.ar.service.ILockService;
import com.assurant.inc.sox.ar.service.base.LockServiceBase;
import com.assurant.inc.sox.domain.ar.ProcessLock;

@Service
public class LockService extends LockServiceBase implements ILockService {

	public void breakLock(String taskId) {
		
		ProcessLock lock = this.lockDao.findByProcessId(taskId);
		lock.setHolderId(this.sessionSystemUser.getUserId());
		lock.setLockedDate(new Date());
		this.lockDao.update(lock);
	}

	public LockDTO getLock(String taskId) {
		ProcessLock lock = this.lockDao.findByProcessId(taskId);
		return (lock == null || ProcessLock.DELETED.equals(lock.getDeleteFlag())) ? null : new LockDTO(lock);
	}

	public void lock(String taskId) {

		ProcessLock lock = this.lockDao.findByProcessId(taskId);
		if (lock == null) {
			lock = new ProcessLock();
			lock.setId(taskId);
			lock.setDeleteFlag(ProcessLock.NOT_DELETED);
			lock.setHolderId(this.sessionSystemUser.getUserId());
			lock.setLockedDate(new Date());
			this.lockDao.update(lock);
		} else {
			lock.setDeleteFlag(ProcessLock.NOT_DELETED);
			lock.setHolderId(this.sessionSystemUser.getUserId());
			lock.setLockedDate(new Date());
			this.lockDao.insert(lock);
		}
	}

	public void unlock(String taskId) {
		ProcessLock lock = this.lockDao.findByProcessId(taskId);
		if (lock != null) {
			lock.setDeleteFlag(ProcessLock.DELETED);
			this.lockDao.update(lock);
		}
	}
}
