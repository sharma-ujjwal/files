package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.IndividualDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


/**
 * Bean to handle data for the individual selection modal panel
 * 
 */

@Component("individualSelectionBean")
@Scope("session")
public class IndividualSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(IndividualSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("IndividualSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> individuals = createBundleBean.getIndividuals();
        individuals.clear();
        for (SelectAdapter item : chosen) {
            individuals.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("IndividualSelectionBean.retrieve(...) -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();

        if (searchString.length() < 2) {
            JSFUtils.addFacesErrorMessage("Enter at least 2 characters.");
        } else {
            for (IndividualDTO individual : metaDataService.retrieveIndividuals(searchString)) {
                FilterCriteriaDTO dto = new FilterCriteriaDTO();
                dto.setFilterCriteriaType(FilterCriteriaType.USERS);
                dto.setFilterValueName(individual.getName());
                dto.setFilterValueKey(String.valueOf(individual.getId()));
                FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
                results.add(adapter);
            }
            if (results.isEmpty()) {
                JSFUtils.addFacesErrorMessage("No results found for search.");
            }
        }

        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        logger.debug("IndividualSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter item : createBundleBean.getIndividuals()) {
            results.add(item);
        }
        return results;
    }
}
