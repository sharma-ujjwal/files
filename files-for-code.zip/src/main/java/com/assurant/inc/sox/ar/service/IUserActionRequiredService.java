package com.assurant.inc.sox.ar.service;

import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.UserActionRequiredDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;

public interface IUserActionRequiredService {

	/**
	 * Retrieves the retrieves user actions items for the provided review user access ids and application ids. The results will be
	 * returned in order sorted with accesses first (sorted by user name) and comments next (sorted by user name).
	 * 
	 * @param reviewUserAccessIds the review user access ids that are rejected
	 * @param reviewApplicationIds the review application ids that need action taken on them.
	 * @return a sorted list of user action required dto items.
	 */
	public List<UserActionRequiredDTO> retrieveActionItems(Long reviewerId, Long applicationId);

	public void completeActionItem(UserActionRequiredDTO userActionRequiredDTO, Date validateDate);

	public List<WorkOrderDTO> retrieveWorkOrdersByReviewUser(Long reviewUserId);

	public void addWorkOrder(List<UserActionRequiredDTO> userActionRequiredDTOs, String reasonCode, String taskId,
	    Long workOrderNumber, String comments);

	public void addWorkOrder(ReviewUserDTO reviewUserDTO, String reasonCode, String taskId, Long workOrderNumber, String comments);

	public void validateUsersAccesses(List<UserActionRequiredDTO> userActionRequiredDTOs);

	public void validateInvalidUsersAccesses(List<UserActionRequiredDTO> userActionRequiredDTOs);

	public void completeActionRequiredTask(String taskId);
}
