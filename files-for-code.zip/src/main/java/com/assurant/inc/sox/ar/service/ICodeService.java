package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;

public interface ICodeService {
	/**
	 * Retrieves the code with the given value from the given code set.
	 * This uses caching so we don't have thousands of calls to the database.  
	 * After a value is found it is cached for 24 hrs. (See CodeServiceBase.init())
	 * @param codeSet the code set that the desired code is from.
	 * @param value the value of the code to retrieve.
	 * @return the code from the code set with the given value. If the code does not exist then a null is returned.
	 */
	public CodeDTO retrieveCodeByValueFromCache(CodeSet codeSet, String value);

	/**
	 * Retrieves all of the codes that are a member of the given code set.
	 * @param codeSet the code set to retrieve codes for.
	 * @return the codes from the provided code set. If no codes are found then an empty list will be returned.
	 */
	public List<CodeDTO> retrieveAllCodesByType(CodeSet codeSet);
}
