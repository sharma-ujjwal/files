package com.assurant.inc.sox.ar.client.bean.review;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;

/**
 * @author JW14004
 * 
 * Adapt a FilterCriteriaDTO to a SelectAdapter to be manipulated by the modal panels.
 * 
 */
public class FilterCriteriaSelectAdapter extends SelectAdapter {
    private FilterCriteriaDTO dto;

    public FilterCriteriaSelectAdapter(FilterCriteriaDTO dto) {
        super();
        this.dto = dto;
    }

    @Override
    public String getDisplayString() {
        return dto.getFilterValueName();
    }

    @Override
    public String getId() {
        return dto.getFilterValueName();
    }

    public FilterCriteriaType getType() {
        return dto.getFilterCriteriaType();
    }
    
    @Override
    public Object getObject() {
        return dto;
    }
}
