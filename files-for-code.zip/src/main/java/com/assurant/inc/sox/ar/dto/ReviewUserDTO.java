package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.UserStatus;

public class ReviewUserDTO {

	private final ReviewUser reviewUser;
	private final CodeDTO rejectCode;
	private final CodeDTO completedFlag;
	private String managerName;

	public ReviewUserDTO(ReviewUser reviewUser, CodeDTO rejectCode, CodeDTO completeFlag) {
		this.reviewUser = reviewUser;
		this.rejectCode = rejectCode;
		this.completedFlag = completeFlag;
		
	}

	public ReviewUser getReviewUser() {
		return this.reviewUser;
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getReviewUserId()
	 */
	public Long getReviewUserId() {
		return this.reviewUser.getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getCreatedBy()
	 */
	public String getCreatedBy() {
		return this.reviewUser.getCreatedBy();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getCreatedDate()
	 */
	public Date getCreatedDate() {
		return this.reviewUser.getCreatedDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getReviewerId()
	 */
	public Long getReviewerId() {
		return this.reviewUser.getReviewerId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getReviewUserComment()
	 */
	public String getRejectComment() {
		return this.reviewUser.getReviewUserComment();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getReviewUserStatusDate()
	 */
	public Date getRejectDate() {
		return this.reviewUser.getReviewUserStatusDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getUserId()
	 */
	public Long getUserId() {
		return this.reviewUser.getUserId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.ReviewUser#getUserName()
	 */
	public String getUserName() {
		return this.reviewUser.getUserName();
	}

	public void setUserName(String name) {
		this.reviewUser.setUserName(name);
	}

	public String getDepartmentName() {
		Department department = reviewUser.getDepartment();
		return (department == null) ? null : department.getName();
	}

	public String getDivisionName() {
		Division division = reviewUser.getDivision();
		return (division == null) ? null : division.getName();
	}

	public String getUserStatus() {
		UserStatus userStatus = reviewUser.getUserStatus();
		return (userStatus == null) ? null : userStatus.getUserStatusDescription();
	}

	public String getManagerName() {
		return this.managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public CodeDTO getRejectCode() {
		return rejectCode;
	}

	public CodeDTO getCompletedFlag() {
		return completedFlag;
	}

}
