package com.assurant.inc.sox.ar.service;

import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.admin.ui.RejectedUserUI;
import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.ExtractSystem;
import com.assurant.inc.sox.domain.ar.RejectedUser;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;

public interface IRejectedUserService {
	public List<RejectedUserUI> findAll();

	public List<RejectedUserUI> findByValue(String srcUserId,
			Long extrctSysId, String selectedDateCriteria,
			Date createdDateCriteria);
	

	public void addUser(String keyId, String firstName, String middleName,
			String lastName, Long userTypeId, Long departmentId,
			Long divisionId, String location, String jobTitle,
			Long supervisorId, String bsnssSgmnt,
			String phone, String emailAddress, Long userStatusId,
			String satStatus, String satJobRole, String satComment,
			Long rejectedUserId, Long extractSysId, Date extractSysDate);

	public List<SelectItem> getAvailableInternalIdentifierType();

	public String getAlternateIds(String keyId);

/*
	public void saveAlternateId(String keyId, String lookUpAltId,
			Long rejectedUserId, Long userId, Long internalIdentifierType);
*/
	// Removed for testing
	// public List<SelectItem> getAvailableDepartment();

	// public List<SelectItem> getAvailableDivision();

	// public List<SelectItem> getAvailableUserType();
	public void updateUser(Long rejectedUserId, Long userId, String keyId, 
			String firstNm, String mddlNm, String lastNm, Long userTypeId, 
			Long departmentId, Long divisionId, String location, String jobTitle,
			Long supervisorId, String costCenter, String bsnssSgmnt,
			String phone, String emailAddress, Long userStatusId,
			String satStatus, String satJobRole, String satComment);
	/*
	
	public void updateUser(Long rejectedUserId, Long userId, String keyId, String firstName, String middleName,
			String lastName, Long userTypeId, Long departmentId,
			Long divisionId, String location, String jobTitle,
			Long supervisorId, String costCenter, String bsnssSgmnt,
			String phone, String emailAddress, Long userStatusId,
			String satStatus);
*/
	public List<User> findByUserName(String searchFirstName,String searchLastName);
	public void populatSupevisorData(Long supervisor);

	public List<SelectItem> populateSupevisorDepartments(Long supervisor);

	public List<SelectItem> populateSupevisorDivisions(Long supervisor);

	public List<SelectItem> populateSupevisorCostCenters(Long supervisor);

	public List<SelectItem> populateSupevisorBusinessSegments(Long supervisor);

	public List<SelectItem> populateSupevisorJobTitles(Long supervisor, String existingJobTitle);

	public List<SelectItem> populateSupevisorLocations(Long supervisor, String existingLocation);

	public List<UserStatus> findUserStatusList();
	
	public List<Department> retrieveAllDepartments();
	
	public List<Division> retrieveAllDivisions();
	
	public List<UserType> retrieveAllUserTypes();

	public List<String> retrieveAllBusinessSeg();
	
	public List<String> retrieveAllCostCenter();
	
	public List<ExtractSystem> retrieveExtractSystems();

	public List<Supervisor> retrieveAllSupervisors();

	public String findUserExist(Long excludeUserId, String searchKeyId, String satMFId, String satGFId, 
			String satCFId, String satLCSId,String satFDMSId, String satSiteminderId, 
			String searchSatAltId1,	String searchSatAltId2, String searchSatAltId3);

	public List<UserUI> searchAssociatedUser(String searchFirstNm,
			String searchLastNm, String keyId, Long supervisorId,
			List userStatuses, List userTypes,
			List departments, List divisions, String location);	

	public void updateAltIdsForUser(Long userId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3);

	public void updateAltIds(Long rejectedUserId, Long userId, String keyId, String emailAddress, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3);

	public List<User> findUsersBySupevisorId(Long supervisorId);

	public boolean isAltIdExists(String altId);

	public RejectedUser findByRejectedUserId(Long rejectedUserId);

	public List<RejectedUser> findBySrcUserId(String srcUserId);

	public void reconcileRejects();
	
}
