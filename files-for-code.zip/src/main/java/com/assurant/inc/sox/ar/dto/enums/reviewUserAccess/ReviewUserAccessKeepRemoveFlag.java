package com.assurant.inc.sox.ar.dto.enums.reviewUserAccess;

import com.assurant.inc.sox.domain.ar.ReviewUserAccess;

public enum ReviewUserAccessKeepRemoveFlag {

    KEEP(ReviewUserAccess.KEEP_FLAG), REMOVE(ReviewUserAccess.REMOVE_FLAG);
    
    private final String flagValue;
    
    private ReviewUserAccessKeepRemoveFlag(String flagValue) {
        this.flagValue = flagValue;
    }
    
    public String getFlagValue()
    
    {
        return this.flagValue;
    }
    
    public static ReviewUserAccessKeepRemoveFlag getByFlagValue(String flagValue) {
        ReviewUserAccessKeepRemoveFlag result = null;
        for(ReviewUserAccessKeepRemoveFlag flag : ReviewUserAccessKeepRemoveFlag.values()){
            if(flag.flagValue.equalsIgnoreCase(flagValue)){
                result = flag;
                break;
            }
        }
        return result;
    }
}
