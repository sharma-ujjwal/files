package com.assurant.inc.sox.ar.utils;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	public static Date getDateDaysAgo(int days) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, -days);
		return calendar.getTime();
	}
}