package com.assurant.inc.sox.ar.comparators;

import java.util.Comparator;

/**
 * @author JW14004
 * 
 * Compares two objects by comparing the value of the given field for each
 * object. If the fields are of different types, they are converted to a String
 * and compared with the String value.
 * 
 */
@SuppressWarnings("unchecked")
public class GenericComparator implements Comparator {
	/** Stores the name of the getter method */
	private String getterName;

	/** Is the order ascending or descending, ascending if true */
	private boolean ascending;

	/** The number to return if o1 < 02 */
	private int ordernumber;

	/**
	 * Sort ascending by fieldName
	 * 
	 * @param fieldName String of length > 0
	 */
	public GenericComparator(String fieldName) {
		this(fieldName, true);
	}
	
	/**
	 * @param fieldName String of length > 0
	 * @param ascending
	 */
	public GenericComparator(String fieldName, boolean ascending) {
		super();
		this.getterName = computerGetterName(fieldName);
		this.ascending = ascending;
		this.ordernumber = ascending ? -1 : 1;
	}

	@SuppressWarnings("unchecked")
	public int compare(Object o1, Object o2) {
		if (o1 == null || o2 == null) {
			return o1 == o2 ? 0 : (o1 == null ? ordernumber : -ordernumber);
		}
		try {
			Comparable v1 = (Comparable) o1.getClass().getMethod(getterName).invoke(o1);
			Comparable v2 = (Comparable) o2.getClass().getMethod(getterName).invoke(o2);
			if (v1 == null || v2 == null) {
				return v1 == v2 ? 0 : (v1 == null ? ordernumber : -ordernumber);
			}
			return ascending ? v1.compareTo(v2) : v2.compareTo(v1);
		} catch (Exception e) {
			throw new RuntimeException("Error in compare ", e);
		}
	}

	/**
	 * Computes the name of the getter for the given field name. Add "get" to
	 * the front and upper case the first letter. Fails on null or empty string.
	 * 
	 * @param name the name of the field
	 * @return the getter for the field name
	 */
	private String computerGetterName(String name) {
		return "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
	}
}
