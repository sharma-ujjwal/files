package com.assurant.inc.sox.ar.dto.tasklist;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewBundle;

public class BundleTaskListDTO extends AbstractTaskListDTO {

	private final ReviewBundleDTO reviewBundle;

	public BundleTaskListDTO(ReviewDTO review, ReviewBundleDTO bundle) {
		super(review != null ?review : new ReviewDTO(new Review(), new CodeDTO(new Code()), new CodeDTO(new Code())));
		if (bundle != null) {
			this.reviewBundle = bundle;
		} else {
			this.reviewBundle = new ReviewBundleDTO(new ReviewBundle(), new CodeDTO(new Code()));
		}
	}

	@Override
	public String getStatus() {
		return this.reviewBundle.getStatus().getDisplay();
	}

	public CodeDTO getBundleStatus() {
		return this.reviewBundle.getStatus();
	}

	public ReviewBundleDTO getReviewBundle() {
		return reviewBundle;
	}
}
