/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import com.assurant.inc.sox.ar.service.IReviewOwnerSummaryService;
import com.assurant.inc.sox.dao.ar.IReviewOwnerSummaryDao;
import com.assurant.inc.sox.domain.admin.ReviewOwnerSummary;
import com.assurant.inc.sox.domain.searchable.ReviewOwnerSummarySearchCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author Brian Olson
 *
 */
@Service
public class ReviewOwnerSummaryService implements IReviewOwnerSummaryService {

	@Autowired
	private IReviewOwnerSummaryDao reviewOwnerSummaryDao;
	
	public IReviewOwnerSummaryDao getReviewOwnerSummaryDao() {
		
		return reviewOwnerSummaryDao;
	}

	public void setReviewOwnerSummaryDao(IReviewOwnerSummaryDao reviewOwnerSummaryDao) {
		this.reviewOwnerSummaryDao = reviewOwnerSummaryDao;
	}

	@Transactional(readOnly = true)
	public List<ReviewOwnerSummary> retrieveReviewOwnerSummariesByCriteria(
			ReviewOwnerSummarySearchCriteria criteria) {
		System.out.println("****In ReviewOwnerSummary Class");
		System.out.println("Conflict Hima Type: - "+criteria.getConflictTypeId());
		System.out.println("criteria.getApplicationId(): - "+criteria.getApplicationId());
		System.out.println("criteria.getOwnerTypeDescription(): - "+criteria.getOwnerTypeDescription());
		System.out.println("criteria.getReviewOwnerName(): - "+criteria.getReviewOwnerName());
		System.out.println("criteria.getConflictCode(): - "+criteria.getConflictCode());
		System.out.println("criteria.getLeftConflictName(): - "+criteria.getLeftConflictName());
		System.out.println("criteria.getRightConflictName(): - "+criteria.getRightConflictName());
		System.out.println("criteria.getCommentText(): - "+criteria.getCommentText());
		//System.out.println("Conflict Type: - "+criteria.getActiveOnly().booleanValue());
		return this.reviewOwnerSummaryDao.findReviewOwnerSummariesByCriteria(criteria);
	}
}
