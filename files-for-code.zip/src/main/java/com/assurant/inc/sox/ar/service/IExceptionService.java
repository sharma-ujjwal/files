/**
 * 
 */
package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.client.admin.ui.ExceptionSummaryUI;
import com.assurant.inc.sox.domain.admin.ExceptionSummary;

/**
 * @author Brian Olson
 *
 */
public interface IExceptionService {
	
	public ExceptionSummary getExceptionSummaryByUserId(Long userId);
	public List<ExceptionSummary> retrieveActiveExceptions();
	public List<ExceptionSummary> retrieveInactiveExceptions();
	public List<ExceptionSummary> retrieveDirectReportsBySupervisorId(Long userId, Long supervisorId);
	public void updateUser(ExceptionSummaryUI exceptionSummary);
}
