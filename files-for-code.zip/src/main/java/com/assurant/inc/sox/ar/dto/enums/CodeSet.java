package com.assurant.inc.sox.ar.dto.enums;

import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewBundle;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.ReviewWorkOrder;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.domain.ar.ReviewerReassignment;

public enum CodeSet {
	REVIEW_BUNDLE_STATUS(ReviewBundle.TABLE_NAME, ReviewBundle.STATUS_COLUMN_NAME), REVIEW_STATUS(Review.TABLE_NAME,
	    Review.STATUS_COLUMN_NAME), REVIEW_TYPE(Review.TABLE_NAME, Review.TYPE_COLUMN_NAME), REVIEWER_REASSIGNMENT_REASON(
	    ReviewerReassignment.TABLE_NAME, ReviewerReassignment.REASSIGN_REASON), REVIEWER_REJECT_REASON(Reviewer.TABLE_NAME,
	    Reviewer.REJECT_CODE_COLUMN_NAME), REVIEWER_STATUS(Reviewer.TABLE_NAME, Reviewer.STATUS_CODE_COLUMN_NAME), REVIEW_USER_REJECT_REASON(
	    ReviewUser.TABLE_NAME, ReviewUser.REJECT_CODE_COLUMN_NAME), REVIEW_USER_COMPLETE(ReviewUser.TABLE_NAME,
	    ReviewUser.COMPLETED_FLAG_COLUMN_NAME), REVIEW_USER_ACCESS_KEEP_REMOVE(ReviewUserAccess.TABLE_NAME,
	    ReviewUserAccess.KEEP_REMOVE_COLUMN_NAME), REVIEW_USER_ACCESS_STATUS(ReviewUserAccess.TABLE_NAME,
	  	    ReviewUserAccess.STATUS_COLUMN_NAME), WORK_ORDER_REASON(ReviewWorkOrder.TABLE_NAME, ReviewWorkOrder.REASON_COLUMN);

	private final String tableName;
	
	private final String columnName;

	private CodeSet(String tableName, String columnName) {
		this.tableName = tableName;
		this.columnName = columnName;
	}

	public String getTableName() {
		return tableName;
	}

	public String getColumnName() {
		return columnName;
	}

}
