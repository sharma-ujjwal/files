package com.assurant.inc.sox.ar.client.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.primefaces.event.TabChangeEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.jsf.FacesContextUtils;

import com.assurant.inc.sox.ar.client.bean.tasklist.AllTaskListBean;
import com.assurant.inc.sox.ar.client.bean.tasklist.BigBrotherTaskListBean;
import com.assurant.inc.sox.ar.client.bean.tasklist.MyTaskListBean;
import com.assurant.inc.sox.ar.client.bean.tasklist.RejectedAccessesTaskListBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.SystemUserUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.AbstractTaskListUI;
import com.assurant.inc.sox.ar.client.ui.tasklist.ActionRequiredTasklistUI;
import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.impl.SystemUserService;
import com.assurant.inc.sox.ar.utils.http.HttpHelper;
import org.springframework.context.annotation.Scope;

@Component("sessionDataBean")
@Scope("session")
public class SessionDataBean {

	/*
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(SessionDataBean.class);

	private SystemUserUI systemUser;
	private String selectedTabId;
	private static final String ALL_TASK_TAB_ID = "allTaskTab";
	private static final String MY_TASK_TAB_ID = "myTaskTab";
	private static final String BIG_BROTHER_TASK_TAB_ID = "bigBrotherTaskTab";
	private static final String REJECTED_ACCESSES_TAB_ID = "rejectedAccessestab";
	private String firstName;
	private String lastName;
	public String getName() {
		return this.firstName + " " + this.lastName;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public SessionDataBean() {

		this.selectedTabId = MY_TASK_TAB_ID;

		/*
		 * http header stuff
		 */
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		// Enumeration headerNames = request.getHeaderNames();
		// while(headerNames.hasMoreElements()){
		// String headerName = (String) headerNames.nextElement();
		// logger.debug("-------------http header name = " + headerName);
		// logger.debug("-------------http header = " + request.getHeader(headerName));
		// }

		String userId = request.getHeader("sm_user");
		String ldapGroups = request.getHeader("sm_groups");
		this.lastName = request.getHeader("sm_lastname");
		this.firstName = request.getHeader("sm_firstname");

		System.out.println("MYCARS soxDataAccess SessionDataBean() --> ldapGroups:: " + ldapGroups);

		if (ldapGroups == null) {
			ldapGroups = "CN=User_Iris_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_ProxyDeveloperPersona_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_PRD_FILENET_GRPEOIDC_EOIFORM_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_PRD_FILENET_RpsDC_EOIFORM_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=System.Teams.Policy.Update.Optional.ML.1,OU=Azure,OU=Groups,DC=clarica,DC=com^CN=User_GitHubCopilotAll_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_STG_FILENET_IndDC_RpsDC_CMS_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBSOXITOWNER_STAGE,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBSOXITOWNER_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=Users_SQL_ML_grpEoI1_qa_RO,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_DEV_FILENET_IndDC_RpsDC_CSWB_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_SIT_FILENET_IndDC_RpsDC_CSWB_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_STG_FILENET_IndDC_RpsDC_CSWB_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_SIT_FILENET_GroupDC_GWEW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_STG_FILENET_GroupDC_GWEW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_SIT_FILENET_RpsDC_WEW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_STG_FILENET_RpsDC_WEW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=Users_SQL_ML_INDClaims1_qa_RO,OU=User,OU=Groups,DC=clarica,DC=com^CN=Users_SQL_ML_INDClaims1_dv_RO,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_STG_FILENET_IndDC_AROW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_SIT_FILENET_IndDC_AROW_USERS_RO_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_TCoETosca,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBSOXAPP_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBSOXAPP_STAGE,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENROLLMENT_ADMIN_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENROLLMENT_USER_STAGE,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENROLLMENT_USER_DEV,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENROLLMENT_USER_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBAEB_EDI_ADMIN_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENGAGEUSERS_STAGE,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENGAGEUSERS_PROD,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_EBENGAGEUSERS_SIT,OU=User,OU=Groups,DC=clarica,DC=com^CN=User_MFAEnable_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=USER_VPN_StaffCanada_ML,OU=User,OU=Groups,DC=clarica,DC=com^CN=User26749XenAppRoamingProfileMLWrite,OU=User,OU=Groups,DC=clarica,DC=com^CN=User27073McAfeeDeviceControlNoReadNoWrite,OU=User,OU=Groups,DC=clarica,DC=com";
		}

		if (userId == null || userId.equals("")) {
			//userId = "DS03287";
			//lastName = "test";
			//firstName = "FirstName";
			userId = "hg12";
//			userId = "DS03287";
//			lastName = "test";
//			firstName = "FirstName";
//			userId = "TESTSOXITOWNER";
//			userId = "DR00111";
			lastName = "Dummy";
			firstName = "User";
		}
		logger.debug("-------------User Info =  lastName " + this.lastName + " firstName - " +this.firstName);
		logger.debug("-------------User Info =  SM_USER " + userId );
		SystemUserDTO systemUserDTO = (SystemUserDTO) FacesContextUtils.getWebApplicationContext(FacesContext.getCurrentInstance())
				.getBean("sessionSystemUser");

		SystemUserService systemUserService = (SystemUserService) FacesContextUtils.getWebApplicationContext(
				FacesContext.getCurrentInstance()).getBean("systemUserService");

		String soxLdapITComplianceRole = (String) FacesContextUtils.getWebApplicationContext(FacesContext.getCurrentInstance())
				.getBean("soxLdapITComplianceRole");

		String soxLdapReviewerRole = (String) FacesContextUtils.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean(
				"soxLdapReviewerRole");

		String soxLdapIpsUserRole = (String) FacesContextUtils.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean(
				"soxLdapIpsUserRole");

		List<String> ldapRoles = HttpHelper.parseHttpHeaderGroups(ldapGroups);
		logger.debug("-------------SM_GROUPS = " + ldapRoles);

		// TODO temp remove
		if(ldapGroups == null ||ldapGroups.equals("")){
			ldapRoles.add("EBSOXMTL");
			ldapRoles.add("EBSOXITOWNER");
			//ldapRoles.add("EBSOXIPSUSER");
			ldapRoles.add("EBSOXAPP");
			ldapRoles.add("EBBOSOXDESIGNER");
		}
//		 TODO temp remove
//		 userId = "DR00111";
		// userId = "testsoxitowner";
		//userId = "DS03287";
//		userId = "TESTSOXITOWNER";
//		userId = "EU74777";

		if (ldapRoles != null) {
			systemUserDTO.setItComplianceUser(ldapRoles.contains(soxLdapITComplianceRole));
			systemUserDTO.setReviewer(ldapRoles.contains(soxLdapReviewerRole));
			systemUserDTO.setIpsUser(ldapRoles.contains(soxLdapIpsUserRole));
		}

		systemUserDTO.setLdapRoles(ldapRoles);
		systemUserDTO.setUserId(userId.toUpperCase());
		systemUserDTO.setFirstName(firstName);
		systemUserDTO.setLastName(lastName);

		systemUserDTO = systemUserService.getSystemUserAccesses(ldapRoles);

		this.setSystemUser(new SystemUserUI(systemUserDTO));
	}

	public void onTabChange(TabChangeEvent event) {
		String tabId = event.getTab().getId();
		if (MY_TASK_TAB_ID.equals(tabId)) {
			doMyTaskListTabSwitch();
		} else if (ALL_TASK_TAB_ID.equals(tabId)) {
			doAllTaskListTabSwitch();
		} else if (BIG_BROTHER_TASK_TAB_ID.equals(tabId)) {
			doBigBrotherTaskListTabSwitch();
		} else if ("rejectedAccessesTaskTab".equals(tabId) || REJECTED_ACCESSES_TAB_ID.equals(tabId)) {
			doRejectedAccessesTaskListTabSwitch();
		}
	}

	public SystemUserUI getSystemUser() {
		return systemUser;
	}

	public void setSystemUser(SystemUserUI systemUser) {
		this.systemUser = systemUser;
	}

	public String getLoggedInUserId() {
		return getSystemUser().getUserId();
	}

	public void initSelectedTasklistBean() {
		if (this.selectedTabId.equals(MY_TASK_TAB_ID)) {
			MyTaskListBean bean = (MyTaskListBean) JSFUtils.lookupBean("myTaskListBean");
			bean.initBean();
		} else if (this.selectedTabId.equals(ALL_TASK_TAB_ID)) {
			AllTaskListBean bean = (AllTaskListBean) JSFUtils.lookupBean("allTaskListBean");
			bean.initBean();
		} else if (this.selectedTabId.equals(BIG_BROTHER_TASK_TAB_ID)) {
			BigBrotherTaskListBean bean = (BigBrotherTaskListBean) JSFUtils.lookupBean("bigBrotherTaskListBean");
			bean.initBean();
		} else if (this.selectedTabId.equals(REJECTED_ACCESSES_TAB_ID)) {
			RejectedAccessesTaskListBean bean = (RejectedAccessesTaskListBean) JSFUtils.lookupBean("rejectedAccessesTaskListBean");
			bean.initBean();
		}

	}

	private void unloadTasklistBeans() {
		MyTaskListBean myBean = (MyTaskListBean) JSFUtils.lookupBean("myTaskListBean");
		myBean.unloadBean();

		AllTaskListBean allBean = (AllTaskListBean) JSFUtils.lookupBean("allTaskListBean");
		allBean.unloadBean();

		BigBrotherTaskListBean bigBroBean = (BigBrotherTaskListBean) JSFUtils.lookupBean("bigBrotherTaskListBean");
		bigBroBean.unloadBean();

		RejectedAccessesTaskListBean rejAccessBean = (RejectedAccessesTaskListBean) JSFUtils
				.lookupBean("rejectedAccessesTaskListBean");
		rejAccessBean.unloadBean();

	}

	public String doMyTaskListTabSwitch() {
		this.selectedTabId = MY_TASK_TAB_ID;
		this.unloadTasklistBeans();
		this.initSelectedTasklistBean();
		return null;
	}

	public String doAllTaskListTabSwitch() {
		this.selectedTabId = ALL_TASK_TAB_ID;
		this.unloadTasklistBeans();
		this.initSelectedTasklistBean();
		return null;
	}

	public String doBigBrotherTaskListTabSwitch() {
		this.selectedTabId = BIG_BROTHER_TASK_TAB_ID;
		this.unloadTasklistBeans();
		this.initSelectedTasklistBean();
		return null;
	}

	@SuppressWarnings("unchecked")
	public String doRejectedAccessesTaskListTabSwitch() {
		this.selectedTabId = REJECTED_ACCESSES_TAB_ID;

		MyTaskListBean myBean = (MyTaskListBean) JSFUtils.lookupBean("myTaskListBean");
		List<AbstractTaskListUI> tasks = (List<AbstractTaskListUI>) myBean.getTaskListTable().getValue();
		if (tasks.size() > 0) {
			List<ActionRequiredTasklistUI> filteredList = new ArrayList<ActionRequiredTasklistUI>();
			for (AbstractTaskListUI taskList : tasks) {
				if (taskList instanceof ActionRequiredTasklistUI) {
					filteredList.add((ActionRequiredTasklistUI) taskList);
				}
			}
			this.unloadTasklistBeans();
			RejectedAccessesTaskListBean rejAccessBean = (RejectedAccessesTaskListBean) JSFUtils
					.lookupBean("rejectedAccessesTaskListBean");
			rejAccessBean.prePopTable(filteredList);
		}
		else {
			this.unloadTasklistBeans();
		}


		this.initSelectedTasklistBean();
		return null;
	}

	public String getAllTaskTabId() {
		return ALL_TASK_TAB_ID;
	}

	public String getMyTaskTabId() {
		return MY_TASK_TAB_ID;
	}

	public String getBigBrotherTaskTabId() {
		return BIG_BROTHER_TASK_TAB_ID;
	}

	public String getRejectedAccessesTaskTabId() {
		return REJECTED_ACCESSES_TAB_ID;
	}

	public String getSelectedTabId() {
		return selectedTabId;
	}

	public void setSelectedTabId(String selectedTabId) {
		this.selectedTabId = selectedTabId;
	}

	public boolean isItComplianceUser() {
		return systemUser.isItComplianceUser();
	}

	public boolean isReviewer() {
		return systemUser.isReviewer();
	}

}