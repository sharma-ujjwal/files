package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDashboardDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.dto.enums.reviewUser.ReviewUserCompletedFlag;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import com.assurant.inc.sox.ar.service.base.ReviewUserServiceBase;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.domain.luad.User;

/**
 * Review User Service handles the update and retrieval of a users
 * 
 * @author BB68602
 * 
 */
@Service
public class ReviewUserService extends ReviewUserServiceBase implements IReviewUserService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.assurant.inc.sox.ar.service.IReviewUserService#retrieveByReviewerIdNonRejected(Long, ReviewTypeCode)
	 */
	public List<ReviewUserDTO> retrieveByReviewerIdNonRejected(Long reviewerId, CodeDTO reviewTypeCode) {
		getLogger().debug("retrieveByReviewerIdNonRejected(reviewerId) --> being executed.");

		return buildReviewUserDtoList(getReviewUserDao().findByReviewerIdNonRejected(reviewerId), reviewTypeCode);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.assurant.inc.sox.ar.service.IReviewUserService#retrieveByReviewerId(Long, ReviewTypeCode)
	 */
	public List<ReviewUserDTO> retrieveByReviewerId(Long reviewerId, CodeDTO reviewTypeCode) {
		getLogger().debug("retrieveByReviewerId(reviewerId) --> being executed.");

		return buildReviewUserDtoList(getReviewUserDao().findByReviewerId(reviewerId), reviewTypeCode);
	}

	/**
	 * Build a list of review user dtos
	 * 
	 * @param reviewUsers
	 * @return
	 */
	private List<ReviewUserDTO> buildReviewUserDtoList(List<ReviewUser> reviewUsers, CodeDTO reviewTypeCode) {
		getLogger().debug("buildReviewUserDtoList(List<ReviewUser>) --> being executed.");

		HashMap<Long, User> managerCacheMap = new HashMap<Long, User>();
		
		List<ReviewUserDTO> dtos = new ArrayList<ReviewUserDTO>();
		for (ReviewUser user : reviewUsers) {

			CodeDTO rejectCode = null;
			CodeDTO completeCode = null;
			if( user.getReviewUserStatusCd() != null){
				rejectCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_REJECT_REASON, user.getReviewUserStatusCd());
			}
			if(user.getReviewCompletedFlag() != null){
				completeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_COMPLETE, user.getReviewCompletedFlag());
			}
			ReviewUserDTO dto = new ReviewUserDTO(user, rejectCode, completeCode);
			buildReviewUserDTO(dto, reviewTypeCode, managerCacheMap);
			dtos.add(dto);
		}
		return dtos;
	}

	private List<ReviewUserDashboardDTO> buildReviewUserDashboardDtoList(List<ReviewUser> reviewUsers, CodeDTO reviewTypeCode) {
		getLogger().debug("buildReviewUserDashboardDtoList(List<ReviewUser>) --> being executed.");
		
		HashMap<Long, User> managerCacheMap = new HashMap<Long, User>();
		
		List<ReviewUserDashboardDTO> dtos = new ArrayList<ReviewUserDashboardDTO>();
		for (ReviewUser user : reviewUsers) {
			CodeDTO rejectCode = null;
			CodeDTO completeCode = null;
			if(user.getReviewUserStatusCd() != null){
				rejectCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_REJECT_REASON, user.getReviewUserStatusCd());	
			}
			if(user.getReviewCompletedFlag() != null){
				completeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_COMPLETE, user.getReviewCompletedFlag());
			}
			ReviewUserDashboardDTO dto = new ReviewUserDashboardDTO(user, rejectCode, completeCode);
			buildReviewUserDTO(dto, reviewTypeCode, managerCacheMap);
			dtos.add(dto);
		}
		return dtos;
	}

	private void buildReviewUserDTO(ReviewUserDTO dto, CodeDTO reviewTypeCode, HashMap<Long, User> manager) {
		boolean isNonManager = !(ReviewTypeCode.MANAGER.getCode().equalsIgnoreCase(reviewTypeCode.getValue()));
		final ReviewUser user = dto.getReviewUser();
		/*
		 * This is a business rule to help them when they have bad data. Sometimes there is bad data and there is no user name for a
		 * record and they don't know easily which one it is, so they want up to make it top of the list "@" and display they key if
		 * of the user.
		 */
		if ((dto.getUserName() == null) || (dto.getUserName() != null && dto.getUserName().trim().equals(""))) {
			User employee = this.userDao.findByUserId(user.getUserId());
			dto.setUserName("@ No Name Found - KeyId=" + employee.getPk().getKeyId());
		}

		if (isNonManager) {
			Long userId = user.getManagerId();
			if (userId != null && userId.longValue() > 0) {
				/*
				 * Try and see if the manager/supervisor is already gotten from
				 * another user, if so get it from the temp cache
				 */
				User supervisor = manager.get(userId);
				if(supervisor == null){
					/*
					 * if supervisor is not found in cache then get it from 
					 * the database
					 */
					//changed for cr#6
					//supervisor = this.userDao.findByUserId(userId);
					supervisor = this.userDao.findByMgrUserId(userId);
					if(supervisor != null){
						/*
						 * if a supervisor was found then add it to the cache
						 */
						manager.put(supervisor.getUserId(), supervisor);
					}
				}
				dto.setManagerName(this.buildName(supervisor));
			}
		}
	}

	/**
	 * Builds name of the user.
	 * 
	 * @param user
	 * @return
	 */
	private String buildName(User user) {
		getLogger().debug("buildName(User user)--> being executed.");
		if (user == null) {
			return null;
		}

		String name = user.getLastName() + ", " + user.getFirstName();
		if (user.getMiddleName() != null) {
			name = name + " " + user.getMiddleName();
		}
		return name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.assurant.inc.sox.ar.service.IReviewUserService#rejectReviewUsers(List<ReviewUserDTO>, ReviewUserRejectReasonCode,
	 *      String)
	 */
	public void rejectReviewUsers(List<ReviewUserDTO> reviewUsers, ReviewerDTO reviewer, String reasonCode, String rejectComment) {
		getLogger().debug("rejectReviewUsers(List<ReviewUserDTO>) --> being executed.");
		for (ReviewUserDTO reviewUserDTO : reviewUsers) {

			ReviewUser reviewUser = reviewUserDTO.getReviewUser();
			beginRejectedUserSavvionProcess(reviewUser.getId());

			reviewUser.setReviewUserStatusCd(reasonCode);
			reviewUser.setReviewUserComment(rejectComment);
			reviewUser.setReviewUserStatusDate(new Date());
			reviewUser.setReviewCompletedFlag("Y");

			getReviewUserDao().save(reviewUser);
		}

		if (reviewUsers.size() > 0) {
			// if there are any rejected users then set the aciton required flag
			Reviewer reviewerDomain = reviewer.getReviewer();
			reviewerDomain.setActionsRequired(Reviewer.ACTION_REQUIRED_FLAG);
			this.reviewerDao.save(reviewerDomain);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.assurant.inc.sox.ar.service.IReviewUserService#completeReviewUser(ReviewUserDTO)
	 */
	public void completeReviewUser(ReviewUserDTO reviewUser) {
		getLogger().debug("completeReviewUser(ReviewUserDTO reviewUser)--> being executed.");
		ReviewUser user = reviewUser.getReviewUser();
		user.setReviewCompletedFlag(ReviewUserCompletedFlag.YES.getFlag());
		this.reviewUserDao.save(user);
	}

	private void beginRejectedUserSavvionProcess(Long reviewUserId) {

		HashMap<String, Object> dataSlots = new HashMap<String, Object>(5);
		dataSlots.put(ITaskValues.DATASLOTS_ASSIGNEE, this.savvionITComplianceUserId);
		dataSlots.put(ITaskValues.DATASLOTS_VALIDATE_REJECTED_USER_ID, reviewUserId.toString());

		this.workflowService.createProcess(WorkflowTemplateCode.rejectUserWF,
				DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_REJECT_USER,
		    ITaskValues.PROCESS_INSTANCE_NAME_PREFIX_SUMMARY, 
		    ITaskValues.PRIORITY_LOW, 
		    this.savvionITComplianceUserId,
		    dataSlots);
	}

	public List<ReviewUserDashboardDTO> retrieveByReviewerIdDashboard(Long reviewerId, CodeDTO reviewTypeCode) {
		getLogger().debug("retrieveByReviewerIdDashboard(reviewerId) --> being executed.");
		List<ReviewUser> users = getReviewUserDao().findByReviewerId(reviewerId);
		List<ReviewUserDashboardDTO> dtos = buildReviewUserDashboardDtoList(users, reviewTypeCode);
		calculateStats(dtos);
		return dtos;
	}

	private void calculateStats(List<ReviewUserDashboardDTO> dtos) {
		for (ReviewUserDashboardDTO dto : dtos) {
			List<ReviewUserAccess> accesses = getReviewUserAccessDao().findByReviewUserId(dto.getReviewUserId());
			int keepCount = 0;
			int removeCount = 0;
			for (ReviewUserAccess access : accesses) {
				if (ReviewUserAccess.KEEP_FLAG.equalsIgnoreCase(access.getKeepRemoveFlg())) {
					keepCount++;
				} else if (ReviewUserAccess.REMOVE_FLAG.equalsIgnoreCase(access.getKeepRemoveFlg())) {
					removeCount++;
				}
			}
			dto.setAccessesCount(accesses.size());
			dto.setAcceptedCount(keepCount);
			dto.setRejectedCount(removeCount);
		}
	}

	public ReviewUserDTO retrieveById(Long reviewUserId) {
		ReviewUser result = this.reviewUserDao.findById(reviewUserId);

		if (result == null) {
			return null;
		}

		CodeDTO rejectCode = null;
		CodeDTO completeCode = null;
		if(result.getReviewUserStatusCd() != null){
			rejectCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_REJECT_REASON, result.getReviewUserStatusCd());
		}
		if(result.getReviewCompletedFlag() != null){
			completeCode = this.codeService.retrieveCodeByValueFromCache(CodeSet.REVIEW_USER_COMPLETE, result.getReviewCompletedFlag());
		}

		return new ReviewUserDTO(result, rejectCode, completeCode);
	}

}
