package com.assurant.inc.sox.ar.utils.exceptions;

public class NonClosableReview extends Exception {

	private static final long serialVersionUID = 1L;

	public NonClosableReview(String message) {
		super(message);
	}
}
