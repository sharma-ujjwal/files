package com.assurant.inc.sox.ar.client.bean.review.selectmodals;

import java.util.ArrayList;
import java.util.List;

import com.assurant.inc.sox.ar.client.bean.review.FilterCriteriaSelectAdapter;
import com.assurant.inc.sox.ar.client.bean.review.SelectAdapter;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.SourceNameDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Bean to handle data for the system selection modal panel
 * 
 */
@Component("sourceNameSelectionBean")
@Scope("session")
public class SourceNameSelectionBean extends CreateBundleSelectionBean {
	private static final Logger logger = LoggerFactory.getLogger(SourceNameSelectionBean.class);
    @Override
    public String apply() {
        logger.debug("SourceNameSelectionBean.apply() -> Being executed.");
        List<FilterCriteriaSelectAdapter> systems = createBundleBean.getSystems();
        systems.clear();
        for (SelectAdapter item : chosen) {
            systems.add((FilterCriteriaSelectAdapter) item);
        }
        return null;
    }

    @Override
    public List<SelectAdapter> retrieve(String searchString) {
        logger.debug("SourceNameSelectionBean.retrieve(...) -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SourceNameDTO appSystem : metaDataService.retrieveSourceNames(searchString)) {
            FilterCriteriaDTO dto = new FilterCriteriaDTO();
            dto.setFilterCriteriaType(FilterCriteriaType.SOURCE_SYSTEM);
            dto.setFilterValueName(appSystem.getName());
            dto.setFilterValueKey(String.valueOf(appSystem.getId()));
            FilterCriteriaSelectAdapter adapter = new FilterCriteriaSelectAdapter(dto);
            results.add(adapter);
        }
        
        if (results.isEmpty()) {
        	JSFUtils.addFacesErrorMessage("No results found for search.");
		}        
        
        return results;
    }

    @Override
    public List<SelectAdapter> restore() {
        logger.debug("SourceNameSelectionBean.restore() -> Being executed.");
        List<SelectAdapter> results = new ArrayList<SelectAdapter>();
        for (SelectAdapter adapter : createBundleBean.getSystems()) {
            results.add(adapter);
        }
        return results;
    }
}
