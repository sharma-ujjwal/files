package com.assurant.inc.sox.ar.client.ui;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;

public class ReviewUI {

	private final ReviewDTO review;

	public ReviewUI(ReviewDTO review) {
		this.review = review;
	}

	public String getAdHoc() {
		return this.review.isAdHoc();
	}

	public ReviewDTO getReview() {
		return this.review;
	}

	public String getName() {
		return this.review.getReviewName();
	}

	public Date getCreatedDate() {
		return this.review.getCreatedDate();
	}

	public String getCreatedBy() {
		return this.review.getCreatedBy();
	}

	public String getTypeCode() {
		return this.review.getReviewTypeCd().getDisplay();
	}

	public int getNumberOfReports() {
		return this.review.getNumberOfReports();
	}

	public String getStatusCode() {
		return this.review.getReviewStatusCd().getDisplay();
	}

	public Long getReviewId() {
		return this.review.getReviewId();
	}

	public String getComments() {
		return this.review.getReviewComments();
	}

	/**
	 * @param reviewComments
	 * @see com.assurant.inc.sox.ar.dto.ReviewDTO#setReviewComments(java.lang.String)
	 */
	public void setComments(String reviewComments) {
		this.review.setReviewComments(reviewComments);
	}

	@Override
	public String toString() {
		return this.review.toString();
	}

	public boolean isNotManagerReview() {
        return !isManagerReview();
    }
    
    public boolean isManagerReview() {
        return ReviewTypeCode.MANAGER.getCode().equals(this.review.getReviewTypeCd().getValue());
    }
    
	public boolean isDataOwnerReview() {
		return ReviewTypeCode.DATA_OWNER.getCode().equals(this.review.getReviewTypeCd().getValue());
	}

	public boolean isSODReview() {
		return ReviewTypeCode.SEGREGATION_OF_DUTIES.getCode().equals(this.review.getReviewTypeCd().getValue());
	}
	
	public boolean isPrivilegedAccessReview() {
		return ReviewTypeCode.PRIVILEGED_ACCESS.getCode().equals(this.review.getReviewTypeCd().getValue());
	}

	public boolean isShowDataOwner(){
		return (this.isDataOwnerReview() || this.isPrivilegedAccessReview());
	}
}
