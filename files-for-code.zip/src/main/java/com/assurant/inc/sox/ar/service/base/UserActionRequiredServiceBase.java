package com.assurant.inc.sox.ar.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.dao.ar.IReviewApplicationDao;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.dao.ar.IReviewWorkOrderDao;
import com.assurant.inc.sox.dao.luad.IUserAccessDao;
import org.springframework.stereotype.Component;

@Component
public class UserActionRequiredServiceBase {
	protected static final Logger logger = LoggerFactory.getLogger(UserActionRequiredServiceBase.class);

	@Autowired
	protected IReviewUserAccessDao reviewUserAccessDao;
	@Autowired
	protected IReviewApplicationDao reviewApplicationDao;
	
	@Autowired
	protected IReviewUserDao reviewUserDao;
	@Autowired
	protected IWorkflowService workflowService;
	@Autowired
	protected IUserAccessDao userAccessDao;
	@Autowired
	protected IReviewWorkOrderDao workOrderDao;
	@Autowired
	protected ICodeService codeService;

	public IReviewUserAccessDao getReviewUserAccessDao() {
		return reviewUserAccessDao;
	}

	public void setReviewUserAccessDao(IReviewUserAccessDao reviewUserAccessDao) {
		this.reviewUserAccessDao = reviewUserAccessDao;
	}

	public IReviewApplicationDao getReviewApplicationDao() {
		return reviewApplicationDao;
	}

	public void setReviewApplicationDao(IReviewApplicationDao reviewApplicationDao) {
		this.reviewApplicationDao = reviewApplicationDao;
	}

	public IReviewUserDao getReviewUserDao() {
		return reviewUserDao;
	}

	public void setReviewUserDao(IReviewUserDao reviewUserDao) {
		this.reviewUserDao = reviewUserDao;
	}

	public IReviewWorkOrderDao getWorkOrderDao() {
		return workOrderDao;
	}

	public void setWorkOrderDao(IReviewWorkOrderDao workOrderDao) {
		this.workOrderDao = workOrderDao;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

	public IUserAccessDao getUserAccessDao() {
		return userAccessDao;
	}

	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}

	public void setUserAccessDao(IUserAccessDao userAccessDao) {
		this.userAccessDao = userAccessDao;
	}
}
