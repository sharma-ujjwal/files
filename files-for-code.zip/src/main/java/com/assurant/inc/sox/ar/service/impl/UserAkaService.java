package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.IInternalIdentifierTypeService;
import com.assurant.inc.sox.ar.service.IUserAkaService;
import com.assurant.inc.sox.ar.service.IUserService;
import com.assurant.inc.sox.dao.ar.IUserAkaDAO;
import com.assurant.inc.sox.domain.luad.InternalIdentifierType;
import com.assurant.inc.sox.domain.luad.UserAka;
@Service
public class UserAkaService implements
		IUserAkaService {

	@Autowired
	IUserAkaDAO userAkaDAO;
	

	@Autowired
	IInternalIdentifierTypeService internalIdentifierTypeService;

	@Autowired
	IUserService userService;
	@Autowired
	private SystemUserDTO systemUser;

	public void update(Long userId, Long typeId,String lookUpAltId) {
		
		UserAka userAka= this.userAkaDAO.findByUserAndType(userId, typeId);
		if (userAka!=null){
			Date currentDate = new Date();
			userAka.setIntrnlIdntfyrTxt(lookUpAltId);
			userAka.setLstChngdDt(currentDate);
			userAka.setLstChngdBy(this.systemUser.getUserId());
			this.userAkaDAO.save(userAka);
		}
		else{
			this.add(userId, typeId, lookUpAltId);
		}
	}
	
	public void delete(Long userId, Long typeId,String lookUpAltId) {
		
		UserAka userAka= this.userAkaDAO.findByUserAndType(userId, typeId);
		if (userAka!=null){
			Date currentDate = new Date();
			if((userAka.getIntrnlIdntfyrTxt()!=null) && 
					(lookUpAltId.equalsIgnoreCase(userAka.getIntrnlIdntfyrTxt()))){
				userAka.setDltFlg("Y");
				userAka.setLstChngdDt(currentDate);
				userAka.setLstChngdBy(this.systemUser.getUserId());
				this.userAkaDAO.save(userAka);
			}
		}
	}
	
	public void markAsDelete(Long userId, Long typeId) {
		
		UserAka userAka= this.userAkaDAO.findByUserAndType(userId, typeId);
		if (userAka!=null){
			Date currentDate = new Date();
			userAka.setDltFlg("Y");
			userAka.setLstChngdDt(currentDate);
			userAka.setLstChngdBy(this.systemUser.getUserId());
			this.userAkaDAO.save(userAka);
		}
	}

	public UserAka findByUserAndType(Long uId, Long typeId){
		return this.userAkaDAO.findByUserAndType(uId, typeId);
	}

	public List<UserAka> findAllByUser(Long uId){
		return this.userAkaDAO.findAllByUser(uId);
	}

	public List<UserAka> findAll(){
		return this.userAkaDAO.findAll();
	}

	public void add(Long userId, Long internalIdentifierTypeId,String lookUpAltId) {
		
		InternalIdentifierType internalIdentifierType = this.internalIdentifierTypeService
				.findById(internalIdentifierTypeId);
		if(lookUpAltId!=null && !StringUtils.isEmpty(lookUpAltId)){
			UserAka userAka= new UserAka();
			Date currentDate = new Date();
			userAka.setUserId(userId);
			userAka.setInternalIdentifierType(internalIdentifierType);
			userAka.setIntrnlIdntfyrTxt(lookUpAltId);
			userAka.setCrtdDt(currentDate);
			userAka.setCrtdBy(this.systemUser.getUserId());
			userAka.setDltFlg("N");
			this.userAkaDAO.save(userAka);
		}
	}
	
	public void deleteAllByUserId(Long userId) {
		
		List<UserAka> userAkaList= this.userAkaDAO.findAllByUser(userId);
		if (userAkaList!=null){
			for(UserAka userAka: userAkaList){
				Date currentDate = new Date();
					userAka.setDltFlg("Y");
					userAka.setLstChngdDt(currentDate);
					userAka.setLstChngdBy(this.systemUser.getUserId());
					this.userAkaDAO.save(userAka);
			}
		}
	}

	public boolean isAltIdExists(String altId){
		return this.userAkaDAO.isAltIdExists(altId);
	}
	
}
