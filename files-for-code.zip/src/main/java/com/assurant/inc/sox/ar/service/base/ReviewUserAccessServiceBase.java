package com.assurant.inc.sox.ar.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.impl.ReviewUserAccessService;
import com.assurant.inc.sox.dao.ar.IReviewApplicationDao;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import org.springframework.stereotype.Component;

@Component
public class ReviewUserAccessServiceBase {

	@Autowired
	protected IReviewUserAccessDao reviewUserAccessDao = null;
	@Autowired
	protected IReviewApplicationDao reviewApplicationDao = null;
	
	@Autowired
	protected ICodeService codeService;
	@Autowired
	protected IReviewerDao reviewerDao = null;

	protected static final Logger logger = LoggerFactory.getLogger(ReviewUserAccessService.class);

	public static Logger getLogger() {
		return logger;
	}

	public IReviewUserAccessDao getReviewUserAccessDao() {
		return this.reviewUserAccessDao;
	}

	public void setReviewUserAccessDao(IReviewUserAccessDao reviewUserAccessDao) {
		this.reviewUserAccessDao = reviewUserAccessDao;
	}

	public IReviewApplicationDao getReviewApplicationDao() {
		return this.reviewApplicationDao;
	}

	public void setReviewApplicationDao(IReviewApplicationDao reviewApplicationDao) {
		this.reviewApplicationDao = reviewApplicationDao;
	}

	public IReviewerDao getReviewerDao() {
		return reviewerDao;
	}

	public void setReviewerDao(IReviewerDao reviewerDao) {
		this.reviewerDao = reviewerDao;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}
}
