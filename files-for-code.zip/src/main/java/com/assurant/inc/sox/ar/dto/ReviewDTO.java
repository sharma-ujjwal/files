package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.Review;

public class ReviewDTO {

	private final Review review;
	private final CodeDTO typeCode;
	private final CodeDTO statusCode;

	private int numberOfReports;

	public ReviewDTO(Review review, CodeDTO reviewTypeCode, CodeDTO statusCode) {
		this.review = review;
		this.statusCode = statusCode;
		this.typeCode = reviewTypeCode;
		
	}

	public Review getReview() {
		return this.review;
	}

	/**
	 * @return the numberOfReports
	 */
	public int getNumberOfReports() {
		return this.numberOfReports;
	}

	/**
	 * @param numberOfReports the numberOfReports to set
	 */
	public void setNumberOfReports(int numberOfReports) {
		this.numberOfReports = numberOfReports;
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getReviewId()
	 */
	public Long getReviewId() {
		return this.review.getId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getCreatedBy()
	 */
	public String getCreatedBy() {
		return this.review.getCreatedBy();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getCreatedDate()
	 */
	public Date getCreatedDate() {
		return this.review.getCreatedDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getReviewComments()
	 */
	public String getReviewComments() {
		return this.review.getReviewComments();
	}

	/**
	 * @param reviewComments
	 * @see com.assurant.inc.sox.domain.ar.Review#setReviewComments(java.lang.String)
	 */
	public void setReviewComments(String reviewComments) {
		this.review.setReviewComments(reviewComments);
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getReviewName()
	 */
	public String getReviewName() {
		return this.review.getReviewName();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getReviewStatusCd()
	 */
	public CodeDTO getReviewStatusCd() {
		return this.statusCode;
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#getReviewTypeCd()
	 */
	public CodeDTO getReviewTypeCd() {
		return this.typeCode;
	}

	public Date getTargetCompleteDate() {
		return this.review.getReviewTargetDate();
	}

	public String isAdHoc() {
		return this.review.getAdHoc();
	}

	public Date getReviewCompletedDate() {
		return this.review.getReviewCompletedDate();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Review#toString()
	 */
	@Override
	public String toString() {
		return this.review.toString();
	}

	public CodeDTO getTypeCode() {
		return typeCode;
	}
}
