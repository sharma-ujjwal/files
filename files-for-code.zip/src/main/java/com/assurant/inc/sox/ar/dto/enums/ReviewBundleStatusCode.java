package com.assurant.inc.sox.ar.dto.enums;

import com.assurant.inc.sox.domain.ar.ReviewBundle;

public enum ReviewBundleStatusCode {
	IN_PROCESS(ReviewBundle.IN_PROCESS_STATUS_CODE), APPROVED(
	    ReviewBundle.APPROVED_STATUS_CODE), REJECTED(ReviewBundle.REJECTED_STATUS_CODE), SUBMITTED(
	    ReviewBundle.SUBMITTED_STATUS_CODE), COMPLETED(ReviewBundle.COMPLETED_STATUS_CODE),
	    REJECTED_W_NO_CONFLICTS(ReviewBundle.REJECTED_W_NO_CONFLICTS_STATUS_CODE);

	private final String code;
	

	private ReviewBundleStatusCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}
}
