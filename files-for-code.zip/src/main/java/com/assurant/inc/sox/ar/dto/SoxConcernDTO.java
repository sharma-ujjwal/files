package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.SoxConcern;

public class SoxConcernDTO {
    private SoxConcern soxConcern;

    public SoxConcernDTO(SoxConcern soxConcern) {
        super();
        this.soxConcern = soxConcern;
    }

    public String getSoxConcernCode() {
        return soxConcern.getSoxConcernCode();
        
    }

    public String getSoxConcernDescription() {
        return soxConcern.getSoxConcernDescription();
    }
    
    public Date getActiveFromDate() {
		return this.soxConcern.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.soxConcern.getActiveToDate();
	}
	
	public Long getId() {
		return this.soxConcern.getId();
	}
}
