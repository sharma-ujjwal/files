/**
 * 
 */
package com.assurant.inc.sox.ar.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.ISoxConcernService;
import com.assurant.inc.sox.consts.DateUtil;
import com.assurant.inc.sox.consts.IFlags;
import com.assurant.inc.sox.dao.ar.ISoxConcernDao;
import com.assurant.inc.sox.domain.ar.SoxConcern;

 /**
 * @author RuthSchmalz
 */
@Service
public class SoxConcernService implements ISoxConcernService {
	
	@Autowired
	private ISoxConcernDao soxConcernDao;
	
	@Autowired
	private SystemUserDTO systemUser;

	public SoxConcernService() {
		
	}

	public List<SoxConcern> retrieveAllSoxConcernByCode(String codeSelect){
		return  this.soxConcernDao.findByValue(codeSelect);
	}
	
	public List<SoxConcern> retrieveAllSoxConcerns() {
		return this.soxConcernDao.findAll();
	}
	
	public SoxConcern findDuplicate(String code) {
		return this.soxConcernDao.findDuplicate(code);
	}

	public List<SoxConcern> retrieveDeletedSoxConcerns() {
		return this.soxConcernDao.findDeleted();
	}
	
	public List<SoxConcern> retrieveDeletedSoxConcernsByName(String soxConcernCodeSearchText) {
		return this.soxConcernDao.findDeletedByName(soxConcernCodeSearchText);
	}

	public List<SoxConcern> retrieveUnassignedSoxConcerns() {
		return this.soxConcernDao.findUnassigned();
	}

	public List<SoxConcern> retrieveUnassignedSoxConcernsByCode(String soxConcernCodeSearchText) {
		return this.soxConcernDao.findUnassignedByName(soxConcernCodeSearchText);
	}

	@Transactional  //This causes a RollBack if any errors are encountered.
	public void add(String soxConcernCode, String soxConcernDescription) {
		Date currentDate = new Date();
		
		//Create a SoxConcern record.
		SoxConcern soxConcern = new SoxConcern();
		
		soxConcern.setSoxConcernCode(soxConcernCode);		
		soxConcern.setSoxConcernDescription(soxConcernDescription);
		soxConcern.setDeleteFlag(IFlags.NOT_DELETED);
		soxConcern.setCreatedBy(this.systemUser.getUserId());
		soxConcern.setCreatedDate(currentDate);

		soxConcern.setActiveFromDate(currentDate);
		soxConcern.setActiveToDate(DateUtil.END_OF_TIME);
		this.soxConcernDao.save(soxConcern);
	}

		
	//**                 DELETE                   ******
	@Transactional  //This causes a RollBack if any errors are encountered.
	public void delete(SoxConcern soxConcern) {
		Date currentDate = new Date();

		//Create an audit trail record using the Existing record.
		//This will generate a new ID and a new record will be added. 
		//(Delete Flag = N)
		SoxConcern currentSoxConcern = new SoxConcern();
		currentSoxConcern.setSoxConcernCode(soxConcern.getSoxConcernCode());
		currentSoxConcern.setSoxConcernDescription(soxConcern.getSoxConcernDescription());
		currentSoxConcern.setDeleteFlag(IFlags.NOT_DELETED);
		currentSoxConcern.setCreatedBy(soxConcern.getCreatedBy());
		currentSoxConcern.setCreatedDate(soxConcern.getCreatedDate());
		currentSoxConcern.setLastChangedBy(this.systemUser.getUserId());
		currentSoxConcern.setLastChangedDate(currentDate);
		
		currentSoxConcern.setActiveFromDate(soxConcern.getActiveFromDate());
		currentSoxConcern.setActiveToDate(DateUtils.addSeconds(currentDate,-1));
		this.soxConcernDao.save(currentSoxConcern);
			
		//Create a Deleted SoxConcern record using the Existing record.
		//Using the existing ID, update the record. 
		//(Delete Flag = Y)
		soxConcern.setDeleteFlag(IFlags.DELETED);
		soxConcern.setActiveFromDate(currentDate);
		soxConcern.setActiveToDate(currentDate);
		this.soxConcernDao.save(soxConcern);
	}

	public boolean canSoxConcernBeDeleted(String soxConcernCode) {
		return this.soxConcernDao.canSoxConcernBeDeleted(soxConcernCode);
	}
}
