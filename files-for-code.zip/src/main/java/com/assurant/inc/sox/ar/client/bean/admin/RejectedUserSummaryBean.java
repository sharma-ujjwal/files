package com.assurant.inc.sox.ar.client.bean.admin;

import com.assurant.inc.sox.ar.client.admin.ui.RejectedUserUI;
import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.service.IExtractSystemService;
import com.assurant.inc.sox.ar.service.IRejectedUserService;
import com.assurant.inc.sox.ar.service.IUserService;
import com.assurant.inc.sox.domain.ar.*;
import com.assurant.inc.sox.domain.luad.User;


import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import javax.faces.application.FacesMessage;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import java.util.*;

@Component("rejectedUserSummaryBean")
@Scope("session")
public class RejectedUserSummaryBean {

	private static final Logger logger = LoggerFactory
			.getLogger(RejectedUserSummaryBean.class);
	private List<RejectedUserUI> rejectedUserList;
	@Autowired
	private IRejectedUserService rejectedUserService;
	@Autowired
	private IExtractSystemService extractSystemService;
	@Autowired
	private IUserService userService;

	private String displayAmount = "10";
	private String popupDisplayAmount = "10";
	private String oldSortColumn;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;

	private boolean renderAddUserModalPanel;
	private boolean renderSearchUserModalPanel;
	private boolean renderAddSearchedUserPanel;
	private boolean renderAssociatedUserSearchModalPanel;
	private boolean renderSearchedAssociatedUserModalPanel;
	private boolean renderAddAlternateIdModalPanel;
	private Long rejectedUserId;
	private Long userId;
	private String lastName;
	private String firstName;
	private String middleName;
	private Long departmentId;
	private String departmentName;
	private Long divisionId;
	private String divisionName;
	private String keyId;

	private Long supervisorId;
	private String supervisorName;
	private Long status;
	private String userStatusDescription;
	private String existingAlternateIds;

	private Long userType;
	private String userTypeDescription;
	private String costCenter;
	private String jobTitle = "";
	private String emailAddress;
	private String phone;
	private String satStatus;
	private String location = "";
	private String satAltId1;
	private String satAltId2;
	private String satAltId3;
	private String newAltId;

	private String satMFId;
	private String satGFId;
	private String satCFId;
	private String satLCSId;
	private String satFDMSId;
	private String satSiteMinderId;
	private String satJobRole;
	private String satComment;
	private String bsnssSgmnt;
	private String lookUpAltId;
	private String srcUserId;
	private String searchSrcUserId;
	private Long searchExtrctSysId;
	private boolean isInitialLoad = true;

	public String getSearchSrcUserId() {
		return searchSrcUserId;
	}

	public Long getSearchExtrctSysId() {
		return searchExtrctSysId;
	}

	public void setSearchExtrctSysId(Long searchExtrctSysId) {
		this.searchExtrctSysId = searchExtrctSysId;
	}

	public void setSearchSrcUserId(String searchSrcUserId) {
		this.searchSrcUserId = searchSrcUserId;
	}

	private List<SelectItem> availableExtractSystem;
	private List<SelectItem> availablecreatedDateCriteria;
	private String selectedDateCriteria;
	private Long extrctSysId;
	private Date extractSysDate;
	private String extrctSysName;
	private Date createdDateCriteria;

	private List<UserUI> userList;

	private List<SelectItem> supevisorDepartments = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorDivisions = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorBusinessSegments = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorJobTitles = new ArrayList<SelectItem>();
	private List<SelectItem> supevisorLocations = new ArrayList<SelectItem>();
	private List<UserUI> supervisorDirectReports = new ArrayList<UserUI>();


	public List<UserUI> getSupervisorDirectReports() {
		if (this.supervisorDirectReports == null || this.supervisorId == null)
			this.supervisorDirectReports = new ArrayList<UserUI>();
		return this.supervisorDirectReports;
	}

	public void setSupervisorDirectReports(List<UserUI> supervisorDirectReports) {
		this.supervisorDirectReports = supervisorDirectReports;
	}

	private List<SelectItem> availableDepartment;
	private List<SelectItem> availableDivision;
	private List<SelectItem> availableStatus;
	private List<SelectItem> availableUserType;
	private List<SelectItem> availableBusinessSeg;
	private List<SelectItem> availableCostCenter;
	//private List<SelectItem> availableFilters;


	//private List<Long> userTypes = new ArrayList<Long>();
	//private List<Long> departments = new ArrayList<Long>();
	//private List<Long> divisions = new ArrayList<Long>();
	//private List<Long> userStatuses = new ArrayList<Long>();
	private List searchDepartments;
	private List searchDivisions;
	private List searchStatuses;
	private List searchUserTypes;

	public List<String> getSearchStatuses() {
		return searchStatuses;
	}

	public void setSearchStatuses(List searchStatuses) {
		this.searchStatuses = searchStatuses;
	}

	public List getSearchUserTypes() {
		return searchUserTypes;
	}

	public void setSearchUserTypes(List searchUserTypes) {
		this.searchUserTypes = searchUserTypes;
	}

	public List getSearchDepartments() {
		return searchDepartments;
	}

	public void setSearchDepartments(List searchDepartments) {
		this.searchDepartments = searchDepartments;
	}

	public List getSearchDivisions() {
		return searchDivisions;
	}

	public void setSearchDivisions(List searchDivisions) {
		this.searchDivisions = searchDivisions;
	}

	private Long internalIdentifierTypes;
	private String internalIdentifierTypeCD;

	public String getInternalIdentifierTypeCD() {
		return internalIdentifierTypeCD;
	}

	public void setInternalIdentifierTypeCD(String internalIdentifierTypeCD) {
		this.internalIdentifierTypeCD = internalIdentifierTypeCD;
	}

	private boolean activeChecked;
	private boolean leaveChecked;
	private boolean inactiveChecked;

	public List<RejectedUserUI> getRejectedUserList() {
		if (rejectedUserList == null) {
			if(this.isInitialLoad){
				this.isInitialLoad = false;
				refreshList(false);
			}
			else
				refreshList(true);
		}

		return rejectedUserList;
	}

	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getPopupDisplayAmount() {
		return popupDisplayAmount;
	}

	public void setPopupDisplayAmount(String popupDisplayAmount) {
		this.popupDisplayAmount = popupDisplayAmount;
	}

	public void setRejectedUserList(List<RejectedUserUI> rejectedUserList) {
		this.rejectedUserList = rejectedUserList;
	}

	public IRejectedUserService getRejectedUserService() {
		return rejectedUserService;
	}

	public void setRejectedUserService(IRejectedUserService rejectedUserService) {
		this.rejectedUserService = rejectedUserService;
	}

	public boolean isRenderAddUserModalPanel() {
		return renderAddUserModalPanel;
	}

	public void setRenderAddUserModalPanel(boolean renderAddUserModalPanel) {
		this.renderAddUserModalPanel = renderAddUserModalPanel;
	}

	public boolean isRenderSearchUserModalPanel() {
		return renderSearchUserModalPanel;
	}

	public void setRenderSearchUserModalPanel(boolean renderSearchUserModalPanel) {
		this.renderSearchUserModalPanel = renderSearchUserModalPanel;
	}

	public boolean isRenderAddSearchedUserPanel() {
		return renderAddSearchedUserPanel;
	}

	public void setRenderAddSearchedUserPanel(boolean renderAddSearchedUserPanel) {
		this.renderAddSearchedUserPanel = renderAddSearchedUserPanel;
	}

	public boolean isRenderAssociatedUserSearchModalPanel() {
		return renderAssociatedUserSearchModalPanel;
	}

	public void setRenderAssociatedUserSearchModalPanel(
			boolean renderAssociatedUserSeachModalPanel) {
		this.renderAssociatedUserSearchModalPanel = renderAssociatedUserSeachModalPanel;
	}

	public boolean isRenderSearchedAssociatedUserModalPanel() {
		return renderSearchedAssociatedUserModalPanel;
	}

	public void setRenderSearchedAssociatedUserModalPanel(
			boolean renderSearchedAssociatedUserModalPanel) {
		this.renderSearchedAssociatedUserModalPanel = renderSearchedAssociatedUserModalPanel;
	}

	public boolean isRenderAddAlternateIdModalPanel() {
		return renderAddAlternateIdModalPanel;
	}

	public void setRenderAddAlternateIdModalPanel(
			boolean renderAddAlternateIdModalPanel) {
		this.renderAddAlternateIdModalPanel = renderAddAlternateIdModalPanel;
	}

	public Long getRejectedUserId() {
		return this.rejectedUserId;
	}

	public void setRejectedUserId(Long rejectedUserId) {
		this.rejectedUserId = rejectedUserId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public List<SelectItem> getSupevisorDepartments() {

		if (supevisorDepartments == null) {
			this.supevisorDepartments = new ArrayList<SelectItem>();
			this.supevisorDepartments.add(new SelectItem(0, "Not Available"));

		} else if (supevisorDepartments.isEmpty()) {
			this.supevisorDepartments = new ArrayList<SelectItem>();
			this.supevisorDepartments.add(new SelectItem(0, "Not Available"));
		}

		return supevisorDepartments;
	}

	public List<SelectItem> getSupevisorDivisions() {

		if (supevisorDivisions == null) {
			supevisorDivisions = new ArrayList<SelectItem>();
			this.supevisorDivisions.add(new SelectItem(0, "Not Available"));
		} else if (supevisorDivisions.isEmpty()) {
			supevisorDivisions = new ArrayList<SelectItem>();
			this.supevisorDivisions.add(new SelectItem(0, "Not Available"));
		}

		return supevisorDivisions;
	}
	/*
        public List<SelectItem> getSupevisorCostCenters() {

            if (supevisorCostCenters == null) {
                supevisorCostCenters = new ArrayList<SelectItem>();
                this.supevisorCostCenters.add(new SelectItem(0, "Not Available"));
            } else if (supevisorCostCenters.isEmpty()) {
                supevisorCostCenters = new ArrayList<SelectItem>();
                this.supevisorCostCenters.add(new SelectItem(0, "Not Available"));
            }

            return supevisorCostCenters;
        }
    */
	public List<SelectItem> getSupevisorBusinessSegments() {

		if (supevisorBusinessSegments == null) {
			supevisorBusinessSegments = new ArrayList<SelectItem>();
			this.supevisorBusinessSegments.add(new SelectItem(0,
					"Not Available"));
		} else if (supevisorBusinessSegments.isEmpty()) {
			supevisorBusinessSegments = new ArrayList<SelectItem>();
			this.supevisorBusinessSegments.add(new SelectItem(0,
					"Not Available"));
		}

		return supevisorBusinessSegments;
	}

	public List<SelectItem> getSupevisorJobTitles() {

		if (supevisorJobTitles == null) {
			this.supevisorJobTitles = new ArrayList<SelectItem>();
			this.supevisorJobTitles.add(new SelectItem(0, "Not Available"));
		} else if (supevisorJobTitles.isEmpty()) {
			this.supevisorJobTitles = new ArrayList<SelectItem>();
			this.supevisorJobTitles.add(new SelectItem(0, "Not Available"));
		}
		return supevisorJobTitles;
	}

	public List<SelectItem> getSupevisorLocations() {

		if (supevisorLocations == null) {
			supevisorLocations = new ArrayList<SelectItem>();
			supevisorLocations.add(new SelectItem(0, "Not Available"));
		} else if (supevisorLocations.isEmpty()) {
			supevisorLocations = new ArrayList<SelectItem>();
			supevisorLocations.add(new SelectItem(0, "Not Available"));
		}

		return supevisorLocations;
	}

	// ******* Refresh the List RESET button *******
	public void refreshList(boolean resort) {
		oldSortColumn = "";

		if (this.rejectedUserList == null) {
			System.out.println("Rejected user summary bean in If condition, 405" + rejectedUserList );
			resort = false;
		}



		logger.debug("******************** Refresh List on reject user summary *****************************");
		System.out.println("searchSrcUserId : "+this.searchSrcUserId);
		System.out.println("searchExtrctSysId : "+this.searchExtrctSysId);
		System.out.println("selectedDateCriteria : "+selectedDateCriteria);
		System.out.println("createdDateCriteria : "+createdDateCriteria);
		System.out.println("************************************************************");

		this.rejectedUserList = this.rejectedUserService.findByValue(this.searchSrcUserId,
				this.searchExtrctSysId, selectedDateCriteria, createdDateCriteria);

		if (resort)
			this.doSort();
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public Long getDivisionId() {
		return divisionId;
	}

	public void setDivisionId(Long divisionId) {
		this.divisionId = divisionId;
	}

	public String getDivisionName() {
		return divisionName;
	}

	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public Long getSupervisorId() {
		return supervisorId;
	}

	public void setSupervisorId(Long supervisorId) {
		this.supervisorId = supervisorId;
	}

	public String getSupervisorName() {
		return supervisorName;
	}

	public Long getStatus() {
		return status;
	}

	public void setStatus(Long status) {
		this.status = status;
	}

	public String getUserStatusDescription() {
		return this.userStatusDescription;
	}

	public String getExistingAlternateIds() {
		return existingAlternateIds;
	}

	public Long getUserType() {
		return userType;
	}

	public void setUserType(Long userType) {
		this.userType = userType;
	}

	public String getUserTypeDescription() {
		return userTypeDescription;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSatStatus() {
		return satStatus;
	}

	public void setSatStatus(String satStatus) {
		this.satStatus = satStatus;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSatAltId1() {
		return satAltId1;
	}

	public void setSatAltId1(String satAltId1) {
		this.satAltId1 = satAltId1;
	}

	public String getSatAltId2() {
		return satAltId2;
	}

	public void setSatAltId2(String satAltId2) {
		this.satAltId2 = satAltId2;
	}

	public String getSatAltId3() {
		return satAltId3;
	}

	public void setSatAltId3(String satAltId3) {
		this.satAltId3 = satAltId3;
	}

	public String getNewAltId() {
		return newAltId;
	}

	public void setNewAltId(String newAltId) {
		this.newAltId = newAltId;
	}

	public String getSatMFId() {
		return satMFId;
	}

	public void setSatMFId(String satMFId) {
		this.satMFId = satMFId;
	}

	public String getSatGFId() {
		return satGFId;
	}

	public void setSatGFId(String satGFId) {
		this.satGFId = satGFId;
	}

	public String getSatCFId() {
		return satCFId;
	}

	public void setSatCFId(String satCFId) {
		this.satCFId = satCFId;
	}

	public String getSatLCSId() {
		return satLCSId;
	}

	public void setSatLCSId(String satLCSId) {
		this.satLCSId = satLCSId;
	}

	public String getSatFDMSId() {
		return satFDMSId;
	}

	public void setSatFDMSId(String satFDMSId) {
		this.satFDMSId = satFDMSId;
	}

	public String getSatSiteMinderId() {
		return satSiteMinderId;
	}

	public void setSatSiteMinderId(String satSiteMinderId) {
		this.satSiteMinderId = satSiteMinderId;
	}

	public String getSatJobRole() {
		return satJobRole;
	}

	public void setSatJobRole(String satJobRole) {
		this.satJobRole = satJobRole;
	}

	public String getSatComment() {
		return satComment;
	}

	public void setSatComment(String satComment) {
		this.satComment = satComment;
	}

	public String getBsnssSgmnt() {
		return bsnssSgmnt;
	}

	public void setBsnssSgmnt(String bsnssSgmnt) {
		this.bsnssSgmnt = bsnssSgmnt;
	}

	public String getLookUpAltId() {
		return lookUpAltId;
	}

	public void setLookUpAltId(String lookUpAltId) {
		this.lookUpAltId = lookUpAltId;
	}

	public String getSrcUserId() {
		return srcUserId;
	}

	public void setSrcUserId(String srcUserId) {
		this.srcUserId = srcUserId;
	}

	public List<SelectItem> getAvailableExtractSystem() {
		List<ExtractSystem> extractSystemList = this.rejectedUserService.retrieveExtractSystems();
		//Sort
		Collections.sort(extractSystemList, new Comparator<ExtractSystem>() {
			public int compare(ExtractSystem sys1, ExtractSystem sys2) {
				return sys1.getExtrctSysId().compareTo(sys2.getExtrctSysId());
			}
		});
		availableExtractSystem = new ArrayList<SelectItem>();
		availableExtractSystem.add(new SelectItem("-1","Please select"));
		for (ExtractSystem es : extractSystemList) {
			if (es.getExtrctSysNm()!=null)
				availableExtractSystem.add(new SelectItem(es.getExtrctSysId(),
						es.getExtrctSysId() +" - "+es.getExtrctSysNm()));
		}
		return availableExtractSystem;
	}

	public List<SelectItem> getAvailablecreatedDateCriteria() {
		availablecreatedDateCriteria = new ArrayList<SelectItem>();
		availablecreatedDateCriteria.add(new SelectItem("lt", "Before"));
		availablecreatedDateCriteria.add(new SelectItem("gt", "After"));
		availablecreatedDateCriteria.add(new SelectItem("eq", "Equal"));
		return availablecreatedDateCriteria;
	}

	public Long getExtrctSysId() {
		return this.extrctSysId;
	}

	public void setExtrctSysId(Long extrctSysId) {
		this.extrctSysId = extrctSysId;
	}

	public Date getExtractSysDate() {
		return extractSysDate;
	}

	public void setExtractSysDate(Date extractSysDate) {
		this.extractSysDate = extractSysDate;
	}

	public String getExtrctSysName() {
		return this.extrctSysName;
	}

	public void setExtrctSysName(String extrctSysName) {
		this.extrctSysName = extrctSysName;
	}

	public Date getCreatedDateCriteria() {
		return createdDateCriteria;
	}

	public void setCreatedDateCriteria(Date createdDateCriteria) {
		this.createdDateCriteria = createdDateCriteria;
	}

	public String getSelectedDateCriteria() {
		return selectedDateCriteria;
	}

	public void setSelectedDateCriteria(String selectedDateCriteria) {
		this.selectedDateCriteria = selectedDateCriteria;
	}

	public List<UserUI> getUserList() {
		return userList;
	}

	public void setUserList(ArrayList<UserUI> userList) {
		this.userList = userList;
	}
	/*
        public List<Long> getUserTypes() {
            return userTypes;
        }

        public void setUserTypes(List<Long> selectedUserTypes) {
            this.userTypes = selectedUserTypes;
        }

        public List<Long> getDepartments() {
            return departments;
        }

        public void setDepartments(List<Long> departments) {
            this.departments = departments;
        }

        public List<Long> getDivisions() {
            return divisions;
        }

        public void setDivisions(List<Long> divisions) {
            this.divisions = divisions;
        }
    */
	public Long getInternalIdentifierTypes() {
		return internalIdentifierTypes;
	}

	public void setInternalIdentifierTypes(Long internalIdentifierTypes) {
		this.internalIdentifierTypes = internalIdentifierTypes;
	}

	public boolean isActiveChecked() {
		return activeChecked;
	}

	public void setActiveChecked(boolean activeChecked) {
		this.activeChecked = activeChecked;
	}

	public boolean isLeaveChecked() {
		return leaveChecked;
	}

	public void setLeaveChecked(boolean leaveChecked) {
		this.leaveChecked = leaveChecked;
	}

	public boolean isInactiveChecked() {
		return inactiveChecked;
	}

	public void setInactiveChecked(boolean inactiveChecked) {
		this.inactiveChecked = inactiveChecked;
	}

	// ******* GO button *******
	public String goSearch() {
//		this.rejectedUserList = this.rejectedUserService.findByValue(this.searchSrcUserId,
//				this.searchExtrctSysId, selectedDateCriteria, createdDateCriteria);
		this.refreshList(false);
		return null;
	}

	// ******* RESET button *******
	public String resetSearch() {
		this.searchSrcUserId = null;
		this.searchExtrctSysId = null;
		this.createdDateCriteria = null;
		refreshList(false);
		return null;
	}

	public void init() {
		this.isInitialLoad = true;
		this.searchSrcUserId = null;
		this.searchExtrctSysId = null;
		this.createdDateCriteria = null;
		this.rejectedUserList = null;
	}


	// ******* List Headers *******
	public void doSort() {
		final String column = (JSFUtils.getParameter("column") == null ? "createdDate"
				: JSFUtils.getParameter("column"));
		CommonPageActionHelper.sortListByField(rejectedUserList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
	}
	public void doUserSort() {
		final String column = (JSFUtils.getParameter("column") == null ? "lastName"
				: JSFUtils.getParameter("column"));
		CommonPageActionHelper.sortListByField(userList, column,
				this.oldSortColumn);
		this.oldSortColumn = column;
	}

	public void doDisplayRowListener() {
		logger.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
	}
	// ******* CLEAR FIELDS ******
	public void clearFields(){
		this.userId = null;
		this.lastName = "";
		this.firstName = "";
		this.middleName = "";
		this.departmentId = null;
		this.divisionId = null;
		this.keyId = "";
		this.supervisorId = null;
		this.populateSupevisorData();
		this.status = null;
		this.userType = null;
		this.costCenter = "";
		//this.deleteFlag = ;
		this.jobTitle = "";
		this.emailAddress = "";
		this.phone = "";
		this.location = "";

		this.satJobRole = "";
		this.bsnssSgmnt = "";
		this.satAltId1 = "";
		this.satAltId2 = "";
		this.satAltId3 = "";
		this.satMFId = "";
		this.satGFId = "";
		this.satCFId = "";
		this.satFDMSId = "";
		this.satLCSId = "";
		this.satSiteMinderId = "";

	}

	public String showAddUserPanel() {
		String rejectedUserIdParam = (JSFUtils.getParameter("column") == null ? "name"
				: JSFUtils.getParameter("column"));

		RejectedUser selectedRejectedUser;

		this.clearFields();

		for (RejectedUserUI rejectedUserUI : this.rejectedUserList) {
			if (rejectedUserIdParam.equals(rejectedUserUI.getRejectedUserId()
					.toString())) {

				selectedRejectedUser = rejectedUserUI.getRejectedUser();
				this.emailAddress = selectedRejectedUser.getSrcEmailAddress();
				this.rejectedUserId = Long.parseLong(rejectedUserIdParam);
				this.keyId = rejectedUserUI.getSrcUserId();
				this.extrctSysId = rejectedUserUI.getExtractSystemId();
				this.extractSysDate = rejectedUserUI.getCreatedDate();
				this.extrctSysName = rejectedUserUI.getExtractSystemName();
			}
		}

		this.renderAddUserModalPanel = true;
		return null;
	}

	public String doAddNewUser() {

		System.out.println("this.keyId "+this.keyId);
		System.out.println("this.firstName "+this.firstName);
		System.out.println("this.lastName "+this.lastName);
		System.out.println("this.status "+this.status);
		System.out.println("this.supervisorId "+this.supervisorId);
		System.out.println("this.userType "+this.userType);
		System.out.println("this.departmentId "+this.departmentId);
		System.out.println("this.divisionId "+this.divisionId);
		System.out.println("this.bsnssSgmnt "+this.bsnssSgmnt);



		if (this.keyId == null || "".equals(this.keyId)) {
			String message = "Key Id is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above First Name is required. ");
		if (this.firstName == null || "".equals(this.firstName)) {
			String message = "First Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above last Name is required. ");
		if (this.lastName == null || "".equals(this.lastName)) {
			String message = "Last Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above user status is required. ");
		if (this.status == null || this.status ==0) {
			String message = "User Status is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above Supervisor is required. ");
		if (this.supervisorId == null || this.supervisorId ==0) {
			String message = "Supervisor is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above user type is required. ");
		if (this.userType == null || this.userType ==0) {
			String message = "User Type is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above department is required. ");
		if (this.departmentId == null || this.departmentId ==0) {
			String message = "Department is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above division is required. ");
		if (this.divisionId == null || this.divisionId ==0) {
			String message = "Division is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("Above business segment is required. ");
		if (this.bsnssSgmnt == null) {
			String message = "Business Segment is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		System.out.println("end of business segment is required. ");

		this.keyId = this.keyId.toUpperCase();
		this.firstName = this.firstName.toUpperCase();
		this.middleName = this.middleName.toUpperCase();
		this.lastName = this.lastName.toUpperCase();
		System.out.println("***** Job Title is ***** :"+this.jobTitle);
		if(this.jobTitle!=null) {
			this.jobTitle = this.jobTitle.toUpperCase();
		}
		String userExistMsg = this.rejectedUserService.findUserExist(-1L, this.keyId, "", "", "","", "", "","", "", "");
		if (!"".equals(userExistMsg)) {
			JSFUtils.addFacesErrorMessage(userExistMsg);
			this.renderAddUserModalPanel = true;
			return null;
		}
		this.rejectedUserService.addUser(this.keyId, this.firstName, this.middleName, this.lastName,
				this.userType, this.departmentId, this.divisionId, this.location, this.jobTitle,
				this.supervisorId, this.bsnssSgmnt, this.phone, this.emailAddress,
				this.status, satStatus,this.satJobRole, this.satComment,
				this.rejectedUserId, this.extrctSysId, this.extractSysDate);

		// Display Message.
		String message = "Added User " + this.lastName + " " + this.firstName + " "
				+ this.middleName;
		FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
		refreshList(false);
		this.renderAddUserModalPanel = false;
		clearSelection();
		return null;
	}

	public String doAddUser() {

		if (this.firstName==null || "".equals(this.firstName)) {
			String message = "First Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.lastName==null || "".equals(this.lastName)) {
			String message = "Last Name is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.status == null|| this.status ==0) {
			String message = "User Status is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.supervisorId == null|| this.supervisorId ==0) {
			String message = "Supervisor is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.userType == null ||this.userType==0) {
			String message = "User Type is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.departmentId == null || this.departmentId==0) {
			String message = "Department is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.divisionId == null|| this.divisionId==0) {
			String message = "Division is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}
		if (this.bsnssSgmnt == null) {
			String message = "Business Segment is required.";
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddUserModalPanel = true;
			return null;
		}

		this.rejectedUserService.updateUser(this.rejectedUserId, userId, keyId, firstName, middleName, lastName,
				userType, departmentId, divisionId, location, jobTitle,
				supervisorId, costCenter, bsnssSgmnt, phone, emailAddress,
				status, satStatus, this.satJobRole, this.satComment);
		// Display Message.
		String message = "Added User " + lastName + " " + firstName + " "
				+ middleName;
		FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(message));
		refreshList(false);
		this.renderAddSearchedUserPanel = false;
		clearSelection();
		return null;
	}

	public String doAddAlternateId() {

		boolean isUpdatable = true;
		if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_ALT_ID1")){
			if (this.satAltId1!=null && !"".equalsIgnoreCase(satAltId1)){
				JSFUtils.addFacesErrorMessage("SatAltID1 already exists");
				isUpdatable = false;
			}
			else
				this.satAltId1 = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_ALT_ID2")){
			if (this.satAltId2!=null && !"".equalsIgnoreCase(satAltId2)){
				JSFUtils.addFacesErrorMessage("SatAltID2 already exists");
				isUpdatable = false;
			}
			else
				this.satAltId2 = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_ALT_ID3")){
			if (this.satAltId3!=null && !"".equalsIgnoreCase(satAltId3)){
				JSFUtils.addFacesErrorMessage("SatAltID3 already exists");
				isUpdatable = false;
			}
			else
				this.satAltId3 = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_MF_ID")){
			if (this.satMFId!=null && !"".equalsIgnoreCase(satMFId)){
				JSFUtils.addFacesErrorMessage("SAT_MF_ID already exists");
				isUpdatable = false;
			}
			else
				this.satMFId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_CF_ID")){
			if (this.satCFId!=null && !"".equalsIgnoreCase(satCFId)){
				JSFUtils.addFacesErrorMessage("SAT_CF_ID already exists");
				isUpdatable = false;
			}
			else
				this.satCFId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_GF_ID")){
			if (this.satGFId!=null && !"".equalsIgnoreCase(satGFId)){
				JSFUtils.addFacesErrorMessage("SAT_GF_ID already exists");
				isUpdatable = false;
			}
			else
				this.satGFId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_LCS_ID")){
			if (this.satLCSId!=null && !"".equalsIgnoreCase(satLCSId)){
				JSFUtils.addFacesErrorMessage("SAT_LCS_ID already exists");
				isUpdatable = false;
			}
			else
				this.satLCSId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_FDMS_ID")){
			if (this.satFDMSId!=null && !"".equalsIgnoreCase(satFDMSId)){
				JSFUtils.addFacesErrorMessage("SAT_FDMS_ID already exists");
				isUpdatable = false;
			}
			else
				this.satFDMSId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("SAT_SITEMIND_ID")){
			if (this.satSiteMinderId!=null && !"".equalsIgnoreCase(satSiteMinderId)){
				JSFUtils.addFacesErrorMessage("SAT_SITEMIND_ID already exists");
				isUpdatable = false;
			}
			else
				this.satSiteMinderId = this.newAltId;
		}
		else if (internalIdentifierTypeCD.equalsIgnoreCase("EMAIL_ADDR")){
			if (this.emailAddress!=null && !"".equalsIgnoreCase(emailAddress)){
				JSFUtils.addFacesErrorMessage("EMAIL_ADDR already exists");
				isUpdatable = false;
			}
			else
				this.emailAddress = this.newAltId;
		}
		else{
			JSFUtils.addFacesErrorMessage("Please select available Alternate Id Types");
			isUpdatable = false;
		}

		if(this.rejectedUserService.isAltIdExists(this.newAltId)){
			JSFUtils.addFacesErrorMessage("Alternate Id exists "+ this.newAltId);
			isUpdatable = false;
		}

		if(!isUpdatable){
			this.renderAddAlternateIdModalPanel = true;
			return null;
		}
		else{
			this.rejectedUserService.updateAltIdsForUser( this.userId,
					this.satMFId, this.satGFId, this.satCFId, this.satLCSId, this.satFDMSId,
					this.satSiteMinderId, this.satAltId1, this.satAltId2, this.satAltId3);

			this.rejectedUserService.updateAltIds(this.rejectedUserId,
					this.userId, this.keyId, this.emailAddress,
					this.satMFId, this.satGFId, this.satCFId, this.satLCSId, this.satFDMSId,
					this.satSiteMinderId, this.satAltId1, this.satAltId2, this.satAltId3);

			String message = "Added Alternate Id " + this.newAltId ;
			FacesContext.getCurrentInstance().addMessage(message, new FacesMessage(message));

			this.renderAddAlternateIdModalPanel = false;
			this.refreshList(false);
			clearSelection();
		}
		return null;
	}

	// ******* Add User Panel CANCEL *******
	public String doCancelAddUser() {
		logger.debug("doCancelAddUserPanel() --> being executed.");
		this.renderAddUserModalPanel = false;
		//clearSelection();
		return null;
	}

	public String showSearchUser() {
		final String srcUserName = (JSFUtils.getParameter("column") == null ? "name"
				: JSFUtils.getParameter("column"));
		if (JSFUtils.getParameter("rejectedIdcolumn") != null)
			this.rejectedUserId  = Long.parseLong(JSFUtils.getParameter("rejectedIdcolumn"));
		System.out.println("******Rejected ID Column** "+this.rejectedUserId);
		if (JSFUtils.getParameter("newAltIdcolumn") != null)
			this.newAltId  = JSFUtils.getParameter("newAltIdcolumn");

		List<User> usersRetrieved = new ArrayList<User>();
		this.userList = new ArrayList<UserUI>(usersRetrieved.size() + 1);

		String searchLastName;
		String searchFirstName;
		if(srcUserName.indexOf(",") != -1){
			searchLastName = srcUserName.substring(0, srcUserName
					.indexOf(',') - 1).trim();
			searchFirstName = srcUserName
					.substring(srcUserName.indexOf(',') + 1).trim();
		}
		else{
			searchLastName = srcUserName;
			searchFirstName = srcUserName;
		}
		usersRetrieved = this.rejectedUserService.findByUserName(searchFirstName,
				searchLastName);
		for (User user : usersRetrieved) {
			this.userList.add(new UserUI(user));
		}
		this.renderSearchUserModalPanel = true;
		return null;
	}

	public String doCancelSearchUser() {
		logger.debug("doCancelSearchUserPanel() --> being executed.");
		this.renderSearchUserModalPanel = false;
		return null;
	}

	public String showAddUserPanelFromSearch() {

		this.clearFields();

		RejectedUser selectedRejectedUser = this.rejectedUserService.findByRejectedUserId(this.rejectedUserId);
		if (selectedRejectedUser!=null){
			this.emailAddress = selectedRejectedUser.getSrcEmailAddress();
			this.keyId = selectedRejectedUser.getSrcUserId();
			ExtractSystem es = selectedRejectedUser.getExtractSystem();
			this.extrctSysId = es.getExtrctSysId();
			this.extrctSysName = es.getExtrctSysNm();
		}

		this.renderSearchUserModalPanel = false;
		this.renderAddUserModalPanel = true;
		return null;
	}

	public String showAddSearchedUserPanel() {
		final String searchKeyId = (JSFUtils.getParameter("column") == null ? "name"
				: JSFUtils.getParameter("column"));

		for (UserUI userUI : userList) {
			if (userUI.getKeyId().equals(searchKeyId)) {
				this.populateSearchedUserData(userUI.getUser());
//				populateSupevisorData();
			}
		}
		this.renderSearchUserModalPanel = false;
		//commented renderAddSearchedUserPanel to force only pick alternate Id
		//this.renderAddSearchedUserPanel = true;
		this.renderAddAlternateIdModalPanel = true;
		return null;
	}

	public String doCancelAssociatedUserSearch() {
		logger.debug("doCancelAssociatedUserSearch() --> being executed.");
		this.renderSearchedAssociatedUserModalPanel = true;
		this.renderSearchedAssociatedUserModalPanel = false;
		return null;
	}

	public String showAddAlternateIdPanel() {
		final String searchKeyId = (JSFUtils.getParameter("column") == null ? "name"
				: JSFUtils.getParameter("column"));

		this.firstName = null;
		this.lastName = null;
		this.supervisorId = null;
		this.keyId = null;
		this.searchStatuses = null;
		this.searchUserTypes = null;
		this.searchDepartments = null;
		this.searchDivisions = null;

		for (UserUI userUI : userList) {
			if (userUI.getKeyId().equals(searchKeyId))
				this.populateSearchedUserData(userUI.getUser());
		}
		this.renderSearchedAssociatedUserModalPanel = false;
		this.renderAddAlternateIdModalPanel = true;
		return null;
	}

	public String doCancelAddAlternateId() {
		logger.debug("doCancelAddUserPanel() --> being executed.");
		this.renderAddAlternateIdModalPanel = false;
		clearSelection();
		return null;
	}

	public void populateSearchedUserData(User selectedUser){
		System.out.println("*** 1326 Populate Search User Data");
		this.keyId = selectedUser.getPk().getKeyId();
		this.userId = selectedUser.getUserId();
		this.firstName = selectedUser.getFirstName();
		this.lastName = selectedUser.getLastName();
		this.userTypeDescription = selectedUser.getUserType()
				.getUserTypeDescription();
		this.departmentName = selectedUser.getDepartment().getName();
		this.divisionName = selectedUser.getDivision().getName();
		this.emailAddress = selectedUser.getEmailAddress();
		this.supervisorId = selectedUser.getSupervisorId();
		this.supervisorName = selectedUser.getSupervisor();
		this.departmentId = selectedUser.getDepartment().getId();
		this.divisionId = selectedUser.getDivision().getId();
		this.costCenter = selectedUser.getCostCenter();
		this.bsnssSgmnt = selectedUser.getBusinessSegment();
		this.jobTitle = selectedUser.getJobTitle();
		this.location = selectedUser.getLocation();
		this.phone = selectedUser.getLocation();
		this.satStatus = selectedUser.getSatStatus();
		this.satComment = selectedUser.getSatComment();
		this.satJobRole = selectedUser.getSatJobRole();
		this.userStatusDescription = selectedUser.getUserStatus()
				.getUserStatusDescription();
		this.existingAlternateIds = rejectedUserService
				.getAlternateIds(keyId.toString());
		this.satMFId = selectedUser.getSatMfId();
		this.satGFId = selectedUser.getSatGfId();
		this.satCFId = selectedUser.getSatCfId();
		this.satLCSId = selectedUser.getSatLcsId();
		this.satFDMSId = selectedUser.getSatFdmsId();
		this.satSiteMinderId = selectedUser.getSatSiteminderId();
		this.satAltId1 = selectedUser.getSatAltId1();
		this.satAltId2 = selectedUser.getSatAltId2();
		this.satAltId3= selectedUser.getSatAltId3();

		System.out.println("*** 1362 Populate Search User Data End");
	}

	public void populateSupevisorData() {

		supevisorDepartments = new ArrayList<SelectItem>();
		supevisorDivisions = new ArrayList<SelectItem>();
		supevisorBusinessSegments = new ArrayList<SelectItem>();
		supevisorJobTitles = new ArrayList<SelectItem>();
		supevisorLocations = new ArrayList<SelectItem>();

		if(this.supervisorId!=null){
			this.rejectedUserService.populatSupevisorData(this.supervisorId);
			this.supevisorDepartments = this.rejectedUserService.populateSupevisorDepartments(this.supervisorId);
			this.supevisorDivisions = this.rejectedUserService.populateSupevisorDivisions(this.supervisorId);
			this.supevisorBusinessSegments = this.rejectedUserService
					.populateSupevisorBusinessSegments(this.supervisorId);
			this.supevisorJobTitles = this.rejectedUserService.populateSupevisorJobTitles(this.supervisorId,"");
			this.supevisorLocations = this.rejectedUserService.populateSupevisorLocations(this.supervisorId,"");
			List<User> directReports = this.rejectedUserService.findUsersBySupevisorId(this.supervisorId);
			this.supervisorDirectReports = new ArrayList<UserUI>();
			for (User user : directReports) {
				this.supervisorDirectReports.add(new UserUI(user));
			}
			CommonPageActionHelper.sortListByField(this.supervisorDirectReports, "name",
					this.oldSortColumn);

		}
	}

	public String doCancelAddSearhedUser() {
		logger.debug("doCancelAddUserPanel() --> being executed.");
		this.renderAddSearchedUserPanel = false;
		clearSelection();
		return null;
	}

	public String showAltUserSearchPanel() {
		this.firstName = null;
		this.lastName = null;
		this.userId = null;
		this.supervisorId = null;
		this.keyId = null;
		this.searchStatuses = null;
		this.searchUserTypes = null;
		this.searchDepartments = null;
		this.searchDivisions = null;

		this.renderSearchUserModalPanel = false;
		this.renderAssociatedUserSearchModalPanel = true;
		return null;
	}

	public String showAssociatedUserSearchPanel() {

		if (JSFUtils.getParameter("rejectedIdcolumn") != null)
			this.rejectedUserId  = Long.parseLong(JSFUtils.getParameter("rejectedIdcolumn"));
		if (JSFUtils.getParameter("newAltIdcolumn") != null)
			this.newAltId  = JSFUtils.getParameter("newAltIdcolumn");
		this.firstName = null;
		this.lastName = null;
		this.userId = null;
		this.keyId = null;
		this.supervisorId = null;
		this.searchStatuses = null;
		this.searchUserTypes = null;
		this.searchDepartments = null;
		this.searchDivisions = null;

		this.renderAssociatedUserSearchModalPanel = true;
		return null;
	}

	public String doSearchAssociatedUser() {
		this.userList = this.rejectedUserService.searchAssociatedUser(firstName, lastName, keyId,
				supervisorId, searchStatuses, searchUserTypes, searchDepartments, searchDivisions,
				location);
		this.renderAssociatedUserSearchModalPanel = false;
		this.renderSearchedAssociatedUserModalPanel = true;
		return null;
	}

	public String doCancelSearchAssociatedUser() {
		logger.debug("doCancelSearchAssociatedUser() --> being executed.");
		this.rejectedUserId = null;
		this.renderSearchedAssociatedUserModalPanel = false;
		this.renderAssociatedUserSearchModalPanel = false;
		return null;
	}

	public void clearSelection() {
		this.userId = null;
		this.keyId = "";
		this.userId = null;
		this.firstName = "";
		this.middleName = "";
		this.lastName = "";
		this.userType = null;
		this.status = null;
		this.departmentId = null;
		this.divisionId = null;
		this.emailAddress = "";
		this.supervisorId = null;
		this.supevisorDepartments = null;
		this.supevisorDivisions = null;
		//this.supevisorCostCenters = null;
		this.supevisorJobTitles = null;
		this.supevisorLocations = null;
		this.supevisorBusinessSegments = null;
		this.costCenter = "";
		this.bsnssSgmnt = "";
		this.jobTitle = "";
		this.location = "";
		this.phone = "";
		this.satStatus = "";
		this.satComment = "";
		this.satJobRole = "";

	}
	public List<SelectItem> getAvailableStatus() {

		List<UserStatus> userStatusList = this.rejectedUserService.findUserStatusList();
		//Sort
		Collections.sort(userStatusList, new Comparator<UserStatus>() {
			public int compare(UserStatus userStatus1, UserStatus userStatus2) {
				return userStatus1.getUserStatusDescription().compareTo(userStatus2.getUserStatusDescription());
			}
		});
		availableStatus = new ArrayList<SelectItem>();
		for (UserStatus us : userStatusList) {
			if (us.getUserStatusDescription()!=null)
				availableStatus.add(new SelectItem(us.getId(), us.getUserStatusDescription()));
		}
		return availableStatus;
	}

	public List<SelectItem> getAvailableUserType() {
		List<UserType> userTypeName = this.rejectedUserService.retrieveAllUserTypes();
		//Sort
		Collections.sort(userTypeName, new Comparator<UserType>() {
			public int compare(UserType userType1, UserType userType2) {
				return userType1.getUserTypeDescription().compareTo(userType2.getUserTypeDescription());
			}
		});

		this.availableUserType = new ArrayList<SelectItem>();
		this.availableUserType.add(new SelectItem("", ""));
		for(UserType ut:userTypeName){
			if(ut.getUserTypeDescription()!=null){
				this.availableUserType.add(new SelectItem(ut.getId(), ut.getUserTypeDescription()));
			}
		}
		return this.availableUserType;
	}

	public List<SelectItem> getMultiSelectDepartmentList(){
		List<Department> deptNames = this.rejectedUserService.retrieveAllDepartments();
		//Sort
		Collections.sort(deptNames, new Comparator<Department>() {
			public int compare(Department dept1, Department dept2) {
				return dept1.getName().compareTo(dept2.getName());
			}
		});
		this.availableDepartment = new ArrayList<SelectItem>();
		this.availableDepartment.add(new SelectItem("", ""));
		for(Department dep:deptNames){
			if(dep.getName()!=null && dep.getDepartmentNmCostCenter() !=null)
				this.availableDepartment.add(new SelectItem(""+dep.getId(), dep.getDepartmentNmCostCenter()));
		}

		return this.availableDepartment;

	}


	public List<SelectItem> getMultiSelectDivisionList() {
		List<Division> divName = this.rejectedUserService.retrieveAllDivisions();
		//Sort
		Collections.sort(divName, new Comparator<Division>() {
			public int compare(Division div1, Division div2) {
				return div1.getName().compareTo(div2.getName());
			}
		});
		this.availableDivision = new ArrayList<SelectItem>();
		this.availableDivision.add(new SelectItem("", ""));
		for(Division div:divName){
			if(div.getName()!=null)
				this.availableDivision.add(new SelectItem(""+div.getId(), div.getName()));
		}

		return this.availableDivision;
	}

	public List<SelectItem> getMultiSelectUserTypeList() {
		List<UserType> userTypeName = this.rejectedUserService.retrieveAllUserTypes();

		//Sort
		Collections.sort(userTypeName, new Comparator<UserType>() {
			public int compare(UserType userType1, UserType userType2) {
				return userType1.getUserTypeDescription().compareTo(userType2.getUserTypeDescription());
			}
		});

		List<SelectItem> usrTypeList = new ArrayList<SelectItem>();
		usrTypeList.add(new SelectItem("", ""));
		for(UserType ut:userTypeName){
			if(ut.getUserTypeDescription()!=null){
				usrTypeList.add(new SelectItem(""+ut.getId(), ut.getUserTypeDescription()));
			}
		}
		return usrTypeList;
	}

	public List<SelectItem> getMultiSelectUserStatusList() {
		List<UserStatus> userStatusList = this.rejectedUserService.findUserStatusList();

		//Sort
		Collections.sort(userStatusList, new Comparator<UserStatus>() {
			public int compare(UserStatus userStatus1, UserStatus userStatus2) {
				return userStatus1.getUserStatusDescription().compareTo(userStatus2.getUserStatusDescription());
			}
		});

		List<SelectItem> statusList = new ArrayList<SelectItem>();
		for (UserStatus us : userStatusList) {
			if (us.getUserStatusDescription()!=null)
				statusList.add(new SelectItem(""+us.getId(), us.getUserStatusDescription()));
		}
		return statusList;
	}

	public List<SelectItem> getAvailableInternalIdentifierType() {
		return rejectedUserService.getAvailableInternalIdentifierType();
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public List<SelectItem> getAvailableSupervisors() {
		List<Supervisor> supervisorsList = this.rejectedUserService.retrieveAllSupervisors();

		List<SelectItem> availableSupervisors = new ArrayList<SelectItem>();
		availableSupervisors.add(new SelectItem("", ""));
		for (Supervisor supervisor : supervisorsList) {
			StringBuilder formattedName = new StringBuilder();
			String firstName = supervisor.getFirstName();
			String lastName = supervisor.getLastName();
			String middleName = (supervisor.getMiddleName()!=null)?supervisor.getMiddleName():"";

			if (!"".equals(lastName)) {
				formattedName.append(lastName);

				if (!"".equals(firstName)) {
					formattedName.append(", ");
				}
			}

			if (!"".equals(firstName)) {
				formattedName.append(firstName);

				if (!"".equals(middleName)) {
					formattedName.append(" ").append(middleName.substring(0, 1));
				}
			}

			availableSupervisors.add(new SelectItem(supervisor.getUserId(),
					formattedName.toString()));
		}

		return availableSupervisors;
	}

	private DataScroller dataScroller;
	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}

	public String doReconcile() {
		// reconcile rejects
		logger.debug("******************** Do Reconsile - Start *****************************");
		logger.debug("searchExtrctSysId before reconcile : "+this.searchExtrctSysId);
		this.rejectedUserService.reconcileRejects();
		if(this.searchExtrctSysId==-1){
			this.searchExtrctSysId = null;
			System.out.println("In doreconcile line 1642" +searchExtrctSysId);
		}
		logger.debug("searchExtrctSysId after reconcile: "+this.searchExtrctSysId);
		this.refreshList(false);
		logger.debug("searchExtrctSysId after refreshing: "+this.searchExtrctSysId);
		logger.debug("******************** Do Reconsile - End *****************************");
		return null;
	}


} // end DepartmentSummaryBean

