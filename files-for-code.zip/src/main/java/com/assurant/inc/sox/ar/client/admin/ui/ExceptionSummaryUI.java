/**
 * 
 */
package com.assurant.inc.sox.ar.client.admin.ui;

import org.apache.commons.lang3.StringUtils;

import com.assurant.inc.sox.domain.admin.ExceptionSummary;

/**
 * @author Brian Olson
 *
 */
public class ExceptionSummaryUI {
	
	private final ExceptionSummary exceptionSummary;
	
	public ExceptionSummaryUI(ExceptionSummary exceptionSummary) {
		this.exceptionSummary = exceptionSummary;
	}

	public ExceptionSummary getExceptionSummary() {
		return exceptionSummary;
	}
	
	public Long getUserId() {
		return this.exceptionSummary.getUserId();
	}

	public String getFirstName() {
		return this.exceptionSummary.getFirstName();
	}

	public String getLastName() {
		return this.exceptionSummary.getLastName();
	}

	public String getMiddleName() {
		return this.exceptionSummary.getMiddleName();
	}

	public Long getDivisionId() {
		return this.exceptionSummary.getDivisionId();
	}
	
	public void setDivisionId(Long divisionId) {
		this.exceptionSummary.setDivisionId(divisionId);
	}

	public String getDivisionName() {
		return (isMissingDivision() ? "" : this.exceptionSummary.getDivisionName());
	}

	public void setDivisionName(String divisionName) {
		this.exceptionSummary.setDivisionName(divisionName);
	}
	
	public Long getDepartmentId() {
		return this.exceptionSummary.getDepartmentId();
	}
	
	public void setDepartmentId(Long departmentId) {
		this.exceptionSummary.setDepartmentId(departmentId);
	}

	public String getDepartmentNameCostCenter() {
		return (isMissingDepartment() ? "" : this.exceptionSummary.getDepartmentNameCostCenter());
	}

	public void setDepartmentNameCostCenter(String departmentNameCostCenter) {
		this.exceptionSummary.setDepartmentNameCostCenter(departmentNameCostCenter);
	}
	
	public Long getSupervisorId() {
		return this.exceptionSummary.getSupervisorId();
	}

	public void setSupervisorId(Long supervisorId) {
		this.exceptionSummary.setSupervisorId(supervisorId);
	}
	
	public String getSupervisorName() {
		return (isMissingSupervisor() ? "" : this.exceptionSummary.getSupervisorName());
	}

	public void setSupervisorName(String supervisorName) {
		this.exceptionSummary.setSupervisorName(supervisorName);
	}
	
	public String getJobTitle() {
		return this.exceptionSummary.getJobTitle();
	}

	public Long getUserTypeId() {
		return this.exceptionSummary.getUserTypeId();
	}

	public void setUserTypeId(Long userTypeId) {
		this.exceptionSummary.setUserTypeId(userTypeId);
	}
	
	public String getUserTypeName() {
		return (isMissingUserType() ? "" : this.exceptionSummary.getUserTypeName());
	}

	public void setUserTypeName(String userTypeName) {
		this.exceptionSummary.setUserTypeName(userTypeName);
	}
	
	public Long getUserStatusId() {
		return this.exceptionSummary.getUserStatusId();
	}

	public void setUserStatusId(Long userStatusId) {
		this.exceptionSummary.setUserStatusId(userStatusId);
	}
	
	public String getUserStatusName() {
		return (isMissingUserStatus() ? "" : this.exceptionSummary.getUserStatusName());
	}

	public void setUserStatusName(String userStatusName) {
		this.exceptionSummary.setUserStatusName(userStatusName);
	}

	public String getEmail() {
		return (isMissingEmail() ? "" : this.exceptionSummary.getEmail());
	}

	public void setEmail(String email) {
		this.exceptionSummary.setEmail(email);
	}
	
	public String getPhone() {
		return this.exceptionSummary.getPhone();
	}

	public String getKeyId() {
		return this.exceptionSummary.getKeyId();
	}

	public String getLocation() {
		return this.exceptionSummary.getLocation();
	}

	public String getFormattedFullName() {
		StringBuilder formattedName = new StringBuilder();
		String firstName = this.exceptionSummary.getFirstName();
		String middleName = this.exceptionSummary.getMiddleName();
		String lastName = this.exceptionSummary.getLastName();
		if (StringUtils.isNotEmpty(lastName)) {
			formattedName.append(lastName);
			
			if (StringUtils.isNotEmpty(firstName)) {
				formattedName.append(", ");
			}
		}
		
		if (StringUtils.isNotEmpty(firstName)) {
			formattedName.append(firstName);
			
			if (StringUtils.isNotEmpty(middleName)) {
				formattedName.append(" ").append(middleName.substring(0, 1));
			}
		}
		
		return formattedName.toString();
	}

	public boolean isMissingDepartment() {
		return this.exceptionSummary.isMissingDepartment();
	}
	
	public boolean isMissingDivision() {
		return this.exceptionSummary.isMissingDivision();
	}
	
	public boolean isMissingUserStatus() {
		return this.exceptionSummary.isMissingUserStatus();
	}
	
	public boolean isMissingUserType() {
		return this.exceptionSummary.isMissingUserType();
	}

	public boolean isMissingSupervisor() {
		return this.exceptionSummary.isMissingSupervisor();
	}
	
	public boolean isMissingEmail() {
		return this.exceptionSummary.isMissingEmail();
	}

}
