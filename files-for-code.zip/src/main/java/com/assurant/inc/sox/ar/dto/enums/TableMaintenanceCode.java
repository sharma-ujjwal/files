package com.assurant.inc.sox.ar.dto.enums;

public enum TableMaintenanceCode {
	APPLICATION("Application"),
	CONFLICTS("Conflict"),
	CONFLICTTYPES("Conflict Type"),
	DATA_OWNER("Data Owner"),
	DEPARTMENTS("Department"),
	DIVISIONS("Division"),
	ENVIRONMENT("Environment"),
	FUNCTIONDUTY("Function Duty"),
	REVIEW_OWNER("Review Owner"),
	SOD_OWNER("SOD Owner"),
	SOXCONCERN("Sox Concern"),
	USERSTATUS("User Status"),
	USERTYPE("User Type"),
	USERTABLE("User"),
	PRIVILEGECOMMENTS("Privilege Comments");
	private String departmentName;
	
	private TableMaintenanceCode(String departmentName){
		this.departmentName = departmentName;
	}
	
	public String departmentName(){
		return this.departmentName;
	}
}
