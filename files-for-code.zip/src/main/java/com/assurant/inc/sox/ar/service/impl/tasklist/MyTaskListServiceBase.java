package com.assurant.inc.sox.ar.service.impl.tasklist;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.dao.ar.IApplicationDao;
import com.assurant.inc.sox.dao.ar.IReviewApplicationDao;
import com.assurant.inc.sox.dao.ar.IReviewBundleDao;
import com.assurant.inc.sox.dao.ar.IReviewDao;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.dao.ar.IReviewWorkOrderDao;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import org.springframework.stereotype.Component;

@Component
public class MyTaskListServiceBase {
	protected static final Logger logger = LoggerFactory.getLogger(MyTaskListService.class);

	//@Autowired
	//protected ISavvionService savvionService;
	@Autowired
	protected IWorkflowService workflowService;

	@Resource(name = "savvionITComplianceUserId")
	@Autowired
	protected String savvionITComplianceUserId;

	@Autowired
	protected IReviewDao reviewDao;
	
	@Autowired
	protected IReviewerDao reviewerDao;
	@Autowired
	protected IReviewUserDao reviewUserDao;
	@Autowired
	protected IReviewBundleDao reviewBundleDao;
	@Autowired
	protected IReviewUserAccessDao reviewUserAccessDao;
	@Autowired
	protected IReviewApplicationDao reviewApplicationDao;
	@Autowired
	protected IApplicationDao applicationDao;
	@Autowired
	protected IReviewWorkOrderDao workOrderDao;
	@Autowired
	protected ICodeService codeService;
	@Autowired
	protected IReviewBundleService reviewBundleService = null;
	
	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}

	public IReviewDao getReviewDao() {
		return reviewDao;
	}

	public void setReviewDao(IReviewDao reviewDao) {
		this.reviewDao = reviewDao;
	}

	public IReviewerDao getReviewerDao() {
		return reviewerDao;
	}

	public void setReviewerDao(IReviewerDao reviewerDao) {
		this.reviewerDao = reviewerDao;
	}

	public IReviewUserDao getReviewUserDao() {
		return reviewUserDao;
	}

	public void setReviewUserDao(IReviewUserDao reviewUserDao) {
		this.reviewUserDao = reviewUserDao;
	}

	public IReviewBundleDao getReviewBundleDao() {
		return reviewBundleDao;
	}

	public void setReviewBundleDao(IReviewBundleDao reviewBundleDao) {
		this.reviewBundleDao = reviewBundleDao;
	}

	public IReviewUserAccessDao getReviewUserAccessDao() {
		return reviewUserAccessDao;
	}

	public void setReviewUserAccessDao(IReviewUserAccessDao reviewUserAccessDao) {
		this.reviewUserAccessDao = reviewUserAccessDao;
	}

	public IReviewApplicationDao getReviewApplicationDao() {
		return reviewApplicationDao;
	}

	public void setReviewApplicationDao(IReviewApplicationDao reviewApplicationDao) {
		this.reviewApplicationDao = reviewApplicationDao;
	}

	public String getSavvionITComplianceUserId() {
		return savvionITComplianceUserId;
	}

	public void setSavvionITComplianceUserId(String savvionITComplianceUserId) {
		this.savvionITComplianceUserId = savvionITComplianceUserId;
	}

	public IApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(IApplicationDao applicationDao) {
		this.applicationDao = applicationDao;
	}

	public IReviewWorkOrderDao getWorkOrderDao() {
		return workOrderDao;
	}

	public void setWorkOrderDao(IReviewWorkOrderDao workOrderDao) {
		this.workOrderDao = workOrderDao;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

}
