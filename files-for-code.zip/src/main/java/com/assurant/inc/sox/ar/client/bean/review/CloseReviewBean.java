package com.assurant.inc.sox.ar.client.bean.review;

import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.utils.exceptions.NonClosableReview;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component("closeReviewBean")
@Scope("session")
public class CloseReviewBean {
	private static final Logger log = LoggerFactory.getLogger(CloseReviewBean.class);

	private boolean showCloseReviewPanel;
	private List<SelectItem> outstandingReviewSelectItems;
	private String selectedReview;
	@Autowired
	@Qualifier("reviewService")
	private IReviewService reviewService;

	public void doPrepareCloseReviewPanel() {
		this.populateOutstandingReviews();
		this.showCloseReviewPanel = true;
		this.selectedReview = null;
	}

	@SuppressWarnings("unchecked")
	private void populateOutstandingReviews() {
		log.debug("populateOutstandingReviews() -- enter.");
		List<ReviewDTO> outstandingReviews = reviewService.retrieveReviewsByStatus(ReviewStatusCode.OUTSTANDING);
		Collections.sort(outstandingReviews, new GenericComparator("reviewName"));

		List<SelectItem> outstandingReviewSelectItemLocs = new ArrayList<SelectItem>(outstandingReviews.size() + 1);
		outstandingReviewSelectItemLocs.add(new SelectItem("", "(select one)"));
		for (ReviewDTO aReview : outstandingReviews) {
			outstandingReviewSelectItemLocs.add(new SelectItem(String.valueOf(aReview.getReviewId()), aReview.getReviewName()));
		}
		this.outstandingReviewSelectItems = outstandingReviewSelectItemLocs;

	}

	/**
	 * Cancels the close review page.
	 * @return null return to the same page.
	 */
	public void doCancelReview() {
		log.debug("doCancelReview() -- enter.");
		this.showCloseReviewPanel = false;
	}

	/**
	 * Closes the outstanding review.
	 * @return null return to the same page.
	 */
	public void doCloseReview() {
		log.debug("doCloseReview() -- enter.");
		// if no review is selected, display error message.
		if (StringUtils.isBlank(this.selectedReview)) {
			JSFUtils.addFacesErrorMessage("A review must be selected to close.");
		} else {
			try {
				this.reviewService.closeReview(Long.parseLong(this.selectedReview));
				this.showCloseReviewPanel = false;
			} catch (NonClosableReview e) {
				JSFUtils.addFacesErrorMessage(e.getMessage());
			}
		}
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	public String getSelectedReview() {
  	return selectedReview;
  }

	public void setSelectedReview(String selectedReview) {
  	this.selectedReview = selectedReview;
  }

	public boolean isShowCloseReviewPanel() {
  	return showCloseReviewPanel;
  }

	public List<SelectItem> getOutstandingReviewSelectItems() {
  	return outstandingReviewSelectItems;
  }
	
	
}
