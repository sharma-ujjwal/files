package com.assurant.inc.sox.ar.dto.tasklist;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.Reviewer;

public class ReviewerTaskListDTO extends AbstractTaskListDTO {

	private final ReviewerDTO reviewer;
	private String status = "Incomplete";

	private boolean rowSelected = false;

	public ReviewerTaskListDTO(ReviewDTO reviewDTO, ReviewerDTO reviewer) {
		super((reviewDTO != null) ? reviewDTO : new ReviewDTO(new Review(), new CodeDTO(new Code()), new CodeDTO(new Code()))); // Prevents null
		this.reviewer = (reviewer != null) ? reviewer : new ReviewerDTO(new Reviewer(), new CodeDTO(new Code()), new CodeDTO(new Code()), ""); // Safe reviewer object
		this.status = "Incomplete";
	}
	
	public ReviewerTaskListDTO(String status) {
		super(null);
		this.reviewer = null;
		this.status = status;
	}	

	public ReviewerDTO getReviewer() {
		return reviewer;
	}

	@Override
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public boolean isRowSelected() {
		return rowSelected;
	}

	public void setRowSelected(boolean rowSelected) {
		this.rowSelected = rowSelected;
	}
}