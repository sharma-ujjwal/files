package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.SoxConcern;
import java.util.Date;

public class SoxConcernUI {
	private final SoxConcern soxConcern;
	private boolean checked;

	public SoxConcernUI(SoxConcern soxConcern) {
		this.soxConcern = soxConcern;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	
	public Long getId() {
		return this.soxConcern.getId();
	}
	
	public String getSoxConcernCode() {
		return this.soxConcern.getSoxConcernCode();
	}

	
	public String getSoxConcernDescription() {
		return this.soxConcern.getSoxConcernDescription();
	}
	
	public String getCreatedBy() {
		return this.soxConcern.getCreatedBy();
	}
		
		public Date getCreatedDate() {
		return this.soxConcern.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.soxConcern.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.soxConcern.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.soxConcern.getDeleteFlag();
	}

	public SoxConcern getSoxConcern() {
		return soxConcern;
	}
	
	public Date getActiveFromDate() {
		return this.soxConcern.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.soxConcern.getActiveToDate();
	}
	
}  //end of SoxConcernUI
