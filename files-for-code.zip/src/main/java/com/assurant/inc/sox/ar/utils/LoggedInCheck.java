package com.assurant.inc.sox.ar.utils;

import org.apache.commons.lang3.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.jsf.FacesContextUtils;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpSession;

public class LoggedInCheck implements PhaseListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(LoggedInCheck.class);
	
	public PhaseId getPhaseId() {
		return PhaseId.RESTORE_VIEW;
		//return PhaseId.ANY_PHASE;
	}
    @PostConstruct
	public void beforePhase(PhaseEvent event) {
		FacesContext fc = event.getFacesContext();

		HttpServletRequest httpServletRequest = (HttpServletRequest) fc.getExternalContext().getRequest();
		
		if (isSessionControlRequiredForThisResource(httpServletRequest)) {
			if (isSessionInvalid(httpServletRequest)) {
					logger.debug("-------------Session is null" +httpServletRequest);
				logout();
			}
		}
		
	}

	public void afterPhase(PhaseEvent event) {

	}

	/*
	 * session shouldn't be checked for some pages. For example: for timeout
	 * page.. Since we're redirecting to timeout page from this filter, if we
	 * don't disable session control for it, filter will again redirect to it
	 * and this will be result with an infinite loop...
	 */
	private boolean isSessionControlRequiredForThisResource(
			HttpServletRequest httpServletRequest) {
		String requestPath = httpServletRequest.getRequestURI();
		logger.debug("isSessionControlRequiredForThisResource(), requestPath="+ requestPath);
		String test = "/SoxAutoReview/xhtml/dashboard/reviewManagementDashboard.xhtml";
		String test2 = "/SoxAutoReview/xhtml/tasklist/tasklistPage.xhtml";
		boolean controlRequired = !StringUtils.contains(requestPath, test) && !StringUtils.contains(requestPath, test2);
		return controlRequired;

	}

	private boolean isSessionInvalid(HttpServletRequest httpServletRequest) {
		logger.debug("isSessionInvalid()");
		boolean sessionInValid = (httpServletRequest.getRequestedSessionId() != null)
			&& !httpServletRequest.isRequestedSessionIdValid();
        logger.debug("isSessionInvalid() with value : "+sessionInValid);
		return sessionInValid;
	}
	
	/**
	 * Logs the user out, destorys the current session and navigates the user to the generic log out screen.
	 */
	public void logout() {
		FacesContext context = FacesContext.getCurrentInstance();

		HttpServletResponse httpServletResponse = (HttpServletResponse) context.getExternalContext().getResponse();
		
		HttpServletResponseWrapper httpWrapper = new HttpServletResponseWrapper(httpServletResponse);
		String appURL = (String) FacesContextUtils
			.getWebApplicationContext(FacesContext.getCurrentInstance()).getBean("appURL");

		try{
			httpWrapper.sendRedirect(appURL);

		}catch(Exception e){
			logger.error("LogOut redirect error: ", e);
		}

		context.responseComplete();
	}
	
	/**
	 * Destroys the current http session.
	 * 
	 * @param context
	 *            the context to destroy the session for.
	 */
	public void destroySession(FacesContext context) {
		HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
		session.invalidate();
	}
}