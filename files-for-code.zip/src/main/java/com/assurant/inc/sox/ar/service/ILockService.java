package com.assurant.inc.sox.ar.service;

import com.assurant.inc.sox.ar.dto.LockDTO;

public interface ILockService {

	public void lock(String taskd);

	public void breakLock(String taskId);

	public LockDTO getLock(String taskId);
	
	public void unlock(String taskId);
}
