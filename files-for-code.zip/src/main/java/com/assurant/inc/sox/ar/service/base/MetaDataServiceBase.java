package com.assurant.inc.sox.ar.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.impl.MetaDataService;
import com.assurant.inc.sox.dao.ar.IApplicationDao;
import com.assurant.inc.sox.dao.ar.IApplicationSystemDao;
import com.assurant.inc.sox.dao.ar.IConflictDao;
import com.assurant.inc.sox.dao.ar.IConflictTypeDao;
import com.assurant.inc.sox.dao.ar.IDepartmentDao;
import com.assurant.inc.sox.dao.ar.IDivisionDao;
import com.assurant.inc.sox.dao.ar.IEnvironmentDao;
import com.assurant.inc.sox.dao.ar.IFilterTypeDao;
import com.assurant.inc.sox.dao.ar.ISoxConcernDao;
import com.assurant.inc.sox.dao.ar.ISupervisorDao;
import com.assurant.inc.sox.dao.ar.IUserStatusDao;
import com.assurant.inc.sox.dao.ar.IUserTypeDao;
import com.assurant.inc.sox.dao.luad.IPrivilegeCommentDao;
import com.assurant.inc.sox.dao.luad.IUserAccessDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import org.springframework.stereotype.Component;

@Component
public class MetaDataServiceBase {

    @Autowired
    protected IDivisionDao divisionDao = null;
    @Autowired
    protected IDepartmentDao departmentDao = null;
    @Autowired
    protected IApplicationDao applicationDao = null;
    
    @Autowired
    protected IApplicationSystemDao applicationSystemDao = null;
    @Autowired
    protected IEnvironmentDao environmentDao = null;
    @Autowired
    protected ISoxConcernDao soxConcernDao = null;
    @Autowired
    protected IUserStatusDao userStatusDao = null;
    @Autowired
    protected IUserTypeDao userTypeDao = null;
    @Autowired
    protected IFilterTypeDao filterTypeDao= null;
    @Autowired
    protected IPrivilegeCommentDao privilegeCommentDao = null;
    @Autowired
    protected ISupervisorDao supervisorDao = null;
    @Autowired
    protected IUserDao userDao = null;
    @Autowired
    protected IUserAccessDao userAccessDao = null;
    @Autowired
    protected IConflictTypeDao conflictTypeDao = null;
    @Autowired
    protected IConflictDao conflictDao = null;
    
    protected static final Logger logger = LoggerFactory.getLogger(MetaDataService.class);

    public static Logger getLogger() {
        return logger;
    }

    public IApplicationDao getApplicationDao() {
        return this.applicationDao;
    }

    public void setApplicationDao(IApplicationDao applicationDao) {
        this.applicationDao = applicationDao;
    }

    public IApplicationSystemDao getApplicationSystemDao() {
        return this.applicationSystemDao;
    }

    public void setApplicationSystemDao(IApplicationSystemDao applicationSystemDao) {
        this.applicationSystemDao = applicationSystemDao;
    }

    public IDepartmentDao getDepartmentDao() {
        return this.departmentDao;
    }

    public void setDepartmentDao(IDepartmentDao departmentDao) {
        this.departmentDao = departmentDao;
    }

    public IDivisionDao getDivisionDao() {
        return this.divisionDao;
    }

    public void setDivisionDao(IDivisionDao divisionDao) {
        this.divisionDao = divisionDao;
    }

    public IEnvironmentDao getEnvironmentDao() {
        return this.environmentDao;
    }

    public void setEnvironmentDao(IEnvironmentDao environmentDao) {
        this.environmentDao = environmentDao;
    }

    public ISoxConcernDao getSoxConcernDao() {
        return soxConcernDao;
    }

    public void setSoxConcernDao(ISoxConcernDao soxConcernDao) {
        this.soxConcernDao = soxConcernDao;
    }

    public IUserStatusDao getUserStatusDao() {
        return userStatusDao;
    }

    public void setUserStatusDao(IUserStatusDao userStatusDao) {
        this.userStatusDao = userStatusDao;
    }

    public IUserTypeDao getUserTypeDao() {
        return userTypeDao;
    }

    public void setUserTypeDao(IUserTypeDao userTypeDao) {
        this.userTypeDao = userTypeDao;
    }

    /**
     * @return the filterTypeDao
     */
    public IFilterTypeDao getFilterTypeDao() {
        return this.filterTypeDao;
    }

    /**
     * @param filterTypeDao the filterTypeDao to set
     */
    public void setFilterTypeDao(IFilterTypeDao filterTypeDao) {
        this.filterTypeDao = filterTypeDao;
    }

    public IPrivilegeCommentDao getPrivilegeCommentDao() {
        return privilegeCommentDao;
    }

    public void setPrivilegeCommentDao(IPrivilegeCommentDao privilegeCommentDao) {
        this.privilegeCommentDao = privilegeCommentDao;
    }

	public ISupervisorDao getSupervisorDao() {
		return supervisorDao;
	}

	public void setSupervisorDao(ISupervisorDao supervisorDao) {
		this.supervisorDao = supervisorDao;
	}

	public IUserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	public IUserAccessDao getUserAccessDao() {
		return userAccessDao;
	}

	public void setUserAccessDao(IUserAccessDao userAccessDao) {
		this.userAccessDao = userAccessDao;
	}

	public IConflictTypeDao getConflictTypeDao() {
		return conflictTypeDao;
	}

	public void setConflictTypeDao(IConflictTypeDao conflictTypeDao) {
		this.conflictTypeDao = conflictTypeDao;
	}

	public IConflictDao getConflictDao() {
		return conflictDao;
	}

	public void setConflictDao(IConflictDao conflictDao) {
		this.conflictDao = conflictDao;
	}
}
