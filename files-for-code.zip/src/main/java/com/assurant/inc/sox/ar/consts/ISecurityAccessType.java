package com.assurant.inc.sox.ar.consts;


public interface ISecurityAccessType {
	
    /*
     * common security access
     */
    public static final String SEARCH_BY_CRITERIA = "searchByCriteria";
    public static final String REMOVE_ROLES = "removeRoles";
    public static final String ADD_ROLES = "addRoles";
    public static final String RETRIEVE_ROLES = "retrieveRoles";
    public static final String RETRIEVE_ACCESSES = "retrieveAccesses";
    public static final String RETRIEVE_PRIVILEGES = "retrievePrivileges";
    public static final String RETRIEVE_USERS = "retrieveUsers";
    public static final String ADD_USERS = "addUsers";
    public static final String REMOVE_USERS = "removeUsers";
    public static final String ADD_PRIVILEGES = "addPrivileges";
    public static final String REMOVE_PRIVILEGES = "removePrivileges";

    /*
     * role security access
     */
    public static final String ROLE_SERVICE = "RoleService.";
    public static final String CREATE_ROLE = "createRole";
    public static final String UPDATE_ROLE = "updateRole";
    public static final String RETIRE_ROLE = "retireRole";
    
    /*
     * user security access
     */
    public static final String USER_SERVICE = "UserService.";
    public static final String CREATE_USER = "createUser";
    public static final String UPDATE_USER ="updateUser";
    public static final String REMOVE_ACCESSES ="removeAccesses";
    public static final String ADD_ACCESSES ="addAccesses";    

    /*
     * access security 
     */
    public static final String ACCESS_SERVICE = "AccessService.";
    public static final String RETRIEVE_REVIEW_ACCESS = "retrieveReviewAccess";
    public static final String UPDATE_ACCESSES = "updateAccesses";
    
    /*
     * report security access
     */
    public static final String REPORT_SERVICE = "ReportService.";
    
	/*
	 * Viewing tabs
	 */
	public static final String VIEW_ROLES = "viewRoles";
	public static final String VIEW_USERS = "viewUsers";
	public static final String VIEW_ACCESSES = "viewAccesses";
	public static final String VIEW_REPORTS = "viewReports";
	
	/*
	 * Automation of Reviews
	 */
	//-------------------------------------------------------------------------------------//
	
	public static final String VIEW_DASHBOARD = "viewDashBoard";
	
	/*
	 * Review Actions
	 */
	public static final String REVIEW_SERVICE = "ReviewService.";
	
	public static final String PERFORM_REVIEW_ACTIONS = "performReviewActions";
}
