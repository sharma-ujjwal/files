package com.assurant.inc.sox.ar.client.bean.review;

import java.util.ArrayList;
import java.util.List;


import javax.faces.component.UIParameter;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.FilterCriteriaUI;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerField;
import com.assurant.inc.sox.ar.service.impl.ReviewBundleService;
import com.assurant.inc.sox.ar.service.impl.ReviewerService;
import com.assurant.inc.sox.ar.utils.DisplayStringBuilder;
import org.primefaces.component.column.Column;
import org.primefaces.component.commandlink.CommandLink;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component("reviewBundleSummaryBean")
@Scope("session")
public class ReviewBundleSummaryBean {
	private static final Logger logger = LoggerFactory.getLogger(ReviewBundleSummaryBean.class);
	private static final String SORT_ACTION_PARAM_NAME = "sortFieldName";
	@Autowired
	@Qualifier("reviewerService")
	private ReviewerService reviewerService;
	@Autowired
	@Qualifier("reviewBundleService")
	private ReviewBundleService reviewBundleService;

	private DataTable reviewSummaryTable = new DataTable();
	private ReviewUI review;
	private ReviewBundleUI reviewBundle;
	private String previousSortFieldCodeValue;

	private List<FilterCriteriaUI> filterCriteriaValues;
	private String filterCriteriaText;
	private int numberOfReports;
	private int totalNumberOfReviewedUsers;

	private boolean showAcceptBundle = true;

	// ----------------------------- Faces Injected Properties ----------------
	public ReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(ReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	// ----------------------------- Page Properties --------------------------
	public ReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(ReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	public DataTable getReviewSummaryTable() {
		return reviewSummaryTable;
	}

	public void setReviewSummaryTable(DataTable reviewSummaryTable) {
		this.reviewSummaryTable = reviewSummaryTable;
	}

	public ReviewUI getReview() {
		return review;
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public String getFilterCriteriaText() {
		return filterCriteriaText;
	}

	public int getNumberOfReports() {
		return numberOfReports;
	}

	public int getTotalNumberOfReviewedUsers() {
		return totalNumberOfReviewedUsers;
	}

	public Integer getDisplayAmount() {
		return this.reviewSummaryTable.getRows();
	}

	public void setDisplayAmount(Integer displayAmount) {
		this.reviewSummaryTable.setRows(displayAmount);
	}

	/**
	 * If there is no data for the bundle then add a message to the screen to let the user know and don't render the accept bundle
	 * button.
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	/**
	 * Checks if review bundle is empty.
	 * @param true if bundle empty.
	 */
	public boolean isBundleEmpty() {
		logger.debug("isBundleEmpty() --> being executed.");
		if (this.reviewBundle != null && (((List<ReviewerUI>) this.reviewSummaryTable.getValue()) != null)) {
			return (((List<ReviewerUI>) this.reviewSummaryTable.getValue()).isEmpty());
		} else {
			return true;
		}
	}

	// ----------------------------- Page Actions -----------------------------
	/**
	 * Sorts the review summary table by the given field.
	 */
	public String doSortByField() {
		logger.debug("doSortByField -- enter");
		String sortFieldCodeValue = JSFUtils.getParameter(SORT_ACTION_PARAM_NAME);
		CommonPageActionHelper.sortListByField(this.reviewSummaryTable, sortFieldCodeValue, this.previousSortFieldCodeValue);
		this.previousSortFieldCodeValue = sortFieldCodeValue;
		return null;
	}

	/**
	 * Edits the criteria for review bundle.
	 * @return String to navigate to the create bundle page.
	 */
	public String doEditCriteria() {
		logger.debug("doEditCriteria -- enter");
		getReviewBundleService().rejectBundleSummary(this.reviewBundle.getReviewBundleId());

		CreateBundleBean bean = (CreateBundleBean) JSFUtils.lookupBean("createBundleBean");
		bean.receive(this.filterCriteriaValues, this.review);

		return "createBundle";
	}

	/**
	 * Accepts the review bundle.
	 * @return String to navigate to task list page.
	 */
	public String doAcceptBundle() {
		logger.debug("doAcceptBundle -- enter");
		this.reviewBundleService.acceptBundleSummary(this.reviewBundle.getReviewBundleId());

		SessionDataBean bean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
		bean.initSelectedTasklistBean();

		return "taskList";
	}

	/**
	 * Rejects the review bundle.
	 * @return String to navigate to task list page.
	 */
	public String doRejectBundle() {
		logger.debug("doRejectBundle -- enter");
		this.reviewBundleService.rejectBundleSummary(this.reviewBundle.getReviewBundleId());

		SessionDataBean bean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
		bean.initSelectedTasklistBean();

		return "taskList";
	}
	
	/**
	 * Rejects the review bundle.
	 * @return String to navigate to task list page.
	 */
	public String doRejectBundleWithOutConflicts() {
		logger.debug("doRejectBundleWithOutConflicts -- enter");
		this.reviewBundleService.rejectSODBundleSummaryWithNoConflict(this.reviewBundle.getReviewBundleId());

		SessionDataBean bean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
		bean.initSelectedTasklistBean();

		return "taskList";
	}	
	

	/**
	 * Performs cancel on the review bundle summary page.
	 * @return String to navigate to task list page.
	 */
	public String doCancel() {
		logger.info("doCancel -- enter");
		
		SessionDataBean bean = (SessionDataBean) JSFUtils.lookupBean("sessionDataBean");
		bean.initSelectedTasklistBean();
		
		return "taskList";
	}

	// ----------------------------- Helper methods ---------------------------

	/**
	 * Loads the review bundle summary bean.
	 * @param selectedReview the selected review.
	 * @param selectedReviewBundle the selected review bundle.
	 */
	@SuppressWarnings("unchecked")
	public void initBean(ReviewUI selectedReview, ReviewBundleUI selectedReviewBundle) {
		logger.debug("initBean -- enter");
		this.review = selectedReview;
		this.reviewBundle = selectedReviewBundle;
		this.reviewSummaryTable = this.buildTable();
		this.numberOfReports = ((List) this.reviewSummaryTable.getValue()).size();

		if(this.numberOfReports == 0){
			JSFUtils.addFacesErrorMessage("No results found for search criteria.");
		}

		this.filterCriteriaValues = this.buildFilterCriteriaList();
		this.filterCriteriaText = DisplayStringBuilder.buildFilterCriteriaText(this.filterCriteriaValues);
		this.totalNumberOfReviewedUsers = this.buildTotalNumberOfReviewedUsers();

	}

	@SuppressWarnings("unchecked")
	private int buildTotalNumberOfReviewedUsers() {
		int result = 0;
		for(ReviewerUI reviewer : (List<ReviewerUI>) this.reviewSummaryTable.getValue()){
			Long numberOfReviewedUsers = reviewer.getNumberOfReviewedUsers();
			if(numberOfReviewedUsers != null){
				result += numberOfReviewedUsers.longValue();
			}
		}
		return result;
	}

	private List<FilterCriteriaUI> buildFilterCriteriaList() {
		List<FilterCriteriaDTO> filters = this.reviewBundleService.retrieveFilterCriteria(this.reviewBundle.getReviewBundleId());
		List<FilterCriteriaUI> result = new ArrayList<FilterCriteriaUI>(filters.size());
		for(FilterCriteriaDTO filter : filters){
			result.add(new FilterCriteriaUI(filter));
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private DataTable buildTable() {
		DataTable table = new DataTable();
		table.setVar("reviewer");
		table.setStyleClass("defaultTableHeader");
		table.setRows(10);
//		table.setWidth("100%");
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		table.setValue(this.retrieveReviewers());

		List tableChildren = table.getChildren();
		if(this.review.isSODReview()){ //SOD type Review
			logger.debug("getReviewSummaryTable -- building SOD type table.");
			tableChildren.add(this.buildSODOwnerColumn());
			tableChildren.add(this.buildSODConflictTypeColumn());
			tableChildren.add(this.buildReviewerColumn());
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			tableChildren.add(this.buildNumberOfReviewedAppUsersColumn());
			tableChildren.add(this.buildStatusColumn());
		}else if(!this.review.isNotManagerReview()){ //Manager type review
			logger.debug("getReviewSummaryTable -- building manager type table.");
			tableChildren.add(this.buildReviewerColumn());
			tableChildren.add(this.buildEscalationMgrColumn());
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			tableChildren.add(this.buildNumberOfReviewedDirectReportsColumn());
			tableChildren.add(this.buildStatusColumn());
		} else { //Data Owner and privileged access type review
			logger.debug("getReviewSummaryTable -- building data owner type table.");
			tableChildren.add(this.buildDataOwnerNameColumn());
		    tableChildren.add(this.buildApplicationColumn());
			tableChildren.add(this.buildReviewerColumn());
			tableChildren.add(this.buildDivisionColumn());
			tableChildren.add(this.buildDepartmentColumn());
			tableChildren.add(this.buildNumberOfReviewedAppUsersColumn());
			tableChildren.add(this.buildStatusColumn());
		}
		String sortField = ReviewerField.REVIEWER_NAME.getFieldName();
		CommonPageActionHelper.sortListByField(table, sortField, null);
		this.previousSortFieldCodeValue = sortField;
		return table;
	}

	/**
	 * Builds the SOD owner name column.
	 * 
	 * @return the SOD owner name column.
	 */
	private Column buildSODOwnerColumn() {
		return this.buildColumn("SOD Owner(s)", ReviewerField.SOD_OWNER, "sortBySODOwnerLink");
	}
	
	/**
	 * Builds the SOD conflict type column.
	 * 
	 * @return the SOD conflict type column.
	 */
	private Column buildSODConflictTypeColumn() {
		return this.buildColumn("SOD Conflict Type", ReviewerField.SOD_CONFLICT_DISPLAY, "sortByConflictTypeLink");
	}
	
	/**
	 * Builds the reviewer column.
	 * 
	 * @return the reviewer column.
	 */
	private Column buildReviewerColumn() {
		return this.buildColumn("Reviewer", ReviewerField.REVIEWER_NAME, "sortByReviewerLink");
	}

	/**
	 * Builds the escalation manager column.
	 * 
	 * @return the escalation manager column.
	 */
	private Column buildEscalationMgrColumn() {
		return this.buildColumn("Escalation Manager", ReviewerField.ESCALATION_MGR, "sortByEscalationMgrLink");
	}
	/**
	 * Builds the data owner name column.
	 * 
	 * @return the data owner name column.
	 */
	private Column buildDataOwnerNameColumn() {
		return this.buildColumn("Data Owner(s)", ReviewerField.OWNER, "sortByDataOwnerLink");
	}

	/**
	 * Builds the department column.
	 * 
	 * @return the department column.
	 */
	private Column buildDepartmentColumn() {
		return this.buildColumn("Department", ReviewerField.DEPARTMENT, "sortByDepartmentLink");
	}

	private Column buildDivisionColumn() {
		return this.buildColumn("Division", ReviewerField.DIVISION, "sortByDivisionLink");
	}
	
	/**
	 * Builds the application column.
	 * 
	 * @return the application column.
	 */
	private Column buildApplicationColumn() {
		return this.buildColumn("Application", ReviewerField.APPLICATION, "sortByApplicationLink");
	}

	/**
	 * Builds the number of reviewed users column.
	 * 
	 * @return the number of reviewed users column.
	 */
	private Column buildNumberOfReviewedDirectReportsColumn() {
		return this.buildColumn("# Direct Reports", ReviewerField.NUMBER_OF_REVIEWED_USERS,
		        "sortByNumberOfReviewedDirectReportsLink");
	}

	/**
	 * Builds the number of reviewed application users column.
	 * 
	 * @return the number of reviewed application users column.
	 */
	private Column buildNumberOfReviewedAppUsersColumn() {
		return this.buildColumn("# Application Users", ReviewerField.NUMBER_OF_REVIEWED_USERS,
		        "sortByNumberOfReviewedAppUsersLink");
	}

	/**
	 * Builds the status column.
	 * 
	 * @return the status column.
	 */
	private Column buildStatusColumn() {
		return this.buildColumn("User Status", ReviewerField.DISTINCT_EMP_STATUSES, "sortByStatusLink");
	}

	private Column buildColumn(String colHeaderValue, ReviewerField field, String headerLinkId) {

		CommandLink link = HtmlTableBuilderUtil.buildHeaderLink(colHeaderValue,
		        "#{reviewBundleSummaryBean.doSortByField}", headerLinkId);

		UIParameter param = new UIParameter();
		String fieldName = field.getFieldName();
		param.setValue(fieldName);
		param.setName(SORT_ACTION_PARAM_NAME);
		link.getChildren().add(param);

		StringBuilder sb = new StringBuilder(20).append("#{reviewer.").append(fieldName).append('}');

		return HtmlTableBuilderUtil.buildColumn(link, HtmlTableBuilderUtil.buildOutputText(sb.toString()));
	}

	private List<ReviewerUI> retrieveReviewers() {
		logger.debug("reviewerService.retrieveByBundleId(reviewBundleId) -> begin");
		List<ReviewerDTO> reviewerDtos = this.reviewerService.retrieveByBundleId(this.reviewBundle.getReviewBundleId());
		logger.debug("reviewerService.retrieveByBundleId(reviewBundleId) -> end. List size = " + reviewerDtos.size());
		List<ReviewerUI> result = new ArrayList<ReviewerUI>(reviewerDtos.size());
		for(ReviewerDTO reviewerDTO : reviewerDtos){
			result.add(new ReviewerUI(reviewerDTO));
			showAcceptBundle = false;
		}
		return result;
	}

	public boolean isSODReviewWithOutConflicts() {
		return review.isSODReview() && isBundleEmpty();
	}

	public boolean isShowAcceptBundle() {
		return showAcceptBundle;
	}

	public void setShowAcceptBundle(boolean showAcceptBundle) {
		this.showAcceptBundle = showAcceptBundle;
	}
}
