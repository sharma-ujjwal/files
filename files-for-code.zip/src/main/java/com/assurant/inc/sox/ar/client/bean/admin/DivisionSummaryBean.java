package com.assurant.inc.sox.ar.client.bean.admin;

import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang3.StringUtils;

import org.primefaces.component.datascroller.DataScroller;
import org.primefaces.event.data.PageEvent;

import com.assurant.inc.sox.ar.client.admin.ui.DivisionUI;
import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.dto.enums.FilterTableCode;
import com.assurant.inc.sox.ar.service.IDivisionService;
import com.assurant.inc.sox.domain.ar.Division;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("divisionSummaryBean")
@Scope("session")
public class DivisionSummaryBean {
	private static final Logger logger = LoggerFactory
			.getLogger(DivisionSummaryBean.class);
	private List<DivisionUI> divisionList;
	private List<DivisionUI> deletedDivisionList = new ArrayList<DivisionUI>();
	@Autowired
	@Qualifier("divisionService")
	private IDivisionService divisionService;
	private String displayAmount = "10";
	private String oldSortColumn;
	private String divisionName;
	private String activeFilter = FilterTableCode.ACTIVE_ROWS.name();
	private String divisionNameSearchText;
	private boolean renderAddDivisionModalPanel;
	private boolean renderDeleteDivisionModalPanel;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private boolean allChecked;
	private String pageNumber = "1";
	private String 	lastPageNumber= "1";
	private DataScroller dataScroller;

	public List<DivisionUI> getDivisionList() {
		if (divisionList == null) {
			refreshList();
		}
		return divisionList;
	}
	
	// ******* Refresh the List  RESET button *******
	public void refreshList() {
		this.allChecked = false;
		
		this.divisionList = new ArrayList<DivisionUI>();
		List<Division> divisionsRetrieved = new ArrayList<Division>();
		if (FilterTableCode.ACTIVE_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.divisionNameSearchText)) {
				divisionsRetrieved = this.divisionService.retrieveAllDivisionsByName(this.divisionNameSearchText);
			} else {
				divisionsRetrieved = this.divisionService.retrieveAllDivisions();
			}
			
		} else if (FilterTableCode.DELETED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.divisionNameSearchText)) {
				divisionsRetrieved = this.divisionService.retrieveDeletedDivisionsByName(this.divisionNameSearchText);
			} else {
				divisionsRetrieved = this.divisionService.retrieveDeletedDivisions();
			}

		} else if (FilterTableCode.UNASSIGNED_ROWS.name().equals(this.activeFilter)) {
			if (StringUtils.isNotEmpty(this.divisionNameSearchText)) {
				divisionsRetrieved = this.divisionService.retrieveUnassignedDivisionsByName(this.divisionNameSearchText);
			} else {
				divisionsRetrieved = this.divisionService.retrieveUnassignedDivisions(); // constructor JSF call
			}
		}
		for (Division division : divisionsRetrieved) {
			this.divisionList.add(new DivisionUI(division));
		}
	    this.doSort();
	}

	// ******* GO button *******	
	public String goSearch() {
		refreshList();
		return "";
	}
	
	// ******* RESET  button *******	
	public String resetSearch() {
		this.divisionList = null;
		this.divisionNameSearchText = null;
		this.oldSortColumn = null;
		refreshList();
		return "";
	}
	
	// *******  Filter ListBox *******	
	public String switchFilterTables() {
		this.oldSortColumn = null;
		this.refreshList();
		this.clearSelections();
		return "";
	}

	// *******  List Headers *******	
	public void doSort() {
		String column = JSFUtils.getParameter("column");
		if (column == null) {
			if (this.oldSortColumn != null) {
				column = this.oldSortColumn;
			} else {
				column = "name";
			}
			
			this.oldSortColumn = null;
		}
		CommonPageActionHelper.sortListByField(divisionList, column, this.oldSortColumn);
		this.oldSortColumn = column;
		this.clearSelections();
	}

	// ******* Add Division Panel  *******
	public String showAddDivisionPanel() {
		this.renderAddDivisionModalPanel = true;
		this.divisionName = "";
	//	this.selectedConflictTypeId = null;
		this.clearSelections();
		return null;
	}

	// *******  Add Division Panel  CANCEL  *******
	public String doCancelAdd() {
		logger.debug("doCancelAddDivisionPanel() --> being executed.");
		this.renderAddDivisionModalPanel = false;
		this.clearSelections();
		return null;
	}

	// ******* Add Division Panel  SAVE *******
	public String doAddDivision() {
		logger.debug("doAddDivision() --> being executed.");
		// Displays error message if reason not provided

		if (!validDivisionName()) {
			String message = "Division name is required.";
			JSFUtils.addFacesErrorMessage(message);
			//this.renderAddDivisionModalPanel = true;
			return null;
		}
		
		this.divisionName = this.divisionName.toUpperCase();  //change name to all upper Cases	
		
		Division duplicateDivision = this.divisionService.findDuplicate(divisionName);
		if (duplicateDivision != null) {
			String message = "Division name " + divisionName
					+ " already exists with ID of " + duplicateDivision.getId();
			JSFUtils.addFacesErrorMessage(message);
			this.renderAddDivisionModalPanel = true;
			return null;
		}
 	     	     
		divisionService.add(divisionName);

		// Display Message.
		String message = "Added Division " + divisionName;
		JSFUtils.addFacesMessage(message);
		this.refreshList();

		this.renderAddDivisionModalPanel = false;
		return "";
	}
	
	// ******* Delete Division  Panel *******
	public String showDeleteDivisionPanel() {
		populateDeletedDivisionList();
		if (this.deletedDivisionList.isEmpty()) {
			String message = "Please select at least one division.";
			FacesContext.getCurrentInstance().addMessage(message,
					new FacesMessage(message));
		} else {
			this.renderDeleteDivisionModalPanel = true;
		}
		return null;
	}

	private void populateDeletedDivisionList() {
		deletedDivisionList = new ArrayList<DivisionUI>();
		
		for (DivisionUI ui : this.divisionList) {
			if (ui.isChecked()) {
				this.deletedDivisionList.add(ui);
			}
		}
	}
	

	public void doDisplayRowListener() {
		logger.debug("doDisplayRowListener(DataScrollerEvent event) --> being executed.");
		this.clearSelections();
	}

	public void doScrollerListener(PageEvent event) {
		logger.debug("doScrollerListener(DataScrollerEvent event) --> being executed.");
		/*pageNumber = event.getNewScrolVal();
		lastPageNumber = event.getOldScrolVal();*/
		int newPage = event.getPage();
		lastPageNumber = pageNumber;
		pageNumber = String.valueOf(newPage);
		this.clearSelections();
	}

	// ******* switch Check Box Toggle *******
	public void switchCheckBoxToggle() {
		this.allChecked = !this.allChecked;   //toggle true & false
		
			if (allChecked) {
				int pageSize = Integer.parseInt(displayAmount);
				int intLastPageNumber = Integer.parseInt(lastPageNumber);
				
				int pageNum;
				
				//user pressed an arrow "first", "last", "next", "previous", "fastforward", "fastrewind" 
				if ("first".equals(pageNumber))
				             pageNum = 1;
					else if ("last".equals(pageNumber))
						     pageNum = (int)(Math.ceil((double)divisionList.size() / pageSize)) ;
					else if ("next".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
					else if ("previous".equals(pageNumber))
						     pageNum = intLastPageNumber - 1;
					else if ("fastforward".equals(pageNumber))
						     pageNum = intLastPageNumber + 1;
				    else if ("fastrewind".equals(pageNumber))
				    	     pageNum = intLastPageNumber - 1;
					else   //user pressed a real number
						     pageNum = Integer.parseInt(this.pageNumber);
			

			int firstRow = (pageNum - 1) * pageSize;
			int lastRow = Math
					.min((firstRow + pageSize), divisionList.size());
			
			for (int currRow = firstRow; currRow < lastRow; currRow++) {
				divisionList.get(currRow).setChecked(true);
			}
		} else {
			for (DivisionUI divisionUI : this.divisionList) {
				divisionUI.setChecked(false);
			}
		}
	}
	
	private void clearSelections() {
		this.allChecked = false;
		for (DivisionUI divisionUI : this.divisionList) {
			divisionUI.setChecked(false);
		}
	}


		
	// ******* Delete Division  Panel  DELETE  *******
	public String doDelete() {
		List<String> unableToDelete = new ArrayList<String>(); 
		for (DivisionUI ui : this.deletedDivisionList) {
			// first perform a check to ensure that no one user record has the
			// curren department assigned
			if (this.divisionService.canDivisionBeDeleted(ui.getId())) {
				this.divisionService.delete(ui.getDivision());
			} else {
				unableToDelete.add(ui.getName() + " (" + ui.getId() + ")");
			}
		}	

		if (unableToDelete.size() > 0) {
			JSFUtils.addFacesErrorMessage("All selected divisions were deleted " +
					"except for the following, which are assigned to at least one " +
					"user record: " + StringUtils.join(unableToDelete, ", "));
		} else {
			JSFUtils.addFacesMessage("Successfully deleted all selected departments");
		}

		this.refreshList();
		
		this.deletedDivisionList = new ArrayList<DivisionUI>();
		this.renderDeleteDivisionModalPanel = false;
		return null;
	}
	
	// ******* Delete Division  Panel  CANCEL  *******
	public String doCancelDelete() {
		this.deletedDivisionList = new ArrayList<DivisionUI>();
		this.renderDeleteDivisionModalPanel = false;
		return null;
	}

	
	
	// *******   gets & setters           *******
	public boolean validDivisionName() {
		return (StringUtils.isNotEmpty(divisionName));
	}
	
	//public boolean validConflictType() {
	//	return this.selectedConflictTypeId != null;
	//}
	
	
	public boolean isRenderAddDivisionModalPanel() {
		return renderAddDivisionModalPanel;
	}

	public void setRenderAddDivisionModalPanel(
			boolean renderAddDivisionModalPanel) {
		this.renderAddDivisionModalPanel = renderAddDivisionModalPanel;
	}

	public boolean isRenderDeleteDivisionModalPanel() {
		return renderDeleteDivisionModalPanel;
	}

	public void setRenderDeleteDivisionModalPanel(
			boolean renderDeleteDivisionModalPanel) {
		this.renderDeleteDivisionModalPanel = renderDeleteDivisionModalPanel;
	}

	public List<DivisionUI> getDeletedDivisionList() {
		return deletedDivisionList;
	}

	public void setDeletedDivisionList(List<DivisionUI> deletedDivisionList) {
		this.deletedDivisionList = deletedDivisionList;
	}
	
	public boolean isDeleteEnabled() {
		return (FilterTableCode.valueOf(this.activeFilter) == FilterTableCode.UNASSIGNED_ROWS);
	}
	public String getDivisionName() {
		return this.divisionName;
	}

	public void setDivisionName(String name) {
		this.divisionName = name;
	}
	
	public String getDisplayAmount() {
		return displayAmount;
	}

	public void setDisplayAmount(String displayAmount) {
		this.displayAmount = displayAmount;
	}

	public String getActiveFilter() {
		return activeFilter;
	}

	public void setActiveFilter(String activeFilter) {
		this.activeFilter = activeFilter;
	}

	public String getDivisionNameSearchText() {
		return divisionNameSearchText;
	}

	public void setDivisionNameSearchText(String divisionNameSearchText) {
		this.divisionNameSearchText = divisionNameSearchText;
	}

	public void setDivisionList(List<DivisionUI> divisionList) {
		this.divisionList = divisionList;
	}

	public IDivisionService getDivisionService() {
		return divisionService;
	}

	public void setDivisionService(IDivisionService divisionService) {
		this.divisionService = divisionService;
	}

//	public Long getSelectedConflictTypeId() {
//		return selectedConflictTypeId;
//	}
//
//	public void setSelectedConflictTypeId(Long selectedConflictType) {
//		this.selectedConflictTypeId = selectedConflictType;
//	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public boolean isAllChecked() {
		return allChecked;
	}

	public void setAllChecked(boolean allChecked) {
		this.allChecked = allChecked;
	}

	public String getSelectAllLinkText() {
		return "Select " + (this.allChecked ? "None" : "All");
	}

	public List<SelectItem> getAvailableFilters() {
		List<SelectItem> availableFilters = new ArrayList<SelectItem>();
		availableFilters.add(new SelectItem(FilterTableCode.ACTIVE_ROWS.name(),
				FilterTableCode.ACTIVE_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.DELETED_ROWS.name(),
				FilterTableCode.DELETED_ROWS.filterName()));
		availableFilters.add(new SelectItem(FilterTableCode.UNASSIGNED_ROWS.name(),
				FilterTableCode.UNASSIGNED_ROWS.filterName()));

		return availableFilters;
	}

	public void init() {
		this.divisionList = null;
		this.deletedDivisionList = null;
		this.divisionNameSearchText = null;
		this.oldSortColumn = null;
		this.allChecked = false;
		this.activeFilter = FilterTableCode.ACTIVE_ROWS.name();
		this.displayAmount = "10";
		this.pageNumber = "1";
		this.lastPageNumber = "1";
	}

	public DataScroller getDataScroller() {
		return dataScroller;
	}

	public void setDataScroller(DataScroller dataScroller) {
		this.dataScroller = dataScroller;
	}
}

