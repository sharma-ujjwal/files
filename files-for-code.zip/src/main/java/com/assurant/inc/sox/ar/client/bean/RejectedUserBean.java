package com.assurant.inc.sox.ar.client.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlOutputText;

import com.assurant.inc.sox.ar.service.impl.ReviewUserService;
import com.assurant.inc.sox.ar.service.impl.UserActionRequiredService;
import org.apache.commons.lang3.StringUtils;

import org.primefaces.component.column.Column;
import org.primefaces.component.datatable.DataTable;

import com.assurant.inc.sox.ar.client.bean.util.HtmlTableBuilderUtil;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.ReviewBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUserUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.client.ui.WorkOrderUI;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.ar.dto.enums.WorkOrderField;
import com.assurant.inc.sox.ar.dto.enums.reviewUser.ReviewUserField;
import com.assurant.inc.sox.ar.dto.tasklist.RejectedUserTasklistDTO;
import com.assurant.inc.sox.ar.service.IReviewUserService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.IUserActionRequiredService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
public class RejectedUserBean {
	private static final Logger logger = LoggerFactory.getLogger(RejectedUserBean.class);
	private static final int MAX_COMMENT_LENGTH = 1000;
	@Autowired
	@Qualifier("reviewUserService")
	private ReviewUserService reviewUserService;
	@Autowired
	@Qualifier("reviewerService")
	private IReviewerService reviewerService;
	@Autowired
	@Qualifier("userActionRequiredService")
	private UserActionRequiredService userActionRequiredService;
	private ReviewUI review;
	private ReviewBundleUI reviewBundle;
	private ReviewerUI reviewer;
	private DataTable workOrderTable;
	private DataTable rejectedUserTable;
	private String taskId;
	private boolean renderAddActivityModalPanel;
	private String commentsInput;
	private String selectReasonInput;
	private String workOrderNo;
	private String userName;
	private Long rejectedReviewUserId;
	private boolean renderAttestConfirmationModalPanel;
	@Autowired
	@Qualifier("sessionDataBean")
	private SessionDataBean sessionDataBean;
	private boolean renderWOTable;

	// ---------------------- faces injected properties -------------------------
	public IReviewUserService getReviewUserService() {
		return reviewUserService;
	}

	public void setReviewUserService(ReviewUserService reviewUserService) {
		this.reviewUserService = reviewUserService;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IUserActionRequiredService getUserActionRequiredService() {
		return userActionRequiredService;
	}

	public void setUserActionRequiredService(UserActionRequiredService userActionRequiredService) {
		this.userActionRequiredService = userActionRequiredService;
	}

	// ---------------------- page properties -----------------------------------
	public DataTable getWorkOrderTable() {
		return workOrderTable;
	}

	public void setWorkOrderTable(DataTable workOrderTable) {
		this.workOrderTable = workOrderTable;
	}

	public DataTable getRejectedUserTable() {
		return rejectedUserTable;
	}

	public void setRejectedUserTable(DataTable rejectedUserTable) {
		this.rejectedUserTable = rejectedUserTable;
	}

	public ReviewUI getReview() {
		return review;
	}

	public ReviewBundleUI getReviewBundle() {
		return reviewBundle;
	}

	public ReviewerUI getReviewer() {
		return reviewer;
	}

	// ----------------------- page actions --------------------------------------
	/**
	 * Adds the work order for the rejected review user.
	 * @return null to return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doAddActivity() {
		logger.debug("doAddActivity() --> being executed.");
		for (ReviewUserUI ui : (List<ReviewUserUI>) this.rejectedUserTable.getValue()) {
			this.userName = ui.getUserName();
		}
		this.commentsInput = null;
		this.selectReasonInput = null;
		this.workOrderNo = null;
		this.renderAddActivityModalPanel = true;
		return null;
	}

	/**
	 * Cancels the add activity panel.
	 * @return null return to the same page.
	 */
	public String doCancelAddActivityPanel() {
		logger.debug("doCancelAddActivityPanel() --> being executed.");
		this.renderAddActivityModalPanel = false;
		return null;
	}

	/**
	 * Saves the work order created for the selected action required items.
	 * @return null return to the same page.
	 */
	@SuppressWarnings("unchecked")
	public String doSaveAddActivityPanel() {
		logger.debug("doSaveAddActivityPanel() --> being executed.");
		// Displays error message if reason not provided
		if (this.selectReasonInput.equals("")) {
			JSFUtils.addFacesErrorMessage("A reason must be selected to add a activity.");
		} else if (!(StringUtils.isNumeric(this.workOrderNo))) {
			JSFUtils.addFacesErrorMessage("The work order number must be numeric.  Value provided: " + this.workOrderNo);
		} else if (StringUtils.isNotBlank(this.commentsInput) && this.commentsInput.length() > MAX_COMMENT_LENGTH) {
			JSFUtils.addFacesErrorMessage("The maximum length of the comment is " + MAX_COMMENT_LENGTH);
		} else {

			ReviewUserDTO reviewUserDto = null;
			for (ReviewUserUI ui : (List<ReviewUserUI>) this.rejectedUserTable.getValue()) {
				reviewUserDto = ui.getReviewUserDTO();
			}

			Long workOrderNumber = null;
			if (StringUtils.isNotBlank(this.workOrderNo)) {
				workOrderNumber = Long.parseLong(this.workOrderNo);
			}
			this.userActionRequiredService.addWorkOrder(reviewUserDto, this.selectReasonInput, this.taskId, workOrderNumber,
			    this.commentsInput);
			this.renderAddActivityModalPanel = false;

			refreshTables();
		}

		return null;
	}

	/**
	 * Completes the reject user task.
	 * @return null return to the same page.
	 */
	public String doCompleteRejectUserTask() {
		logger.debug("doCompleteRejectUserTask() --> being executed.");
		this.renderAttestConfirmationModalPanel = true;
		return null;
	}

	/**
	 * Cancels the complete process.
	 * @return null to return to the same page.
	 */
	public String doCancelAttestConfirmationPanel() {
		logger.debug("doCancelAttestConfirmationPanel() --> being executed.");
		this.renderAttestConfirmationModalPanel = false;
		return null;
	}

	/**
	 * Completes the reject user task
	 * @return null return to the same page.
	 */
	public String doSaveAttestConfirmationPanel() {
		logger.debug("doSaveAttestConfirmationPanel() --> being executed.");
		this.userActionRequiredService.completeActionRequiredTask(this.taskId);
		// return to the task list page after complete process.
		this.sessionDataBean.initSelectedTasklistBean();
		this.renderAttestConfirmationModalPanel = false;
		return "taskList";
	}

	// ---------------------- helper actions ------------------------------------
	/**
	 * Initializes the rejected user bean.
	 * @param taskList the rejected user task list.
	 */
	public void initBean(RejectedUserTasklistDTO taskList) {
		logger.debug("initBean --> enter");
		this.review = new ReviewUI(taskList.getReview());
		ReviewerDTO reviewerDTO = taskList.getReviewer();
		this.reviewerService.populateReviewerDistinctEnvName(reviewerDTO);
		this.reviewer = new ReviewerUI(reviewerDTO);

		this.rejectedReviewUserId = taskList.getRejectedReviewUserId();
		this.rejectedUserTable = this.buildRejectedUserTable(this.rejectedReviewUserId);
		this.workOrderTable = this.buildWorkOrderTable(this.rejectedReviewUserId);
		this.taskId = taskList.getTaskId();
		this.reviewBundle = new ReviewBundleUI(taskList.getReviewBundle());
	}

	private DataTable buildWorkOrderTable(Long rejectedUserId) {
		logger.debug("buildWorkOrderTable --> enter");
		DataTable table = new DataTable();
		table.setVar("workOrder");
		table.setStyleClass("defaultTableHeader");
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");
		table.setValue(this.retrieveWorkOrders(rejectedUserId));

	List<UIComponent> children = table.getChildren();
		children.add(this.buildCreateDateColumn());
		children.add(this.buildNumberColumn());
		children.add(this.buildReasonCodeColumn());
		children.add(this.buildCommentsColumn());
		return table;
}

	@SuppressWarnings("unchecked")
	private void refreshTables() {
		logger.debug("refresh() --> being executed.");
		// refresh the work order table
		List workOrderValues = (List) this.workOrderTable.getValue();
		workOrderValues.clear();
		workOrderValues.addAll(this.retrieveWorkOrders(this.rejectedReviewUserId));
	}

	private UIComponent buildReasonCodeColumn() {
		return this.buildWorkOrderColumn("Code", WorkOrderField.REASON_CODE.getFieldName());
	}

	private UIComponent buildCommentsColumn() {
		return this.buildWorkOrderColumn("Comments", WorkOrderField.COMMENTS.getFieldName());
	}

	private UIComponent buildNumberColumn() {
		return this.buildWorkOrderColumn("Work Order", WorkOrderField.WORK_ORDER_NUMBER.getFieldName());
	}

	private UIComponent buildCreateDateColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Date"), HtmlTableBuilderUtil.buildDateOutputText(this
		    .buildWorkOrderFieldBinding(WorkOrderField.CREATE_DATE.getFieldName())));
	}

	private Column buildWorkOrderColumn(String colHeaderValue, String field) {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(colHeaderValue), HtmlTableBuilderUtil.buildOutputText(this
		    .buildWorkOrderFieldBinding(field)));
	}

	private String buildWorkOrderFieldBinding(String fieldName) {
		return new StringBuilder(20).append("#{workOrder.").append(fieldName).append('}').toString();
	}

	private List<WorkOrderUI> retrieveWorkOrders(Long rejectedUserId) {
		List<WorkOrderDTO> workOrderDTOs = this.userActionRequiredService.retrieveWorkOrdersByReviewUser(rejectedUserId);
		List<WorkOrderUI> workOrders = new ArrayList<WorkOrderUI>(workOrderDTOs.size());
		boolean hasWOFlag = false;
		for (WorkOrderDTO workOrderDTO : workOrderDTOs) {
			// check if the task has WO
			if (workOrderDTO != null) {
				hasWOFlag = true;
			}
			workOrders.add(new WorkOrderUI(workOrderDTO));
		}
		// if the task has work orders, display the work order table
		if (hasWOFlag) {
			this.renderWOTable = true;
		} else {
			this.renderWOTable = false;
		}
		return workOrders;
	}

	private DataTable buildRejectedUserTable(Long reviewUserId) {
		logger.debug("buildActionReqListTable() --> being executed.");

		DataTable table = new DataTable();
		table.setVar("rejectUser");
		table.setStyleClass("defaultTableHeader");
		table.setStyle("width:100%");
		table.setRowStyleClass("oddRow, evenRow");

		table.setValue(Collections.singletonList(this.retrieveRejectedUser(reviewUserId)));
		List<UIComponent> children = table.getChildren();
		children.add(this.buildBundleNameColumn());
		children.add(this.buildEmployeeNameColumn());
		children.add(this.buildDepartmentColumn());
		children.add(this.buildRejectedDateColumn());
		children.add(this.buildRejectedCodeColumn());
		children.add(this.buildRejectCommentsColumn());

		return table;
	}

	private ReviewUserUI retrieveRejectedUser(Long reviewUserId) {
		return new ReviewUserUI(this.reviewUserService.retrieveById(reviewUserId));
	}

	private String buildFieldBinding(String fieldName) {
		return new StringBuilder(20).append("#{rejectUser.").append(fieldName).append('}').toString();
	}

	private Column buildRejectCommentsColumn() {
		return this.buildColumn("Comments", ReviewUserField.REJECT_COMMENTS.getFieldName());
	}

	private Column buildRejectedCodeColumn() {
		return this.buildColumn("Reject Code", ReviewUserField.REJECT_CODE.getFieldName());
	}

	private Column buildRejectedDateColumn() {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Date Rejected"), HtmlTableBuilderUtil.buildDateOutputText(this
		    .buildFieldBinding(ReviewUserField.REJECT_DATE.getFieldName())));
	}

	private Column buildDepartmentColumn() {
		return this.buildColumn("Department", ReviewUserField.DEPT.getFieldName());
	}

	private Column buildEmployeeNameColumn() {
		return this.buildColumn("Employee", ReviewUserField.NAME.getFieldName());
	}

	private Column buildBundleNameColumn() {
		HtmlOutputText text = new HtmlOutputText();
		text.setValue(this.reviewer.getBundleName());
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink("Bundle"), text);
	}

	private Column buildColumn(String colHeaderValue, String field) {
		return HtmlTableBuilderUtil.buildColumn(this.buildHeaderLink(colHeaderValue), HtmlTableBuilderUtil.buildOutputText(this
		    .buildFieldBinding(field)));
	}

	private HtmlOutputText buildHeaderLink(String value) {
		HtmlOutputText text = new HtmlOutputText();
		text.setValue(value);
		return text;
	}

	public boolean isRenderAddActivityModalPanel() {
		return renderAddActivityModalPanel;
	}

	public void setRenderAddActivityModalPanel(boolean renderAddActivityModalPanel) {
		this.renderAddActivityModalPanel = renderAddActivityModalPanel;
	}

	public String getCommentsInput() {
		return commentsInput;
	}

	public void setCommentsInput(String commentsInput) {
		this.commentsInput = commentsInput;
	}

	public String getSelectReasonInput() {
		return selectReasonInput;
	}

	public void setSelectReasonInput(String selectReasonInput) {
		this.selectReasonInput = selectReasonInput;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getRejectedReviewUserId() {
		return rejectedReviewUserId;
	}

	public void setRejectedReviewUserId(Long rejectedReviewUserId) {
		this.rejectedReviewUserId = rejectedReviewUserId;
	}

	public SessionDataBean getSessionDataBean() {
		return sessionDataBean;
	}

	public void setSessionDataBean(SessionDataBean sessionDataBean) {
		this.sessionDataBean = sessionDataBean;
	}

	public boolean isRenderAttestConfirmationModalPanel() {
		return renderAttestConfirmationModalPanel;
	}

	public void setRenderAttestConfirmationModalPanel(boolean renderAttestConfirmationModalPanel) {
		this.renderAttestConfirmationModalPanel = renderAttestConfirmationModalPanel;
	}

	public boolean isRenderWOTable() {
		return renderWOTable;
	}

	public void setRenderWOTable(boolean renderWOTable) {
		this.renderWOTable = renderWOTable;
	}
}
