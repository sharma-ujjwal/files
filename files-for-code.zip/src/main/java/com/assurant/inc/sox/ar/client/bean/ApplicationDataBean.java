package com.assurant.inc.sox.ar.client.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

import javax.faces.bean.ApplicationScoped;
import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.enums.CodeSet;
import com.assurant.inc.sox.ar.service.IApplicationService;
import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IConflictTypeService;
import com.assurant.inc.sox.domain.ar.ConflictType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * JSF bean that contains the data that is global to the application such as static possible values for drop down boxes.
 */
@Component("applicationBean")
@Scope("application")
public class ApplicationDataBean {
	private static final Logger log = LoggerFactory.getLogger(ApplicationDataBean.class);
	private List<SelectItem> availableRowDisplayItems;
	private List<SelectItem> availableReviewTypes;
	private List<SelectItem> availableReviewerRejectReasons;
	private List<SelectItem> availableReviewerReassignReasons;
	private List<SelectItem> availableReviewUserRejectReasons;
	private List<SelectItem> avaliableWorkOrderReasons;
	private List<SelectItem> availableConflictTypes;

	@Autowired
	@Qualifier("codeService")
	private ICodeService codeService;

	@Autowired
	@Qualifier("conflictTypeService")
	private IConflictTypeService conflictTypeService;
	@Autowired
	@Qualifier("applicationService")
	private IApplicationService applicationService;
	
	private static final SelectItem EMPTY_SELECT_ITEM = new SelectItem("", "");

	/**
	 * The available row counts used for table row display.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableRowDisplayItems() {
		synchronized (this) {
			if (this.availableRowDisplayItems == null) {
				log.debug("constructor -- row display");
				// init the number of row displays (table rows to display)
				List<SelectItem> availableRowDisplayItemsLoc = new ArrayList<SelectItem>(4);
				availableRowDisplayItemsLoc.add(new SelectItem("10", "10"));
				availableRowDisplayItemsLoc.add(new SelectItem("25", "25"));
				availableRowDisplayItemsLoc.add(new SelectItem("50", "50"));
				availableRowDisplayItemsLoc.add(new SelectItem("100", "100"));
				this.availableRowDisplayItems = Collections.unmodifiableList(availableRowDisplayItemsLoc);
			}
		}
		return this.availableRowDisplayItems;
	}

	/**
	 * The available review types used for selecting a review type.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableReviewTypes() {
		synchronized (this) {
			if (this.availableReviewTypes == null) {
				log.debug("getAvailableReviewTypes -- review types.");
				// init the review types
				List<CodeDTO> codes = this.codeService.retrieveAllCodesByType(CodeSet.REVIEW_TYPE);
				List<SelectItem> types = new ArrayList<SelectItem>(codes.size() + 1);
				types.add(EMPTY_SELECT_ITEM);
				for (CodeDTO code : codes) {
					types.add(new SelectItem(code.getValue(), code.getDisplay()));
				}
				this.availableReviewTypes = Collections.unmodifiableList(types);
			}
		}
		return this.availableReviewTypes;
	}

	/**
	 * The available reviewer reassignment reasons.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableReviewerReassignReasons() {
		synchronized (this) {
			if (this.availableReviewerReassignReasons == null) {
				log.debug("getAvailableReviewerReassignReasons -- init list");
				// init the reviewer reassign reasons
				List<CodeDTO> reassignReasonValues = this.codeService.retrieveAllCodesByType(CodeSet.REVIEWER_REASSIGNMENT_REASON);

				List<SelectItem> availableReviewerReassignReasonsLoc = new ArrayList<SelectItem>(reassignReasonValues.size() + 1);
				availableReviewerReassignReasonsLoc.add(EMPTY_SELECT_ITEM);
				for (CodeDTO code : reassignReasonValues) {
					availableReviewerReassignReasonsLoc.add(new SelectItem(code.getValue(), code.getDisplay()));
				}
				this.availableReviewerReassignReasons = Collections.unmodifiableList(availableReviewerReassignReasonsLoc);
			}
		}
		return this.availableReviewerReassignReasons;
	}

	public List<SelectItem> getAvaliableWorkOrderReasons() {
		synchronized (this) {
			if (this.avaliableWorkOrderReasons == null) {
				log.debug("getAvaliableWorkOrderReasons -- reject reasons");
				List<CodeDTO> woReasonValues = this.codeService.retrieveAllCodesByType(CodeSet.WORK_ORDER_REASON);
				List<SelectItem> avaliableWorkOrderReasonsLoc = new ArrayList<SelectItem>(woReasonValues.size() + 1);
				avaliableWorkOrderReasonsLoc.add(new SelectItem("", ""));
				for (CodeDTO code : woReasonValues) {
					avaliableWorkOrderReasonsLoc.add(new SelectItem(code.getValue(), code.getDisplay()));
				}
				this.avaliableWorkOrderReasons = Collections.unmodifiableList(avaliableWorkOrderReasonsLoc);
			}
		}
		return this.avaliableWorkOrderReasons;
	}

	/**
	 * The available reviewer rejection reasons for rejecting a reviewer.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableReviewerRejectReasons() {

		synchronized (this) {
			if (this.availableReviewerRejectReasons == null) {
				log.debug("getAvailableReviewerRejectReasons -- reject reasons");
				List<CodeDTO> rejectReasonValues = this.codeService.retrieveAllCodesByType(CodeSet.REVIEWER_REJECT_REASON);
				List<SelectItem> availableReviewerRejectReasonsLoc = new ArrayList<SelectItem>(rejectReasonValues.size() + 1);
				availableReviewerRejectReasonsLoc.add(new SelectItem("", ""));
				for (CodeDTO code : rejectReasonValues) {
					availableReviewerRejectReasonsLoc.add(new SelectItem(code.getValue(), code.getDisplay()));
				}
				this.availableReviewerRejectReasons = Collections.unmodifiableList(availableReviewerRejectReasonsLoc);
			}
		}

		return this.availableReviewerRejectReasons;
	}

	/**
	 * The available reviewer rejection reasons for rejecting a reviewer.
	 * 
	 * @return an unmodifiable list of select items.
	 */
	public List<SelectItem> getAvailableReviewUserRejectReasons() {

		synchronized (this) {
			if (this.availableReviewUserRejectReasons == null) {
				{
					log.debug("getAvailableReviewUserRejectReasons -- reject reasons");
					List<CodeDTO> rejectReasonValues = this.codeService.retrieveAllCodesByType(CodeSet.REVIEW_USER_REJECT_REASON);
					List<SelectItem> availableReviewUserRejectReasonsLoc = new ArrayList<SelectItem>(rejectReasonValues.size() + 1);
					availableReviewUserRejectReasonsLoc.add(new SelectItem("", ""));
					for (CodeDTO code : rejectReasonValues) {
						availableReviewUserRejectReasonsLoc.add(new SelectItem(code.getValue(), code.getDisplay()));
					}
					this.availableReviewUserRejectReasons = Collections.unmodifiableList(availableReviewUserRejectReasonsLoc);
				}
			}
		}

		return this.availableReviewUserRejectReasons;
	}

	public List<SelectItem> getAvaliableConflictTypes() {
		synchronized (this) {
			if (this.availableConflictTypes == null) {
				log.debug("getAvaliableATODConflictTypes -- App to Division types.");
				List<ConflictType> conflictTypes = this.conflictTypeService.retrieveAllConflictTypes();
				List<SelectItem> types = new ArrayList<SelectItem>(conflictTypes.size() + 1);
				types.add(EMPTY_SELECT_ITEM);
				for (ConflictType conflictType : conflictTypes) {
					types.add(new SelectItem(conflictType.getId(), conflictType.getConflictTypeText()));
				}
				this.availableConflictTypes = Collections.unmodifiableList(types);
			}
		}
		return this.availableConflictTypes;
	}

	/**
	 * Get the server default time zone to be used for the JSF date components because they were defaulting to GMT and we need them
	 * to show Central.
	 */
	public String getTimeZone() {
		return TimeZone.getDefault().getID();
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

	public IConflictTypeService getConflictTypeService() {
		return conflictTypeService;
	}

	public void setConflictTypeService(IConflictTypeService conflictTypeService) {
		this.conflictTypeService = conflictTypeService;
	}

	public IApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(IApplicationService applicationService) {
		this.applicationService = applicationService;
	}
}
