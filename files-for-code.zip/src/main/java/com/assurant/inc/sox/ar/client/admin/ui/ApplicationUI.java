package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.Application;
import java.util.Date;

public class ApplicationUI {
	private final Application application;
	private boolean checked;

	public ApplicationUI(Application application) {
		this.application = application;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public Long getId() {
		return this.application.getId();
	}

	public String getName() {
		return this.application.getName();
	}

	public String getCreatedBy() {
		return this.application.getCreatedBy();
	}

	public Date getCreatedDate() {
		return this.application.getCreatedDate();
	}

	public String getLastChangedBy() {
		return this.application.getLastChangedBy();
	}

	public Date getLastChangedDate() {
		return this.application.getLastChangedDate();
	}

	public String getDeleteFlag() {
		return this.application.getDeleteFlag();
	}

	public Date getActiveFromDate() {
		return this.application.getActiveFromDate();
	}

	public Date getActiveToDate() {
		return this.application.getActiveToDate();
	}

	public Application getApplication() {
		return application;
	}

}