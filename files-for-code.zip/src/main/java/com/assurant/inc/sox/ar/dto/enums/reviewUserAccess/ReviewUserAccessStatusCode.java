package com.assurant.inc.sox.ar.dto.enums.reviewUserAccess;

import com.assurant.inc.sox.domain.ar.ReviewUserAccess;

public enum ReviewUserAccessStatusCode {
	ACTIVE(ReviewUserAccess.ACCESS_STATUS_FLAG_ACTIVE), INACTIVE(ReviewUserAccess.ACCESS_STATUS_FLAG_INACTIVE);
	
	private final String value;
	
	private ReviewUserAccessStatusCode(String code) {
		this.value = code;
	}

	public String getCode() {
		
  	return value;
  }

	

}
