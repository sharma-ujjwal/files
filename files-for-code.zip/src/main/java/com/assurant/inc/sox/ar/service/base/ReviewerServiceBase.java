package com.assurant.inc.sox.ar.service.base;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.ar.service.impl.ReviewerService;
import com.assurant.inc.sox.dao.ar.IReviewApplicationDao;
import com.assurant.inc.sox.dao.ar.IReviewBundleDao;
import com.assurant.inc.sox.dao.ar.IReviewDao;
import com.assurant.inc.sox.dao.ar.IReviewOwnerDao;
import com.assurant.inc.sox.dao.ar.IReviewUserAccessDao;
import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import com.assurant.inc.sox.dao.ar.IReviewerReassignmentDao;
import com.assurant.inc.sox.dao.luad.IUserAccessDao;
import com.assurant.inc.sox.dao.luad.IUserDao;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ReviewerServiceBase {
	protected static final Logger logger = LoggerFactory.getLogger(ReviewerService.class);

	@Autowired
	@Qualifier("reviewerDao")
	protected IReviewerDao reviewerDao;
	@Autowired
	@Qualifier("reviewUserDao")
	protected IReviewUserDao reviewUserDao;
	
	@Autowired
	@Qualifier("reviewBundleDao")
	protected IReviewBundleDao reviewBundleDao;
	@Autowired
	@Qualifier("reviewDao")
	protected IReviewDao reviewDao;
	@Autowired
	protected IReviewerReassignmentDao reviewReassignmentDao;
	@Autowired
	@Qualifier("workflowService")
	protected IWorkflowService workflowService;
	
	@Autowired
	@Qualifier("reviewUserAccessDao")
	protected IReviewUserAccessDao reviewUserAccessDao;
	@Autowired
	private SystemUserDTO sessionSystemUser;
	@Autowired
	@Qualifier("reviewBundleService")
	private IReviewBundleService reviewBundleService = null;
	@Autowired
	@Qualifier("reviewApplicationDao")
	protected IReviewApplicationDao reviewApplicationDao;
	@Autowired
	@Qualifier("userDao")
	protected IUserDao userDao;
	@Autowired
	protected IReviewOwnerDao reviewOwnerDao;
	@Resource(name = "appURL")
	@Autowired
	protected String appURL;
	@Resource(name = "fromEmailAddress")
	@Autowired
	protected String fromEmailAddress;

	@Resource(name = "savvionITComplianceUserId")
	@Autowired
	protected String savvionITComplianceUserId;
	@Autowired
	@Qualifier("codeService")
	protected ICodeService codeService;

	@Autowired
	@Qualifier("userAccessDao")
	protected IUserAccessDao userAccessDao;

	/**
	 * Retrieves the system user from the http session data (note this process binds this app to spring's web support).
	 * 
	 * @return the sessionSystemUser from the http session.
	 */
	public SystemUserDTO getSessionSystemUser() {
		return this.sessionSystemUser;
	}

	/**
	 * Sets the system user from the http session data (note this process binds this app to spring's web support).
	 * 
	 * @param the sessionSystemUser from the http session.
	 */
	public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
		this.sessionSystemUser = sessionSystemUser;
	}

	public static Logger getLogger() {
		return logger;
	}

	public IReviewerDao getReviewerDao() {
		return this.reviewerDao;
	}

	public void setReviewerDao(IReviewerDao reviewerDao) {
		this.reviewerDao = reviewerDao;
	}

	public IReviewUserDao getReviewUserDao() {
		return this.reviewUserDao;
	}

	public void setReviewUserDao(IReviewUserDao reviewUserDao) {
		this.reviewUserDao = reviewUserDao;
	}

	public IReviewBundleDao getReviewBundleDao() {
		return this.reviewBundleDao;
	}

	public void setReviewBundleDao(IReviewBundleDao reviewBundleDao) {
		this.reviewBundleDao = reviewBundleDao;
	}

	public IReviewUserAccessDao getReviewUserAccessDao() {
		return reviewUserAccessDao;
	}

	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}

	public void setReviewUserAccessDao(IReviewUserAccessDao reviewUserAccessDao) {
		this.reviewUserAccessDao = reviewUserAccessDao;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}

	/**
	 * @return the userDao
	 */
	public IUserDao getUserDao() {
		return this.userDao;
	}

	/**
	 * @param userDao the userDao to set
	 */
	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}

	public String getAppURL() {
		return appURL;
	}

	public void setAppURL(String appURL) {
		this.appURL = appURL;
	}

	public String getFromEmailAddress() {
		return fromEmailAddress;
	}

	public void setFromEmailAddress(String fromEmailAddress) {
		this.fromEmailAddress = fromEmailAddress;
	}

	public IReviewApplicationDao getReviewApplicationDao() {
		return reviewApplicationDao;
	}

	public void setReviewApplicationDao(IReviewApplicationDao reviewApplicationDao) {
		this.reviewApplicationDao = reviewApplicationDao;
	}

	public String getSavvionITComplianceUserId() {
		return savvionITComplianceUserId;
	}

	public void setSavvionITComplianceUserId(String savvionITComplianceUserId) {
		this.savvionITComplianceUserId = savvionITComplianceUserId;
	}

	public IReviewDao getReviewDao() {
		return reviewDao;
	}

	public void setReviewDao(IReviewDao reviewDao) {
		this.reviewDao = reviewDao;
	}

	public IReviewerReassignmentDao getReviewReassignmentDao() {
		return reviewReassignmentDao;
	}

	public void setReviewReassignmentDao(IReviewerReassignmentDao reviewReassignmentDao) {
		this.reviewReassignmentDao = reviewReassignmentDao;
	}

	public IReviewOwnerDao getReviewOwnerDao() {
		return reviewOwnerDao;
	}

	public void setReviewOwnerDao(IReviewOwnerDao reviewOwnerDao) {
		this.reviewOwnerDao = reviewOwnerDao;
	}

	public IUserAccessDao getUserAccessDao() {
		return userAccessDao;
	}

	public void setUserAccessDao(IUserAccessDao userAccessDao) {
		this.userAccessDao = userAccessDao;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

}
