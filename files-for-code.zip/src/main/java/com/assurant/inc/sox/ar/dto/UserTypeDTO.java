package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.UserType;

public class UserTypeDTO {
    private UserType userType;
    
    public UserTypeDTO(UserType userType) {
        super();
        this.userType = userType;
        
    }

    public long getUserTypeId() {
		Long id = userType.getId();
        return (id == null) ? 0 : id.longValue();
	}

	public String getUserTypeDescription() {
        return userType.getUserTypeDescription();
    }
	
	public Date getActiveFromDate() {
		return this.userType.getActiveFromDate();
	}

	public Date getActiveToDate() {
	    return this.userType.getActiveToDate();
	}
}
