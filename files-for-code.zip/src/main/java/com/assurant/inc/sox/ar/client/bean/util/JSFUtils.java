package com.assurant.inc.sox.ar.client.bean.util;

import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UICommand;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;

/**
 * A utility class for accessing data from the FacesContext such as param values.
 */
public abstract class JSFUtils {

	/**
	 * Extracts a string parameter from the request.
	 * 
	 * @param parmName
	 *            the parameter returned.
	 * @return the parameter for the given name or a null if the parameter is not found.
	 */
	public static String getParameter(String parmName) {
		Map<String, String> paramMap = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
		return paramMap.get(parmName);
	}

	/**
	 * Adds an error message to the faces context.
	 * 
	 * @param message
	 *            the message to add.
	 */
	public static void addFacesErrorMessage(String message) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, null));
	}

	/**
	 * Add an info-level message to the FacesContext
	 * 
	 * @param message
	 * 			the message to add
	 */
	public static void addFacesMessage(String message) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, message, null));
	}

	/**
	 * Utility method to create a value binding
	 * 
	 * @param toBind
	 *            the String to bind
	 * @return the ValueBinding
	 */
	public static ValueBinding createValueBinding(String toBind) {
		return FacesContext.getCurrentInstance().getApplication().createValueBinding(toBind);
	}

	/**
	 * Create a value binding for given component with given name and given binding.
	 * 
	 * @param component
	 *            the component for which to set the binding
	 * @param name
	 *            the name of the binding
	 * @param binding
	 *            the value of the binding
	 */
	public static void setValueBinding(UIComponent component, String name, String binding) {
		component.setValueBinding(name, JSFUtils.createValueBinding(binding));
	}

	/**
	 * Lookup a faces managed bean
	 * 
	 * @param beanName
	 *            the name of the bean
	 * @return the bean found
	 */
	public static Object lookupBean(String beanName) {
		final FacesContext ctx = FacesContext.getCurrentInstance();
		return ctx.getApplication().getELResolver().getValue(ctx.getELContext(), null, beanName);
	}

	public static void setActionBinding(UICommand command, String binding) {
		command.setAction(FacesContext.getCurrentInstance().getApplication().createMethodBinding(binding, null));
	}
}
