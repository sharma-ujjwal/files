package com.assurant.inc.sox.ar.dto.enums;

import com.assurant.inc.sox.domain.ar.FilterType;

public enum FilterCriteriaType {
	
    MANAGER(FilterType.MANAGER_FILTER_TYPE), // Empty Comment
    USERS(FilterType.USERS_FILTER_TYPE),
    APPLICATIONS(FilterType.APPLICATIONS_FILTER_TYPE),
    SOX_CONCERN(FilterType.SOX_CONCERN_FILTER_TYPE),
    ENVIRONMENT(FilterType.ENVIRONMENT_FILTER_TYPE),
    USER_STATUS(FilterType.USER_STATUS_FILTER_TYPE),
    USER_TYPE(FilterType.USER_TYPE_FILTER_TYPE),
    SOURCE_SYSTEM(FilterType.SOURCE_SYSTEM_FILTER_TYPE),
    PRIV_DESCRIPTION(FilterType.PRIV_DESCRIPTION_FILTER_TYPE),
    PRIV_VALUE(FilterType.PRIV_VALUE_FILTER_TYPE),
    COST_CENTER(FilterType.COST_CENTER_FILTER_TYPE),
    DEPARTMENT(FilterType.DEPARTMENT_FILTER_TYPE),
    DIVISION(FilterType.DIVISION_FILTER_TYPE),
    CONFLICT(FilterType.CONFLICT_FILTER_TYPE);

    private final String value;

    private FilterCriteriaType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public static FilterCriteriaType getByCodeValue(String codeValue) {
        FilterCriteriaType result = null;
        for (FilterCriteriaType code : FilterCriteriaType.values()) {
            if (code.value.equalsIgnoreCase(codeValue)) {
                result = code;
                break;
            }
        }
        return result;
    }
    
    public static FilterCriteriaType getByCodeName(String codeName) {
        FilterCriteriaType result = null;
        for (FilterCriteriaType code : FilterCriteriaType.values()) {
            if (code.name().equalsIgnoreCase(codeName)) {
                result = code;
                break;
            }
        }
        return result;
    }
}
