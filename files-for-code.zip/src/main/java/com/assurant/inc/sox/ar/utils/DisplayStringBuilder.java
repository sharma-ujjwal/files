package com.assurant.inc.sox.ar.utils;

import java.util.List;

import com.assurant.inc.sox.ar.client.ui.FilterCriteriaUI;

public class DisplayStringBuilder {

	public static String buildCommaDelimitedList(List<String> values) {
		if(values == null) {
			return "";
		}
		
		StringBuilder sb = new StringBuilder(128);
		for(String value : values){
			sb.append(value);
			sb.append(", ");
		}
		// trim off the last 2 chars
		if(sb.length() > 0){
			sb.setLength(sb.length() - 2);
		}
		return sb.toString();
	}
	
	public static String buildFilterCriteriaText(List<FilterCriteriaUI> filterCriteriaValues) {
		StringBuilder sb = new StringBuilder(256);
		for (FilterCriteriaUI filter : filterCriteriaValues) {
			sb.append(filter.getFilterCriteriaTypeValue());
			sb.append(": ");
			sb.append(filter.getFilterValueName());
			sb.append("<br>");
		}

		if (sb.length() > 4) {
			// trunk the last br
			sb.setLength(sb.length() - 4);
		}
		return sb.toString();
	}	
}
