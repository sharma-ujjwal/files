package com.assurant.inc.sox.ar.dto.enums.tasklist;

public enum TaskListField {
	REVIEW_TYPE_DISPLAY("reviewTypeCodeDisplay"), REVIEW_NAME("reviewName"), CREATE_DATE("createDate"), TASK_NAME("name"), ASSIGNED_TO(
	    "assignedTo"), TARGET_DUE_DATE("targetDueDate"), STATUS("status"), TASK_ID("taskId"), ENTITY_NAME("backingEntityName"), ENTITY_ID(
	    "backingEntiyId"), TYPE_CODE_VALUE("typeCodeValue"), IS_CLICKABLE("clickable"), SELECTED("selected"), REVIEWER_NM(
	    "reviewerName"), APP_NAME("applicationName"), WORKORDER_NUMS("workOrderNumbers"), IS_LOCKED("locked"), LOCKED_BY("lockedBy");

	private final String fieldName;

	private TaskListField(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return this.fieldName;
	}
}
