package com.assurant.inc.sox.ar.utils.exceptions;

public class TaskException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String errorMessage = null;
	
    /**
     * A String Copy of the Stack Trace.
     */
    private String faultMessage = null;
	
	public TaskException(String errorMessage){
		this.errorMessage = errorMessage;		
	}    
    
	public TaskException(String errorMessage, Exception e){
		this.errorMessage = errorMessage;
		this.faultMessage = e.getMessage();
		
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFaultMessage() {
		return faultMessage;
	}

	public void setFaultMessage(String faultMessage) {
		this.faultMessage = faultMessage;
	}
	
	@Override
	public String toString(){
		return errorMessage + " - " + faultMessage;
	}
}
