package com.assurant.inc.sox.ar.dto;

import java.util.Date;

import com.assurant.inc.sox.domain.ar.ProcessLock;

public class LockDTO {

	private final ProcessLock lock;

	public LockDTO(ProcessLock lock) {
		this.lock = lock;
		
	}

	public String getHolder() {
		return this.lock.getHolderId();
	}

	public Date getCreated() {
		return this.lock.getLockedDate();
	}

	public boolean isLockedBy(String userId) {
		return this.lock.getHolderId().equalsIgnoreCase(userId);
	}

}
