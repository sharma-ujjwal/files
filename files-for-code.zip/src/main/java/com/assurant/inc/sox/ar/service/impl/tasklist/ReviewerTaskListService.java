package com.assurant.inc.sox.ar.service.impl.tasklist;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.assurant.inc.sox.ar.utils.DateUtil;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.assurant.inc.sox.ar.dto.ReviewBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.tasklist.ReviewerTaskListDTO;
import com.assurant.inc.sox.ar.service.tasklist.IReviewerTaskListService;
import com.assurant.inc.sox.ar.utils.exceptions.TaskException;
import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.ITaskValues;
import com.assurant.inc.sox.consts.TaskTypeCode;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.luad.User;
import com.assurant.inc.sox.dto.TaskDTO;

/**
 * Reviewer Task List service to retrieve the reviewer's task list.
 */
@Service
public class ReviewerTaskListService extends ReviewerTaskListServiceBase implements IReviewerTaskListService {

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewerTaskListService#retrieveTaskListForReviewer()
	 */
	public List<ReviewerTaskListDTO> retrieveTaskListForReviewer() throws TaskException {
		getLogger().debug("retrieveTaskListForReviewer() --> being executed.");

		return retrieveSavvionTasksForReviewer(getSessionSystemUser().getUserId());
		
	}

	/*
	 * @see com.assurant.inc.sox.ar.service.IReviewerTaskListService#retrieveTaskListForAllReviewers()
	 */
	public List<ReviewerTaskListDTO> retrieveTaskListForAllReviewers() throws TaskException {
		getLogger().debug("retrieveTaskListForAllReviewers() --> being executed.");
		
		StopWatch sw = new StopWatch();
		sw.start("get savvion tasks");
		List<TaskDTO> taskDTOs = getWorkflowService().retrieveProcessesByTemplateName(
				DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY)
				.stream()
				.filter(taskDTO -> taskDTO.getTaskCreatedDate().before(DateUtil.getDateDaysAgo(0)))
				.sorted((task1, task2) -> task2.getTaskCreatedDate().compareTo(task1.getTaskCreatedDate())) // Sort by latest date first
				.limit(100)
				.toList();
		sw.stop();
		List<ReviewerTaskListDTO> results = new ArrayList<ReviewerTaskListDTO>();

		
		sw.start("get tasklist");
		for(TaskDTO taskDTO : taskDTOs){
			if(TaskTypeCode.REVIEWER_TASK.equals(taskDTO.getTaskCode())){

				ReviewerTaskListDTO dto = buildReviewerTaskListDTO(taskDTO);
				
				if(dto != null){
					results.add(dto);
				}
			}
		}
		sw.stop();
		getLogger().debug(sw.prettyPrint());
		return results;
	}

	public List<ReviewerTaskListDTO> retrieveTaskListForReviewersTeam() throws TaskException {
		getLogger().debug("retrieveTaskListForReviewersTeam() --> being executed.");
		List<ReviewerTaskListDTO> allReviewersTasklists = new ArrayList<ReviewerTaskListDTO>();
		/*
		 * get the supervisors info
		 */
		Supervisor supervisor = getSupervisorDao().findByKeyId(getSessionSystemUser().getUserId());

		/*
		 * null check
		 */
		if(supervisor != null){
			/*
			 * get all the supervisors subordinates
			 */
			List<User> superviorsUsers = getUserDao().findUsersForSupervisor(supervisor.getUserId());
	
			List<Supervisor> subordinates = new ArrayList<Supervisor>();
			/*
			 * for each subor
			 */
			for(User user : superviorsUsers){
				Supervisor subordinate = getSupervisorDao().findByKeyId(user.getPk().getKeyId());
				if(subordinate != null && subordinate.getKeyId() != null){
					subordinates.add(subordinate);
				}
			}
			
			for(Supervisor subordinateManager : subordinates){
				List<ReviewerTaskListDTO> reviewerTaskListDTO = retrieveSavvionTasksForReviewer(subordinateManager.getKeyId());
				allReviewersTasklists.addAll(reviewerTaskListDTO);
			}
		}
		return allReviewersTasklists;
	}

	/**
	 * Method to build the reviewTaskListDTO, will look up the reviewer and review info to put into the dto
	 * 
	 * @param savvionDTO
	 * @return ReviewerTaskListDTO
	 */
	private ReviewerTaskListDTO buildReviewerTaskListDTO(TaskDTO taskDTO) {
		getLogger().debug("buildReviewerTaskListDTO(SavvionDTO) --> being executed.");
		/*
		 * Get savvion data slot for process
		 */
		Map<String, Object> dataSlots = taskDTO.getDataSlots();
		ReviewerTaskListDTO taskList = null;

		if(dataSlots != null){
			/*
			 * get reviewer id
			 */
			String reviewerIdString = ((String) dataSlots.get(ITaskValues.DATASLOTS_REVIEWER_ID));
			/*
			 * get reviewerDTO
			 */
	
			
			//ReviewerDTO reviewerDTO = getReviewerService().retrieveById(new Long(reviewerIdString));
			ReviewerDTO reviewerDTO = getReviewerService().retrieveByIdWithSlim(Long.parseLong(reviewerIdString));
			
			if(reviewerDTO == null){
				return null;
			}
			/*
			 * get review bundle
			 */
			ReviewBundleDTO reviewBundleDTO = getReviewBundleService().retrieveById(reviewerDTO.getReviewBundleId());
			/*
			 * get review
			 */
			ReviewDTO reviewDTO = getReviewService().retrieveReviewById(reviewBundleDTO.getReviewId());
			/*
			 * build tasklist dto
			 */
			taskList = new ReviewerTaskListDTO(reviewDTO, reviewerDTO);
			taskList.setAssignedTo(reviewerDTO.getReviewerName());
			taskList.setName(taskDTO.getTaskDescription());
			if("Verify Access".equalsIgnoreCase(taskList.getName())){
				taskList.setTaskStatus(taskList.getStatus());
			}else{
				taskList.setTaskStatus(reviewBundleDTO.getStatus().getDisplay());
			}
			taskList.setCreateDate(taskDTO.getTaskCreatedDate());
			taskList.setTaskId(taskDTO.getProcessId());
			taskList.setTypeCode(taskDTO.getTaskCode());

		}
		else{
			getLogger().error("Task Data Slots null " + taskDTO.getProcessId());
		}

		return taskList;
	}

	private List<ReviewerTaskListDTO> retrieveSavvionTasksForReviewer(String id) {
		getLogger().debug("retrieveSavvionTasksForReviewer(id) --> being executed.");
		/*
		 * get all Task tasks for user
		 */
		List<TaskDTO> taskDTOs = new ArrayList<TaskDTO>();
		try{
			taskDTOs = getWorkflowService().retrieveProcessesByAssignedTo(id);
		}catch(TaskException se){
			getLogger().error("Savvion Exception for id: " +id+ " error: " + se, se);
		}

		List<ReviewerTaskListDTO> results = new ArrayList<ReviewerTaskListDTO>();

		/*
		 * if the task is a reviewer task then build a dto for it and put it in the list
		 */
		int count = 0;
		for(TaskDTO tasknDTO : taskDTOs){
			if (count < 40) {
				if (tasknDTO.getTaskCode().equals(TaskTypeCode.REVIEWER_TASK)) {
					ReviewerTaskListDTO dto = buildReviewerTaskListDTO(tasknDTO);
					if (dto != null) {
						results.add(dto);
					}
				}
				count++;
			} else {
				break;
			}
		}

		return results.stream()
				.limit(50)
				.toList();
	}
}
