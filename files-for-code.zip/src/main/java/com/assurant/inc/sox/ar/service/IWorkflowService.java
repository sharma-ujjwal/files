package com.assurant.inc.sox.ar.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.assurant.inc.sox.consts.DataSlotsTemplateCode;
import com.assurant.inc.sox.consts.WorkflowTemplateCode;
import com.assurant.inc.sox.dto.TaskDTO;

/**
 * Service for working with workflow.
 */
public interface IWorkflowService {
    /**
     * Creates and submits a new workflow process.
     * 
     * @param processTemplate the workflow process template value.
     * @param processInstanceNamePrefix the process name prefix to add to the task.
     * @param priority the priority of the process.
     * @param assignedTo who to assign the process to.
     * @param list of the workSteps that are associated with the workflow, so all
     * 		  worksteps will be assigned to that user
     * @param Map of the dataslots to be inital set with the creation of the process
     * @return the id of the workflow process that was created.
     */
    public String createProcess(WorkflowTemplateCode processCode, DataSlotsTemplateCode dataSlotsTemplateCode,String processInstanceNamePrefix,
            String priority, String assignedTo, HashMap<String, Object> dataSlots);

    /**
     * Updates the data slots for the workflow process for the given process id.
     * 
     * @param processId the id of the workflow process to update.
     * @param dataSlots the data slots vlaues to update.
     */
    public void updateProcessDataSlots(String processId, Map<String, Object> dataSlots);

    /**
     * Retrieves all of the workflow processes that are assigned to the provided user.
     * 
     * @param userId the id of the user to retrieved the processes for.
     * @return the workflow process for the provided user. If no process are found then an empty list
     *         will be returned.
     */
    public List<TaskDTO> retrieveProcessesByAssignedTo(String userId);

    /**
     * Retrieves all of the workflow process for the given process template name.
     * 
     * @param processTemplateName the process template name to retrieve processes for.
     * @return the workflow process for the provided process template name. If no process are found
     *         then an empty list will be returned.
     */
    public List<TaskDTO> retrieveProcessesByTemplateName(DataSlotsTemplateCode dataSlotsTemplateCode);

    /**
     * Completes the workflow process with the provided id.
     * @param processId the id of the process to complete.
     */
    public void completeProcess(String processId, Map<String, Object> variables);
    
    /**
     * Creates and submits a new list of workflow process. This is added to speed up the creation
     * of multiple tasks.  This will only call connect() and disconnect once per call as apposed
     * to createProcess which calls connect/disconnect for each task created
     * 
     * @param processTemplate the workflow process template value.
     * @param processInstanceNamePrefix the process name prefix to add to the task.
     * @param priority the priority of the process.
     * @param list of the workSteps that are associated with the workflow, so all
     * 		  worksteps will be assigned to that user
     * @param Map of the workflow reviewers to be inital set with the creation of the process
     * @return the id of the workflow process that was created.
     */
    public void createBulkProcess(WorkflowTemplateCode processCode,String processInstanceNamePrefix,
            String priority, List<HashMap<String, Object>> reviewers);    
    
    
    /**
     * Get task id by workflow id.
     * @param workflowId
     * @return
     */
    public String getTaskId(String workflowId);
}
