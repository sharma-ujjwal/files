package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;

public class SystemUserUI {

	private final SystemUserDTO systemUserDTO;

	public SystemUserUI(SystemUserDTO systemUserDTO) {
		this.systemUserDTO = systemUserDTO;
	}

	public String getFirstName() {
		return systemUserDTO.getFirstName();
	}

	public String getLastName() {
		return systemUserDTO.getLastName();
	}

	public String getUserId() {
		return systemUserDTO.getUserId();
	}

	public boolean isViewDashBoard() {
		return systemUserDTO.isViewDashBoard();
	}

	public boolean isPerformReviewActions() {
		return systemUserDTO.isPerformReviewActions();
	}

	public boolean isPerformAdminActions() {
		return systemUserDTO.isPerformAdminActions();
	}
	
	public String getName() {
		return systemUserDTO.getName();
	}

	public boolean isItComplianceUser() {
		return systemUserDTO.isItComplianceUser();
	}

	public boolean isReviewer() {
	    return systemUserDTO.isReviewer();
    }
	
	public boolean isIpsUser() {
		if (systemUserDTO != null) {
			return this.systemUserDTO.isIpsUser();
		} else {
			return false;
		}

	}
}
