package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.domain.ar.UserStatus;

public interface IUserStatusService {
	public void add(String userStatusName); 	
	public void delete(UserStatus userStatus);	

	public UserStatus findDuplicate(String name); 
	public List<UserStatus> retrieveAllUserStatuss(); 
	public List<UserStatus> retrieveAllUserStatusByCode(String CodeSelect); 
	public List<UserStatus> retrieveDeletedUserStatuss() ; 
	public List<UserStatus> retrieveDeletedUserStatussByName(String userStatusNameSearchText) ;
	public List<UserStatus> retrieveUnassignedUserStatuss() ; 
	public List<UserStatus> retrieveUnassignedUserStatussByName(String userStatusNameSearchText);
	public boolean canUserStatusBeDeleted(Long id); 

	
}
