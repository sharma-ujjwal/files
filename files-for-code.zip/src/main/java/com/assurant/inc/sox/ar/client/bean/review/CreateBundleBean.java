package com.assurant.inc.sox.ar.client.bean.review;

import static com.assurant.inc.sox.ar.client.bean.util.JSFUtils.addFacesErrorMessage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.bean.SessionDataBean;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.FilterCriteriaUI;
import com.assurant.inc.sox.ar.client.ui.ReviewUI;
import com.assurant.inc.sox.ar.comparators.GenericComparator;
import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;
import com.assurant.inc.sox.ar.dto.EnvironmentDTO;
import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;
import com.assurant.inc.sox.ar.dto.ReviewDTO;
import com.assurant.inc.sox.ar.dto.SoxConcernDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.UserTypeDTO;
import com.assurant.inc.sox.ar.dto.enums.FilterCriteriaType;
import com.assurant.inc.sox.ar.dto.enums.ReviewStatusCode;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.service.IMetaDataService;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * The backing bean for the create bundle page (criteria page).
 */
@Component("createBundleBean")
@Scope("session")
public class CreateBundleBean {
    private static final String DEFAULT_SOXCONCERN = "Y";
    private static final String DEFAULT_ENVIRONMENT = "PRODUCTION";
    private static final String DEFAULT_USERSTATUS = "ACTIVE";

    private static final Logger logger = LoggerFactory.getLogger(CreateBundleBean.class);

    private static int COMMA_LIST_SIZE = 3;
    private static String NONE_KEY = "NONE";
    private static String NONE_TEXT = "(select one)";

    @Autowired
    @Qualifier("metaDataService")
    private IMetaDataService metaDataService;
    @Autowired
    @Qualifier("reviewBundleService")
    private IReviewBundleService reviewBundleService;
    @Autowired
    @Qualifier("reviewService")
    private IReviewService reviewService;
    @Autowired
    @Qualifier("sessionDataBean")
    private SessionDataBean sessionDataBean;
    private ReviewUI reviewUI;
    private String selectedConflictType = NONE_KEY;

    private List<FilterCriteriaSelectAdapter> managers = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> applications = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> individuals = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> systems = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> departments = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> privDescriptions = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> privValues = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> costCenters = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> divisions = new ArrayList<FilterCriteriaSelectAdapter>();
    private List<FilterCriteriaSelectAdapter> conflicts = new ArrayList<FilterCriteriaSelectAdapter>();
    
    private List<List<FilterCriteriaSelectAdapter>> allCriteriaLists = new ArrayList<List<FilterCriteriaSelectAdapter>>();

    private List<String> userTypes = new ArrayList<String>();
    private List<String> soxConcernValues = new ArrayList<String>();
    private List<String> userStatuses = new ArrayList<String>();
    private List<String> environments = new ArrayList<String>();

    private List<SelectItem> availableUserTypes;
    private List<SelectItem> availableSoxConcernValues;
    private List<SelectItem> availableUserStatuses;
    private List<SelectItem> availableEnvironments;
    private List<SelectItem> availableReviews;
    private List<SelectItem> availableConflictTypes;

    public CreateBundleBean() {
        super();
        allCriteriaLists.add(managers);
        allCriteriaLists.add(applications);
        allCriteriaLists.add(individuals);
        allCriteriaLists.add(systems);
        allCriteriaLists.add(departments);
        allCriteriaLists.add(privDescriptions);
        allCriteriaLists.add(privValues);
        allCriteriaLists.add(costCenters);
        allCriteriaLists.add(divisions);
        allCriteriaLists.add(conflicts);
    }

    /**
     * Create a comma delimited String listing the elements of the given List. If there are more items than the
     * COMMA_LIST_SIZE, those items are not included in the String, but the string will end in an ellipsis (...)
     * 
     * @param aList the List to separate into commas
     * @return a commaized String
     */
    private final String commaize(List<? extends SelectAdapter> aList) {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        String comma = "";
        Iterator<? extends SelectAdapter> i = aList.iterator();
        while (i.hasNext() && count++ < COMMA_LIST_SIZE) {
            SelectAdapter ad =  i.next();
            sb.append(comma).append(ad.getDisplayString());
            comma = ", ";
        }
        if (aList.size() > COMMA_LIST_SIZE) {
            sb.append(", ...");
        }
        return sb.toString();
    }

    public String doClear() {
        logger.debug("doClear() --> being executed.");
        resetVariables();
        return null;
    }

    public void conflictTypeChanged() {
    	conflicts.clear();
    	return;
    }
    
    public boolean getShowAddConflictButton() {
    	final String str = getSelectedConflictType();
    	return (str != null) && !NONE_KEY.equals(getSelectedConflictType());
    }
    
    public String doContinue() {
        logger.debug("doContinue() --> being executed.");
        

    	if (sessionDataBean.getSystemUser().isPerformReviewActions()) {
    		

            // Clear fields that don't apply to type
            clearBasedOnReviewType();
    		
            // Error checks
            if (getReviewUI() == null) {
                addFacesErrorMessage("Must select a review");
                return null;
            }
            if (isSegregationOfDuties() && conflicts.size() < 1) {
            	addFacesErrorMessage("Must select at least one conflict for Segregation of Duties Review");
                return null;
            }
            if (getEnvironments().size() < 1) {
            	addFacesErrorMessage("Must select at least one Environment");
                return null;
            }
            if (getUserStatuses().size() < 1) {
            	addFacesErrorMessage("Must select at least one User Status");
                return null;
            }
            if (getSoxConcernValues().size() < 1) {
            	addFacesErrorMessage("Must select at least one Sox Concern");
                return null;
            }
            
            // Add criteria from the modal panels
            List<FilterCriteriaDTO> criteriaList = new ArrayList<FilterCriteriaDTO>();
            for (List<FilterCriteriaSelectAdapter> currentList : allCriteriaLists) {
                for (FilterCriteriaSelectAdapter ad : currentList) {
                    criteriaList.add((FilterCriteriaDTO) ad.getObject());
                }
            }

            // Add criteria from the drop downs
            for (String value : soxConcernValues) {
                criteriaList.add(makeCriteria(FilterCriteriaType.SOX_CONCERN, value, availableSoxConcernValues));
            }
            for (String value : environments) {
                criteriaList.add(makeCriteria(FilterCriteriaType.ENVIRONMENT, value, availableEnvironments));
            }
            for (String value : userTypes) {
                criteriaList.add(makeCriteria(FilterCriteriaType.USER_TYPE, value, availableUserTypes));
            }
            for (String value : userStatuses) {
                criteriaList.add(makeCriteria(FilterCriteriaType.USER_STATUS, value, availableUserStatuses));
            }

            // Create Bundle and save
            reviewBundleService.createReviewBundle(getReviewUI().getReviewId(), criteriaList);

            this.sessionDataBean.initSelectedTasklistBean();
    		
            return "taskList";

        } 
        
    	JSFUtils.addFacesErrorMessage("No permissions to perform current action.");
        return "";
    }

    /**
     * Finds label of SelectItem in given list with the value given in the key.
     * 
     * @param selectItems the List to search
     * @param key the key(value) to find in the List
     * @return the found label, or the key if not found
     */
    private String findLabelByValue(List<SelectItem> selectItems, String key) {
        for (SelectItem aSelectItem : selectItems) {
            if (aSelectItem.getValue().equals(key)) {
                return aSelectItem.getLabel();
            }
        }
        return key;
    }
    
    public String getSelectedConflictType() {
    	return this.selectedConflictType;
    }
    
    public List<FilterCriteriaSelectAdapter> getApplications() {
        return applications;
    }

    public List<FilterCriteriaSelectAdapter> getConflicts() {
        return conflicts;
    }
    
    public List<SelectItem> getAvailableConflictTypes() {
		if (availableConflictTypes == null) {
			availableConflictTypes = new ArrayList<SelectItem>();
			availableConflictTypes.add(new SelectItem(NONE_KEY, NONE_TEXT));
			List<ConflictTypeDTO> conflictList = metaDataService.retrieveConflictTypes();

			/*
			 * sort the dto so when we build the UI object is shows up in the
			 * same order each time
			 */
			doSort("name", conflictList);

			for (ConflictTypeDTO dto : conflictList) {
				availableConflictTypes.add(new SelectItem(String.valueOf(dto.getId()), String.valueOf(dto.getName())));
			}
		}
		return availableConflictTypes;
	}
    
    public List<SelectItem> getAvailableEnvironments() {
        logger.debug("getAvailableEnvironments() --> being executed.");
        if (availableEnvironments == null) {
            availableEnvironments = new ArrayList<SelectItem>();
            List<EnvironmentDTO> envList = metaDataService.retrieveEnvironments();
            
            /*
             * sort the dto so when we build the UI object is shows
             * up in the same order each time
             */
            doSort("name", envList);            
            
            for (EnvironmentDTO env : envList) {
                // key is same as name
                availableEnvironments.add(new SelectItem(String.valueOf(env.getName()), env.getName()));
            }
        }
        return availableEnvironments;
    }

    @SuppressWarnings("unchecked")
    public List getAvailableReviews() {
        logger.debug("getAvailableReviews() --> being executed.");
        if (availableReviews == null) {
            availableReviews = new ArrayList<SelectItem>();
            availableReviews.add(new SelectItem(NONE_KEY, NONE_TEXT));
            List<ReviewDTO> reviewList = reviewService.retrieveReviewsByStatus(ReviewStatusCode.OUTSTANDING);
            /*
             * sort the dto so when we build the UI object is shows
             * up in the same order each time
             */
            doSort("reviewName", reviewList);
            
            for (ReviewDTO aReview : reviewList) {
                availableReviews.add(new SelectItem(String.valueOf(aReview.getReviewId()), aReview.getReviewName()));
            }
        }
        return availableReviews;
    }

    public List<SelectItem> getAvailableSoxConcernValues() {
        logger.debug("getAvailableSoxConcernValues() --> being executed.");
        if (availableSoxConcernValues == null) {
            availableSoxConcernValues = new ArrayList<SelectItem>();
            List<SoxConcernDTO> soxConcernList = metaDataService.retrieveSoxConcerns();
            /*
             * sort the dto so when we build the UI object is shows
             * up in the same order each time
             */
            doSort("soxConcernCode", soxConcernList);
            
            for (SoxConcernDTO concern : soxConcernList) {
                availableSoxConcernValues.add(new SelectItem(concern.getSoxConcernCode(), concern.getSoxConcernCode()));
            }
        }
        return availableSoxConcernValues;
    }

    public List<SelectItem> getAvailableUserStatuses() {
        logger.debug("getAvailableUserStatuses() --> being executed.");
        if (availableUserStatuses == null) {
            availableUserStatuses = new ArrayList<SelectItem>();
            List<UserStatusDTO> userStatusList = metaDataService.retrieveUserStatuses();
            
            /*
             * sort the dto so when we build the UI object is shows
             * up in the same order each time
             */
            doSort("userStatusDescription", userStatusList);
            
            for (UserStatusDTO aUserStatus : userStatusList) {
                availableUserStatuses.add(new SelectItem(String.valueOf(aUserStatus.getUserStatusId()), aUserStatus
                    .getUserStatusDescription()));
            }
        }
        return availableUserStatuses;
    }

    public List<SelectItem> getAvailableUserTypes() {
        logger.debug("getAvailableUserTypes() --> being executed.");
        if (availableUserTypes == null) {
            availableUserTypes = new ArrayList<SelectItem>();
            List<UserTypeDTO> userTypeList = metaDataService.retrieveUserTypes();
            
            /*
             * sort the dto so when we build the UI object is shows
             * up in the same order each time
             */
            doSort("userTypeDescription", userTypeList);            
            
            for (UserTypeDTO aUserType : userTypeList) {
                availableUserTypes.add(new SelectItem(String.valueOf(aUserType.getUserTypeId()), aUserType
                    .getUserTypeDescription()));
            }
        }
        return availableUserTypes;
    }

    public List<FilterCriteriaSelectAdapter> getCostCenters() {
        return costCenters;
    }

    public List<FilterCriteriaSelectAdapter> getDepartments() {
        return departments;
    }

    public List<FilterCriteriaSelectAdapter> getDivisions() {
        return divisions;
    }

    public String getDisplayConflicts() {
    	return commaize(conflicts);
    }
    
    public String getDisplayApplications() {
        return commaize(applications);
    }

    public String getDisplayCostCenters() {
        return commaize(costCenters);
    }

    public String getDisplayDepartments() {
        return commaize(departments);
    }
    
    public String getDisplayDivisions() {
        return commaize(divisions);
    }

    public String getDisplayIndividuals() {
        return commaize(individuals);
    }

    public String getDisplayManagers() {
        return commaize(managers);
    }

    public String getDisplayPrivDescriptions() {
        return commaize(privDescriptions);
    }

    public String getDisplayPrivValues() {
        return commaize(privValues);
    }

    public String getDisplaySystems() {
        return commaize(systems);
    }

    public List<String> getEnvironments() {
        return environments;
    }

    public List<FilterCriteriaSelectAdapter> getIndividuals() {
        return individuals;
    }

    public List<FilterCriteriaSelectAdapter> getManagers() {
        return managers;
    }

    public IMetaDataService getMetaDataService() {
        return metaDataService;
    }

    public List<FilterCriteriaSelectAdapter> getPrivDescriptions() {
        return privDescriptions;
    }

    public List<FilterCriteriaSelectAdapter> getPrivValues() {
        return privValues;
    }

    public ReviewUI getReviewUI() {
        return reviewUI;
    }

    public IReviewBundleService getReviewBundleService() {
        return reviewBundleService;
    }

    public IReviewService getReviewService() {
        return reviewService;
    }

    public String getSelectedReview() {
        return (getReviewUI() == null) ? NONE_KEY : String.valueOf(getReviewUI().getReviewId());
    }

    public List<String> getSoxConcernValues() {
        return soxConcernValues;
    }

    public List<FilterCriteriaSelectAdapter> getSystems() {
        return systems;
    }

    public List<String> getUserStatuses() {
        return userStatuses;
    }

    public List<String> getUserTypes() {
        return userTypes;
    }

    public boolean isSegregationOfDuties() {
        if (getReviewUI() == null) {
            return false;
        }
        return getReviewUI().getReview().getReviewTypeCd().getValue().equals(ReviewTypeCode.SEGREGATION_OF_DUTIES.getCode());
    }

    /**
     * @param type The FilterCriteriaType to make
     * @param value the value of the criteria, generally the id
     * @param items the list of SelectItems from which to find the display value
     * @return the created FilterCriteriaDTO
     */
    private FilterCriteriaDTO makeCriteria(FilterCriteriaType type, String value, List<SelectItem> items) {
        FilterCriteriaDTO criteria = new FilterCriteriaDTO();
        criteria.setFilterCriteriaType(type);
        criteria.setFilterValueKey(value);
        criteria.setFilterValueName(findLabelByValue(items, value));
        return criteria;
    }

    /**
     * Break up the given criteria into lists to edit in the user interface
     * 
     * @param criteriaList null, or list or criteria
     * @param reviewUI null, or reviewUI to preselect
     */
    public void receive(List<FilterCriteriaUI> criteriaList, ReviewUI selectedReview) {
        clearVariables();
        if (criteriaList != null) {
        	for (FilterCriteriaUI criteriaUI : criteriaList) {
        		populateOneCriteria(criteriaUI.getFilterCriteriaDTO());
        	}
        } else {
        	selectDefaults();
        }
        setReviewUI(selectedReview);
    }

    /**
     * @param criteriaDTO
     */
    private void populateOneCriteria(FilterCriteriaDTO criteriaDTO) {
        switch (criteriaDTO.getFilterCriteriaType()) {
        case MANAGER:
            managers.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case APPLICATIONS:
            applications.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case USERS:
            individuals.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case SOURCE_SYSTEM:
            systems.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case DEPARTMENT:
            departments.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case PRIV_DESCRIPTION:
            privDescriptions.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case PRIV_VALUE:
            privValues.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case COST_CENTER:
            costCenters.add(new FilterCriteriaSelectAdapter(criteriaDTO));
            break;
        case ENVIRONMENT:
            environments.add(criteriaDTO.getFilterValueKey());
            break;
        case SOX_CONCERN:
            soxConcernValues.add(criteriaDTO.getFilterValueKey());
            break;
        case USER_STATUS:
            userStatuses.add(criteriaDTO.getFilterValueKey());
            break;
        case USER_TYPE:
            userTypes.add(criteriaDTO.getFilterValueKey());
            break;
        }
    }

    /**
     * This is called when review changes, or during submit to ensure filter criteria not
     * valid for the review type is empty.
     */
    private void clearBasedOnReviewType() {
        if (isSegregationOfDuties()) {
            applications.clear();
            divisions.clear();
        } else {
            conflicts.clear();
        }
    }
    
    public void clearVariables() {
        managers.clear();
        applications.clear();
        individuals.clear();
        systems.clear();
        departments.clear();
        privDescriptions.clear();
        privValues.clear();
        costCenters.clear();
        divisions.clear();
        conflicts.clear();

        userTypes.clear();
        soxConcernValues.clear();
        userStatuses.clear();
        environments.clear();

        setReviewUI(null);
        setSelectedConflictType(null);
        
        availableUserTypes = null;
        availableSoxConcernValues = null;
        availableEnvironments = null;
        availableReviews = null;
        availableConflictTypes = null;
    }
    
    public void resetVariables() {
        clearVariables();
        selectDefaults();
    }

    private void selectDefaults() {
        for (SelectItem item : getAvailableEnvironments()) {
            if (item.getValue().equals(DEFAULT_ENVIRONMENT)) {
                environments.add((String) item.getValue());
                break;
            }
        }
        for (SelectItem item : getAvailableSoxConcernValues()) {
            if (item.getValue().equals(DEFAULT_SOXCONCERN)) {
                soxConcernValues.add((String) item.getValue());
                break;
            }
        }
        for (SelectItem item : getAvailableUserStatuses()) {
            if (item.getLabel().equals(DEFAULT_USERSTATUS)) {
                userStatuses.add((String) item.getValue());
                break;
            }
        }
    }

    public void setApplications(List<FilterCriteriaSelectAdapter> applications) {
        this.applications = applications;
    }
    
    public void setConflicts(List<FilterCriteriaSelectAdapter> conflicts) {
        this.conflicts = conflicts;
    }

    public void setCostCenters(List<FilterCriteriaSelectAdapter> costCenters) {
        this.costCenters = costCenters;
    }

    public void setDepartments(List<FilterCriteriaSelectAdapter> departments) {
        this.departments = departments;
    }

    public void setDivisions(List<FilterCriteriaSelectAdapter> divisions) {
        this.divisions = divisions;
    }
    
    public void setEnvironments(List<String> selectedEnvironments) {
        this.environments = selectedEnvironments;
    }

    public void setIndividuals(List<FilterCriteriaSelectAdapter> individuals) {
        this.individuals = individuals;
    }

    public void setManagers(List<FilterCriteriaSelectAdapter> managers) {
        this.managers = managers;
    }

    public void setMetaDataService(IMetaDataService metaDataService) {
        this.metaDataService = metaDataService;
        // init when we get the service. would prefer to use postconstruct
        // annotation but it isn't work with jsf managed beans.
        selectDefaults();
    }

    public void setPrivDescriptions(List<FilterCriteriaSelectAdapter> privDescriptions) {
        this.privDescriptions = privDescriptions;
    }

    public void setPrivValues(List<FilterCriteriaSelectAdapter> privValues) {
        this.privValues = privValues;
    }

    public void setReviewUI(ReviewUI aReviewUI) {
        reviewUI = aReviewUI;
    }

    public void setReviewBundleService(IReviewBundleService reviewBundleService) {
        this.reviewBundleService = reviewBundleService;
    }

    public void setReviewService(IReviewService reviewService) {
        this.reviewService = reviewService;
    }
    
    public void setSelectedConflictType(String selectedConflictType) {
        this.selectedConflictType = selectedConflictType;
    }
    
    public void setSelectedReview(String selectedReview) {
        if (!selectedReview.equals(NONE_KEY)) {
            setReviewUI(new ReviewUI(reviewService.retrieveReviewById(Long.parseLong(selectedReview))));
        } else {
            setReviewUI(null);
        }
        clearBasedOnReviewType();
    }

    public void setSoxConcernValues(List<String> selectedSoxConcernValues) {
        this.soxConcernValues = selectedSoxConcernValues;
    }

    public void setSystems(List<FilterCriteriaSelectAdapter> systems) {
        this.systems = systems;
    }

    public void setUserStatuses(List<String> selectedUserStatuses) {
        this.userStatuses = selectedUserStatuses;
    }

    public void setUserTypes(List<String> selectedUserTypes) {
        this.userTypes = selectedUserTypes;
    }

    public SessionDataBean getSessionDataBean() {
        return sessionDataBean;
    }

    public void setSessionDataBean(SessionDataBean sessionDataBean) {
        this.sessionDataBean = sessionDataBean;
    }
    
    /**
     * Sort list by field name
     */
    @SuppressWarnings("unchecked")
    private void doSort(String fieldName, List sortList) {
    	Collections.sort(sortList, new GenericComparator(fieldName));
    }    
}
