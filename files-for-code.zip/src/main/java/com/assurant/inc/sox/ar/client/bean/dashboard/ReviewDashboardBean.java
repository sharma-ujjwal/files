package com.assurant.inc.sox.ar.client.bean.dashboard;

import com.assurant.inc.sox.ar.client.bean.util.CommonPageActionHelper;
import com.assurant.inc.sox.ar.client.bean.util.JSFUtils;
import com.assurant.inc.sox.ar.client.ui.RejectSodBundleUI;
import com.assurant.inc.sox.ar.client.ui.ReviewDashboardUI;
import com.assurant.inc.sox.ar.client.ui.ReviewerUI;
import com.assurant.inc.sox.ar.dto.RejectSodBundleDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;
import com.assurant.inc.sox.ar.dto.enums.ReviewTypeCode;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.utils.NavigationUtility;
import com.assurant.inc.sox.ar.utils.NavigationUtility;
import org.primefaces.component.datatable.DataTable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;


@Component("reviewDashboardBean")
@Scope("session")
public class ReviewDashboardBean {

    private static final Logger logger = LoggerFactory.getLogger(ReviewDashboardBean.class);

    @Autowired
    @Qualifier("reviewerService")
    private IReviewerService reviewerService;
    @Autowired
    @Qualifier("reviewBundleService")
    private IReviewBundleService reviewBundleService;
    private String oldSortColumn = "";
    private List<ReviewerUI> reviewers;
    private ReviewDashboardUI reviewDashboard;
    private String displayAmount = "10";
    private DataTable reviewersTable;
    private List<RejectSodBundleUI> rejectedSODBundles;

    public ReviewDashboardBean() {
        super();
    }

    public void initReview(ReviewDashboardUI reviewDashboardUI) {
        logger.debug("initReview(ReviewDashboardUI) --> being executed.");
        this.reviewDashboard = reviewDashboardUI;
        this.rejectedSODBundles = null;
        final Long reviewId = reviewDashboardUI.getReviewDashboardDTO().getReviewId();
        List<ReviewerDTO> dtos = reviewerService.retrieveByReviewIdForDashboard(reviewId);
        List<RejectSodBundleDTO> rejectSodBundleDTOs = null;

        if (isSegregationsOfDuties()) {

            rejectSodBundleDTOs = reviewBundleService.retrieveRejectedWithNoConflictsByReviewId(reviewId);

            List<RejectSodBundleUI> rejectedBundles = new ArrayList<RejectSodBundleUI>(rejectSodBundleDTOs.size());

            for (RejectSodBundleDTO rejectSodBundleDTO : rejectSodBundleDTOs) {
                rejectedBundles.add(new RejectSodBundleUI(rejectSodBundleDTO));
            }

            this.rejectedSODBundles = rejectedBundles;
        }

        List<ReviewerUI> uis = new ArrayList<ReviewerUI>(dtos.size());
        for (ReviewerDTO dto : dtos) {
            reviewerService.populateReviewerNumberOfDepts(dto);
            if (isSegregationsOfDuties()) {
                reviewerService.populateReviewerSODValues(dto);
            }
            uis.add(new ReviewerUI(dto));
        }
        CommonPageActionHelper.sortListByField(uis, "currentReviewerName", "");
        this.oldSortColumn = "currentReviewerName";
        this.reviewers = uis;
    }

    public void doSelectReviewer(ActionEvent event) {
        logger.debug("doSelectReviewer() --> being executed.");

        // Get the DataTable component from the event
        UIComponent component = event.getComponent();
        setReviewersTable((DataTable) component.findComponent("reviewersTable"));

        ReviewerUI ui = (ReviewerUI) reviewersTable.getRowData();
        ReviewUserDashboardBean bean = (ReviewUserDashboardBean) JSFUtils.lookupBean("reviewUserDashboardBean");
        bean.initReviewers(ui, reviewDashboard);

        var navigationHandler = NavigationUtility.getNavigationHandlerInstance();
        navigationHandler.handleNavigation(NavigationUtility.getFacesContextInstance(), null, "selectReviewer");
    }

    public void doSort() {
        logger.debug("doSort() --> being executed.");
        final String column = JSFUtils.getParameter("column");
        CommonPageActionHelper.sortListByField(reviewers, column, oldSortColumn);
        oldSortColumn = column;
    }

    public String doReturnToReviewMgmtDashboard() {
        this.rejectedSODBundles = null;
        return "reviewMgmtDashboard";
    }

    public String getDisplayAmount() {
        return displayAmount;
    }

    public void setDisplayAmount(String displayAmount) {
        this.displayAmount = displayAmount;
    }

    public ReviewDashboardUI getReviewDashboard() {
        return reviewDashboard;
    }

    public void setReviewDashboard(ReviewDashboardUI reviewDashboard) {
        this.reviewDashboard = reviewDashboard;
    }

    public List<ReviewerUI> getReviewers() {
        return reviewers;
    }

    public void setReviewers(List<ReviewerUI> reviewers) {
        this.reviewers = reviewers;
    }

    public DataTable getReviewersTable() {
        return reviewersTable;
    }

    public void setReviewersTable(DataTable reviewersTable) {
        this.reviewersTable = reviewersTable;
    }

    public IReviewerService getReviewerService() {
        return reviewerService;
    }

    public void setReviewerService(IReviewerService reviewerService) {
        this.reviewerService = reviewerService;
    }

    public boolean getShowDivisionColumn() {
        return isManager();
    }

    public boolean getShowDepartmentColumn() {
        return isManager();
    }

    public boolean getShowApplicationColumn() {
        return isDataOwner() || isPrivilegedAccess();
    }

    public boolean getShowNumberOfDepartmentsColumn() {
        return isDataOwner() || isPrivilegedAccess() || isSegregationsOfDuties();
    }

    public boolean getShowSodConflictTypeColumn() {
        return isSegregationsOfDuties();
    }

    private boolean isManager() {
        return ReviewTypeCode.MANAGER.getCode().equals(this.reviewDashboard.getReview().getReviewTypeCd().getValue());
    }

    private boolean isDataOwner() {
        return ReviewTypeCode.DATA_OWNER.getCode().equals(this.reviewDashboard.getReview().getReviewTypeCd().getValue());
    }

    private boolean isPrivilegedAccess() {
        return ReviewTypeCode.PRIVILEGED_ACCESS.getCode().equals(this.reviewDashboard.getReview().getReviewTypeCd().getValue());
    }

    private boolean isSegregationsOfDuties() {
        return ReviewTypeCode.SEGREGATION_OF_DUTIES.getCode().equals(this.reviewDashboard.getReview().getReviewTypeCd().getValue());
    }

    public IReviewBundleService getReviewBundleService() {
        return reviewBundleService;
    }

    public void setReviewBundleService(IReviewBundleService reviewBundleService) {
        this.reviewBundleService = reviewBundleService;
    }

    public List<RejectSodBundleUI> getRejectedSODBundles() {
        return rejectedSODBundles;
    }

    public void setRejectedSODBundles(List<RejectSodBundleUI> rejectedSODBundles) {
        this.rejectedSODBundles = rejectedSODBundles;
    }

    public boolean isRenderRejectedSODBundles() {
        return ((rejectedSODBundles == null ? false : !rejectedSODBundles.isEmpty()) && isSegregationsOfDuties());
    }
}
