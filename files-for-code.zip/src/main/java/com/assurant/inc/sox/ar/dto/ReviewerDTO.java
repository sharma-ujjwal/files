package com.assurant.inc.sox.ar.dto;

import java.util.Calendar;
import java.util.Date;

import com.assurant.inc.sox.ar.dto.enums.reviewer.ReviewerStatusCode;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Reviewer;
import com.assurant.inc.sox.domain.ar.UserStatus;

public class ReviewerDTO {

	public static final String OVERDUE = "1";
	public static final String DAYS_DUE = "3";
	public static final String WEEK_DUE = "7";
	public static final String NO_WARNING = "";

	private final Reviewer reviewer;
	private final CodeDTO rejectReasonCode;
	private final CodeDTO statusCode;
	private final String bundleName;
	private ConflictDTO conflict;
	private String ownerName;
	

	// additional fields
	private int numberOfDepartments;
	private String distinctEnvName;
	private String escalationMgrName;
	private boolean hasAccessToApplication;

	public ReviewerDTO(Reviewer reviewer, CodeDTO rejectCode, CodeDTO statusCode, String bundleName) {
		this.reviewer = reviewer;
		this.rejectReasonCode = rejectCode;
		this.statusCode = statusCode;
		this.bundleName = bundleName;
	}
	
	public ReviewerDTO(Reviewer reviewer, String bundleName) {
		this.reviewer = reviewer;
		this.bundleName = bundleName;
		this.rejectReasonCode = null;
		this.statusCode = null;
	}	

	public Reviewer getReviewer() {
		return this.reviewer;
	}

	public Long getReviewerId() {
		return this.reviewer.getId();
	}

	/**
	 * @return the date that the review was created.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getCreatedDate()
	 */
	public Date getCreatedDate() {
		return this.reviewer.getCreatedDate();
	}

	/**
	 * @return the name of the reviewer.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerName()
	 */
	public String getReviewerName() {
		return this.reviewer.getReviewerName();
	}

	/**
	 * @return comments left by the reviewer
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerComment()
	 */
	public String getReviewerComment() {
		return this.reviewer.getReviewerComment();
	}

	public CodeDTO getStatusCode() {
		return statusCode;
	}

	/**
	 * @return the date that the review was rejected.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerRejectDate()
	 */
	public Date getRejectDate() {
		return this.reviewer.getReviewerRejectDate();
	}

	/**
	 * @return the date that the review was released.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerReleaseDate()
	 */
	public Date getReleaseDate() {
		return this.reviewer.getReviewerReleaseDate();
	}

	/**
	 * @return the id of the user that rejected the review.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerRejectById()
	 */
	public String getRejectBy() {
		return this.reviewer.getReviewerRejectBy();
	}

	/**
	 * @return the id of the user that released the review.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerReleaseById()
	 */
	public String getReleaseById() {
		return this.reviewer.getReviewerReleaseBy();
	}

	/**
	 * @return the name of the reviewer's department.
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getReviewerDepartment()
	 */
	public String getReviewerDepartment() {
		Department department = this.reviewer.getDepartment();
		return (department == null) ? null : department.getName();
	}

	/**
	 * @return the name of the reviewer's division.
	 */
	public String getDivision() {
		Division division = this.reviewer.getDivision();
		return (division == null) ? null : division.getName();
	}

	/**
	 * @return the invalidUser
	 */
	public boolean isInvalidUser() {
		// dont want to expose reviewerto the client objects so added helper method.
		return !(Reviewer.ACTIVE_MANAGER_STATUS.equals(this.getReviewerStatus()));
	}

	public String getReviewerEmailAddress() {
		//return this.reviewer.getReviewerEmailAddress();
		return "Rohit.Bajrolia@assurant.com";
	}

	public String getReviewerStatus() {
		UserStatus userStatus = this.reviewer.getUserStatus();
		return (userStatus == null) ? null : userStatus.getUserStatusDescription();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getUserId()
	 */
	public Long getUserId() {
		return this.reviewer.getUserId();
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getRejectCode()
	 */
	public CodeDTO getRejectCode() {
		return this.rejectReasonCode;
	}

	/**
	 * @return
	 * @see com.assurant.inc.sox.domain.ar.Reviewer#getRejectText()
	 */
	public String getRejectText() {
		return this.reviewer.getRejectText();
	}

	public String getApprovedBy() {
		return this.reviewer.getReviewerApprovedBy();
	}

	public Date getApprovedDate() {
		return this.reviewer.getReviewerApprovedDate();
	}

	public Date getDistributionTargetCompleteDate() {
		return this.reviewer.getDistributionTargetCompleteDate();
	}

	public Long getReviewBundleId() {
		return this.reviewer.getReviewBundleId();
	}

	public Date getLastChangedDate() {
		return this.reviewer.getLastChangedDate();
	}

	/**
	 * @return the numberOfReviewedUsers
	 */
	public Long getNumberOfReviewedUsers() {
		return this.reviewer.getNumberOfDirectReports();
	}

	/**
	 * @param numberOfReviewedUsers the numberOfReviewedUsers to set
	 */
	public void setNumberOfReviewedUsers(long numberOfReviewedUsers) {
		this.reviewer.setNumberOfDirectReports(numberOfReviewedUsers);
	}

	public String getBundleName() {
		return this.bundleName;
	}

	public String getApplicationName() {
		Application application = this.reviewer.getApplication();
		return (application == null) ? null : application.getName();
	}

	public Long getApplicationId() {
		Application application = this.reviewer.getApplication();
		return (application == null) ? null : application.getId();
	}

	/**
	 * @return the numberOfDepartments
	 */
	public int getNumberOfDepartments() {
		return this.numberOfDepartments;
	}

	/**
	 * @param numberOfDepartments the numberOfDepartments to set
	 */
	public void setNumberOfDepartments(int numberOfDepartments) {
		this.numberOfDepartments = numberOfDepartments;
	}

	public String getDistinctEmployeeStatuses() {
		return reviewer.getReviewerUserStatusValues();
	}

	public void setDistinctEmployeeStatuses(String distinctEmployeeStatuses) {
		this.reviewer.setReviewerUserStatusValues(distinctEmployeeStatuses);
	}

	public String getOwnerName() {
		return this.ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getDistinctEnvName() {
		return this.distinctEnvName;
	}

	public void setDistinctEnvName(String distinctEnvName) {
		this.distinctEnvName = distinctEnvName;
	}

	public String getAttestedByID() {
		return reviewer.getAttestedByID();
	}

	public Date getAttestedOnDate() {
		return reviewer.getAttestedOnDate();
	}

	public void setAttestedByID(String attestedByID) {
		reviewer.setAttestedByID(attestedByID);
	}

	public void setAttestedOnDate(Date attestedOnDate) {
		reviewer.setAttestedOnDate(attestedOnDate);
	}

	public String getDistributionInstructions() {
		return reviewer.getDistributionInstructions();
	}

	public boolean isActionRequired() {
		return "Y".equalsIgnoreCase(reviewer.getActionsRequired());
	}

	private long daysUntil(Date d) {
		Calendar testDate = Calendar.getInstance();
		Calendar nowDate = Calendar.getInstance();
		testDate.setTime(d);
		zeroTimes(testDate);
		zeroTimes(nowDate);
		long dateMillis = testDate.getTimeInMillis();
		long nowMillis = nowDate.getTimeInMillis();
		final long millisPerDay = 1000L * 60L * 60L * 24L;
		return (dateMillis - nowMillis) / millisPerDay;
	}

	private void zeroTimes(Calendar aCalendar) {
		aCalendar.set(Calendar.MILLISECOND, 0);
		aCalendar.set(Calendar.SECOND, 0);
		aCalendar.set(Calendar.MINUTE, 0);
		aCalendar.set(Calendar.HOUR_OF_DAY, 0);
	}

	public String calculateDaysWarning() {
		if (getDistributionTargetCompleteDate() == null || reviewer.getAttestedOnDate() != null) {
			return NO_WARNING;
		}

		long duration = daysUntil(getDistributionTargetCompleteDate());
		if (duration < 0) {
			return OVERDUE;
		}
		if (duration <= 3) {
			return DAYS_DUE;
		}
		if (duration <= 7) {
			return WEEK_DUE;
		}
		return NO_WARNING;

	}

	/**
	 * If not attested and past due date, is overdue. Does not return true if rejected.
	 * 
	 * @return
	 */
	public boolean isOverdue() {
		return !ReviewerStatusCode.REJECTED.equals(getReviewerStatus()) && reviewer.getAttestedOnDate() == null
		    && calculateDaysWarning().equals(OVERDUE);
	}

	public ConflictDTO getConflict() {
		return conflict;
	}

	public void setConflict(ConflictDTO conflict) {
		this.conflict = conflict;
	}

	public Long getEscalationMgrId() {
		return this.reviewer.getEscalationMgrId();
	}

	public void setEscalationMgrId(Long managerId) {
		reviewer.setEscalationMgrId(managerId);
	}

	public String getEscalationMgrName() {
		return escalationMgrName;
	}

	public void setEscalationMgrName(String escalationMgrName) {
		this.escalationMgrName = escalationMgrName;
	}

	public String getConflictType() {
		return (this.conflict == null) ? null : this.conflict.getConflictTypeText();
	}

	@Override
	public String toString() {
		return new StringBuffer(128).append("Reviewer -- Id: ").append(this.getReviewerId()).append(" Name: ").append(
		    this.getReviewerName()).append(" Bundle Id: ").append(this.getReviewBundleId()).append(" Bundle Name: ").append(
		    this.bundleName).append(" Status: ").append((this.statusCode == null) ? null : this.statusCode.getValue()).toString();
	}

	public Date getLast250AccessChangedDate() {
		return reviewer.getLast250AccessChangedDate();
	}

	public boolean isHasAccessToApplication() {
		return hasAccessToApplication;
	}

	public void setHasAccessToApplication(boolean hasAccessToApplication) {
		this.hasAccessToApplication = hasAccessToApplication;
	}

	public String getReviewerLastStatusCd() {
		return reviewer.getReviewerLastStatusCd();
	}

}
