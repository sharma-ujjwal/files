package com.assurant.inc.sox.ar.client.bean.util;

import org.primefaces.component.column.Column;
import org.primefaces.component.commandlink.CommandLink;

import java.util.TimeZone;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.FacesContext;
import javax.faces.convert.DateTimeConverter;


/**
 * Utility class used to help build html tables. All methods are static.
 */
public abstract class HtmlTableBuilderUtil {

	/**
	 * Builds a column with the given header and detail.
	 * 
	 * @param header the header component for the column.
	 * @param detail the detail value for the column.
	 * @return the column.
	 */
	@SuppressWarnings("unchecked")
	public static Column buildColumn(UIComponent header, UIComponent detail) {
		Column col = new Column();
		col.getFacets().put("header", header);
		col.getChildren().add(detail);
		return col;
	}

	/**
	 * Builds an output text with the provided value binding. The style class will be of "fieldValue".
	 * 
	 * @param valueBinding the value binding to set for the text.
	 * @return the output text.
	 */
	@SuppressWarnings("deprecation")
	public static HtmlOutputText buildOutputText(String valueBinding) {
		HtmlOutputText text = new HtmlOutputText();
		// Must use deprecated mehtod until websphere dies
		text.setValueBinding("value", FacesContext.getCurrentInstance().getApplication().createValueBinding(valueBinding));
		return text;
	}

	/**
	 * Builds a date output text with a formatting of MM/dd/yyyy.
	 * 
	 * @param valueBinding the date field binding.
	 * @return the output text.
	 */
	public static HtmlOutputText buildDateOutputText(String valueBinding) {
		HtmlOutputText text = HtmlTableBuilderUtil.buildOutputText(valueBinding);
		DateTimeConverter converter = new DateTimeConverter();
		converter.setPattern("MM/dd/yyyy");
		converter.setType("date");
		converter.setTimeZone(TimeZone.getDefault());
		text.setConverter(converter);

		return text;
	}

	/**
	 * Builds a header link with the provided string value, actionbinding and id. The link will be styled for a table header sort.
	 * 
	 * @param value the display value.
	 * @param actionBinding the sort action binding.
	 * @param id the id of the link.
	 * @return the command link.
	 */
	@SuppressWarnings( { "unchecked", "deprecation" })
	public static CommandLink buildHeaderLink(String value, String actionBinding, String id) {
		CommandLink link = new CommandLink();
		link.setValue(value);
		// Must use deprecated mehtod until websphere dies
		link.setAction(FacesContext.getCurrentInstance().getApplication().createMethodBinding(actionBinding, null));
		link.setStyleClass("headerSortLink");
		link.setId(id);

		return link;
	}
}
