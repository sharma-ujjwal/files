package com.assurant.inc.sox.ar.utils.interceptors;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.domain.ar.IAuditableAr;

/**
 * Interceptor to set audit infomation on each data table. Will be called before every insert or
 * update to the database.
 * 
 * @author BB68602
 * 
 * 
 */
@Service
public class AuditInterceptor extends EmptyInterceptor {

    private static final long serialVersionUID = 1477024645500535673L;
    private final static String CRTDBY = "createdBy";
    private final static String CRDTDT = "createdDate";
    private final static String LASTCHNGDBY = "lastChangedBy";
    private final static String LASTCHNGDDT = "lastChangedDate";
    private final static String EFFTODT = "effectiveToDt";
    private final static String EFFFROMDT = "effectiveFromDt";
    private final static String DTLFLG = "deleteFlag";

    private final Date THE_END_OF_TIME;

    public AuditInterceptor() {
        Calendar cal = Calendar.getInstance();
        cal.set(4000, Calendar.DECEMBER, 31, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 999);
        this.THE_END_OF_TIME = cal.getTime();
    }

    @Autowired
    private SystemUserDTO sessionSystemUser;

    public SystemUserDTO getSessionSystemUser() {
        return sessionSystemUser;
    }

    public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
        this.sessionSystemUser = sessionSystemUser;
    }

    /**
     * Method that hibernate calls when an update is occuring to set the audit meta data
     * 
     * @return boolean
     */
    @Override
    public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState,
            Object[] previousState, String[] propertyNames, Type[] types) {

        if (entity instanceof IAuditableAr) {
            for (int i = 0; i < propertyNames.length; i++) {
                if (LASTCHNGDBY.equals(propertyNames[i])) {
                    currentState[i] = getSessionSystemUser().getUserId();
                }
                else if (LASTCHNGDDT.equals(propertyNames[i])) {
                    currentState[i] = new Date();
                }
//                else if (DTLFLG.equals(propertyNames[i])) {
//                    currentState[i] = "Y";
//                }
                else if (EFFTODT.equals(propertyNames[i])) {
                    currentState[i] = new Date();
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Method that hibernate calls when an insert is occuring to set the audit meta data
     * 
     * @return boolean
     */
    @Override
    public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames,
            Type[] types) {

        if (entity instanceof IAuditableAr) {
            for (int i = 0; i < propertyNames.length; i++) {
                if (CRTDBY.equals(propertyNames[i])) {
                    state[i] = getSessionSystemUser().getUserId();
                }
                else if (CRDTDT.equals(propertyNames[i])) {
                    state[i] = new Date();
                }
                else if (EFFFROMDT.equals(propertyNames[i])) {
                    state[i] = new Date();
                }
                else if (DTLFLG.equals(propertyNames[i])) {
                    state[i] = "N";
                }
                else if (EFFTODT.equals(propertyNames[i])) {
                    // INFO -- by request of reporting and data architects we are using the magic
                    // date of 12/31/4000
                    // to represent the end of time rather than leaving it null. Debate is still up
                    // on this one but
                    // we are adding this for the time being until the decision is made.
                    state[i] = this.THE_END_OF_TIME;
                }

            }
            return true;
        }

        return false;
    }

}
