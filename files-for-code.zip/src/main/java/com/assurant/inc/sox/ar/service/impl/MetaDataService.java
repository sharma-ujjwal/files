package com.assurant.inc.sox.ar.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.dto.ApplicationDTO;
import com.assurant.inc.sox.ar.dto.ConflictDTO;
import com.assurant.inc.sox.ar.dto.ConflictTypeDTO;
import com.assurant.inc.sox.ar.dto.CostCenterDTO;
import com.assurant.inc.sox.ar.dto.DepartmentDTO;
import com.assurant.inc.sox.ar.dto.DivisionDTO;
import com.assurant.inc.sox.ar.dto.EnvironmentDTO;
import com.assurant.inc.sox.ar.dto.IndividualDTO;
import com.assurant.inc.sox.ar.dto.ManagerDTO;
import com.assurant.inc.sox.ar.dto.PrivDescriptionDTO;
import com.assurant.inc.sox.ar.dto.PrivValueDTO;
import com.assurant.inc.sox.ar.dto.SourceNameDTO;
import com.assurant.inc.sox.ar.dto.SoxConcernDTO;
import com.assurant.inc.sox.ar.dto.UserStatusDTO;
import com.assurant.inc.sox.ar.dto.UserTypeDTO;
import com.assurant.inc.sox.ar.service.IMetaDataService;
import com.assurant.inc.sox.ar.service.base.MetaDataServiceBase;
import com.assurant.inc.sox.domain.ar.Application;
import com.assurant.inc.sox.domain.ar.Conflict;
import com.assurant.inc.sox.domain.ar.ConflictType;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Environment;
import com.assurant.inc.sox.domain.ar.FilterType;
import com.assurant.inc.sox.domain.ar.SoxConcern;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;

/**
 * Meta Data Service is class to get all the possible selection and filter values that the user can select from.
 * 
 * @author BB68602
 * 
 */
@Service
public class MetaDataService extends MetaDataServiceBase implements IMetaDataService {
	

    // used as monitor lock, make final and non-null
    final private HashMap<String, FilterType> filterTypes = new HashMap<String, FilterType>();

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#getFilterTypeByValue(java.lang.String)
     */
    public FilterType getFilterTypeByValue(String value) {
        synchronized (this.filterTypes) {
            if (this.filterTypes.isEmpty()) {
                List<FilterType> types = this.filterTypeDao.findAll();
                for (FilterType type : types) {
                    this.filterTypes.put(type.getFilterTypeValue(), type);
                }

            }
            return this.filterTypes.get(value);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveApplications(java.lang.String)
     */
    public List<ApplicationDTO> retrieveApplications(String searchString) {
        getLogger().debug("retrieveApplications() --> being executed.");
        List<ApplicationDTO> dtos = new ArrayList<ApplicationDTO>();
        for (Application application : getApplicationDao().findByName(searchString)) {
            dtos.add(new ApplicationDTO(application));
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveApplicationSystems(java.lang.String)
     */
    public List<SourceNameDTO> retrieveSourceNames(String searchString) {
        getLogger().debug("retrieveSourceNames() --> being executed.");
        List<SourceNameDTO> dtos = new ArrayList<SourceNameDTO>();
        for (String sourceName : getUserAccessDao().findBySourceName(searchString)) {
        	SourceNameDTO dto = new SourceNameDTO();
        	dto.setId(sourceName);
        	dto.setName(sourceName);
        	dtos.add(dto);
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveDepartments(java.lang.String)
     */
    public List<DepartmentDTO> retrieveDepartments(String searchString) {
        getLogger().debug("retrieveDepartments() --> being executed.");
        List<DepartmentDTO> dtos = new ArrayList<DepartmentDTO>();
        for (Department department : getDepartmentDao().findByName(searchString)) {
            dtos.add(new DepartmentDTO(department));
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveDivisions(java.lang.String)
     */
    public List<DivisionDTO> retrieveDivisions(@SuppressWarnings("unused")
    String searchString) {
        getLogger().debug("retrieveDivisions() --> being executed.");
        List<DivisionDTO> dtos = new ArrayList<DivisionDTO>();
        for (Division division : getDivisionDao().findByName(searchString)) {
            dtos.add(new DivisionDTO(division));
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveEnvironments()
     */
    public List<EnvironmentDTO> retrieveEnvironments() {
        getLogger().debug("retrieveEnvironments() --> being executed.");
        List<EnvironmentDTO> dtos = new ArrayList<EnvironmentDTO>();
        for (Environment environment : getEnvironmentDao().findAll()) {
            dtos.add(new EnvironmentDTO(environment));
        }
        return dtos;
    }

    /*
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveManagers(java.lang.String)
     */
    public List<ManagerDTO> retrieveManagers(String searchString) {
        getLogger().debug("retrieveManagers() --> being executed.");

        List<Supervisor> supervisors = getSupervisorDao().findByName(searchString);
        List<ManagerDTO> resultList = new ArrayList<ManagerDTO>();
        
        for (Supervisor supervisor : supervisors) {
        	ManagerDTO dto = new ManagerDTO();
        	dto.setId(supervisor.getUserId()+"");
        	String name = supervisor.getLastName() +", " + supervisor.getFirstName();
        	if(supervisor.getMiddleName() != null){
        		name = name + " " + supervisor.getMiddleName();
        	}
        	dto.setName(name);
        	resultList.add(dto);
		}

        return resultList;
    }

    /*
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveIndividuals(java.lang.String)
     */
    public List<IndividualDTO> retrieveIndividuals(String searchString) {
        getLogger().debug("retrieveIndividuals(searchString) --> being executed.");

        List<User> users = getUserDao().findActiveUsers(searchString);
        List<IndividualDTO> resultList = new ArrayList<IndividualDTO>();
        
        for (User user : users) {
        	IndividualDTO dto = new IndividualDTO();
        	dto.setId(user.getUserId()+"");
        	dto.setName(user.getLastName() + ", " + user.getFirstName());
        	resultList.add(dto);
		}
        
        return resultList;
    }

    /*
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrievePrivDescriptions(java.lang.String)
     */
    public List<PrivDescriptionDTO> retrievePrivDescriptions(String searchString) {
        getLogger().debug("retrievePrivDescriptions() --> being executed.");
        List<PrivDescriptionDTO> dtos = new ArrayList<PrivDescriptionDTO>();
        for (String description : getPrivilegeCommentDao().findDescriptions(searchString)) {
            PrivDescriptionDTO dto = new PrivDescriptionDTO();
            dto.setId(description);
            dto.setName(description);
            dtos.add(dto);
        }
        return dtos;
    }

    /*
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrievePrivValues(java.lang.String)
     */
    public List<PrivValueDTO> retrievePrivValues(String searchString) {
        getLogger().debug("retrievePrivValues() --> being executed.");
        List<PrivValueDTO> dtos = new ArrayList<PrivValueDTO>();
        for (String description : getPrivilegeCommentDao().findValues(searchString)) {
            PrivValueDTO dto = new PrivValueDTO();
            dto.setId(description);
            dto.setName(description);
            dtos.add(dto);
        }
        return dtos;
    }

    /*
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveCostCenters(java.lang.String)
     */
    public List<CostCenterDTO> retrieveCostCenters(String searchString) {
        getLogger().debug("retrieveCostCenters() --> being executed.");
        
        List<String> costCenters = getUserDao().findCostCenters(searchString);
        List<CostCenterDTO> resultList = new ArrayList<CostCenterDTO>();
        
        for (String costCenter : costCenters) {
        	 CostCenterDTO dto = new CostCenterDTO();
        	 dto.setId(costCenter);
        	 dto.setName(costCenter);
        	 resultList.add(dto);
		}
        
        return resultList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveSoxConcerns()
     */
    public List<SoxConcernDTO> retrieveSoxConcerns() {
        getLogger().debug("retrieveSoxConcerns() --> being executed.");
        List<SoxConcernDTO> dtos = new ArrayList<SoxConcernDTO>();
        for (SoxConcern soxConcern : getSoxConcernDao().findAll()) {
            dtos.add(new SoxConcernDTO(soxConcern));
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveUserStatuses()
     */
    public List<UserStatusDTO> retrieveUserStatuses() {
        getLogger().debug("retrieveUserStatuses() --> being executed.");
        List<UserStatusDTO> dtos = new ArrayList<UserStatusDTO>();
        for (UserStatus userStatus : getUserStatusDao().findAll()) {
            dtos.add(new UserStatusDTO(userStatus));
        }
        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveUserTypes()
     */
    public List<UserTypeDTO> retrieveUserTypes() {
        getLogger().debug("retrieveUserTypes() --> being executed.");
        List<UserTypeDTO> dtos = new ArrayList<UserTypeDTO>();
        for (UserType aUserType : getUserTypeDao().findAll()) {
            dtos.add(new UserTypeDTO(aUserType));
        }
        return dtos;
    }
    
    /* (non-Javadoc)
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retrieveConflictTypes()
     */
    public List<ConflictTypeDTO> retrieveConflictTypes() {
    	getLogger().debug("retrieveConflictTypes() --> being executed.");
    	List<ConflictTypeDTO> dtos = new ArrayList<ConflictTypeDTO>();
    	for (ConflictType aConflictType : getConflictTypeDao().findAll()) {
    		dtos.add(new ConflictTypeDTO(aConflictType));
    	}
    	return dtos;
    }
    
    /* (non-Javadoc)
     * @see com.assurant.inc.sox.ar.service.IMetaDataService#retreiveConflicts(java.lang.Long)
     */
    public List<ConflictDTO> retreiveConflicts(Long conflictTypeId) {
    	getLogger().debug("retreiveConflicts(Long) --> being executed.");
    	List<ConflictDTO> dtos = new ArrayList<ConflictDTO>();
    	for (Conflict aConflict : getConflictDao().findByConflictTypeId(conflictTypeId)) {
    		dtos.add(new ConflictDTO(aConflict));
    	}
    	return dtos;
    }
}
