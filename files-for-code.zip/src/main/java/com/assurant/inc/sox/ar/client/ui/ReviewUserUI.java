package com.assurant.inc.sox.ar.client.ui;

import java.util.Date;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.enums.reviewUser.ReviewUserCompletedFlag;
import com.assurant.inc.sox.domain.ar.ReviewUser;

public class ReviewUserUI implements ISelectableUI {

	protected ReviewUserDTO reviewUserDTO;
	private boolean selected;

	/**
	 * number position of user in list, so when next or previous user is clicked we know which user to get next
	 */
	private int recordNumber = 0;

	public ReviewUserUI() {
		super();
	}

	public ReviewUserUI(ReviewUserDTO reviewUserDTO) {
		super();
		this.reviewUserDTO = reviewUserDTO;
	}

	public ReviewUserDTO getReviewUserDTO() {
		return reviewUserDTO;
	}

	public void setReviewUserDTO(ReviewUserDTO reviewUserDTO) {
		this.reviewUserDTO = reviewUserDTO;
	}

	public Long getReviewerId() {
		return reviewUserDTO.getReviewerId();
	}

	public ReviewUser getReviewUser() {
		return reviewUserDTO.getReviewUser();
	}

	public String getReviewUserComment() {
		return reviewUserDTO.getRejectComment();
	}
	
	public String getRejectCodeDisplay() {
		CodeDTO rejectCode = this.reviewUserDTO.getRejectCode();
		return (rejectCode == null) ? null : rejectCode.getDisplay();
	}

	public Long getReviewUserId() {
		return reviewUserDTO.getReviewUserId();
	}

	public Date getReviewUserStatusDate() {
		return reviewUserDTO.getRejectDate();
	}

	public Long getUserId() {
		return reviewUserDTO.getUserId();
	}

	public String getUserName() {
		return reviewUserDTO.getUserName();
	}

	public void setUserName(String userName) {
		reviewUserDTO.setUserName(userName);
	}

	@Override
	public String toString() {
		return reviewUserDTO.toString();
	}

	public int getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(int recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getDepartmentName() {
		return reviewUserDTO.getDepartmentName();
	}

	public String getDivisionName() {
		return reviewUserDTO.getDivisionName();
	}

	public String getUserStatus() {
		return reviewUserDTO.getUserStatus();
	}

	public String getManagerName() {
		return this.reviewUserDTO.getManagerName();
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public boolean getCompleted() {
		CodeDTO completedFlag = this.reviewUserDTO.getCompletedFlag();
		return (completedFlag != null) && (ReviewUserCompletedFlag.YES.getFlag().equalsIgnoreCase(completedFlag.getValue()));
	}
	
	public String getCompletedDisplay() {
		CodeDTO completedFlag = this.reviewUserDTO.getCompletedFlag();
		return (completedFlag == null) ? "No" : completedFlag.getDisplay();
	}

}
