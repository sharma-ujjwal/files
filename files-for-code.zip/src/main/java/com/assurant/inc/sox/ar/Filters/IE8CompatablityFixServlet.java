package com.assurant.inc.sox.ar.Filters;

import javax.servlet.*;
import java.io.IOException;

public class IE8CompatablityFixServlet implements Filter

{

	public void init(FilterConfig filterConfig) throws ServletException

	{

	}

	public void doFilter(ServletRequest request, ServletResponse response,

	FilterChain chain) throws IOException, ServletException

	{
		/*((HttpServletResponse) response).setHeader("X-UA-Compatible",
				"IE=EmulateIE7");
		((HttpServletResponse) response).setHeader("sm_groups",
				"EBSOXITOWNER");
		((HttpServletResponse) response).setHeader("sm_user",
				"TB42140");*/
		chain.doFilter(request, response);

	}

	public void destroy()

	{

	}

}