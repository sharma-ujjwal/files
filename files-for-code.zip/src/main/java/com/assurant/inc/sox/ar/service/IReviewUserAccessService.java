package com.assurant.inc.sox.ar.service;

import java.util.List;

import com.assurant.inc.sox.ar.dto.ReviewUserApplicationAccessesDTO;
import com.assurant.inc.sox.ar.dto.ReviewerDTO;

/**
 * Service for retrieving user access data.
 */
public interface IReviewUserAccessService {

    /**
     * Retrieves all of the review user application accesses for the given review user id.
     * 
     * @param reviewUserId the review user id to retrieve review user application accesses for.
     * @return the list of all of the review user application accesses for the given review user. If
     *         none are found then an empty list will be returned.
     */
    public List<ReviewUserApplicationAccessesDTO> retrieveByReviewUserId(Long reviewUserId);
    
    /**
     * Stores the given list of application accesses.
     * 
     * @param dtos the List of ReviewUserApplicationDTO to store.
     * @param reviewerDTO the reviewer.
     */
    public void save(List<ReviewUserApplicationAccessesDTO> dtos, ReviewerDTO reviewerDTO);
}
