package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.ar.Department;
import java.util.Date;

public class DepartmentUI {
	private final Department department;
	private boolean checked;

	public DepartmentUI(Department department) {
		this.department = department;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	public String getName() {
		return this.department.getName();
	}

	public String getCostCenter() {
		return this.department.getCostCenter();
	}
	
	public String getDepartmentNameCostCenter() {
		return this.department.getDepartmentNmCostCenter();
	}
	
	public String getCreatedBy() {
		return this.department.getCreatedBy();
	}
		
	public Date getCreatedDate() {
		return this.department.getCreatedDate();
	}
		
	public String getLastChangedBy() {
		return this.department.getLastChangedBy();
	}
		
	public Date getLastChangedDate() {
		return this.department.getLastChangedDate();
	}
	
	public String getDeleteFlag() {
		return this.department.getDeleteFlag();
	}

	public Department getDepartment() {
		return department;
	}

	public Date getActiveFromDate() {
		return this.department.getActiveFromDate();
	}
	
	public Date getActiveToDate() {
		return this.department.getActiveToDate();
	}
	
	public Long getId() {
		return this.department.getId();
	}

	
} //end of departmentUI
