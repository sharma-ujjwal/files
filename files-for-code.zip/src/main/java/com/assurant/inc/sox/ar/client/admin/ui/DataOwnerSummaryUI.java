/**
 * 
 */
package com.assurant.inc.sox.ar.client.admin.ui;

import com.assurant.inc.sox.domain.admin.DataOwnerSummary;

import java.util.Date;

/**
 * @author Brian Olson
 *
 */
public class DataOwnerSummaryUI {
	private final DataOwnerSummary dataOwnerSummary;
	
	public DataOwnerSummaryUI(DataOwnerSummary dataOwnerSummary) {
		this.dataOwnerSummary = dataOwnerSummary;
	}
	
	public String getApplicationName() {
		return this.dataOwnerSummary.getApplicationName();
	}

	public String getCreatedBy() {
		return this.dataOwnerSummary.getCreatedBy();
	}

	public Date getCreatedDate() {
		return this.dataOwnerSummary.getCreatedDate();
	}

	public String getLastChangedBy() {
		return this.dataOwnerSummary.getLastChangedBy();
	}

	public Date getLastChangedDate() {
		return this.dataOwnerSummary.getLastChangedDate();
	}

	public String getOwnerNamesList() {
		StringBuilder sb = new StringBuilder();
		sb.append("<ul class=\"reviewOwnerList\">");
		
		for (int i = 0; i < this.dataOwnerSummary.getOwnerNames().size(); i++) {
			sb.append("<li>");
			if (i == 0) {
				sb.append("<img src=\"/soxautoreviews/images/treeCheck.gif\" />");
			}
			sb.append(this.dataOwnerSummary.getOwnerNames().get(i));
			sb.append("</li>");
		}
		
		sb.append("</ul>");
		return sb.toString();
	}
	
	public String getReviewerNamesList() {
		StringBuilder sb = new StringBuilder();
		sb.append("<ul class=\"reviewOwnerList\">");
		
		for (int i = 0; i < this.dataOwnerSummary.getReviewerNames().size(); i++) {
			sb.append("<li>");
			if (i == 0) {
				sb.append("<img src=\"/soxautoreviews/images/treeCheck.gif\" />");
			}
			sb.append(this.dataOwnerSummary.getReviewerNames().get(i));
			sb.append("</li>");
		}
		
		sb.append("</ul>");
		return sb.toString();
	}

}
