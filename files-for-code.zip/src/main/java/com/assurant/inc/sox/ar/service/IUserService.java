package com.assurant.inc.sox.ar.service;

import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import com.assurant.inc.sox.ar.client.admin.ui.UserUI;
import com.assurant.inc.sox.domain.ar.Department;
import com.assurant.inc.sox.domain.ar.Division;
import com.assurant.inc.sox.domain.ar.Review;
import com.assurant.inc.sox.domain.ar.ReviewOwner;
import com.assurant.inc.sox.domain.ar.Supervisor;
import com.assurant.inc.sox.domain.ar.UserStatus;
import com.assurant.inc.sox.domain.ar.UserType;
import com.assurant.inc.sox.domain.luad.User;

public interface IUserService {	

	public void delete(User user);

	public List<User> retrieveAllActiveUsers();

	public User findById(Long id);
	// public boolean findNameExist(String sName);
/*
	public List<User> retrieveDeletedUser();

	public List<User> retrieveUnassignedUser();

	public List<User> retrieveAllUserByName(String userNameSearchText);

	public List<User> retrieveDeletedUserByName(String userNameSearchText);

	public List<User> retrieveUnassignedUserByName(String userNameSearchText);
*/
	public List<User> getUsersFiltered(boolean isActive, String searchKeyId,
		Long searchSupervisor, String searchFirstNm, String searchLastNm,
		List searchUserType, List searchStatus, List searchDprtmntId,
		List searchDivisionId, List<String> searchCostCenter,
		List<String> searchBsnssSgmnt);
	
	public String findUserExist(Long excludeUserId, String searchKeyId, String satMFId, String satGFId, 
			String satCFId, String satLCSId,String satFDMSId, String satSiteminderId,
			String searchSatAltId1, String searchSatAltId2, String searchSatAltId3);

	public void addUser(String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String bsnssSgmnt, String phone, String emailAddress, Long userStatusId, 
			String satStatus, String satJobRole, String satComment, Long extractSysId, Date extractSysDate);
	
	public void add(String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3, String satStatus,
			String satJobRole, String satComment);

	public void bulkUpdateUsers(List<User> updateUserList, Long supervisorId, Long userStatusId, 
			Long userTypeId, Long departmentId, Long divisionId, String cstCntr, String bsnssSgmnt);
	
	public void updateUsers(List<User> updateUserList);

	public void updateUser(User updateUser);

	public void populatSupevisorData(Long supervisor);

	public List<SelectItem> populateSupevisorDepartments(Long supervisor);

	public List<SelectItem> populateSupevisorDivisions(Long supervisor);

	public List<SelectItem> populateSupevisorCostCenters(Long supervisor);

	public List<SelectItem> populateSupevisorBusinessSegments(Long supervisor);

	public List<SelectItem> populateSupevisorJobTitles(Long supervisor, String existingJobTitle);

	public List<SelectItem> populateSupevisorLocations(Long supervisor, String existingLocation);

	public void updateSupervisorOnUserDelete(Long userId, String lastChangedBy);

	public void updateDirectReportInfo(Long supervisorId);

	public List<User> findByUserName(String searchFirstName,
			String searchLastName);

	public List<UserUI> searchAssociatedUser(String searchFirstNm,
			String searchLastNm, String keyId, Long supervisorId,
			List userStatuses, List userTypes,
			List departments, List divisions, String location);

//	public void addAlternateId(String keyId, String lookUpAltId, Long userId,
//			Long internalIdentifierType);
	
	public void updateUser(Long userId, String keyId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String cstCntr, String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3, 
			String satStatus, String satJobRole, String satComment);

	public List<UserStatus> findUserStatusList();
	
	public List<Department> retrieveAllDepartments();
	
	public List<Division> retrieveAllDivisions();
	
	public List<UserType> retrieveAllUserTypes();

	public List<String> retrieveAllBusinessSeg();
	
	public List<String> retrieveAllCostCenter();
	
	public List<SelectItem> populateSupevisorUserType(Long supervisor);
	
	public List<Supervisor> retrieveAllSupervisors();

	public UserType findUserTypeById(Long id);

	public UserStatus findUserStatusById(Long id);

	public Department findDepartmentById(Long id);

	public Division findDivisionById(Long id);

	public User findUserById(Long id);

	public void updateRejectedUser(Long userId, String firstNm, String mddlNm, String lastNm,
			Long userTypeId, Long departmentId, Long divisionId,
			String location, String jobTitle, Long supervisorId,
			String cstCntr, String bsnssSgmnt, String phone,
			String emailAddress, Long userStatusId, 
			String satStatus, String satJobRole, String satComment);

	public void updateAltIdsForUser(Long userId, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3);

	public void updateAltIds(Long userId, String keyId, String emailAddress, 
			String satMFId, String satGFId, String satCFId, String satLCSId, 
			String satFDMSId, String satSiteminderId, String satAltId1,
			String satAltId2, String satAltId3); 

	public Long findActiveUserIdByKeyId(String keyId);

	public boolean isAltIdExists(String altId);

	public List<User> findUsersBySupevisorId(Long supervisorId);
	
	public boolean isActiveReviewOwner(Long userId);
	
	public List<Review> outstandingReviewsForUserId(Long userId);

	public String activeReviewsMessage(Long userId);

	public boolean isActiveUser(Long userId);
	
	public List<User> findPotentialSupervisors(String keyId, String firstName, String lastName);

	public boolean isIpsUser();
	

}
