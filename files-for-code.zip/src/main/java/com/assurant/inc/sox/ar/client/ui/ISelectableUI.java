package com.assurant.inc.sox.ar.client.ui;

public interface ISelectableUI {
	public boolean isSelected();
	public void setSelected(boolean selected);
}
