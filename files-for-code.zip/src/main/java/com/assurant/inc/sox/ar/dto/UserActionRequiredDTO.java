package com.assurant.inc.sox.ar.dto;

import java.util.List;

public class UserActionRequiredDTO {

	private ReviewUserAccessDTO reviewUserAccessDTO;
	private ReviewApplicationDTO reviewApplicationDTO;
	private final List<WorkOrderDTO> workOrderDTOs;
	private final ReviewUserDTO reviewUser;

	public UserActionRequiredDTO(List<WorkOrderDTO> workOrderDTOs, ReviewUserDTO reviewUser) {
		this.workOrderDTOs = workOrderDTOs;
		this.reviewUser = reviewUser;
	}

	public List<WorkOrderDTO> getWorkOrderDTOs() {
		return workOrderDTOs;
	}

	public ReviewUserDTO getReviewUser() {
		return reviewUser;
	}

	public ReviewUserAccessDTO getReviewUserAccessDTO() {
		return reviewUserAccessDTO;
	}

	public void setReviewUserAccessDTO(ReviewUserAccessDTO reviewUserAccessDTO) {
		this.reviewUserAccessDTO = reviewUserAccessDTO;
	}

	public ReviewApplicationDTO getReviewApplicationDTO() {
		return reviewApplicationDTO;
	}

	public void setReviewApplicationDTO(ReviewApplicationDTO reviewApplicationDTO) {
		this.reviewApplicationDTO = reviewApplicationDTO;
	}

	public Long getReviewApplicationId() {
		if (this.reviewApplicationDTO == null) {
			return null;
		}
		return reviewApplicationDTO.getId();
	}

	public Long getReviewUserAccessId() {
		if (reviewUserAccessDTO != null) {
			return reviewUserAccessDTO.getReviewUserAccessId();
		}
		return null;
	}

}
