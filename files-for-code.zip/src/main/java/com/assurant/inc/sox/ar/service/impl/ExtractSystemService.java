package com.assurant.inc.sox.ar.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assurant.inc.sox.ar.service.IExtractSystemService;
import com.assurant.inc.sox.dao.ar.IExtractSystemDAO;
import com.assurant.inc.sox.domain.ar.ExtractSystem;

@Service
public class ExtractSystemService implements IExtractSystemService{

	@Autowired
	IExtractSystemDAO extractSystemDAO;

	public IExtractSystemDAO getExtractSystemDAO() {
		return extractSystemDAO;
	}

	public void setExtractSystemDAO(IExtractSystemDAO extractSystemDAO) {
		this.extractSystemDAO = extractSystemDAO;
	}

	public List<ExtractSystem> findAll() {
		return this.extractSystemDAO.findAll();
	}
}
