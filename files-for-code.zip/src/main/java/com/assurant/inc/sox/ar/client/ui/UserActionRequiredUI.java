package com.assurant.inc.sox.ar.client.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.assurant.inc.sox.ar.dto.CodeDTO;
import com.assurant.inc.sox.ar.dto.ReviewApplicationDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserAccessDTO;
import com.assurant.inc.sox.ar.dto.ReviewUserDTO;
import com.assurant.inc.sox.ar.dto.UserActionRequiredDTO;
import com.assurant.inc.sox.ar.dto.WorkOrderDTO;
import com.assurant.inc.sox.domain.ar.Code;
import com.assurant.inc.sox.domain.ar.ReviewUser;
import com.assurant.inc.sox.domain.ar.ReviewUserAccess;

public class UserActionRequiredUI implements ISelectableUI{

	private final UserActionRequiredDTO userActionReq;
	private int rowIndex = 0;
	private boolean selected;
	private boolean reviewApplication;
	private boolean commentRenderFlag;
	private boolean completeRenderFlag;
	private boolean validatedFlag;

	public UserActionRequiredUI() {
		List<WorkOrderDTO> workOrderDTO = new ArrayList<>();
		this.userActionReq = new UserActionRequiredDTO(workOrderDTO,
				new ReviewUserDTO(new ReviewUser(), new CodeDTO(new Code()), new CodeDTO(new Code())));
	}

	public UserActionRequiredUI(UserActionRequiredDTO userActionReq) {
		this.userActionReq = userActionReq;
	}

	public UserActionRequiredDTO getUserActionReq() {
		return userActionReq;
	}

	public List<WorkOrderDTO> getWorkOrderDTOs() {
		return userActionReq.getWorkOrderDTOs();
	}

	public List<WorkOrderUI> getWorkOrderUIs() {
		List<WorkOrderUI> workOrderUIs = new ArrayList<WorkOrderUI>(userActionReq.getWorkOrderDTOs().size());
		for (WorkOrderDTO woDTO : userActionReq.getWorkOrderDTOs()) {
			workOrderUIs.add(new WorkOrderUI(woDTO));
		}
		return workOrderUIs;
	}

	public String getWorkOrderNumbers() {
		StringBuffer sb = new StringBuffer();
		for (WorkOrderDTO dto : this.getWorkOrderDTOs()) {
			if (dto.getWorkOrderNumber() != null) {
				sb.append(dto.getWorkOrderNumber().toString()).append("<br>");
			}
		}
		return sb.toString();
	}

	public ReviewUserDTO getReviewUser() {
		return userActionReq.getReviewUser();
	}

	public ReviewUserAccessDTO getReviewUserAccessDTO() {
		return userActionReq.getReviewUserAccessDTO();
	}

	public ReviewApplicationDTO getReviewApplicationDTO() {
		return userActionReq.getReviewApplicationDTO();
	}

	public int getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getUserName() {
		return this.userActionReq.getReviewUser().getUserName();
	}

	public String getAppUserId() {
		/*
		 * b/c this user action object can contain 2 different domain objects
		 * we have to pull the user id from which ever object we have
		 */
		if (userActionReq.getReviewUserAccessDTO() != null) {
			return this.userActionReq.getReviewUserAccessDTO().getApplicationUserId();
		} else if (userActionReq.getReviewApplicationDTO() != null) {
			return userActionReq.getReviewApplicationDTO().getApplicationUserId();
		}
		return "ERROR";
	}

	public String getPrivilegeDescription() {
		if (isReviewApplication()) {
			return null;
		}
		return this.userActionReq.getReviewUserAccessDTO().getPrivilegeDescription();
	}

	public String getPrivilegeValue() {
		if (isReviewApplication()) {
			return null;
		}
		return this.userActionReq.getReviewUserAccessDTO().getPrivilegeValue();
	}

	public String getPrivilegeComment() {
		if (isReviewApplication()) {
			return null;
		}
		return this.userActionReq.getReviewUserAccessDTO().getPrivilegeComment();
	}

	public String getStatus() {
		String result;
		if (isReviewApplication()) {
			result = null;
		} else {
			CodeDTO status = this.userActionReq.getReviewUserAccessDTO().getStatus();
			if (isReviewApplication() || status == null) {
				result = null;
			} else {
				result = status.getDisplay();
			}
		}
		return result;
	}

	public String getSourceName() {
		if (isReviewApplication()) {
			return null;
		}
		return this.userActionReq.getReviewUserAccessDTO().getSourceName();
	}

	public Date getCompleteDate() {
		if (isReviewApplication()) {
			return this.userActionReq.getReviewApplicationDTO().getCompleteDate();
		}
		return this.userActionReq.getReviewUserAccessDTO().getCompleteDate();
	}

	public boolean isReviewApplication() {
		boolean result = false;
		if (this.userActionReq.getReviewUserAccessDTO() == null) {
			result = true;
		}
		return result;
	}

	public boolean isCommentRenderFlag() {
		if (isReviewApplication()) {
			return true;
		}
		return false;
	}

	public void setCommentRenderFlag(boolean commentRenderFlag) {
		this.commentRenderFlag = commentRenderFlag;
	}

	public String getComment() {
		return this.userActionReq.getReviewApplicationDTO().getComment();
	}

	public boolean isCompleteRenderFlag() {
		if ((isReviewApplication() && this.getCompleteDate() == null) || (isValidatedFlag() && this.getCompleteDate() == null)) {
			return true;
		}
		return false;
	}

	public void setCompleteRenderFlag(boolean completeRenderFlag) {
		this.completeRenderFlag = completeRenderFlag;
	}

	public void setReviewApplication(boolean reviewApplication) {
		this.reviewApplication = reviewApplication;
	}

	public boolean isValidatedFlag() {
		return validatedFlag;
	}

	public void setValidatedFlag(boolean validatedFlag) {
		this.validatedFlag = validatedFlag;
	}

	public String getReviewApplicationId() {
		if (userActionReq.getReviewApplicationId() == null) {
			return "";
		}
		return userActionReq.getReviewApplicationId() + "";
	}

	public String getReviewUserAccessId() {
		if (userActionReq.getReviewUserAccessId() == null) {
			return "";
		}
		return userActionReq.getReviewUserAccessId() + "";
	}
	
	/**
	 * Field to sort on, not for display
	 * 
	 * @return
	 */
	public String getSortField() {
		return getUserName() + (isCommentRenderFlag() ? "0" : "1") ;
	}
}
