package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.ConflictDTO;

public class ConflictUI {

	private final ConflictDTO conflict;
	private final String conflictDisplay;
	
	public ConflictUI(ConflictDTO conflict) {
		this.conflict = conflict;
		
		StringBuilder sb = new StringBuilder(128);
		//sb.append(this.conflict.getConflictTypeText());
		//sb.append(" - ");
		sb.append(this.conflict.getLeftConflictName());
		sb.append(" / ");
		sb.append(this.conflict.getRightConflictName());
		
		this.conflictDisplay = sb.toString();
	}
	
	public String getConflictDisplay() {
		return this.conflictDisplay;
	}
}
