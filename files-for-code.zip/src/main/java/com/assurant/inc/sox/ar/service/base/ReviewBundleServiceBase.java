package com.assurant.inc.sox.ar.service.base;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.ILockService;
import com.assurant.inc.sox.ar.service.IMetaDataService;
import com.assurant.inc.sox.ar.service.IReviewService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.ar.service.impl.ReviewBundleService;
import com.assurant.inc.sox.dao.ar.IConflictDao;
import com.assurant.inc.sox.dao.ar.IFilterCriteriaDao;
import com.assurant.inc.sox.dao.ar.IReviewBundleDao;
import com.assurant.inc.sox.dao.ar.IReviewDao;
import com.assurant.inc.sox.dao.ar.IReviewQueueDao;
import org.springframework.stereotype.Component;

@Component
public class ReviewBundleServiceBase {

	protected static final Logger logger = LoggerFactory.getLogger(ReviewBundleService.class);

	@Autowired
	protected IReviewBundleDao reviewBundleDao = null;
	@Autowired
	protected IFilterCriteriaDao filterCriteriaDao = null;
	
	@Autowired
	protected IWorkflowService workflowService=null;
	@Autowired
	protected IReviewerService reviewerService = null;
	@Autowired
	protected IMetaDataService metaDataService = null;
	@Autowired
	protected IReviewQueueDao reviewQueueDao = null;
	@Autowired
	protected IReviewService reviewService = null;
	@Resource(name = "savvionITComplianceUserId")
	@Autowired
	private String savvionITComplianceUserId = null;
	@Autowired
	protected IReviewDao reviewDao = null;
	@Autowired
	protected ICodeService codeService;
	@Autowired
	protected ILockService lockService;
	@Autowired
	protected IConflictDao conflictDao;
	
	public static Logger getLogger() {
		return logger;
	}

	public IFilterCriteriaDao getFilterCriteriaDao() {
		return this.filterCriteriaDao;
	}

	public void setFilterCriteriaDao(IFilterCriteriaDao filterCriteriaDao) {
		this.filterCriteriaDao = filterCriteriaDao;
	}

	public IReviewBundleDao getReviewBundleDao() {
		return this.reviewBundleDao;
	}

	public void setReviewBundleDao(IReviewBundleDao reviewBundleDao) {
		this.reviewBundleDao = reviewBundleDao;
	}

	public IReviewerService getReviewerService() {
		return this.reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public void setMetaDataService(IMetaDataService metaDataService) {
		this.metaDataService = metaDataService;
	}

	public IMetaDataService getMetaDataService() {
		return this.metaDataService;
	}

	public IReviewService getReviewService() {
		return reviewService;
	}

	public void setReviewService(IReviewService reviewService) {
		this.reviewService = reviewService;
	}

	public IReviewQueueDao getReviewQueueDao() {
		return reviewQueueDao;
	}

	public void setReviewQueueDao(IReviewQueueDao reviewQueueDao) {
		this.reviewQueueDao = reviewQueueDao;
	}

	public String getSavvionITComplianceUserId() {
		return savvionITComplianceUserId;
	}

	public IReviewDao getReviewDao() {
		return reviewDao;
	}

	public void setReviewDao(IReviewDao reviewDao) {
		this.reviewDao = reviewDao;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

	public ILockService getLockService() {
		return lockService;
	}

	public void setLockService(ILockService lockService) {
		this.lockService = lockService;
	}

	public IConflictDao getConflictDao() {
		return conflictDao;
	}

	public void setConflictDao(IConflictDao conflictDao) {
		this.conflictDao = conflictDao;
	}
	
	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}
}
