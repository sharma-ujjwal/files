package com.assurant.inc.sox.ar.service.impl;

import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.ar.service.util.WorkflowUtil;
import com.assurant.inc.sox.consts.*;
import com.assurant.inc.sox.dto.TaskDTO;
import org.primefaces.shaded.json.JSONArray;
import org.primefaces.shaded.json.JSONException;
import org.primefaces.shaded.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

//import javax.json.JsonArray;

/**
 * Workflow service to wrap the Workflow api calls for create process, retreive tasks, and reassign.
 * @author Ray Carrender
 */
@Service
public class WorkflowService implements IWorkflowService {
	    
    protected static final Logger logger = LoggerFactory.getLogger(WorkflowService.class);
    
    public static Logger getLogger() {
        return logger;
    }
    
    public WorkflowService() {

    }

	/**
	 * Complete a workitem(task) for a give process.
	 * @param taskId
	 */
	public void completeProcess(String taskId, Map<String, Object> variables)  {
		getLogger().debug("completeProcess(processId) --> being executed.");
		WorkflowUtil.completeTask(taskId, variables);
	}

	
	/**
	 * Creates a new workflow task(process) and assigns the tasks to the given user.
	 */
	
	public String createProcess(WorkflowTemplateCode processCode, 
			DataSlotsTemplateCode dataSlotsTemplateCode, String processInstanceNamePrefix,
			String priority, String assignedTo,
			HashMap<String, Object> dataSlots) {
		getLogger().debug("createProcess(processTemplate, processInstanceNamePrefix) assignee: " + assignedTo + " --> being executed.");
		getLogger().debug("processTemplate: " + processCode.toString() + " processInstanceNamePrefix: " + processInstanceNamePrefix);
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put(ITaskValues.PROCESS_TEMPLATE, processCode.toString());
		variables.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX, processInstanceNamePrefix);
		variables.put(ITaskValues.PRIORITY, priority);
		variables.put(ITaskValues.DATASLOTS_ASSIGNEDTO, assignedTo);
		variables.put(ITaskValues.TEMPLATE_CODE, TaskTypeCode.getTaskTypeCodeByDataSlotsTemplateCode(dataSlotsTemplateCode));
		variables.put(ITaskValues.DATASLOTS_TEMPLATECODE, dataSlotsTemplateCode);
		variables.putAll(dataSlots);
//		variables.put("dataSlots", new JSONObject(dataSlots).toString());
		
		String workflowId = WorkflowUtil.createInstance(WorkflowTemplateCode.createProcess, variables);
		return workflowId;
//		List<TaskDTO> taskIds = WorkflowUtil.getTasks(workflowId);
//		String taskId = WorkflowUtil.getTaskId(workflowId);
		
//		getLogger().debug("workflowId: " + workflowId + " taskId: " + taskId);
			
//		String startTaskResults = WorkflowUtil.startTask(taskId);
//		String reassignTask = WorkflowUtil.reassignTask(taskId, WorkflowUtil.username);
//		String completeTaskResults = WorkflowUtil.completeTask(taskId, variables);
//		getLogger().debug("startTaskResults: " + startTaskResults);
//		getLogger().debug("reassignTask: " + reassignTask);
//		getLogger().debug("completeTaskResults: " + completeTaskResults);
//		return taskId;
	}

	public JSONArray retriveProcesses() throws JSONException {
		String results = WorkflowUtil.retrieveProcesses();
		if(!StringUtils.hasText(results)){
			return new JSONArray();
		}
		return new JSONArray(results);
	}
	
	public List<TaskDTO> retriveProcessesBy(String conditionalValue, String jsonKey) throws JSONException {
		JSONArray array = retriveProcesses();
		List<TaskDTO> results = new ArrayList<TaskDTO>();
		getLogger().debug("array.length()" + array.length());
		for(int i=0; i<array.length(); i++){
			JSONObject value0 = (JSONObject)array.get(i);
			JSONObject value = value0.getJSONObject(ITaskValues.VARIABLES);
			getLogger().debug(i + ": " + value0);
			getLogger().debug(i + ": " + value);
			if(conditionalValue.equalsIgnoreCase(value.getString(jsonKey))){
				TaskDTO dto = new TaskDTO();
				dto.setAssignedTo(value.getString(ITaskValues.DATASLOTS_ASSIGNEDTO));
				/*
				 *  Changed below to accomodate WAM Service change.
				 *  Change is requested in Compass Upgrade Validation
				 * */
				 //dto.setProcessId(value0.getJSONObject(ITaskValues.ID).getString(ITaskValues.ID));
				dto.setProcessId(String.valueOf(value0.getInt(ITaskValues.ID)));
				dto.setTaskCode(TaskTypeCode.valueOf(value.getString(ITaskValues.TEMPLATE_CODE)));
				dto.setTaskCreatedDate(new Date(value0.getString(ITaskValues.START_DATE)));
				dto.setTaskDescription(dto.getTaskCode().getDisplay());
				dto.setDataSlots(getDataSlotsFromRetrieveProcess(value));
				if(!value.isNull(ITaskValues.REVIEWERS))
				{	JSONArray arr = new JSONArray(value.getString(ITaskValues.REVIEWERS));
					for(int p=0;p<arr.length();p++){
						JSONObject obj=arr.getJSONObject(p);
						dto.setDataSlots(getDataSlotsFromRetrieveProcess(obj));
					}
				}
				results.add(dto);
			}
		}
		if (results.isEmpty()) {
			
		}
		return results;
	}

	private static Map<String, Object> getDataSlotsFromRetrieveProcess(JSONObject object) throws JSONException {
		Map<String, Object> values = new HashMap<>();
		for (DataSlotCodes code : DataSlotCodes.values()) {
			if (object.has(code.getCode())) {
				var value = code.getCode().equalsIgnoreCase(ITaskValues.DATASLOTS_REASSIGNED) ? object.getBoolean(code.getCode()) : object.getString(code.getCode());
				values.put(code.getCode(), value);
			}
		}
		return values;
	}

	/**
	 * Retrieve all workflow processes assigned to user
	 */
	public List<TaskDTO> retrieveProcessesByAssignedTo(String userId)  {
		getLogger().debug("retrieveProcessesByAssignedTo(userId) userId:" + userId + " --> being executed.");
		List<TaskDTO> results = null;
		try {
			results = retriveProcessesBy(userId, ITaskValues.DATASLOTS_ASSIGNEDTO);
			if (!results.isEmpty()) {
			} else {
			} 
			
			
		} catch (JSONException e) {
			getLogger().error("JSON Error:", e);
		}
		return results;
	}

	/**
	 * Retrieve all workflow processes for the workflow template.
	 */
	public List<TaskDTO> retrieveProcessesByTemplateName(DataSlotsTemplateCode dataSlotsTemplateCode)  {
		getLogger().debug("retrieveProcessesByTemplateName(templateName) templateName: " + dataSlotsTemplateCode + " --> being executed.");
		List<TaskDTO> results = null;
		try {
			results = retriveProcessesBy(dataSlotsTemplateCode.toString(), ITaskValues.DATASLOTS_TEMPLATECODE);
		} catch (JSONException e) {
			getLogger().error("JSON Error:", e);
		}
		return results;
	}

	/**
	 * Update data slots for give workflow process id
	 */ 
	@SuppressWarnings("unchecked")
	public void updateProcessDataSlots(String processId, Map<String, Object> dataSlots)  {
		getLogger().debug("updateProcessDataSlots(Map<String, Object>) workflowId: " + processId + " --> being executed.");
		WorkflowUtil.updateTask(processId, dataSlots);
//		for(Entry<String, Object> entry : dataSlots.entrySet()){
//			WorkflowUtil.createRequest(new StringBuffer().append("/workflowInstance/").append(processId).append("/variables/").append(entry.getKey()).append("?value=").append(entry.getValue()).toString(), HttpMethod.POST, dataSlots);
//		}
	}
	
	public void createBulkProcess(WorkflowTemplateCode processCode,
			String processInstanceNamePrefix,
			String priority, 
			List<HashMap<String, Object>> reviewers) {
		//add for loop here
		//for(HashMap<String, Object> reviewer:reviewers){
		getLogger().debug("createBulkProcess(...) --> being executed.");		
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put(ITaskValues.TEMPLATE_CODE, processCode.toString());
		variables.put(ITaskValues.PROCESS_INSTANCE_NAME_PREFIX, processInstanceNamePrefix);
		variables.put(ITaskValues.PRIORITY, priority);
		
		// AEB Workflow changes start
		//JSONArray reviewersJSONArray=new JSONArray(reviewers);
		JSONArray reviewersJSONArray = new JSONArray();
		for (HashMap<String, Object> reviewer_wfl : reviewers) {
			reviewersJSONArray.put(reviewer_wfl);
		}
		//variables.put("reviewers", reviewers.toString());
		variables.put(ITaskValues.REVIEWERS, reviewersJSONArray.toString());
		//AEB Workflow changes start
		variables.put(ITaskValues.DATASLOTS_ASSIGNEDTO,reviewers.get(0).get(ITaskValues.DATASLOTS_ASSIGNEDTO));
		//variables.put("assignedTo", "ITCompliance");
		variables.put(ITaskValues.DATASLOTS_TEMPLATECODE, DataSlotsTemplateCode.PROCESS_TEMPLATE_NAME_VERIFY);
		variables.put(ITaskValues.TEMPLATE_CODE, TaskTypeCode.REVIEWER_TASK);
		String workflowId = WorkflowUtil.createInstance(WorkflowTemplateCode.createProcess, variables);
		//List<TaskDTO> taskIds = WorkflowUtil.getTasks(workflowId);
			String taskid=WorkflowUtil.getTaskId(workflowId);
		//WorkflowUtil.startTask(taskIds.get(0).getProcessId());
		WorkflowUtil.startTask(taskid);
	}

	/**
	 * Get task id by workflow id.
	 * @param workflowId
	 */
	public String getTaskId(String workflowId)  {
		getLogger().debug("getTaskId(String workflowId) --> being executed.");
		return WorkflowUtil.getTaskId(workflowId);
	}

	
	
}
