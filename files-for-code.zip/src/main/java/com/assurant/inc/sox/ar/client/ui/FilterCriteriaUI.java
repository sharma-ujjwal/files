package com.assurant.inc.sox.ar.client.ui;

import com.assurant.inc.sox.ar.dto.FilterCriteriaDTO;

public class FilterCriteriaUI {

	private final FilterCriteriaDTO filterCriteriaDTO;

	public FilterCriteriaUI(FilterCriteriaDTO filterCriteriaDTO) {
		super();
		this.filterCriteriaDTO = filterCriteriaDTO;
	}

	public FilterCriteriaDTO getFilterCriteriaDTO() {
		return filterCriteriaDTO;
	}

	public String getFilterCriteriaTypeValue() {
	    return filterCriteriaDTO.getFilterCriteriaTypeValue();
    }

	public String getFilterValueName() {
	    return filterCriteriaDTO.getFilterValueName();
    }
	
	
	
}
