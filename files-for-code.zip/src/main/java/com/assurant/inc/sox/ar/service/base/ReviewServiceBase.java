package com.assurant.inc.sox.ar.service.base;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.assurant.inc.sox.ar.dto.SystemUserDTO;
import com.assurant.inc.sox.ar.service.ICodeService;
import com.assurant.inc.sox.ar.service.IReviewBundleService;
import com.assurant.inc.sox.ar.service.IReviewerService;
import com.assurant.inc.sox.ar.service.IWorkflowService;
import com.assurant.inc.sox.ar.service.impl.ReviewService;
import com.assurant.inc.sox.dao.ar.IReviewBundleDao;
import com.assurant.inc.sox.dao.ar.IReviewDao;
import com.assurant.inc.sox.dao.ar.IReviewUserDao;
import com.assurant.inc.sox.dao.ar.IReviewerDao;
import org.springframework.stereotype.Component;

@Component
public class ReviewServiceBase {

	protected static final Logger logger = LoggerFactory.getLogger(ReviewService.class);
	@Autowired
	protected IReviewDao reviewDao = null;
	@Autowired
	private SystemUserDTO sessionSystemUser;
	
	@Autowired
	protected IReviewerService reviewerService = null;
	@Autowired
	protected IReviewBundleDao reviewBundleDao = null;
	@Resource(name = "savvionITComplianceUserId")
	@Autowired
	protected String savvionITComplianceUserId;
	
	@Autowired
	protected IWorkflowService workflowService=null;
	@Autowired
	protected IReviewUserDao reviewUserDao;
	@Autowired
	protected IReviewerDao reviewerDao;
	@Autowired
	protected IReviewBundleService reviewBundleService;
	@Autowired
	protected ICodeService codeService;

	/**
	 * Retrieves the system user from the http session data (note this process binds this app to spring's web support).
	 * 
	 * @return the sessionSystemUser from the http session.
	 */
	public SystemUserDTO getSessionSystemUser() {
		return this.sessionSystemUser;
	}

	/**
	 * Sets the system user from the http session data (note this process binds this app to spring's web support).
	 * 
	 * @param the sessionSystemUser from the http session.
	 */
	public void setSessionSystemUser(SystemUserDTO sessionSystemUser) {
		this.sessionSystemUser = sessionSystemUser;
	}

	public static Logger getLogger() {
		return logger;
	}

	public IReviewDao getReviewDao() {
		return this.reviewDao;
	}

	public void setReviewDao(IReviewDao reviewDao) {
		this.reviewDao = reviewDao;
	}

	public IReviewerService getReviewerService() {
		return reviewerService;
	}

	public void setReviewerService(IReviewerService reviewerService) {
		this.reviewerService = reviewerService;
	}

	public IReviewBundleDao getReviewBundleDao() {
		return reviewBundleDao;
	}

	public void setReviewBundleDao(IReviewBundleDao reviewBundleDao) {
		this.reviewBundleDao = reviewBundleDao;
	}

	public String getSavvionITComplianceUserId() {
		return savvionITComplianceUserId;
	}

	public void setSavvionITComplianceUserId(String savvionITComplianceUserId) {
		this.savvionITComplianceUserId = savvionITComplianceUserId;
	}

	public ICodeService getCodeService() {
		return codeService;
	}

	public IWorkflowService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(IWorkflowService workflowService) {
		this.workflowService = workflowService;
	}

	public void setCodeService(ICodeService codeService) {
		this.codeService = codeService;
	}

	public IReviewUserDao getReviewUserDao() {
		return reviewUserDao;
	}

	public void setReviewUserDao(IReviewUserDao reviewUserDao) {
		this.reviewUserDao = reviewUserDao;
	}

	public IReviewerDao getReviewerDao() {
		return reviewerDao;
	}

	public void setReviewerDao(IReviewerDao reviewerDao) {
		this.reviewerDao = reviewerDao;
	}

	public IReviewBundleService getReviewBundleService() {
		return reviewBundleService;
	}

	public void setReviewBundleService(IReviewBundleService reviewBundleService) {
		this.reviewBundleService = reviewBundleService;
	}
}
