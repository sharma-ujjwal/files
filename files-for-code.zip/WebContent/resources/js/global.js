function clearFilter(idPrifix) {
    let dataTable = PF(idPrifix.concat('Widget'));
    dataTable.clearFilters();

    // Reset the filter dropdown to its default value
    let filterTypeDropdown = document.getElementById('bodyForm:taskListTabPanel:'+idPrifix+'FilterType');
    if (filterTypeDropdown) {
        filterTypeDropdown.selectedIndex = 0; // Reset to the first option
    }

    // Reset the filter value dropdown or input field
    let filterValueDropdown = document.getElementById('bodyForm:taskListTabPanel:'+idPrifix+'FilterValue');
    if (filterValueDropdown) {
        filterValueDropdown.selectedIndex = 0; // Reset to the first option
    }

    let filterTextInput = document.getElementById('bodyForm:taskListTabPanel:'+idPrifix+'FilterTextValue');
    if (filterTextInput) {
        filterTextInput.value = ''; // Clear the text input
    }

    // Optionally, clear any error messages
    let errorMessage = document.getElementById('bodyForm:headerMessages');
    if (errorMessage) {
        errorMessage.innerHTML = ''; // Clear the error message
    }
}