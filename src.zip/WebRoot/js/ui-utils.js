var oldHoverColor;
var oldClickColor;
var lastClickedRow = null;
			
function onHover(row){
	oldHoverColor = row.style.backgroundColor;
	row.style.backgroundColor='#98c2ea';
}
		
function offHover(row){
	if (row != lastClickedRow)
		row.style.backgroundColor = oldHoverColor;
}

function rowClick(row) {
	if (lastClickedRow != null)
		lastClickedRow.style.backgroundColor = oldClickColor;

	oldClickColor = oldHoverColor;
	lastClickedRow = row;
}

function addLoadEvent(func){
	var oldonload = window.onload;
	if (typeof window.onload != 'function'){
		window.onload = func;
	}else{
		window.onload = function(){
			oldonload();
			func();
		}
	}
}
