var infoWindowAMShown = false;
var infoWindowAMTimer;
function showModalInfoWindow(immediate){
	if (immediate){
		Richfaces.showModalPanel('ajaxLoadingModalBox');
		infoWindowAMShown = true;
	}else{
		infoWindowAMTimer = setTimeout("if(!infoWindowAMShown){Richfaces.showModalPanel('ajaxLoadingModalBox');infoWindowAMShown=true;}", 500);
	}
}

function hideModalInfoWindow(){
	if (infoWindowAMShown){
		Richfaces.hideModalPanel('ajaxLoadingModalBox');
		infoWindowAMShown=false;
	}else{
		if(infoWindowAMTimer)
			clearTimeout(infoWindowAMTimer);
	}
}
