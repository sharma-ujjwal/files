

# Claim Interest Calculator Project

*** 

## Overview

Claims Interest was a Visual Basic 6 application with a SQL Server 2016 back end which is getting rebuild using Java Springboot for backend and React from frontend.

The Application is used by both the Individual and Group business divisions to calculate the interest incurred by the business when the payment of a death benefit is delayed beyond the stated range.

## Tools & Tech

1. Java SpringBoot version-3.2.1
2. Gradle version-8.5
3. Java 17


## Pre-work

1. Install Gradle 
2. Configure artifcatory details at root gradle location (for example: C:\Users\Bk87\\.gradle), create a gradle.properties file with below properties:

    ```bash
    artifactory_user=<ACF2 id>
    artifactory_password=<System encrypted password which can be genarted in artifactory>   
    artifactory_contextUrl=https://artifactory.us.sunlife/artifactory    
    systemProp.proxySet=true    
    systemProp.http.proxyHost=proxy-mwg-http.ca.sunlife    
    systemProp.http.proxyPort=8080    
    systemProp.http.proxyUser=<ACF2 id> 
    systemProp.http.proxyPassword=<System password> 
    systemProp.https.proxyHost=proxy-mwg-http.ca.sunlife    
    systemProp.https.proxyPort=8080    
    systemProp.https.proxyUser=<ACF2 id>   
    systemProp.https.proxyPassword=<System password>  
    org.gradle.java.home=<jdk location (for example: C:\\Program Files\\Java\\jdk-17)>
   ```

## Getting Started

1. Clone the repository:

   ```bash
   git ssh://git@bitbucket.us.sunlife/clinca/claims-interest-calculator.git
   cd claims-interest-calculator
   ```

   OR

   ```bash
   git clone https://<ACF2_ID>@bitbucket.us.sunlife/scm/clinca/claims-interest-calculator.git
   cd claims-interest-calculator
   ```

3. Build the project:

   ```bash
   gradle clean build -xtest
   ```   

4. Run individual modules or the entire project based on your requirements.

    

