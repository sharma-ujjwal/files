package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;


/**
 *
 * CicAdminRepo interface as DAO layer for admin_system_t table.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Repository
public interface CicAdminRepo extends JpaRepository<Admin, Integer> {

    List<Admin> findAllByOrderByAdmnSystDscAsc();
}
