package com.sunlife.us.cic.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * Payee entity Class for payee_t DB table.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Entity
@Getter
@Setter
@Table(name = "payee_t")
public class Payee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "paye_id")
    private Integer payeId;
    @Column(name = "clm_id")
    private Integer clmId;
    @Column(name = "calc_st_cd")
    private String calcStCd;
    @Column(name = "paye_full_nm")
    private String payeFullNm;
    @Column(name = "paye_care_of_txt")
    private String payeCareOfTxt;
    @Column(name = "paye_addr_ln1_txt")
    private String payeAddrLn1Txt;
    @Column(name = "paye_addr_ln2_txt")
    private String payeAddrLn2Txt;
    @Column(name = "paye_city_nm_txt")
    private String payeCityNmTxt;
    @Column(name = "paye_st_cd")
    private String payeStCd;
    @Column(name = "paye_zip_cd")
    private String payeZipCd;
    @Column(name = "paye_zip4_cd")
    private String payeZip4Cd;
    @Column(name = "paye_ssn_tin_num")
    private String payeSsnTinNum;
    @Column(name = "paye_ssn_tin_typ_cd")
    private String payeSsnTinTypCd;
    @Column(name = "paye_clm_int_amt")
    private BigDecimal payeClmIntAmt;
    @Column(name = "paye_clm_pd_amt")
    private BigDecimal payeClmPdAmt;
    @Column(name = "paye_dthb_pmt_amt")
    private BigDecimal payeDthbPmtAmt;
    @Column(name = "paye_wthld_amt")
    private BigDecimal payeWthldAmt;
    @Column(name = "paye_clm_int_rt")
    private BigDecimal payeClmIntRt;
    @Column(name = "paye_wthld_rt")
    private BigDecimal payeWthldRt;
    @Column(name = "paye_int_days_pd_num")
    private int payeIntDaysPdNum;
    @Column(name = "paye_pmt_dt")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date payePmtDt;
    @Column(name = "paye_dflt_ovrd_ind")
    private String payeDfltOvrdInd;
    @Column(name = "lst_updt_dtm")
    private Date lstUpdtDtm;
    @Column(name = "lst_updt_user_id")
    private String lstUpdtUserId;
    @Column(name = "paye_1099int_ind")
    private String paye1099IntInd;

}
