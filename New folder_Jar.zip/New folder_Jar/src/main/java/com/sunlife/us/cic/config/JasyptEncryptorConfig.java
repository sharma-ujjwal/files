package com.sunlife.us.cic.config;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 *
 * JasyptEncryptorConfig Class to decrypt secret DB creds.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description JasyptEncryptorConfig Class to decrypt secret DB creds.
 */
@Configuration
public class JasyptEncryptorConfig {



    @Value("${spring.jasypt.encrytion.key}")
    private String passKey;

    /**
     * Bean for JASYPT Code implementaion
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Bean for JASYPT Code implementaion to decrypt secret DB creds.
     * @return decrypted string
     */
    @Bean(name = "jasyptStringEncryptor")
    public StringEncryptor getPasswordEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(passKey); // encryptor's private key
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName("SunJCE");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        config.setStringOutputType("base64");
        encryptor.setConfig(config);
        return encryptor;
    }

}
