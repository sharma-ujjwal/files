package com.sunlife.us.cic.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * CurrentRate is an entity class that represents the CurrentRate table in the database.
 * This class is used to map the CurrentRate table in the database.
 */
@Entity
@Getter
@Setter
@Table(name = "current_rate_t")
public class CurrentRate {
    @Column(name = "curr_int_rt")
    private BigDecimal currIntRt;

    @Id
    @Column(name = "curr_rt_eff_dt")
    private String currRtEffDt;

    @Column(name = "curr_rt_end_dt")
    private String currRtEndDt;


}
