package com.sunlife.us.cic.config;

import com.sunlife.us.cic.repo.CicAuthUserRepo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static com.sunlife.us.cic.common.util.CustomErrors.USER_NOT_FOUND_EXCEPTION;

/**
 * This configuration class is responsible for setting up all the required beans for Authentication
 */
@Configuration
public class AuthProviderJwtConfiguration {

  private final CicAuthUserRepo userRepository;

    public AuthProviderJwtConfiguration(CicAuthUserRepo userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Description: UserDetails Service bean
     * @return
     */
    @Bean
    UserDetailsService userDetailsService() {
        return username -> userRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException(USER_NOT_FOUND_EXCEPTION.getDescription()));
    }

    /**
     * Description:: Used for password encoding
     * @return
     */
    @Bean
    BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    /**
     * Description: AuthenticationManager bean
     * @param config
     * @return
     * @throws Exception
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    /**
     * Description:: Registering Authentication Provider for JWT validation
     * @return
     */
    @Bean
    AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }
}
