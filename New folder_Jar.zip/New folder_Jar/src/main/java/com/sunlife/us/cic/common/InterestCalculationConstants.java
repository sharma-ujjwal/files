package com.sunlife.us.cic.common;

import java.util.Arrays;
import java.util.List;

public class InterestCalculationConstants {
    public static final String PLEASE_SPECIFY = "Please specify the";
    public static final String IN_EFFECT_ON = "in effect on ";
    public static final String TO_USE = " to use ";
    public static final String FOR_THE = " for the ";
    public static final String OF = " of ";
    public static final String CURRENT_LOAN_RATE = " Current Loan Rate ";
    public static final String INTEREST_RATE = " the Interest Rate";
    public static final String DERIVED_RATE_BASED_ON = "The derived Rate based on";
    public static final String CURRENT_RATE_IN_EFFECT_ON = "The Current Rate in effect on ";
    public static final String IS_NOT_DEFINED_SUPPLY_RATE_TO_USE = " is not defined. Please supply the Rate to use ";
    public static final String IS_NEGATIVE_NUMBER_SUPPLY_RATE_TO_USE = " is a negative number. Please supply the Rate to use ";
    public static final String CURRENT_LOAN_RATE_X = "the Current Loan Rate(";
    public static final String CURRENT_RATE_X = " the Current Rate(";
    public static final String CLOSE_PAREN_MINUS = ") - ";
    public static final String CLOSE_PAREN_PLUS = ") + ";
    public static final String STATE_RULE_AMOUNT_X = " the State Rule Amount(";
    public static final String CLOSE_PAREN = ") ";
    public static final String THE_MAX_OF = " the maximum of ";
    public static final String THE_MIN_OF = " the minimum of ";
    public static final String THE_GREATER_OF = " the greater of ";
    public static final String AND = " and ";
    public static final String CALC_STATE = "calc state";
    public static final String INSURED_RESIDENCE_STATE = "insured residence state";
    public static final String PAYEE_STATE = "payee state";
    public static final String ISSUE_STATE = "contract issue state";
    public static final String COMPACT_CALCULATION = "compact calculation";
    public static final String ZZ_STATE_CODE = "zz";
    public static final String N_INDICATOR = "N";
    public static final String T_INDICATOR = "T";
    public static final String YY_STATE_CODE = "YY";
    public static final int GROUP_ADMIN_SYSTEM_CODE = 10;
    public static final String CLAIM_INTEREST_RATE = "claimInterestRate";
    public static final String NO_INTEREST_PAID_MESSAGE = "No interest was paid as the claim was paid on or before the Payable Period End Date. ";
    public static final String INTEREST_CALCULATION_MESSAGE = "The interest rate was calculated based on the rates for the ";
    public static final String INTEREST_CALCULATION_MESSAGE_TEMPLATE = "The claim interest rate was calculated based on the rates for the %s. The # of days (%d) was based on %s to %s";
    public static final String INTEREST_MESSAGE_FOR_ZZ_STATE = "Individual rates were not found for the state of ZZ as of %s . The calculations cannot be done.";
    public static final String NONE = "NONE";
    public static final String REQUIRED_ID_TYPE_CODE_PROOF = "PROOF";
    public static final String STATE_RULE_AMOUNT = "State Rule Amount";

    //irule codes
    public static final String CURLN = "CURLN";
    public static final String CURLN_PLUS_X = "CURLN+X";
    public static final String CURLN_MINUS_X = "CURLN-X";
    public static final String CLNW_MAX = "CLNW/MAX";
    public static final String CLNW_MIN = "CLNW/MIN";
    public static final String CURRT = "CURRT";
    public static final String CURRT_PLUS_X = "CURRT+X";
    public static final String CURRT_MINUS_X = "CURRT-X";
    public static final String CRTW_MAX = "CRTW/MAX";
    public static final String CRTW_MIN = "CRTW/MIN";
    public static final String GTCLN_X = "GTCLN&X";
    public static final String GTCRT_LN = "GTCRT&LN";
    public static final String GTCRT_AND_X = "GTCRT&X";
    public static final String SPECAMT = "SPECAMT";
    public static final String PROMPT = "PROMPT";

    //anomaly states
    public static final String ANOMALY_STATE_AR = "AR";
    public static final String ANOMALY_STATE_FL = "FL";
    public static final String ANOMALY_STATE_IN = "IN";
    public static final String ANOMALY_STATE_IL = "IL";
    public static final String ANOMALY_STATE_MA = "MA";
    public static final String ANOMALY_STATE_BLANK = " ";


    public static final String MCSTR_GROUP_LOB = "G";
    public static final String MCSTR_INDIVIDUAL_LOB = "I";
    public static final String MCSTR_GROUP_TIER_2_LOB = "H";
    public static final String MCSTR_INDIVIDUAL_TIER_2_LOB = "J";
    public static final String PROOFDTH = "PROOFDTH";
    public static final String PROOF = REQUIRED_ID_TYPE_CODE_PROOF;
    public static final String DEATH = "DEATH";
    public static final String AMOUNT = "AMOUNT";

    // create list of string of: CURLN, CURLN+X, CURLN-X, CLNW/MAX, CLNW/MIN, GTCRT&LN
    public static final List<String> LOAN_IRULE_CODES = List.of(CURLN, CURLN_PLUS_X, CURLN_MINUS_X, CLNW_MAX, CLNW_MIN, GTCLN_X, GTCRT_LN);

    // create list of: CURRT, CURRT+X, CURRT-X, CRTW/MAX, CRTW/MIN, GTCRT&X, GTCRT&LN
    public static final List<String> INTERST_RATE_IRULE_CODES = List.of(CURRT, CURRT_PLUS_X, CURRT_MINUS_X, CRTW_MAX, CRTW_MIN, GTCRT_AND_X, GTCRT_LN);

    public static Boolean isAnomolyState(String stateCode) {
        return Arrays.asList(ANOMALY_STATE_AR, ANOMALY_STATE_FL, ANOMALY_STATE_IN, ANOMALY_STATE_IL, ANOMALY_STATE_MA, ANOMALY_STATE_BLANK).contains(stateCode);
    }


}
