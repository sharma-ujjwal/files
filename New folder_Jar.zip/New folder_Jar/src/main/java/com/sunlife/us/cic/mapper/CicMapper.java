package com.sunlife.us.cic.mapper;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.*;
import com.sunlife.us.cic.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper(componentModel = "spring")
public interface CicMapper {
    CicMapper INSTANCE = Mappers.getMapper( CicMapper.class );

    @Mapping(target = "clmForResDthInd", expression = "java(mapClmForResDthInd(claim))")
    @Mapping(target = "clmCompactClcnInd", expression = "java(mapClmCompactClcnInd(claim))")
    ClaimDTO mapclaim(Claim claim);

    AdminDTO mapAdmin(Admin admin);

    @Mapping(target = "clmId", ignore = true)
    List<PayeeDTO> mapPayee(List<Payee> payee);

    @Mapping(target = "payeDfltOvrdInd", expression = "java(mapBooleanToYesNoString(payeeDTO.getPayeDfltOvrdInd()))")
    @Mapping(target = "paye1099IntInd", expression = "java(mapBooleanToYesNoString(payeeDTO.getPaye1099IntInd()))")
    Payee mapPayeeDTO(PayeeDTO payeeDTO);

    PayorDTO mapPayor(Payor payor);

    @Mapping(target = "stCompactClcnAllowInd", expression = "java(mapCompactFilingAllowed(state))")
    StateDTO mapState(State state);

    @Mapping(target = "clmInsdFirstNm", expression = "java(mapTrimSpace(claimDTO.getClmInsdFirstNm()))")
    @Mapping(target = "clmInsdLastNm", expression = "java(mapTrimSpace(claimDTO.getClmInsdLastNm()))")
    @Mapping(target = "clmPolNum", expression = "java(mapTrimSpace(claimDTO.getClmPolNum()))")
    @Mapping(target = "clmNum", expression = "java(mapTrimSpace(claimDTO.getClmNum()))")
    @Mapping(target = "issStCd", expression = "java(mapTrimSpace(claimDTO.getIssStCd()))")
    @Mapping(target = "clmInsdSsnNum", expression = "java(mapTrimSpace(claimDTO.getClmInsdSsnNum()))")
    Claim mapClaimDTO(ClaimDTO claimDTO);

    default Boolean mapClmForResDthInd(Claim claim) {
        return claim.getClmForResDthInd().equalsIgnoreCase(CicConstants.YES_Y);
    }

    default Boolean mapClmCompactClcnInd(Claim claim) {
        return claim.getClmCompactClcnInd().equalsIgnoreCase(CicConstants.TRUE_T);
    }

    default Boolean mapCompactFilingAllowed(State state) {
        return state.getStCompactClcnAllowInd().equalsIgnoreCase(CicConstants.TRUE_T);
    }

    default String mapBooleanToYesNoString(Boolean value) {
        return value?CicConstants.YES_Y:CicConstants.NO_N;
    }

    default String mapTrimSpace(String data) {
        return data != null? data.trim(): null;
    }

    @Mapping(target = "payeDfltOvrdInd", expression = "java(mapPayeDfltOvrdInd(payee))")
    @Mapping(target = "paye1099IntInd", expression = "java(mapPaye1099IntInd(payee))")
    PayeeDTO mapPayee(Payee payee);

    default Boolean mapPayeDfltOvrdInd(Payee payee) {
        return payee.getPayeDfltOvrdInd().equalsIgnoreCase(CicConstants.YES_Y);
    }

    default Boolean mapPaye1099IntInd(Payee payee) {
        return payee.getPaye1099IntInd().equalsIgnoreCase(CicConstants.YES_Y);
    }

}
