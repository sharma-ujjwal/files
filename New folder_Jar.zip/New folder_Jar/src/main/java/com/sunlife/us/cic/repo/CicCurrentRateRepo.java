package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.CurrentRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.Optional;

public interface CicCurrentRateRepo extends JpaRepository<CurrentRate, String> {

    @Query(value = "SELECT * FROM current_rate_t WHERE curr_rt_eff_dt = (SELECT MAX(curr_rt_eff_dt) FROM current_rate_t WHERE curr_rt_eff_dt <= ?1)", nativeQuery = true)
    Optional<CurrentRate> findCurrentRate(Date payePmtDt);
}
