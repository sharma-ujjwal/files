package com.sunlife.us.cic.controller;


import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.ReportsUtil;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.model.GenerateTaxFileReportsDTO;
import com.sunlife.us.cic.model.ReportsDTO;
import com.sunlife.us.cic.service.CicReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * CicReportController class
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */

@RestController
@RequestMapping("v1/interestcalculator/report")
@Slf4j
public class CicReportController {

    @Autowired
    private final CicReportService reportService;

    public CicReportController(CicReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * This is a standard method to generate PDF report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return ResponseEntity InputStreamResource
     */
    @GetMapping("/pdf")
    @Operation(summary = "Generate PDF Report", description = "Generate PDF Report")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<InputStreamResource> generatePdfReport() {
        InputStreamResource pdfReport = reportService.generatePdfReport();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData(CicConstants.FILENAME, CicConstants.REPORTS_PDF);
        headers.setCacheControl(CicConstants.CACHE_CONTROL);
        return new ResponseEntity<>(pdfReport, headers, HttpStatus.OK);
    }

    /**
     * This is a standard method to generate PDF report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param reportsDTO
     * @return ResponseEntity<InputStreamResource>
     */
    @PostMapping("/printReport")
    @Operation(summary = "Print Report", description = "Print Report")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<InputStreamResource> printReport(@RequestBody ReportsDTO reportsDTO) {

        List<Errors> errorMessages = ReportsUtil.validateReportDates(reportsDTO);

        if (!errorMessages.isEmpty()) {
            throw new InvalidRequestException(errorMessages.stream()
                    .map(Errors::getErrorMessage)
                    .collect(Collectors.joining(", ")));
        }

        InputStreamResource pdfReport = reportService.printReport(reportsDTO);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData(CicConstants.FILENAME, CicConstants.REPORTS_PDF);
        headers.setCacheControl(CicConstants.CACHE_CONTROL);
        return new ResponseEntity<>(pdfReport, headers, HttpStatus.OK);
    }

    /**
     * This is a standard method to generate Tax File
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param generateTaxFileReportsDTO
     * @return ResponseEntity<String>
     */
    @PostMapping("/generateTaxFile")
    @Operation(summary = "Generate Tax File", description = "Generate Tax File")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<String> generateTaxFile(@RequestBody GenerateTaxFileReportsDTO generateTaxFileReportsDTO) {
        String taxFile = reportService.generateTaxFile(generateTaxFileReportsDTO);
        return ResponseEntity.ok(taxFile);
    }

    /**
     * This is a standard method to get Tax Files
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param viewNonPR
     * @param viewPR
     * @return ResponseEntity<Resource>
     */
    @GetMapping("/taxFiles")
    @Operation(summary = "Get Tax Files", description = "Get Tax Files")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<Resource> getTaxFiles(@RequestParam(required = false) String viewNonPR, @RequestParam(required = false) String viewPR){
        String taxFiles;
        if (viewNonPR != null) {
            taxFiles = reportService.getTaxFiles(true, false);
        } else if (viewPR != null) {
            taxFiles = reportService.getTaxFiles(false, true);
        } else {
            throw new InvalidRequestException(CicConstants.VIEWNONPR_OR_VIEWPR_NOTSELECTED);
        }

        ByteArrayResource resource = new ByteArrayResource(taxFiles.getBytes());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        headers.setContentDispositionFormData(CicConstants.FILENAME, CicConstants.TAX_FILE_NAME);
        headers.setCacheControl(CicConstants.CACHE_CONTROL);

        return new ResponseEntity<>(resource, headers, HttpStatus.OK);
    }

    /**
     * Description: This is a standard method to print Individual Report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param claimId
     * @return ResponseEntity<InputStreamResource>
     * @throws IOException
     */
    @GetMapping("/printIndividualReport")
    @Operation(summary = "Print Individual Report", description = "Print Individual Report")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<InputStreamResource> printIndividualReports(@RequestParam("claimId") int claimId) throws IOException {
        InputStreamResource pdfReport = reportService.printIndividualReports(null, claimId);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData(CicConstants.FILENAME, CicConstants.REPORTS_PDF);
        headers.setCacheControl(CicConstants.CACHE_CONTROL);
        return new ResponseEntity<>(pdfReport, headers, HttpStatus.OK);
    }

}
