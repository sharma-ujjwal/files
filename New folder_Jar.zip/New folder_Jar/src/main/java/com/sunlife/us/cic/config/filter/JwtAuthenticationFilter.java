package com.sunlife.us.cic.config.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunlife.us.cic.handler.exceptions.JwtTokenInvalidException;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.User;
import com.sunlife.us.cic.service.impl.JwtService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

import java.io.IOException;

import static com.sunlife.us.cic.common.CicConstants.CONTENT_TYPE;
import static com.sunlife.us.cic.common.SecurityConstants.*;
import static com.sunlife.us.cic.common.util.CustomErrors.JWT_TOKEN_INVALID_EXCEPTION;


/**
 * This Security Filter class validates the JWT token before moving to the SAML2 login
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final HandlerExceptionResolver handlerExceptionResolver;

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    public JwtAuthenticationFilter(
            JwtService jwtService,
            UserDetailsService userDetailsService,
            HandlerExceptionResolver handlerExceptionResolver
    ) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
        this.handlerExceptionResolver = handlerExceptionResolver;
    }

    /**
     * Description:: Internal Filter to verify the token and proceed with request
     * @param request
     * @param response
     * @param filterChain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain
    ) throws ServletException, IOException {
        final String authHeader = request.getHeader(AUTH_HEADER);

        if (authHeader == null || !authHeader.startsWith(BEARER_TOKEN)) {
            filterChain.doFilter(request, response);
            return;
        }
        try {
            final String jwt = authHeader.substring(7);
            final String userName = jwtService.extractUsername(jwt);
            Claims claims = jwtService.extractAllClaims(jwt);
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (userName != null && authentication == null) {
                User userDetails = new User();
                userDetails.setUserName(userName);
                userDetails.setEmail((String) claims.get(EMAIL));
                userDetails.setRole((String) claims.get(ROLE));
                if (jwtService.isTokenValid(jwt, userDetails)) {
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null,
                            userDetails.getAuthorities()
                    );

                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                }
            }
            filterChain.doFilter(request, response);
        } catch (Exception exception) {
            constructFilterResponseObject(response);
        }
    }

    /**
     * Description: Required to construct a JSON Error object thrown from Filter
     * @param object
     * @return
     * @throws JsonProcessingException
     */
    public String convertObjectToJson(Object object) throws JsonProcessingException {
        if (object == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);
    }

    /**
     * Description: This is very specific to the above filter class throwing JWT exceptions. Responsible to throw the error in JSON Format
     * @param response
     * @throws IOException
     */
    public void constructFilterResponseObject(HttpServletResponse response) throws IOException {
        GenericResponseDTO responseDTO = new GenericResponseDTO();
        responseDTO.setCode(JWT_TOKEN_INVALID_EXCEPTION.getCode());
        responseDTO.setMessage(JWT_TOKEN_INVALID_EXCEPTION.getDescription());
        responseDTO.setErrorType(JWT_TOKEN_INVALID_EXCEPTION.getErrorType());
        responseDTO.setErrorDetails(null);
        responseDTO.setReturnCode(String.valueOf(HttpStatus.UNAUTHORIZED.value()));
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(CONTENT_TYPE);
        response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
        response.getWriter().write(convertObjectToJson(responseDTO));
    }
}