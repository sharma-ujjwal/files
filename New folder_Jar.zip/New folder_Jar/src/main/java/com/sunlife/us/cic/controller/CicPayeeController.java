package com.sunlife.us.cic.controller;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.RequestUtil;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.InstructionsDTO;
import com.sunlife.us.cic.model.PayeeDTO;
import com.sunlife.us.cic.model.ViewPayeeResponse;
import com.sunlife.us.cic.service.CicPayeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import java.math.BigDecimal;
import java.util.Date;

@RestController
@RequestMapping("v1/interestcalculator/payee")
@Slf4j
public class CicPayeeController {

    @Autowired
    private CicPayeeService cicPayeeService;

    /**
     * Description deletePayee API is used to delete the payee information.
     * deletePayee API Contoller Code implementaion
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return ResponseEntity of GenericResponseDTO
     * @param payeId
     * @throws InvalidRequestException
     */

    @DeleteMapping("/{payeId}")
    @Operation(method = "deletePayee", summary = "Delete by payee id for Payee", description = "Delete payee information.")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<GenericResponseDTO> deletePayee(@NotNull @PathVariable("payeId")int payeId, HttpServletRequest request) {
        log.info("deletePayee API called : " + payeId);
        RequestUtil.checkForSpecialCharactersInPathParam(request);
        if(payeId == 0) {
            log.error("InvalidRequestException thrown : " + payeId);
            throw new InvalidRequestException(CicConstants.INVALIDPAYEEID + payeId);
        }

        log.info("deletePayee API ended : " + payeId);
        return ResponseEntity.ok(cicPayeeService.deletePayee(payeId));
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description addPayee API is used to add the payee information.
     * addPayee API Contoller Code implementaion
     * @return ResponseEntity of GenericResponseDTO
     * @param payeeDTO
     */
    @PostMapping()
    @Consumes("application/json")
    @Operation(summary = "Add Payee", description = "Add Payee information.")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<PayeeDTO> addPayee(@Valid @RequestBody PayeeDTO payeeDTO, HttpServletRequest request) {
        log.info("addInsurer API called");
        return ResponseEntity.ok(cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * Description editPayee API is used to edit the payee information.
     * editPayee API Contoller Code implementaion
     * @author <a href="ankit.kumar@sunlife.com" >Ankit Kumar(BV26)</a>
     * @return ResponseEntity of GenericResponseDTO
     * @throws InvalidRequestException
     */
    @PatchMapping()
    @Consumes("application/json")
    @Operation(summary = "Edit Payee", description = "Edit Payee information.")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<PayeeDTO> editPayee(@Valid @RequestBody PayeeDTO payeeDTO,HttpServletRequest request){
        log.info("editPayee API called");
        return ResponseEntity.ok(cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * Description viewPayee API is used to view the payee information.
     * viewPayee API Contoller Code implementaion
     * @return ResponseEntity of GenericResponseDTO
     * @param claimId
     * @throws InvalidRequestException
     */
    @GetMapping()
    @Operation(method = "viewPayee", summary = "View by payee id for Payee", description = "View payee information.")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<ViewPayeeResponse> viewPayee(@NotNull @Min(value = 1, message = "The value must be greater than 0") @PathParam("claimId") int claimId, HttpServletRequest request) {

        log.info("viewPayee API called : " + claimId);
        return ResponseEntity.ok(cicPayeeService.viewPayee(claimId));
    }

    @GetMapping("/{clmId}")
    @Operation(method = "getInstructionByStcd", summary = "Get instruction by state code", description = "Get instruction by state code.")
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<InstructionsDTO> getInstructionByStCd(
            @NotNull @Min(value = 1, message = "The value must be greater than 0") @PathVariable("clmId") int clmId,
            @RequestParam("payeStCd") String payeStCd,
            @RequestParam("payeResStCd") String payeResStCd,
            @RequestParam("calcStCd") String calcStCd,
            @RequestParam("issueStCd") String issueStCd,
            @RequestParam("payePmtDt") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date payePmtDt,
            @RequestParam("paymentAmount") BigDecimal paymentAmount) {

        log.info("getInstructionByStcd API called : " + clmId);

        return ResponseEntity.ok(cicPayeeService.getInstructionsFromStCd(clmId, payeStCd, payeResStCd, calcStCd, issueStCd, payePmtDt, paymentAmount));
    }
}
