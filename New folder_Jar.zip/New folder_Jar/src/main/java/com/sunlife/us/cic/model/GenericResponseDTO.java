package com.sunlife.us.cic.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * ErrorMessage Class for GlobalExceptionHandler.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 */
@Getter
@Setter
@NotNull
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GenericResponseDTO {

    private String returnCode;
    private String code = "";
    private String message = "";
    private String errorType = "";
    private String states = "";
    private List<Errors> errorDetails = new ArrayList<>();
}
