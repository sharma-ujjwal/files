package com.sunlife.us.cic.service;

import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.InstructionsDTO;
import com.sunlife.us.cic.model.PayeeDTO;
import com.sunlife.us.cic.model.ViewPayeeResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;

/**
 * CicPayeeService Interface.
 * @author <a href="mailto:megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 * Description This interface is used to define the methods for the Payee service layer.
 */
@Component
public interface CicPayeeService {

    GenericResponseDTO deletePayee(int payeId);

    PayeeDTO addPayee(PayeeDTO payeeDTO);

    ViewPayeeResponse viewPayee(int claimId);

    PayeeDTO editPayee(PayeeDTO payeeDTO);

    InstructionsDTO getInstructionsFromStCd(int clmId, String payeStCd, String payeResStCd, String calcStCd, String issueStCd, Date payePmtDt, BigDecimal paymentAmount);
}
