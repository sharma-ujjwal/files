package com.sunlife.us.cic.handler;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.handler.exceptions.*;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * GlobalExceptionHandler Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This class will handle all the exceptions thrown by the application
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when any internal code exception occurs
     */
    @ExceptionHandler({GlobalException.class})
    public ResponseEntity<GenericResponseDTO> globalException(GlobalException e) {
        if (e.getMessage().contains(CicConstants.ARITHMATIC_EXCEPTION)) {
            return createResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf((CustomErrors.SQL_GRAMMAR_EXCEPTION.getCode())), CustomErrors.SQL_GRAMMAR_EXCEPTION.getDescription(), CustomErrors.SQL_GRAMMAR_EXCEPTION.getErrorType());
        }
        return createResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf((CustomErrors.GLOBAL_EXCEPTION.getCode())), e.getMessage(), CustomErrors.GLOBAL_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when data not found exception occurs
     */
    @ExceptionHandler({DataNotFoundException.class})
    public ResponseEntity<GenericResponseDTO> handleDataNotFoundException(DataNotFoundException e) {
        return createResponseEntity(HttpStatus.NOT_FOUND, String.valueOf(CustomErrors.DATA_NOT_FOUND_EXCEPTION.getCode()), e.getMessage(), CustomErrors.DATA_NOT_FOUND_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when custom validation fails for any request parameter
     */
    @ExceptionHandler({InvalidRequestException.class})
    public ResponseEntity<GenericResponseDTO> handleInvalidRequestException(InvalidRequestException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.INVALID_REQUEST_EXCEPTION.getCode())), e.getMessage(), CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
    }

    /**
     * handleJsonExceptions method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description This method will be triggered when JSON validation fails
     */
    @ExceptionHandler({JsonException.class})
    public ResponseEntity<GenericResponseDTO> handleJsonExceptions(JsonException e) {
        return createErrorDetailsResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.JSON_EXCEPTION.getCode())), e.getMessage(), CustomErrors.JSON_EXCEPTION.getErrorType(),e.getErrorMessageList());
    }

    /**
     * handleApiNotFoundException method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description This method will be triggered when API not found exception occurs
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler({ApiNotFoundException.class})
    public ResponseEntity<GenericResponseDTO> handleApiNotFoundException(ApiNotFoundException e) {
        return createResponseEntity(HttpStatus.NOT_FOUND, String.valueOf((CustomErrors.API_NOT_FOUND_EXCEPTION.getCode())), e.getMessage(), CustomErrors.API_NOT_FOUND_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when unauthorized exception occurs
     */
    @ExceptionHandler({UnauthorizedException.class})
    public ResponseEntity<GenericResponseDTO> handleUnauthorizedException(UnauthorizedException e) {
        return createResponseEntity(HttpStatus.NOT_FOUND, String.valueOf((CustomErrors.UNAUTHORIZED_EXCEPTION.getCode())), e.getMessage(), CustomErrors.UNAUTHORIZED_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when state of API(like paramenters) different from expectd
     */
    @ExceptionHandler(value
            = { IllegalStateException.class})
    public ResponseEntity<GenericResponseDTO> handleIllegalStateException(RuntimeException e) {
        return createResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf((CustomErrors.ILLEGAL_STATE_EXCEPTION.getCode())), CustomErrors.GLOBAL_EXCEPTION.getDescription(), CustomErrors.ILLEGAL_STATE_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when illegal argument exception occurs
     */
    @ExceptionHandler(value = {IllegalArgumentException.class} )
    public ResponseEntity<GenericResponseDTO> handleIllegalArgumentException(RuntimeException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.INVALID_REQUEST_EXCEPTION.getCode())), CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription(), CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when user interest rate not provided exception occurs
     */
    @ExceptionHandler(value = {UserInterestRateNotProvidedException.class})
    public ResponseEntity<GenericResponseDTO> handleUserInterestRateNotProvidedException(UserInterestRateNotProvidedException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.USER_INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getCode())), e.getMessage(), CustomErrors.USER_INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getErrorType());
    }

    /**
     * handleCompactRateNotProvidedException method.
     * Description This method will be triggered when compact rate not provided exception occurs
     */
    @ExceptionHandler(value = {CompactRateNotProvidedException.class})
    public ResponseEntity<GenericResponseDTO> handleCompactRateNotProvidedException(CompactRateNotProvidedException e) {
        String[] parts = e.getMessage().split("\\|");
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((parts[1])), parts[0], CustomErrors.COMPACT_RATE_NOT_PROVIDED_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when loan rate not provided exception occurs
     */
    @ExceptionHandler(value = {LoanRateNotProvidedException.class})
    public ResponseEntity<GenericResponseDTO> handleLoanRateNotProvidedException(LoanRateNotProvidedException e) {
        String[] parts = e.getMessage().split("\\|");
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((parts[1] +"|"+parts[2])), parts[0], CustomErrors.LOAN_RATE_NOT_PROVIDED_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when interest rate not provided exception occurs
     */
    @ExceptionHandler(value = {CompactDateException.class})
    public ResponseEntity<GenericResponseDTO> handleCompactDateException(CompactDateException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.COMPACT_DATE_EXCEPTION.getCode())), e.getMessage(), CustomErrors.COMPACT_DATE_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when interest rate not provided exception occurs
     */
    @ExceptionHandler(value = {InterestRateNotProvidedException.class})
    public ResponseEntity<GenericResponseDTO> handleInterestRateNotProvidedException(InterestRateNotProvidedException e) {
        String[] parts = e.getMessage().split("\\|");
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((parts[1]+"|"+parts[2])), parts[0], CustomErrors.INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getErrorType());
    }

    @ExceptionHandler(value = {EOFException.class} )
    public ResponseEntity<GenericResponseDTO> handleEOFException(RuntimeException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.INVALID_REQUEST_EXCEPTION.getCode())), CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription(), CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
    }


    /**
     *  handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when data type of arguement is different from expectd
     */
    @ExceptionHandler(value
            = { MethodArgumentTypeMismatchException.class})
    public ResponseEntity<GenericResponseDTO> handleArgurmentException(RuntimeException e) {
        return createResponseEntity(HttpStatus.BAD_REQUEST, String.valueOf((CustomErrors.INVALID_REQUEST_EXCEPTION.getCode())), CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription(), CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
    }

    /**
     * handleMethodArgumentNotValid method.
     * Description This method will be triggered when user not found exception occurs
     */
    @ExceptionHandler(SQLGrammarException.class)
    public ResponseEntity<GenericResponseDTO> handleSQLGrammarException(SQLGrammarException ex) {
        // Check if the error is due to arithmetic overflow
        if (ex.getSQLException().getMessage().contains(CicConstants.ARITHMATIC_EXCEPTION)) {
            return createResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf((CustomErrors.SQL_GRAMMAR_EXCEPTION.getCode())), CustomErrors.SQL_GRAMMAR_EXCEPTION.getDescription(), CustomErrors.SQL_GRAMMAR_EXCEPTION.getErrorType());
        }
        return createResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf((CustomErrors.SQL_GRAMMAR_EXCEPTION.getCode())), "SQL Exception", CustomErrors.SQL_GRAMMAR_EXCEPTION.getErrorType());
    }

    /**
     * handleHttpMessageNotReadable method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description This method will be triggered when invalid request exception occurs
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        errorMessage.setCode(String.valueOf(CustomErrors.INVALID_REQUEST_EXCEPTION.getCode()));
        errorMessage.setErrorType(CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
        errorMessage.setMessage(CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription());
        errorMessage.setReturnCode(String.valueOf(status.value()));
        return new ResponseEntity<>(errorMessage, status);
    }

    /**
     *  handleMethodArgumentNotValid method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when invalid arguemwnt exception occurs
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        List<Errors> errorsList = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach((error) ->{
            String fieldName = ((FieldError) error).getField();
            String message = error.getDefaultMessage();
            Errors errors = new Errors();
            errors.setFieldName(fieldName);
            errors.setErrorMessage(fieldName + CicConstants.WHITE_SPACE + message);
            errorsList.add(errors);
        });
        errorMessage.setErrorDetails(errorsList);
        errorMessage.setCode(String.valueOf(CustomErrors.INVALID_REQUEST_EXCEPTION.getCode()));
        errorMessage.setErrorType(CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
        errorMessage.setMessage(CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription());
        errorMessage.setReturnCode(String.valueOf(status.value()));
        return new ResponseEntity<>(errorMessage, status);
    }

    /**
     *  handleNoHandlerFoundException method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be triggered when API not found exception occurs
     */
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(
            NoHandlerFoundException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        errorMessage.setCode(String.valueOf(CustomErrors.API_NOT_FOUND_EXCEPTION.getCode()));
        errorMessage.setErrorType(CustomErrors.API_NOT_FOUND_EXCEPTION.getErrorType());
        errorMessage.setMessage(CustomErrors.API_NOT_FOUND_EXCEPTION.getDescription());
        errorMessage.setReturnCode(String.valueOf(status.value()));
        return new ResponseEntity<>(errorMessage, status);
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     *  handleHandlerMethodValidationException method.
     *  This method will be triggered when validation fails for any request parameter
     */
    @Override
    protected ResponseEntity<Object> handleHandlerMethodValidationException(
                    HandlerMethodValidationException ex,
                    HttpHeaders headers,
                    HttpStatusCode status,
                    WebRequest request) {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        errorMessage.setCode(String.valueOf(CustomErrors.INVALID_REQUEST_EXCEPTION.getCode()));
        errorMessage.setErrorType(CustomErrors.INVALID_REQUEST_EXCEPTION.getErrorType());
        errorMessage.setMessage(ex.getReason());
        errorMessage.setReturnCode(String.valueOf(status.value()));
        return new ResponseEntity<>(errorMessage, status);
    }

    /**
     *  createResponseEntity method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method will be called by above handle methods and will create a response entity according to exception
     */
    private ResponseEntity<GenericResponseDTO> createResponseEntity(HttpStatus httpStatus, String responseCode, String message, String errrorType)    {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        if(errrorType.equalsIgnoreCase(CustomErrors.LOAN_RATE_NOT_PROVIDED_EXCEPTION.getErrorType()) || errrorType.equalsIgnoreCase(CustomErrors.INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getErrorType())){
            String[] parts = responseCode.split("\\|");
            errorMessage.setCode(parts[0]);
            errorMessage.setStates(parts[1]);
        } else {
            errorMessage.setCode(responseCode);
        }
        errorMessage.setMessage(message);
        errorMessage.setErrorType(errrorType);
        errorMessage.setReturnCode(String.valueOf(httpStatus.value()));
        return ResponseEntity.status(httpStatus).body(errorMessage);
    }

    /**
     *  createErrorDetailsResponseEntity method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description This method will be called by above handle methods and will create a Error Details response entity according to exception
     */
    private ResponseEntity<GenericResponseDTO> createErrorDetailsResponseEntity(HttpStatus httpStatus, String responseCode, String message, String errrorType, List<Errors> errorMessageList)    {
        GenericResponseDTO errorMessage = new GenericResponseDTO();
        errorMessage.setCode(responseCode);
        errorMessage.setMessage(message);
        errorMessage.setErrorType(errrorType);
        errorMessage.setErrorDetails(errorMessageList);
        errorMessage.setReturnCode(String.valueOf(httpStatus.value()));
        return ResponseEntity.status(httpStatus).body(errorMessage);
    }
}