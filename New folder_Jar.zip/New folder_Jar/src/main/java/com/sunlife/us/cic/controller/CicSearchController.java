package com.sunlife.us.cic.controller;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.common.util.RequestUtil;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.handler.exceptions.JsonException;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import com.sunlife.us.cic.service.CicSearchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.checkerframework.checker.units.qual.C;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * CicSearchController.
 * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description Controller class for searchInsurer API
 * */
@RestController
@RequestMapping("v1/interestcalculator/search")
@Slf4j
public class CicSearchController {

    @Autowired
    CicSearchService cicSearchService;


    /**
     * searchInsurer API Contoller Code implementaion
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Controller Search insurer claim information from claim_t table.
     * @param searchInput, searchField, pageNumber, pageSize
     * @return ResponseEntity of ViewInsurerResponse
     */
    @GetMapping()
    @Operation(method = "searchInsurer", summary = "Search by claim id for Insurer", description = "Search insurer claim information." )
    @ResponseStatus(code = HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Success")
    public ResponseEntity<ViewInsurerResponse> searchInsurer(@Param(CicConstants.SEARCH_INPUT) String searchInput, @Param(CicConstants.SEARCH_FIELD) String searchField,
    @Param(CicConstants.PAGE_NUMBER_VAR) int pageNumber, @Param(CicConstants.PAGEP_SIZE_VAR) int pageSize, HttpServletRequest request){
        log.info("searchInsurer API called");
        List<Errors> errorsList = new ArrayList<>();
        RequestUtil.validateStringInput(CicConstants.SEARCH_INPUT, searchInput, errorsList);
        RequestUtil.validateStringInput(CicConstants.SEARCH_FIELD, searchField, errorsList);
        RequestUtil.validateIntegerInput(CicConstants.PAGE_NUMBER_VAR, pageNumber, errorsList);
        RequestUtil.validateIntegerInput(CicConstants.PAGEP_SIZE_VAR, pageSize, errorsList);
        if(!errorsList.isEmpty()){
            log.error("Invalid request");
            throw new JsonException(CustomErrors.JSON_EXCEPTION.getDescription(), errorsList);
        }
        if(searchField.equalsIgnoreCase("name") && searchInput != "" && !searchInput.matches(CicConstants.INSURED_NAME_REGEX)){
            log.error("Invalid request");
            throw new InvalidRequestException("Invalid Request: Should not contain special characters");
        } else if (!searchField.equalsIgnoreCase("name"))
            RequestUtil.checkForSpecialCharacters(request);
        searchInput = searchInput.trim();
        searchField = searchField.trim();
        ViewInsurerResponse viewInsurerResponse = cicSearchService.searchInsurer(searchInput, searchField, pageNumber, pageSize);
        if(viewInsurerResponse.getClaimsList().isEmpty())
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(viewInsurerResponse);
        return ResponseEntity.ok(viewInsurerResponse);
    }
}
