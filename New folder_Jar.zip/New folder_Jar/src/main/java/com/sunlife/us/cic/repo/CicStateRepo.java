package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.State;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * CicStateRepo interface as DAO layer for state_t table.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This interface is used to interact with the state_t table in the database.
 */
@Repository
public interface CicStateRepo extends JpaRepository<State, String> {

}
