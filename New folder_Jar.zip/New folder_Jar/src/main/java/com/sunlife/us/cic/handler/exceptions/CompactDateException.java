package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

public class CompactDateException extends RuntimeException {
    public CompactDateException() {
        super(CustomErrors.COMPACT_DATE_EXCEPTION.getDescription());
    }
    public CompactDateException(String message) {
        super(message);
    }
    public CompactDateException(String message, Throwable cause) {
        super(message, cause);
    }
    public CompactDateException(Throwable cause) {
        super(cause);
    }
}
