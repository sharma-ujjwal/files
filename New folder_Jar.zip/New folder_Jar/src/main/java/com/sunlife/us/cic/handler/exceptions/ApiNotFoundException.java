package com.sunlife.us.cic.handler.exceptions;

/**
 *
 * ApiNotFoundException Class.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
import com.sunlife.us.cic.common.util.CustomErrors;

public class ApiNotFoundException extends RuntimeException{

    public ApiNotFoundException() {
        super(CustomErrors.API_NOT_FOUND_EXCEPTION.getDescription());
    }
    public ApiNotFoundException(final String message) {
        super(message);
    }

    public ApiNotFoundException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public ApiNotFoundException(final Throwable cause) {
        super(cause);
    }
}
