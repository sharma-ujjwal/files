package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 * UserInterestRateNotProvidedException is a custom exception class that extends RuntimeException.
 * This exception is thrown when the user interest rate is not provided.
 */
public class UserInterestRateNotProvidedException extends RuntimeException{

    public UserInterestRateNotProvidedException() {
        super(CustomErrors.USER_INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getDescription());
    }
    public UserInterestRateNotProvidedException(String message) {
        super(message);
    }
    public UserInterestRateNotProvidedException(String message, Throwable cause) {
        super(message, cause);
    }
    public UserInterestRateNotProvidedException(Throwable cause) {
        super(cause);
    }
}
