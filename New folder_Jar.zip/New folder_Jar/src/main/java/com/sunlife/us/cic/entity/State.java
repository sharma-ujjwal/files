package com.sunlife.us.cic.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.sql.Date;

/**
 *
 * State entity Class for state_t DB table.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 *
 * */
@Entity
@Getter
@Setter
@Table(name = "state_t")
public class State  {

    @Id
    @Column(name = "st_cd")
    private String stateCd;

    @Column(name = "st_domcl_cd")
    private String stDomclCd;

    @Column(name = "st_dsc")
    private String stDsc;

    @Column(name = "lst_updt_dtm")
    private Date lstUpdtDtm;

    @Column(name = "lst_updt_user_id")
    private String lstUpdtUserId;

    @Column(name = "st_compact_clcn_allow_ind")
    private String stCompactClcnAllowInd;
}
