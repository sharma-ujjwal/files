package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.common.util.CustomErrors;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * JsonException Class.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
public class JsonException extends RuntimeException{

    private List<Errors> errorMessageList = new ArrayList<>();

    public JsonException(List<Errors> errorMessageList) {
        super(CustomErrors.JSON_EXCEPTION.getDescription());
        this.errorMessageList = errorMessageList;
    }
    public JsonException(final String message) {
        super(message);
    }

    public JsonException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public JsonException(final Throwable cause) {
        super(cause);
    }

    public JsonException(final String message, final List<Errors> errorMessageList) {
        super(message);
        this.errorMessageList = errorMessageList;
    }

    public List<Errors> getErrorMessageList() {
        return errorMessageList;
    }

    public void setErrorMessageList(List<Errors> errorMessageList) {
        this.errorMessageList = errorMessageList;
    }
}
