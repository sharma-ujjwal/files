package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;

/**
 * AdminDTO Class for mapping to Admin entity.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Getter
@Setter
public class AdminDTO implements java.io.Serializable {
    private String admnSystDsc;
    private String admnSystCd;
    private String admnSystIdMinLgthNum;
    private String admnSystIdMaxLgthNum;
}
