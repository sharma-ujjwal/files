package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;


/**
 * A Simple model class representing the output post SAML assertion
 */
@Getter
@Setter
public class LoginResponse {
    private String token;
    private long expiresIn;
}
