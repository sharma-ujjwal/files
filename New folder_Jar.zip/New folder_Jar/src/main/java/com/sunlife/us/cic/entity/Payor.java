package com.sunlife.us.cic.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

/**
 *
 * Payor entity Class for payor_company_type_t DB table.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Entity
@Getter
@Setter
@Table(name = "payor_company_type_t")
public class Payor {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name = "pyco_typ_cd")
    private String pycoTypCd;
    @Column(name = "pyco_typ_dsc")
    private String pycoTypDsc;
    @Column(name = "lst_updt_dtm")
    private Date lstUpdtDtm;
    @Column(name = "lst_updt_user_id")
    private String lstUpdtUserId;

}
