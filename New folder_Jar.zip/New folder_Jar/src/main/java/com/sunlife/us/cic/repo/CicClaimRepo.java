package com.sunlife.us.cic.repo;


import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.model.CustomClaimPaymentReportDTO;
import com.sunlife.us.cic.model.IndividualReportDTO;
import com.sunlife.us.cic.model.ReportsDTO;
import com.sunlife.us.cic.model.StateInterestReportDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 *
 * CicClaimsRepo interface as DAO layer for claim_t table.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This interface is used to interact with the claim_t table in the database.
 */
@Repository
public interface CicClaimRepo extends JpaRepository<Claim, Integer> {

    /**
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method is used to find the claim by polic number.
     * @param policyNumber
     * @param pageable
     * @return Page-Claim
     */
    @Query(value = "select * from claim_t t where CHARINDEX(?1, clm_pol_num) > 0", nativeQuery = true)
    Page<Claim> findByPolicyNumberRegex(String policyNumber, Pageable pageable);

    /**
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method is used to find the claim by firstname or lastname.
     * @param name
     * @param pageable
     * @return Page-Claim
     */
    @Query(value = "select * from claim_t t where CHARINDEX(?1, clm_insd_first_nm + ' ' + clm_insd_last_nm) > 0 ", nativeQuery = true)
    Page<Claim> findByClmInsdFirstNmRegexOrClmInsdLastNmRegex(String name, Pageable pageable);

    /**
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method is used to find the claim by ssn.
     * @param ssn
     * @param pageable
     * @return Page-Claim
     */
    @Query(value = "select * from claim_t t where CHARINDEX(?1, clm_insd_ssn_num) > 0", nativeQuery = true)
    Page<Claim> findByClmInsdSsnNumRegex(String ssn, Pageable pageable);

    /**
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: This method is used to find the claim by polic number.
     * @param clmPolNum
     * @return Optional-Object
     */
    Optional<List<Claim>> findByClmPolNum(String clmPolNum);

	/**
	 * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: This method is used to find the claim by polic number and insured ssn number.
	 * @param clmPolNum
	 * @param clmInsdSsnNum
	 * @return Optional-Object
	 */
	Optional<List<Claim>> findByClmPolNumAndClmInsdSsnNum(String clmPolNum, String clmInsdSsnNum);

    /**
     * Description: This method is used to get the claim details for the given date range and lob code.
     * @author <a href="mailto:megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param fromDate
     * @param toDate
     * @param lobCd
     * @return List-StateInterestReportDTO
     */
    @Query(value = """
			 SELECT P.paye_st_cd as payeStCd,
				P.paye_full_nm as payeeName,
				C.clm_num as claimNumber,
				P.paye_clm_pd_amt as totals,
				P.paye_clm_int_amt as claimInterest,
				P.paye_pmt_dt as dateOfPayment,
				count(*) OVER (PARTITION BY P.paye_st_cd) as numberOfClaims,
				SUM(P.paye_clm_pd_amt)  OVER (PARTITION BY P.paye_st_cd) as totalPaid,
				SUM(P.paye_clm_int_amt)  OVER (PARTITION BY P.paye_st_cd) as interestAmount
			 FROM		claim_t				C
			 INNER JOIN 	payee_t				P	ON C.clm_id = P.clm_id
			 INNER JOIN dbo.admin_system_t 	AST	ON C.admn_syst_cd = AST.admn_syst_cd
			 WHERE P.paye_pmt_dt BETWEEN :fromDate AND :toDate AND AST.lob_cd IN (:lobCd)
			 ORDER BY P.paye_st_cd;""", nativeQuery = true)
    List<StateInterestReportDTO> getStateInterestDetails(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("lobCd") List<String> lobCd);

    @Query(value = """
            SELECT  C.clm_id as clmId
                ,insuredName = convert(varchar(102),(C.clm_insd_first_nm))
                ,UPPER((C.lst_updt_user_id)) As  lstUpdUserId
                ,P.paye_full_nm as payeFullNm
                ,P.paye_clm_int_amt as payeClmIntAmt
                ,P.paye_clm_pd_amt as payeClmPdAmt
                ,P.paye_wthld_amt as payeWthldAmt
                ,P.paye_pmt_dt as payePmtDt
            	,SUM(P.paye_clm_int_amt) OVER (PARTITION BY C.clm_id) as totalClaimInterest
            	,SUM(P.paye_wthld_amt) OVER (PARTITION BY C.clm_id) as totalInterestWithheld
            	,SUM(P.paye_clm_pd_amt) OVER (PARTITION BY C.clm_id) as totalPaid
            FROM        claim_t             C
            INNER JOIN  payee_t             P   ON C.clm_id = P.clm_id
            INNER JOIN dbo.admin_system_t   AST ON C.admn_syst_cd = AST.admn_syst_cd
            WHERE P.paye_pmt_dt BETWEEN :fromDate AND :toDate AND AST.lob_cd IN (:lobCd)
            ORDER BY C.clm_id
            """,nativeQuery = true)
    List<CustomClaimPaymentReportDTO> getCustomClaimPaymentDetails(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("lobCd") List<String> lobCd);


    @Procedure(name = "dbo.proc_tax_file_layout_generate")
    List<Object[]> proc_tax_file_layout_generate(@Param("paye_pmt_dt_from_date") Date payePmtDtFromDate, @Param("paye_pmt_dt_to_date") Date payePmtDtToDate);

	/**
	 * Description: This method is used to get the claim and payee details for the given claim id for individual report generation.
	 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
	 * @param clmId
	 * @return List-IndividualReportDTO
	 */
    @Query(value = """
					SELECT  C.clm_id
					,C.clm_num
					,C.clm_pol_num
					,AST.admn_syst_dsc
					,PCT.pyco_typ_dsc
					,calcInsuredFullName = convert(varchar(102),
		CASE
			WHEN ISNULL(C.clm_insd_first_nm, '') <> '' THEN C.clm_insd_first_nm + ' ' + C.clm_insd_last_nm
			ELSE C.clm_insd_last_nm
		END)
					,C.clm_insd_dth_dt
					,C.clm_proof_dt
					,C.clm_tot_dthb_pmt_amt
					,C.clm_tot_int_amt
					,C.clm_tot_clm_pd_amt
					,C.clm_tot_wthld_amt
					,calcInsdDthResStCd = convert(char(17),
		CASE
			WHEN (C.CLM_FOR_RES_DTH_IND = 'Y')			THEN '(foreign address)'
			ELSE C.insd_dth_res_st_cd
		END)
					,C.iss_st_cd
					,C.clm_insd_ssn_num
					,P.paye_full_nm
					,P.paye_addr_ln1_txt
					,P.paye_addr_ln2_txt
					,P.paye_city_nm_txt
					,P.paye_st_cd
					,P.calc_st_cd
					,calcPayeZipCd = convert(char(10),
		CASE
			WHEN (ISNULL(P.paye_zip4_cd,'') <> '')		THEN P.paye_zip_cd + '-' + P.paye_zip4_cd
			ELSE P.paye_zip_cd
		END)
					,P.paye_care_of_txt
					,P.paye_ssn_tin_num
					,P.paye_clm_int_amt
					,P.paye_clm_pd_amt
					,P.paye_dthb_pmt_amt
					,P.paye_clm_int_rt
					,P.paye_wthld_rt
					,P.paye_wthld_amt
					,P.paye_pmt_dt
					,P.paye_int_days_pd_num
					,calcPayeDfltOvrdInd = convert(char(12),
		CASE
			WHEN (P.PAYE_DFLT_OVRD_IND = 'Y')			THEN '(overridden)'
			ELSE ''
		END)
	
								FROM claim_t					C
								LEFT OUTER JOIN payee_t			P		ON	C.clm_id = P.clm_id
								INNER JOIN admin_system_t		AST		ON	C.admn_syst_cd = AST.admn_syst_cd
								INNER JOIN payor_company_type_t	PCT		ON	C.pyco_typ_cd = PCT.pyco_typ_cd
								WHERE C.clm_id = :clmId
												""",nativeQuery = true)
    List<IndividualReportDTO> getIndividualReport(@Param("clmId") Integer clmId);

}