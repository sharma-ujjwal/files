package com.sunlife.us.cic.service;

import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.model.ClaimDTO;
import com.sunlife.us.cic.model.ClaimFormDataDTO;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 *
 * CicClaimsService Interface.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description: This interface is used to define the methods for the claim service layer.
 */
@Component
public interface CicClaimService {
/**
	 * Method to view insurer interface
	 * Description Interface Method which will be implemented to view insurer data from claim table
	 * @return ViewInsurerResponse
	 */
	ViewInsurerResponse viewInsurer(int pageNumber, int pageSize);

	/**
	 * Method to delete insurer interface
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description Interface Method which will be implemented to delete insurer data from claim table
	 * @param claimId
	 * @return GenericResponseDTO
	 */
	GenericResponseDTO deleteInsurer(int claimId);

	ViewInsurerResponse getInsurer(int claimId);

    ClaimFormDataDTO getClaimFormData(Integer claimId);

    GenericResponseDTO addInsurer(ClaimDTO claimDTO, Admin admin);
	GenericResponseDTO editInsurer(ClaimDTO claimDTO, Admin admin);

    Optional<Admin> findAdminById(Integer admnSystCd);
}
