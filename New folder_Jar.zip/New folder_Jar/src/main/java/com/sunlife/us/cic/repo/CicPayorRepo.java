package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.Payor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 *
 * CicPayorRepo interface as DAO layer for payor_company_type_t table.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Repository
public interface CicPayorRepo extends JpaRepository<Payor, String> {

    List<Payor> findAllByOrderByPycoTypDscAsc();
}
