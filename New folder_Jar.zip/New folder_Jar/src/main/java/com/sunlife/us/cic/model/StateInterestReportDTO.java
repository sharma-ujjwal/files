package com.sunlife.us.cic.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Description: StateInterestReportDTO Interface
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
public interface StateInterestReportDTO {

     String getPayeStCd();
     String getPayeeName();
     BigDecimal getTotals();
     String getClaimNumber();
     String getClaimInterest();
     Date getDateOfPayment();
     BigDecimal getNumberOfClaims();
     BigDecimal getInterestAmount();
     BigDecimal getTotalPaid();

}
