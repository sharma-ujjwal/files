package com.sunlife.us.cic.model;


import lombok.Getter;
import lombok.Setter;

/**
 * Description: Response DTO for logged in user details
 */
@Getter
@Setter
public class AuthInfoDTO {

    private String acf2Id;
    private String email;
    private String role;
}
