package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.InterestCalculationConstants;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.common.util.InterestCalculationUtil;
import com.sunlife.us.cic.entity.*;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.*;
import com.sunlife.us.cic.mapper.CicMapper;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.repo.*;
import com.sunlife.us.cic.repo.CicClaimRepo;
import com.sunlife.us.cic.repo.CicPayeeRepo;
import com.sunlife.us.cic.repo.CicStateRepo;
import com.sunlife.us.cic.service.CicPayeeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class CicPayeeServiceImpl implements CicPayeeService {

    @Autowired
    private CicPayeeRepo cicPayeeRepo;

    @Autowired
    private CicStateRepo cicStateRepo;

    @Autowired
    private CicClaimRepo cicClaimRepo;

    @Autowired
    private CicStateRuleRepo cicStateRuleRepo;

    @Autowired
    private CicCurrentRateRepo cicCurrentRateRepo;

    @Autowired
    private CicAdminRepo cicAdminRepo;

    @Autowired
    InterestCalculationUtil interestCalculationUtil;

    @Autowired
    CacheUpdater cacheUpdater;


    /**
     * Description deletePayee API serviceImpl Code implementation
     * deletePayee API serviceImpl Code implementaion
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return GenericResponseDTO (message, code and returncode)
     * @param payeId
     * @throws DataNotFoundException
     * @throws GlobalException
     */
    @Override
    public GenericResponseDTO deletePayee(int payeId) {
        log.info("deleteInsurer Implementation called : " + payeId);
        GenericResponseDTO genericResponse = new GenericResponseDTO();
        try {
            Payee payee = cicPayeeRepo.findById(payeId).orElseThrow(() -> new DataNotFoundException(CicConstants.PAYEENOTFOUND + payeId));
            cicPayeeRepo.deleteById(payeId);

            // Update claim data
            Claim claim = cicClaimRepo.findById(payee.getClmId()).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + payee.getClmId()));
            updateClaimData(payee.getClmId(), claim);

            // Update cache data
            CompletableFuture.runAsync(() -> {
                cacheUpdater.deleteCache(claim);
            });
            genericResponse.setMessage(CicConstants.PAYEEDELETEDSUCCESSFULLY + payeId);
            genericResponse.setReturnCode(HttpStatus.OK.toString());
            genericResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
        }
        catch (DataNotFoundException e){
            log.error("DataNotFoundException thrown : " + e.getMessage());
            throw new DataNotFoundException(e.getMessage());
        }
        catch (Exception e){
            log.error("Exception thrown : " + e.getMessage());
            throw new GlobalException(e.getMessage());
        }
        log.info("deleteInsurer Implementation ended : " + payeId);
        return genericResponse;
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description viewPayee API serviceImpl Code implementation
     * viewPayee API serviceImpl Code implementation
     * @return ViewPayeeResponse (payeeList, totalCount, code and returncode)
     * @param claimId
     * @throws DataNotFoundException
     * @throws GlobalException
     */
    @Override
    public ViewPayeeResponse viewPayee(int claimId) {
        log.info("viewPayee Implementation called : " + claimId);
        ViewPayeeResponse viewPayeeResponse = new ViewPayeeResponse();
        try {
            cicClaimRepo.findById(claimId).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + claimId));
            List<Payee> payeeEntities = cicPayeeRepo.findByClmId(claimId);
            if (payeeEntities.isEmpty()) {
                throw new DataNotFoundException(CicConstants.PAYEE_NOT_FOUND_FOR_CLAIM + claimId);
            }
            List<PayeeDTO> payeeList = CicMapper.INSTANCE.mapPayee(payeeEntities);
            viewPayeeResponse.setPayeeList(payeeList);
            viewPayeeResponse.setTotalCount(cicPayeeRepo.count());
            viewPayeeResponse.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
            viewPayeeResponse.setReturnCode(HttpStatus.OK.toString());
        }
        catch (DataNotFoundException e){
            log.error("DataNotFoundException thrown : " + e.getMessage());
            throw new DataNotFoundException(e.getMessage());
        }
        catch (Exception e){
            log.error("Exception thrown : " + e.getMessage());
            throw new GlobalException(e.getMessage());
        }
        log.info("viewPayee Implementation ended : " + claimId);
        return viewPayeeResponse;
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description addPayee API serviceImpl Code implementation
     * addPayee API serviceImpl Code implementaion
     * @return GenericResponseDTO (message, code and returncode)
     * @param payeeDTO
     * @throws InvalidRequestException
     * @throws GlobalException
     */
    @Override
    @Transactional
    public PayeeDTO addPayee( PayeeDTO payeeDTO) {
        log.info("addPayee Implementation called");
        PayeeDTO payeeDTOResponse = new PayeeDTO();
        try {
            PayeeDTO finalPayeeDTO = payeeDTO;
            Claim claim = cicClaimRepo.findById(payeeDTO.getClmId()).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + finalPayeeDTO.getClmId()));
            ZZStateCheck(payeeDTO, claim);
            if(cicPayeeRepo.findByPayeFullNmAndClmId(payeeDTO.getPayeFullNm(), payeeDTO.getClmId()).isPresent()){
                throw new InvalidRequestException(CicConstants.NAME_ALREADY_EXISTS+payeeDTO.getPayeFullNm()+CicConstants.POLICY_NUMBER_LABEL+claim.getClmPolNum().trim()+CicConstants.NAME_ALREADY_EXISTS_LINE_2);
            }

            // part of interest calculation
            StateRule stateRule = interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt());
            Optional<CurrentRate> currentRate = cicCurrentRateRepo.findCurrentRate(payeeDTO.getPayePmtDt());

            List<Errors> errorList = new ArrayList<>();
            compactRateCheck(payeeDTO, claim, payeeDTO.getPayeStCd());
            stateRuleCheck(payeeDTO, claim, currentRate, errorList);

            CurrentRate currentRate1 = new CurrentRate();
            currentRate1.setCurrIntRt(payeeDTO.getCurrentInterestRate());

            Optional<Admin> admin = cicAdminRepo.findById(claim.getAdmnSystCd());

            interestCalculationUtil.setAdmin(admin.get());
            interestCalculationUtil.setPayeeDTO(payeeDTO);
            interestCalculationUtil.setClaim(claim);
            interestCalculationUtil.setStateRule(stateRule);
            interestCalculationUtil.setCurrentRate(!currentRate.isEmpty()?currentRate.get():currentRate1);
            payeeDTO = interestCalculationUtil.CalcClaimInterest(errorList);

            // logic to save payee
            Payee payeeEntity = CicMapper.INSTANCE.mapPayeeDTO(payeeDTO);

            addPayeeInputDataDBValidation(payeeDTO);
            payeeEntity.setPayeDfltOvrdInd(payeeDTO.getPayeDfltOvrdInd() ? CicConstants.YES_Y : CicConstants.NO_N);
            payeeEntity.setPaye1099IntInd(payeeDTO.getPaye1099IntInd() ? CicConstants.YES_Y : CicConstants.NO_N);
            payeeEntity.setLstUpdtDtm(new Date());
            payeeEntity.setLstUpdtUserId(getLoggedInUserAcf2Id());
            Payee generatedPayee = cicPayeeRepo.save(payeeEntity);

            //update claim data
            updateClaimData(generatedPayee.getClmId(), claim);

            // Update cache data
            CompletableFuture.runAsync(() -> {
                cacheUpdater.deleteCache(claim);
            });

            payeeDTOResponse = CicMapper.INSTANCE.mapPayee(generatedPayee);
            payeeDTOResponse.setMessage(CicConstants.PAYEE_ADDED + generatedPayee.getPayeId());
            payeeDTOResponse.setReturnCode(HttpStatus.OK.toString());
            payeeDTOResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
            payeeDTOResponse.setErrorDetails(errorList);
            payeeDTOResponse.setInterestCalculationMessage(payeeDTO.getInterestCalculationMessage());
            payeeDTOResponse.setCalcStateMsg(payeeDTO.getCalcStateMsg());

        }
        catch (InvalidRequestException e) {
            log.error("InvalidRequestException thrown : "+ e.getMessage());
            throw new InvalidRequestException(e.getMessage());
        }
        catch (LoanRateNotProvidedException e) {
            log.error("LoanRateNotProvidedException thrown : "+ e.getMessage());
            throw new LoanRateNotProvidedException(e.getMessage());
        }
        catch (UserInterestRateNotProvidedException e) {
            log.error("UserInterestRateNotProvidedException thrown : "+ e.getMessage());
            throw new UserInterestRateNotProvidedException(e.getMessage());
        }
        catch (CompactRateNotProvidedException e) {
            log.error("CompactRateNotProvidedException thrown : "+ e.getMessage());
            throw new CompactRateNotProvidedException(e.getMessage());
        }
        catch (InterestRateNotProvidedException e) {
            log.error("InterestRateNotProvidedException thrown : "+ e.getMessage());
            throw new InterestRateNotProvidedException(e.getMessage());
        }
        catch (CompactDateException e) {
            log.error("CompactDateException thrown : "+ e.getMessage());
            throw new CompactDateException(e.getMessage());
        }
        catch (Exception e){
            log.error("Exception thrown : " + e.getMessage());
            throw new GlobalException(e.getMessage());
        }
        log.info("addPayee Implementation ended : " + payeeDTO);
        return payeeDTOResponse;
    }

    private void ZZStateCheck(PayeeDTO payeeDTO, Claim claim) {
        if (claim.getIssStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE)
                || (!StringUtils.isEmpty(claim.getInsdDthResStCd()) && claim.getInsdDthResStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE))
                || (payeeDTO.getPayeDfltOvrdInd() != null && payeeDTO.getPayeDfltOvrdInd()  && !StringUtils.isEmpty(payeeDTO.getCalcStCd()) && payeeDTO.getCalcStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE))) {
            String interestCalculationMessage = String.format(
                    InterestCalculationConstants.INTEREST_MESSAGE_FOR_ZZ_STATE,
                    interestCalculationUtil.formatDate(new Date())
            );
            throw new InvalidRequestException(interestCalculationMessage);
        }
    }

    private static void CurrentRateCheck(Optional<CurrentRate> currentRate, PayeeDTO payeeDTO, Claim claim, String payeeDTO1, StateRule promptStateRule) {
        if(promptStateRule != null && InterestCalculationConstants.INTERST_RATE_IRULE_CODES.contains(promptStateRule.getIruleCd().trim())) {
            if (currentRate.isEmpty() && !payeeDTO.getPayeDfltOvrdInd() && !payeeDTO.getCurrentInterestRateProvided()) {
                throw new UserInterestRateNotProvidedException("Current Rate not found for the given date. Please provide the current rate.");
            } else if (!payeeDTO.getCurrentInterestRateProvided() && !currentRate.isEmpty() && currentRate.get().getCurrIntRt().compareTo(BigDecimal.valueOf(0.0)) < 0 && !payeeDTO.getPayeDfltOvrdInd()) {
                throw new UserInterestRateNotProvidedException("In effect on " + payeeDTO.getPayePmtDt() + " is a negative number. Please supply a rate to use");
            }
        }
    }

    private static void compactRateCheck(PayeeDTO payeeDTO, Claim claim, String payeeDTO1 ) {
        if (!payeeDTO.getCompactInterestRateProvided() && !payeeDTO.getPayeDfltOvrdInd()) {
            String compactResponseCode = "";
            if (claim.getClmCompactClcnInd().equalsIgnoreCase("T")) {
                compactResponseCode += "10019" ;
            }
            if (payeeDTO1.equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE)) {
                compactResponseCode += compactResponseCode.isEmpty() ? "10020" : "," + "10020";
            }
            if(!StringUtils.isEmpty(compactResponseCode))
                throw new CompactRateNotProvidedException("Please specify the interest rate for compact calculation of YY. |" + compactResponseCode);
        }
    }

    public void updateClaimData(Integer clmId, Claim claim) {
        claim.setClmTotIntAmt(cicPayeeRepo.sumPayeClmIntAmtByClmId(clmId) != null?cicPayeeRepo.sumPayeClmIntAmtByClmId(clmId).setScale(2, RoundingMode.HALF_UP):BigDecimal.valueOf(0.0));
        claim.setClmTotWthldAmt(cicPayeeRepo.sumPayeWthldAmtByClmId(clmId) != null ? cicPayeeRepo.sumPayeWthldAmtByClmId(clmId).setScale(2, RoundingMode.HALF_UP):BigDecimal.valueOf(0.0));
        claim.setClmTotClmPdAmt(cicPayeeRepo.sumPayeClmPdAmtByClmId(clmId) != null? cicPayeeRepo.sumPayeClmPdAmtByClmId(clmId).setScale(2, RoundingMode.HALF_UP):BigDecimal.valueOf(0.0));
        claim.setClmTotDthbPmtAmt(cicPayeeRepo.sumPayeDthbPmtAmtByClmId(clmId) != null ? cicPayeeRepo.sumPayeDthbPmtAmtByClmId(clmId).setScale(2, RoundingMode.HALF_UP):BigDecimal.valueOf(0.0));
        claim.setLstUpdtDtm(new Date());
        cicClaimRepo.save(claim);
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description addPayeeInputDataDBValiadtion API serviceImpl Code implementation
     * Description: This method is used to validate state code from DB.
     * @param payeeDTO
     * @throws InvalidRequestException
     */
    private void addPayeeInputDataDBValidation(PayeeDTO payeeDTO) {
        cicStateRepo.findById(payeeDTO.getPayeStCd()).orElseThrow(() ->
                new InvalidRequestException(CicConstants.STATE_NOT_FOUND + CicConstants.COLON_SPACING + payeeDTO.getPayeStCd()));
    }

    /**
     * Description getLoggedInUserAcf2Id is used to get the logged in user acf2 id.
     * @author <a href="ankit.kumar2@sunlife.com">Ankit Kumar(BV26)</a>
     * @return
     */
    private String getLoggedInUserAcf2Id(){
        return ((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

    }

    /**
     * editPayee API serviceImpl Code implementaion
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * @return GenericResponseDTO (message, code and returncode)
     * @throws InvalidRequestException
     * @throws DataNotFoundException
     * @throws GlobalException
     */
    @Override
    @Transactional
    public PayeeDTO editPayee(PayeeDTO payeeDTO) {
        log.info("editPayee Implementation called");
        PayeeDTO payeeDTOResponse = new PayeeDTO();
        PayeeDTO finalPayeeDTO = payeeDTO;
        try {
            Payee payee = cicPayeeRepo.findById(payeeDTO.getPayeId()).orElseThrow(() -> new DataNotFoundException(CicConstants.PAYEENOTFOUND + finalPayeeDTO.getPayeId()));
            Claim claim = cicClaimRepo.findById(payeeDTO.getClmId()).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + finalPayeeDTO.getClmId()));
            ZZStateCheck(payeeDTO, claim);
            if (!payeeDTO.getPayeFullNm().equals(payee.getPayeFullNm()) && cicPayeeRepo.findByPayeFullNmAndClmId(payeeDTO.getPayeFullNm(), payeeDTO.getClmId()).isPresent()) {
                throw new InvalidRequestException(CicConstants.NAME_ALREADY_EXISTS + payeeDTO.getPayeFullNm() + CicConstants.POLICY_NUMBER_LABEL + claim.getClmPolNum().trim() + CicConstants.NAME_ALREADY_EXISTS_LINE_2);
            }
            StateRule stateRule = interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt());
            Optional<CurrentRate> currentRate = cicCurrentRateRepo.findCurrentRate(payeeDTO.getPayePmtDt());

            List<Errors> errorList = new ArrayList<>();
            compactRateCheck(payeeDTO, claim, payeeDTO.getPayeStCd());
            stateRuleCheck(payeeDTO, claim, currentRate, errorList);

            CurrentRate currentRate1 = new CurrentRate();
            currentRate1.setCurrIntRt(payeeDTO.getCurrentInterestRate());
            Optional<Admin> admin = cicAdminRepo.findById(claim.getAdmnSystCd());
            interestCalculationUtil.setAdmin(admin.get());
            interestCalculationUtil.setPayeeDTO(payeeDTO);
            interestCalculationUtil.setClaim(claim);
            interestCalculationUtil.setStateRule(stateRule);
            interestCalculationUtil.setCurrentRate(!currentRate.isEmpty()?currentRate.get():currentRate1);

            // Interest Calculation***********
            payeeDTO = interestCalculationUtil.CalcClaimInterest(errorList);
            Payee  updatedPayee= CicMapper.INSTANCE.mapPayeeDTO(payeeDTO);
            cicStateRepo.findById(payeeDTO.getPayeStCd()).orElseThrow(() -> new InvalidRequestException(CicConstants.STATE_NOT_FOUND+CicConstants.COLON_SPACING+ finalPayeeDTO.getPayeId()));
            updatedPayee.setLstUpdtDtm(new Date());
            updatedPayee.setLstUpdtUserId(getLoggedInUserAcf2Id());
            Payee generatedPayee = cicPayeeRepo.save(updatedPayee);

            //update claim data
            updateClaimData(generatedPayee.getClmId(), claim);

            // Update cache data
            CompletableFuture.runAsync(() ->{
                cacheUpdater.deleteCache(claim);
            });

            payeeDTOResponse = CicMapper.INSTANCE.mapPayee(generatedPayee);
            payeeDTOResponse.setMessage(CicConstants.PAYEE_UPDATED);
            payeeDTOResponse.setReturnCode(HttpStatus.OK.toString());
            payeeDTOResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
            payeeDTOResponse.setErrorDetails(errorList);
            payeeDTOResponse.setInterestCalculationMessage(payeeDTO.getInterestCalculationMessage());
            payeeDTOResponse.setCalcStateMsg(payeeDTO.getCalcStateMsg());

        }
        catch(DataNotFoundException e){
            log.error("DataNotFoundException thrown : "+e.getMessage());
            throw new DataNotFoundException(e.getMessage());
        }
        catch (LoanRateNotProvidedException e) {
            log.error("LoanRateNotProvidedException thrown : "+ e.getMessage());
            throw new LoanRateNotProvidedException(e.getMessage());
        }
        catch (UserInterestRateNotProvidedException e) {
            log.error("UserInterestRateNotProvidedException thrown : "+ e.getMessage());
            throw new UserInterestRateNotProvidedException(e.getMessage());
        }
        catch (InvalidRequestException e){
            log.error("InvalidRequestException thrown: "+e.getMessage());
            throw new InvalidRequestException(e.getMessage());
        }
        catch (CompactRateNotProvidedException e) {
            log.error("CompactRateNotProvidedException thrown : "+ e.getMessage());
            throw new CompactRateNotProvidedException(e.getMessage());
        }
        catch (InterestRateNotProvidedException e) {
            log.error("InterestRateNotProvidedException thrown : "+ e.getMessage());
            throw new InterestRateNotProvidedException(e.getMessage());
        }
        catch (CompactDateException e) {
            log.error("CompactDateException thrown : "+ e.getMessage());
            throw new CompactDateException(e.getMessage());
        }
        catch (Exception e){
            log.error("Exception thrown : "+e.getMessage());
            throw new GlobalException(e.getMessage());
        }

        log.info("editPayee implementation completed : "+payeeDTO.getPayeId());
        return payeeDTOResponse;
    }

    private void stateRuleCheck(PayeeDTO payeeDTO, Claim claim, Optional<CurrentRate> currentRate, List<Errors> errorList) {
        String interestFor = "";
        String stCd = "";
        String responseCode = "";
        String loanInterestFor = "";
        String loanResponseCode = "";
        String statesList = "";
        Boolean stateRuleDataPresent = false;

        if((!payeeDTO.getInterestRateProvided() || !payeeDTO.getCurrentLoanRateProvided()) && !payeeDTO.getPayeDfltOvrdInd()) {
            Map<String, String> states = new LinkedHashMap<>();
            states.put("Issue State", claim.getIssStCd());
            states.put("Insurer Residence State", claim.getClmForResDthInd().equalsIgnoreCase(CicConstants.NO_N) ? claim.getInsdDthResStCd() : "");
            states.put("Payee State", payeeDTO.getPayeStCd());


            for (Map.Entry<String, String> entry : states.entrySet()) {
                if (!StringUtils.isEmpty(entry.getValue())) {
                    String lob = interestCalculationUtil.fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), entry.getValue(), payeeDTO.getPayePmtDt());
                    StateRule promptStateRule = interestCalculationUtil.getStateRuleData(lob, entry.getValue(), payeeDTO.getPayePmtDt());

                    boolean noInterestFlag = false;
                    if ((promptStateRule != null && !stateRuleDataPresent))
                        stateRuleDataPresent = true;
                    if(promptStateRule != null) {
                        noInterestFlag = interestCalculationUtil.step1Call(promptStateRule, errorList, payeeDTO, entry.getValue());

                        if (!noInterestFlag) {
                            noInterestFlag = interestCalculationUtil.step2Call(promptStateRule, errorList, payeeDTO, interestFor);
                        }
                        if (!noInterestFlag) {
                            interestCalculationUtil.step3SetPayablePeriodEndDate(promptStateRule, claim, payeeDTO);
                            if (payeeDTO.getPayePmtDt().compareTo(payeeDTO.getPayablePeriodEndDate()) <= 0) {
                                noInterestFlag = true;
                                errorList.add(new Errors(InterestCalculationConstants.CLAIM_INTEREST_RATE, InterestCalculationConstants.NO_INTEREST_PAID_MESSAGE));
                                payeeDTO.setPayeIntDaysPdNum(0);
                                payeeDTO.setPayeClmIntRt(BigDecimal.valueOf(0.0));
                                payeeDTO.setInterestCalculationMessage(InterestCalculationConstants.INTEREST_CALCULATION_MESSAGE + interestFor + ". No Interest was paid due to the Date of Payment being within the Payable Period.");
                            }
                        }
                    }
                    if(!noInterestFlag) {
                        // If Current Rate was not found, ask the user to supply it
                        CurrentRateCheck(currentRate, payeeDTO, claim, payeeDTO.getPayeStCd(), promptStateRule);

                        if (promptStateRule != null && !promptStateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE) && promptStateRule.getIruleCd().trim().equalsIgnoreCase("PROMPT")) {
                            interestFor += interestFor.isEmpty() ? entry.getKey() + " (" + entry.getValue() + ")" : "," + entry.getKey() + " (" + entry.getValue() + ")";
                            Map<String, String> responseCodes = Map.of(
                                    "Issue State", "10015",
                                    "Insurer Residence State", "10016",
                                    "Payee State", "10017"
                            );
                            statesList += statesList.isEmpty() ? entry.getValue() : "," + entry.getValue();

                            responseCode += responseCode.isEmpty() ? responseCodes.get(entry.getKey()) : "," + responseCodes.get(entry.getKey());
                        }
                        if (promptStateRule != null && InterestCalculationConstants.LOAN_IRULE_CODES.contains(promptStateRule.getIruleCd().trim())) {
                            loanInterestFor += loanInterestFor.isEmpty() ? entry.getKey() + " (" + entry.getValue() + ")" : "," + entry.getKey() + " (" + entry.getValue() + ")";
                            Map<String, String> responseCodes = Map.of(
                                    "Issue State", "10021",
                                    "Insurer Residence State", "10022",
                                    "Payee State", "10023"
                            );
                            statesList += statesList.isEmpty() ? entry.getValue() : "," + entry.getValue();

                            loanResponseCode += loanResponseCode.isEmpty() ? responseCodes.get(entry.getKey()) : "," + responseCodes.get(entry.getKey());
                        }

                    }
                }
            }

            if(!stateRuleDataPresent) {
                throw new RuntimeException("State Rule data is not present for the given state codes");
            }

            if (!interestFor.isEmpty() && !payeeDTO.getInterestRateProvided()) {
                throw new InterestRateNotProvidedException(InterestCalculationConstants.PLEASE_SPECIFY + InterestCalculationConstants.INTEREST_RATE +
                        InterestCalculationConstants.TO_USE + InterestCalculationConstants.FOR_THE + interestFor + "|" + responseCode + "|" + statesList);
            }
            if (!loanInterestFor.isEmpty() && !payeeDTO.getCurrentLoanRateProvided()) {
                throw new LoanRateNotProvidedException(InterestCalculationConstants.PLEASE_SPECIFY + InterestCalculationConstants.CURRENT_LOAN_RATE +
                        InterestCalculationConstants.IN_EFFECT_ON + interestCalculationUtil.formatDate(payeeDTO.getPayePmtDt()) + InterestCalculationConstants.FOR_THE + loanInterestFor+ "|" + loanResponseCode + "|" + statesList);
            }
        }
    }

    @Override
    public InstructionsDTO getInstructionsFromStCd(int clmId, String payeStCd, String payeResStCd, String calcStCd, String issueStCd, Date payePmtDt, BigDecimal paymentAmount) {
        InstructionsDTO instructionsDTO = new InstructionsDTO();
        PayeeDTO payeeDTO = new PayeeDTO();
        payeeDTO.setPayeDthbPmtAmt(paymentAmount);
        payeeDTO.setPayeStCd(payeStCd);
        try {
            Claim claim = cicClaimRepo.findById(clmId).orElseThrow(() -> new DataNotFoundException("Claim not found for id: " + clmId));

            ZZStateCheck(payeeDTO, claim);
            if(claim.getClmForResDthInd().equalsIgnoreCase(CicConstants.YES_Y)){
                instructionsDTO.setClmForResDthInd(CicConstants.YES_Y);
            }
            else{
                instructionsDTO.setClmForResDthInd(CicConstants.NO_N);
                String lob = interestCalculationUtil.fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), claim.getInsdDthResStCd(), payePmtDt);
                StateRule stateRule = interestCalculationUtil.getStateRuleData(lob, claim.getInsdDthResStCd(), payePmtDt);
                if(stateRule == null) {
                    stateRule = interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getInsdDthResStCd(), payePmtDt);
                }
                instructionsDTO.setInsdDthResStCd(claim.getInsdDthResStCd());
                instructionsDTO.setInsdDthResStCdMsg(stateRule != null?stateRule.getStrlSpclInstrTxt():InterestCalculationConstants.NONE);
            }
            if(!StringUtils.isEmpty(payeStCd)){
                instructionsDTO.setPayeStCd(payeStCd);
                instructionsDTO.setPayeResStCd(payeStCd);
                String lob = interestCalculationUtil.fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), payeStCd, payePmtDt);
                StateRule stateRule = interestCalculationUtil.getStateRuleData(lob, payeStCd, payePmtDt);
                if(stateRule == null) {
                    stateRule = interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB,payeStCd, payePmtDt);
                }
                instructionsDTO.setPayeResStCdMsg(stateRule != null?stateRule.getStrlSpclInstrTxt():InterestCalculationConstants.NONE);
            }
            if(!StringUtils.isEmpty(calcStCd) && !calcStCd.equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE)){
                instructionsDTO.setCalcStCd(calcStCd);
                String lob = interestCalculationUtil.fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), calcStCd, payePmtDt);
                StateRule stateRule = interestCalculationUtil.getStateRuleData(lob, calcStCd, payePmtDt);
                if(stateRule == null) {
                    stateRule = interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, calcStCd, payePmtDt);
                }
                instructionsDTO.setCalcStCdMsg(stateRule != null?stateRule.getStrlSpclInstrTxt():InterestCalculationConstants.NONE);
            } else if ( !StringUtils.isEmpty(calcStCd)) {
                instructionsDTO.setCalcStCd(calcStCd);
                StateRule stateRule = interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, calcStCd, payePmtDt);
                if(stateRule == null) {
                    throw new CompactDateException(String.format(CustomErrors.COMPACT_DATE_EXCEPTION.getDescription(), interestCalculationUtil.formatDate(payePmtDt)));
                }
                instructionsDTO.setCalcStCdMsg(stateRule.getStrlSpclInstrTxt());
            }
            if(!StringUtils.isEmpty(issueStCd)){
                instructionsDTO.setIssueStCd(issueStCd);
                String lob = interestCalculationUtil.fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), issueStCd, payePmtDt);
                StateRule stateRule = interestCalculationUtil.getStateRuleData(lob, issueStCd, payePmtDt);
                if(stateRule == null) {
                    stateRule = interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, issueStCd, payePmtDt);
                }
                instructionsDTO.setIssueStCdMsg(stateRule != null?stateRule.getStrlSpclInstrTxt():InterestCalculationConstants.NONE);
            }

        } catch (DataNotFoundException e) {
            log.error("An error occurred while getting instructions from state code: ", e);
            throw new DataNotFoundException(e.getMessage());
        }
        catch (GlobalException e){
            log.error("An error occurred while getting instructions from state code: ", e);
            throw new GlobalException(e.getMessage());
        }
        catch (InvalidRequestException e){
            log.error("An error occurred while getting instructions from state code: ", e);
            throw new InvalidRequestException(e.getMessage());
        }
        return instructionsDTO;
    }


}

