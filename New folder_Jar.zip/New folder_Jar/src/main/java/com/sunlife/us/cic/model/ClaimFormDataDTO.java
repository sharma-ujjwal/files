package com.sunlife.us.cic.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sunlife.us.cic.common.CicConstants;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimFormDataDTO extends GenericResponseDTO {
    List<StateDTO> stateList;
    List<PayorDTO> payorList;
    List<AdminDTO> adminList;
    List<String> tinSsnList;
    List<ClaimDTO> claimList;
    String insdDthResStCd;
    String issStCd;
    private String clmPolNum;
    String adminSystemDesc;
    Boolean clmForResDthInd;
    private Date insDeathDate;
    private Date insProofDate;
}
