package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.StateRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface CicStateRuleRepo extends JpaRepository<StateRule, String> {
    @Query(value = "SELECT * FROM state_rule_t WHERE lob_cd = ?1 AND st_cd = ?2 AND strl_eff_dt = (SELECT MAX(strl_eff_dt) FROM state_rule_t WHERE lob_cd = ?1 AND st_cd = ?2 AND strl_eff_dt <= ?3)", nativeQuery = true)
    StateRule findTopByStCdOrderByStrlEffDtDesc(String lobCd, String stCd, Date payePmtDt);
}
