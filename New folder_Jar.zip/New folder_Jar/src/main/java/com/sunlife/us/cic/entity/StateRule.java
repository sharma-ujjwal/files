package com.sunlife.us.cic.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * StateRule is an entity class that represents the StateRule table in the database.
 * This class is used to map the StateRule table in the database.
 */
@Entity
@Getter
@Setter
@Table(name = "state_rule_t")
@IdClass(StateRuleCompositeKey.class)
public class StateRule {

        @Id
        private String stCd;

        @Id
        private String lobCd;

        @Id
        private String strlEffDt;

        private String calcIdtypCd;
        private String reqdIdtypCd;
        private String iruleCd;
        private String strlEndDt;
        private BigDecimal strlIntRptgFlrAmt;
        private int strlIntCalcOfstNum;
        private int strlIntReqdOfstNum;
        private BigDecimal strlIntRuleAmt;
        private String strlSpclInstrTxt;

}
