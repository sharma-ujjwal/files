package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * PayorDTO Class for mapping to Payor entity.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Getter
@Setter
public class PayorDTO implements Serializable {
    private String pycoTypDsc;
    private String pycoTypCd;
}
