package com.sunlife.us.cic.entity;

public class StateRuleCompositeKey implements java.io.Serializable {

    private String stCd;
    private String lobCd;
    private String strlEffDt;
}
