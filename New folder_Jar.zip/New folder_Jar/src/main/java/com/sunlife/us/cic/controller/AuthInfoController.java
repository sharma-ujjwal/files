package com.sunlife.us.cic.controller;


import com.sunlife.us.cic.model.AuthInfoDTO;
import com.sunlife.us.cic.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * This Controller will help the UI to get the user logged in Details
 */
@RestController
@RequestMapping("v1/interestcalculator/auth")
public class AuthInfoController {

    /**
     * Description: Get the user info like, Username, Email and Role. This is a protected API
     * @return
     */
    @GetMapping()
    public ResponseEntity<AuthInfoDTO> getLoggedInUserInfo() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();
        AuthInfoDTO authInfoDTO = new AuthInfoDTO();
        authInfoDTO.setRole(currentUser.getRole());
        authInfoDTO.setEmail(currentUser.getEmail());
        authInfoDTO.setAcf2Id(currentUser.getUsername());
        return ResponseEntity.ok(authInfoDTO);
    }
}
