package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 * Description: Class for handling JWT Token related exceptions
 */
public class JwtTokenInvalidException extends RuntimeException {

    public JwtTokenInvalidException() {
        super(CustomErrors.JWT_TOKEN_INVALID_EXCEPTION.getDescription());
    }

    public JwtTokenInvalidException(final String message) {
        super(message);
    }

    public JwtTokenInvalidException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public JwtTokenInvalidException(final Throwable cause) {
        super(cause);
    }
}