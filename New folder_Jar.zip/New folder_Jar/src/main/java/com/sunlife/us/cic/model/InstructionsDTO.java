package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class InstructionsDTO implements Serializable {

    private String payeStCd;

    private String payeResStCd;
    private String payeResStCdMsg;

    private String calcStCd;
    private String calcStCdMsg;

    private String issueStCd;
    private String issueStCdMsg;

    private String clmForResDthInd;
    private String insdDthResStCd;
    private String insdDthResStCdMsg;

}
