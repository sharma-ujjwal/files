package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 *
 * InvalidRequestException Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 */
public class InvalidRequestException extends RuntimeException {

    public InvalidRequestException() {
        super(CustomErrors.INVALID_REQUEST_EXCEPTION.getDescription());
    }
    public InvalidRequestException(final String message) {
        super(message);
    }

    public InvalidRequestException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public InvalidRequestException(final Throwable cause) {
        super(cause);
    }
}
