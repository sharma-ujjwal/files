package com.sunlife.us.cic.model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.sunlife.us.cic.common.CicConstants;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * PayeeDTO Class for mapping to Payee entity.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Getter
@Setter
@AllArgsConstructor
public class PayeeDTO extends GenericResponseDTO implements java.io.Serializable {

    private Integer payeId;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private Integer clmId;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private String calcStCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    private String payeFullNm;

    private String payeCareOfTxt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    private String payeAddrLn1Txt;
    private String payeAddrLn2Txt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @Pattern(regexp = CicConstants.NAME_REGEX, message = CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String payeCityNmTxt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @Pattern(regexp = CicConstants.ALPHA_NUMERIC_REGEX, message = CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String payeStCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @Pattern(regexp = CicConstants.NUMERIC_REGEX, message = CicConstants.SHOULD_HAVE_DIGITS_ONLY)
    private String payeZipCd;

    private String payeZip4Cd;

    private String payeSsnTinNum;

    private String payeSsnTinTypCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private BigDecimal payeClmIntAmt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private BigDecimal payeClmPdAmt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @DecimalMax(value = "99000000.00", message = "The value must be less than or equal to $99 million")
    private BigDecimal payeDthbPmtAmt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private BigDecimal payeWthldAmt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private BigDecimal payeClmIntRt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @Max(value = 99, message = "The value must be less than or equal to 99")
    private BigDecimal payeWthldRt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private Integer payeIntDaysPdNum;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date payePmtDt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private Boolean payeDfltOvrdInd;

    private Date lstUpdtDtm;

    private String lstUpdtUserId;
    private Boolean paye1099IntInd;
    private Date payablePeriodEndDate;
    private Date figuredFromDate;

    private Boolean currentLoanRateProvided;
    private BigDecimal issueInterestRate;

    private Boolean currentInterestRateProvided;
    private BigDecimal currentInterestRate;

    private String overRideState;
    private BigDecimal overRideInterestRate;

    private Boolean compactInterestRateProvided;
    private BigDecimal compactInterestRate;

    private String interestCalculationMessage;

    private Boolean interestRateProvided;
    private BigDecimal residenceInterestRate;

    private String calcStateMsg;
    private BigDecimal payeeInterestRate;
    public PayeeDTO() {
    }
}
