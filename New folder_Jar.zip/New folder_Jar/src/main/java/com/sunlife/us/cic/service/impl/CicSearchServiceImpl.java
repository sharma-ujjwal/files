package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.mapper.CicMapper;
import com.sunlife.us.cic.model.ClaimDTO;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import com.sunlife.us.cic.repo.CicClaimRepo;
import com.sunlife.us.cic.service.CicSearchService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * CicSearchService Interface.
 * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This class is used to implement the service methods for the CicSearchService interface.
 */
@Service
@Slf4j
public class CicSearchServiceImpl implements CicSearchService {
    @Autowired
    private CicClaimRepo cicClaimRepo;

    /**
     * Method to search insurer
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Method to search insurer in claim table based on search input and search field
     * @param searchInput
     * @param searchField
     * @param pageNumber
     * @param pageSize
     * @return ViewInsurerResponse
     */
    @Cacheable(
            value = "searchCache",
            key = "#searchInput.concat('-').concat(#searchField).concat('-').concat(#pageNumber)")
    @Override
    public ViewInsurerResponse searchInsurer(String searchInput, String searchField, int pageNumber, int pageSize) {
        log.info("searchInsurer Implementation called");
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        List<ClaimDTO> claimDTOList = new ArrayList<>();

        Page<Claim> claimList = getClaimList(searchInput, searchField, pageNumber, pageSize);
        if (claimList == null || claimList.getTotalPages() <= 0) {
            throw new DataNotFoundException(CicConstants.REQUESTDATANOTPRESENT);
        }

        claimList.getContent().forEach(claim -> {
            ClaimDTO claimDTO = CicMapper.INSTANCE.mapclaim(claim);
            claimDTO.setDeleteActive(claim.getPayee().isEmpty());
            claimDTO.setAdmnSystDsc(claim.getAdmin().getAdmnSystDsc());
            claimDTOList.add(claimDTO);
        });

        viewInsurerResponse.setTotalCount(claimList.getTotalElements());
        viewInsurerResponse.setClaimsList(claimDTOList);
        viewInsurerResponse.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
        viewInsurerResponse.setReturnCode(HttpStatus.OK.toString());

        log.info("viewInsurer Implementation ended");
        return viewInsurerResponse;
    }

    private Page<Claim> getClaimList(String searchInput, String searchField, int pageNumber, int pageSize) {
        switch (searchField) {
            case CicConstants.POLICY_NUMBER_FIELD:
                return cicClaimRepo.findByPolicyNumberRegex(searchInput, getPageRequest(pageNumber, pageSize));
            case CicConstants.SSN_NUMBER_FIELD:
                return cicClaimRepo.findByClmInsdSsnNumRegex(searchInput, getPageRequest(pageNumber, pageSize));
            case CicConstants.NAME_FIELD:
                return cicClaimRepo.findByClmInsdFirstNmRegexOrClmInsdLastNmRegex(searchInput, getPageRequest(pageNumber, pageSize));
            default:
                throw new InvalidRequestException("Invalid search field : " + searchField);
        }
    }

    private PageRequest getPageRequest(int pageNumber, int pageSize) {
        return PageRequest.of(pageNumber - 1, pageSize, Sort.by(CicConstants.LAST_UPDATED_DATE).descending());
    }
}
