package com.sunlife.us.cic.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sunlife.us.cic.common.CicConstants;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * ClaimDTO Class for mapping to Claim entity.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * for mapping Claim entity.
 */
@Getter
@Setter
@AllArgsConstructor
public class ClaimDTO implements java.io.Serializable {

    private Integer clmId;

    @Pattern(regexp = CicConstants.ALPHA_NUMERIC_REGEX, message =  CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String clmNum;

    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @NotNull(message = CicConstants.CANT_BE_NULL)
    @Size(min = 5, max = 10, message = "should have at least 5 and at max 10 characters")
    @Pattern(regexp = CicConstants.ALPHA_NUMERIC_REGEX, message = CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String clmPolNum;

    private BigDecimal clmTotDthbPmtAmt;
    private BigDecimal clmTotIntAmt;
    private BigDecimal clmTotClmPdAmt;
    private BigDecimal clmTotWthldAmt;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    private String clmInsdFirstNm;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    private String clmInsdLastNm;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @Pattern(regexp = CicConstants.ALPHA_NUMERIC_REGEX, message = CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String issStCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date clmInsdDthDt;

    @NotNull(message =  CicConstants.CANT_BE_NULL)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date clmProofDt;


    private String clmInsdSsnNum;

    private String insdDthResStCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private Boolean clmForResDthInd;

    private Boolean clmCompactClcnInd;
    private Boolean deleteActive;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    private Integer admnSystCd;

    @NotNull(message = CicConstants.CANT_BE_NULL)
    @NotEmpty(message = CicConstants.CANT_BE_EMPTY)
    @Pattern(regexp = CicConstants.ALPHA_NUMERIC_REGEX, message = CicConstants.SHOULD_NOT_HAVE_SPECIAL_CHARACTERS)
    private String pycoTypCd;

    private String admnSystDsc;

    public ClaimDTO() {

    }

}
