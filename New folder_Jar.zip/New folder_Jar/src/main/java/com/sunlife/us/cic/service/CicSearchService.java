package com.sunlife.us.cic.service;

import com.sunlife.us.cic.model.ViewInsurerResponse;
import org.springframework.stereotype.Component;

/**
 * CicSearchService Interface.
 * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This interface is used to define the methods for the search service layer.
 */
@Component
public interface CicSearchService {

    /**
     * Method to search insurer interface
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Interface Method which will be implemented to search insurer in claim table based on search input and search field
     * @param searchInput
     * @param searchField
     * @param pageNumber
     * @param pageSize
     * @return ViewInsurerResponse
     */
    ViewInsurerResponse searchInsurer(String searchInput, String searchField, int pageNumber, int pageSize);
}
