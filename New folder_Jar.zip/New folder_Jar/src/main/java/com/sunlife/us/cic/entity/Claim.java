package com.sunlife.us.cic.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * Claims entity Class for claim_t DB tabel.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Entity
@Getter
@Setter
@Table(name = "claim_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Claim {

    /**
     * As claimId is a primary key in claim_t, GenerationType.IDENTITY is used  to generate the primary key value by the database itself using the auto-increment column option.
     */
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "clm_id")
    private Integer clmId;

    @Column(name = "clm_num")
    private String clmNum;

    @Column(name = "clm_pol_num")
    private String clmPolNum;

    @Column(name = "clm_tot_dthb_pmt_amt")
    private BigDecimal clmTotDthbPmtAmt;

    @Column(name = "clm_tot_int_amt")
    private BigDecimal clmTotIntAmt;

    @Column(name = "clm_insd_first_nm")
    private String clmInsdFirstNm;

    @Column(name = "clm_insd_last_nm")
    private String clmInsdLastNm;

    @Column(name = "clm_insd_ssn_num")
    private String clmInsdSsnNum;

    @Column(name = "clm_insd_dth_dt")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date clmInsdDthDt;

    @Column(name = "clm_Proof_dt")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/New_York", locale = "en-US")
    private Date clmProofDt;

    @Column(name = "clm_tot_clm_pd_amt")
    private BigDecimal clmTotClmPdAmt;

    @Column(name = "clm_tot_wthld_amt")
    private BigDecimal clmTotWthldAmt;

    @Column(name = "iss_st_cd")
    private String issStCd;

    @Column(name = "insd_dth_res_st_cd")
    private String insdDthResStCd;

    @Column(name = "lst_updt_dtm")
    private Date lstUpdtDtm;

    @Column(name = "lst_updt_user_id")
    private String lstUpdtUserId;

    @Column(name = "clm_for_res_dth_ind")
    private String clmForResDthInd;

    @Column(name = "clm_compact_clcn_ind")
    private String clmCompactClcnInd;

    @Column(name = "admn_syst_cd")
    private Integer admnSystCd;

    @Column(name = "pyco_typ_cd")
    private String pycoTypCd;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "admn_syst_cd", insertable=false, updatable=false)
    private Admin admin;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pyco_typ_cd", insertable=false, updatable=false)
    private Payor payor;

    @OneToOne()
    @JoinColumn(name = "iss_st_cd", insertable=false, updatable=false)
    private State state;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "clm_id",insertable=false, updatable=false)
    private List<Payee> payee;

}

