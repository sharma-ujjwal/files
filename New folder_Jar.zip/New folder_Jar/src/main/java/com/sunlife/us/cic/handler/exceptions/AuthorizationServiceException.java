package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;


/**
 *  Description: This handles the authorization exception if the user logged in is not autorized to view the content
 */
public class AuthorizationServiceException extends RuntimeException{

    public AuthorizationServiceException() {
        super(CustomErrors.USER_NOT_FOUND_EXCEPTION.getDescription());
    }

    public AuthorizationServiceException(final String message) {
        super(message);
    }

    public AuthorizationServiceException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public AuthorizationServiceException(final Throwable cause) {
        super(cause);
    }
}
