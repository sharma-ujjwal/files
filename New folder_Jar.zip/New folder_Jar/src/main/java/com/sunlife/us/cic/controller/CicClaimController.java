package com.sunlife.us.cic.controller;

import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.handler.exceptions.JsonException;
import com.sunlife.us.cic.common.util.RequestUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.sunlife.us.cic.service.CicClaimService;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 *
 * CicClaimsController Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 */

@RestController
@RequestMapping("v1/interestcalculator/insured")
@Slf4j
public class CicClaimController {
	@Autowired
	CicClaimService cicClaimService;

	@Autowired
	RequestUtil requestUtil;

	/**
	 * Description viewInsurer API is used to view the recent insurer claim information
	 * viewInsurer API Contoller Code implementaion
	 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
	 * Description: This method is used to view recent Insurer claim information.
	 * @return string
	 * @param pageNumber
	 * @param pageSize
	 * @throws JsonException
	 */
	@GetMapping()
	@Consumes("application/json")
	@Operation(summary = "View recent Insurer", description = "View recent Insurer claim information.")
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<ViewInsurerResponse> viewInsurer(@Param("pageNumber") int pageNumber, @Param("pageSize") int pageSize, HttpServletRequest request){
		log.info("viewInsurer API called");
		RequestUtil.checkForSpecialCharacters(request);
		List<Errors> errorMessages = RequestUtil.validate(pageNumber, pageSize);
		if(!errorMessages.isEmpty()) {
			log.debug("Error in request validation" + errorMessages);
			log.error("json exception occurred");
			throw new JsonException(CustomErrors.JSON_EXCEPTION.getDescription(), errorMessages);
		}
		log.debug("Request validation successful");
		log.info("viewInsurer API ended");
		return ResponseEntity.ok(cicClaimService.viewInsurer(pageNumber, pageSize));
	}

	/**
	 * Description deleteInsurer API is used to delete the insurer claim information.
	 * deleteInsurer API Contoller Code implementaion
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: This method is used to delete insurer claim information.
	 * @return ResponseEntity of GenericResponseDTO
	 * @param claimId
	 * @throws InvalidRequestException
	 */
	@DeleteMapping()
	@Operation(method = "deleteInsurer", summary = "Delete by claim id for Insurer", description = "Delete insurer claim information." )
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<GenericResponseDTO> deleteInsurer(@NotNull @Min(value = 1, message = "value should be greater than 0") @PathParam("claimId")int claimId, HttpServletRequest request) {
		log.info("deleteInsurer API called : " + claimId);
		RequestUtil.checkForSpecialCharacters(request);

		log.info("deleteInsurer API ended : " + claimId);
		return ResponseEntity.ok(cicClaimService.deleteInsurer(claimId));
	}


	/**
	 * Description getInsurer API is used to get the details of a particular insurer based on claim ID
	 * getInsurer API Contoller Code implementaion
	 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
	 * @return ResponseEntity of ViewInsurerResponse
	 * @param claimId
	 * @throws DataNotFoundException
	 */
	@GetMapping("/{claimId}")
	@Consumes("application/json")
	@Operation(summary = "Get Insurer", description = "Get Insurers based on Claim Id.")
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<ViewInsurerResponse> getInsurer(@NotNull @PathVariable("claimId")int claimId, HttpServletRequest request){
		log.info("getInsurer API called : " + claimId);
		RequestUtil.checkForSpecialCharactersInPathParam(request);
		if(claimId == 0) {
			log.error("DataNotFoundException thrown : " + claimId);
			throw new DataNotFoundException(CicConstants.INVALIDCLAIMID + claimId);
		}
		log.info("getInsurer API ended : " + claimId);
		log.debug("Response is :" + cicClaimService.getInsurer(claimId) + " for claimId : " + claimId);
		return ResponseEntity.ok(cicClaimService.getInsurer(claimId));
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description getClaimFormData API is used to get the claim form data
	 * getClaimFormData API Contoller Code implementaion
	 * @return ResponseEntity of ClaimFormDataDTO
	 */

	@GetMapping("/formdata")
	@Consumes("application/json")
	@Operation(summary = "Get Claim Form Data", description = "Get Claim Form Data.")
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<ClaimFormDataDTO> getClaimFormData(@RequestParam(required = false) Integer claimId) {
		log.info("getClaimFormData API called");
		return ResponseEntity.ok(cicClaimService.getClaimFormData(claimId));
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: addInsurer API is used to add the insurer claim information.
	 * This method is used to add insurer claim information.
	 * It accepts a valid ClaimDTO object and a HttpServletRequest object as parameters.
	 * The ClaimDTO object should contain the necessary details for the insurer claim.
	 * The HttpServletRequest object is used to get request details.
	 * @param claimDTO This is a valid ClaimDTO object containing the insurer claim details.
	 * @param request This is a HttpServletRequest object used to get request details.
	 * @return ResponseEntity of GenericResponseDTO This returns a response entity with a generic response DTO.
	 * @throws InvalidRequestException This exception is thrown when the request is invalid.
	 */
	@PostMapping()
	@Consumes("application/json")
	@Operation(summary = "Add Insurer", description = "Add Insurer claim information.")
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<GenericResponseDTO> addInsurer(@Valid @RequestBody ClaimDTO claimDTO, HttpServletRequest request) {
		log.info("addInsurer API called");
		List<Errors> errorsList = new ArrayList<>();
		Optional<Admin> admin = cicClaimService.findAdminById(claimDTO.getAdmnSystCd());
		RequestUtil.validatePolicyNumber(claimDTO, errorsList, admin);
		if(!errorsList.isEmpty()){
			log.error("Invalid request for addInsurer "+ errorsList);
			throw new JsonException(CustomErrors.JSON_EXCEPTION.getDescription(), errorsList);
		}
		return ResponseEntity.ok(cicClaimService.addInsurer(claimDTO, admin.get()));
	}


	/**
	 * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
	 * Description editInsurer API is used to edit the claim information of the insurer
	 * @return ResponseEntity of GenericResponseDTO
	 */
	@PatchMapping()
	@Consumes("application/json")
	@Operation(summary = "Edit Insurer", description = "Edit Insurer claim information.")
	@ResponseStatus(code = HttpStatus.OK)
	@ApiResponse(responseCode = "200", description = "Success")
	public ResponseEntity<GenericResponseDTO> editInsurer(@Valid @RequestBody ClaimDTO claimDTO, HttpServletRequest request) {
		log.info("editInsurer API called");
		List<Errors> errorsList = new ArrayList<>();
		Optional<Admin> admin = cicClaimService.findAdminById(claimDTO.getAdmnSystCd());
		RequestUtil.validatePolicyNumber(claimDTO, errorsList, admin);
		if(!errorsList.isEmpty()){
			log.error("Invalid request for addInsurer "+ errorsList);
			throw new JsonException(CustomErrors.JSON_EXCEPTION.getDescription(), errorsList);
		}
		return ResponseEntity.ok(cicClaimService.editInsurer(claimDTO, admin.get()));
	}

}
