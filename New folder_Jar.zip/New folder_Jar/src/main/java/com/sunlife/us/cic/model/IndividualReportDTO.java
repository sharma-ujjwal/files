package com.sunlife.us.cic.model;

import java.util.Date;

/**
 * Description: IndividualReportDTO Interface
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */

public interface IndividualReportDTO {
    Integer getClm_id();
    String getClm_num();
    String getClm_pol_num();
    String getAdmn_syst_dsc();
    String getPyco_typ_dsc();
    String getCalcInsuredFullName();
    Date getClm_insd_dth_dt();
    Date getClm_proof_dt();
    Double getClm_tot_dthb_pmt_amt();
    Double getClm_tot_int_amt();
    Double getClm_tot_clm_pd_amt();
    Double getClm_tot_wthld_amt();
    String getCalcInsdDthResStCd();
    String getIss_st_cd();
    String getClm_insd_ssn_num();
    String getPaye_full_nm();
    String getPaye_addr_ln1_txt();
    String getPaye_addr_ln2_txt();
    String getPaye_city_nm_txt();
    String getPaye_st_cd();
    String getCalc_st_cd();
    String getCalcPayeZipCd();
    String getPaye_care_of_txt();
    String getPaye_ssn_tin_num();
    Double getPaye_clm_int_amt();
    Double getPaye_clm_pd_amt();
    Double getPaye_dthb_pmt_amt();
    Double getPaye_clm_int_rt();
    Double getPaye_wthld_rt();
    Double getPaye_wthld_amt();
    Date getPaye_pmt_dt();
    Integer getPaye_int_days_pd_num();
    String getCalcPayeDfltOvrdInd();

}
