package com.sunlife.us.cic.common;

import com.sunlife.us.cic.model.Errors;
import jakarta.validation.constraints.Null;

import java.util.List;

import java.util.Arrays;

/**
 *
 * CicConstants Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Global constants class
 */
public class CicConstants {
    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewInsurer API constants
     **/
    public final static String INSURERREQUESTVO = "InsurerRequestVO";
    public final static String PAGENUMBER = "PageNumber";
    public final static String PAGESIZE = "PageSize";

    public final static String REQUESTCANNOTBENULL = "Request cannot be null";
    public final static String PAGENUMBERERROR = "Page number cannot be less than or equal to 0";
    public final static String PAGESIZEERROR = "Page size cannot be less than or equal to 0";

    /**
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * deleteInsurere API constants
     **/
    public final static String CLAIMDELETEDSUCCESSFULLY = "Claim deleted successfully : ";

    public final static String PAYEEDELETEDSUCCESSFULLY = "Payee deleted successfully : ";
    public final static String INVALIDCLAIMID = "Invalid data, claim id : ";

    public final static String INVALIDPAYEEID = "Invalid data, Payee id : ";
    public final static String CLAIMNOTFOUND = "Claim not found : ";

    public final static String REQUESTDATANOTPRESENT = "Required data does not exist";

    public final static String PAYEENOTFOUND = "Payee not found : ";
    public final static String PAYEE_NOT_FOUND_FOR_CLAIM = "Payee not found for Claim Id : ";
    public final static String CLAIM_PAYEE_PRESENT = "Claim can not be deleted as Payee data is present for claim Id : ";

    public final static String INPUT_CANNOT_BE_NULL = "Input cannot be null or empty";
    public final static String INPUT_CANNOT_BE_ZERO = "Input cannot be less than or equal to zero";
    public final static String SEARCH_INPUT = "searchInput";
    public final static String SEARCH_FIELD = "searchField";
    public final static String PAGE_NUMBER_VAR = "pageNumber";
    public final static String PAGEP_SIZE_VAR = "pageSize";
    public final static String CLAIM_INSD_DTH_DT = "clm_insd_dth_dt";
    public static final String CLAIM_ADDED = "Claim added successfully";
    public static final String CLAIM_UPDATED = "Claim updated successfully";
    public static final String PAYEE_ADDED = "Payee added successfully : ";
    public static final String STATE_NOT_FOUND = "State not found";
    public static final String YES_Y = "Y";
    public static final String NO_N = "N";
    public static final String TRUE_T = "T";
    public static final String FALSE_F = "F";
    public static final String INVALID_ADMIN_SYSTEM_CODE = "Invalid admin system code";
    public static final String INVALID_PAYOR_CODE = "Invalid payor code";
    public static final int ADMIN_SOLAR_SYSTEM_CODE = 24;
    public static final int ADMIN_LEVEREGE_SYSTEM_CODE = 20;
    public static final String ADMIN_SYSTEM_GROUP_G = "G";
    public static final String COLON_SPACING = " : ";
    public static final String DEATH_DATE_GREATER_THAN_PROOF_DATE = "Death date cannot be greater than proof date";
    public static final String CANT_BE_NULL = "can't be null";
    public static final String CANT_BE_EMPTY = "can't be empty";
    public static final String SHOULD_NOT_HAVE_SPECIAL_CHARACTERS = "should not have special characters";

    public static final String WHITE_SPACE = " ";
    public static final String ALPHA_NUMERIC_REGEX = "([A-Za-z0-9]+)";
    public static final String NUMERIC_REGEX = "([0-9]+)";
    public static final String NAME_REGEX = "([A-Za-zÀ-ÿ, ,_,.]*)";
    public static final String INSURED_NAME_REGEX = "([-A-Za-zÀ-ÿ0-9 ,_.\\/\\\\]*)";    public static final String SHOULD_HAVE_DIGITS_ONLY = "should have digits only";
    public static final List<String> SSN_TIN = Arrays.asList("P", "B");
    public static final String INVALID_SSN_TIN_TYPE = "Invalid SSN or TIN type";
    public static final String NAME_ALREADY_EXISTS = "A record with the specified key (Payee name ";

    public static final String NAME_ALREADY_EXISTS_LINE_2 = ") already exists. Please specify a unique key.";
    public static final String POLICY_NUMBER_LABEL = "/Policy Number ";

    public static final String PAYEE_UPDATED = "Payee updated successfully";
    public static final String CLAIM_ALREADY_PRESENT = "Claim with this policy number is already present";

    public static final String CLAIM_ALREADY_PRESENT_POLICY_SSN = "A record with the specified key (Claim Number %s ) already exists. Please specify a unique key.";
    public static final String CLMPOLNUM = "clmPolNum";
    public static final String ADMNSYSTCD = "admnsystcd";
    public static final String POLICY_NUMBER_LENGTH = "Policy number length should be of ";
    public static final String POLICY_NUMBER_FIELD = "policyNumber";
    public static final String SSN_NUMBER_FIELD = "SSN";
    public static final String NAME_FIELD = "name";
    public final static String LAST_UPDATED_DATE = "lst_updt_dtm";
    public final static String LAST_UPDATED_DATE_WITHOUT_UNDERSCORE = "lstUpdtDtm";
    public static final String RESIDENCE_STATE_NULL_MSG = "Residence State Code cannot be null when not foreign resident";
    public static final String TIN_TYPE_CODE_P = "P";
    public static final String TIN_TYPE_CODE_B = "B";

    public static final String LINEOFBUSINESS_I = "I";
    public static final String LINEOFBUSINESS_INDIVIDUAL = "Individual";
    public static final String LINEOFBUSINESS_G = "G";
    public static final String LINEOFBUSINESS_GROUP = "Group";
    public static final String LINEOFBUSINESS_ALL = "All";
    public static final String LINEOFBUSINESS_I_G = "I, G";
    public static final String CROSS_FIELD_VALIDATIONS = "Cross-field validation errors were found. These must be corrected before the report can be produced: ";

    //Constants for Reports
    public final static String FILENAME = "filename";
    public final static String REPORTS_PDF = "reports.pdf";
    public final static String TAX_FILE_NAME = "taxFiles.txt";
    public final static String CACHE_CONTROL = "must-revalidate, post-check=0, pre-check=0";
    public static final String CONTENT_TYPE = "application/json";
    public static final String TAXFILE_PR = "PR";
    public static final String VIEWNONPR_OR_VIEWPR_NOTSELECTED = "Please select either viewNonPR or viewPR";
    public static final String GENERATE_TAX_FILE_SUCCESS_MESSAGE = "%d record(s) were written to the %s tax file. The total interest (Box 1) amount was $%.2f and the total Interest Withheld (Box 4) amount was $%.2f.\n" +
            "%d record(s) were written to the %s tax file. The total interest (Box 1) amount was $%.2f and the total Interest Withheld (Box 4) amount was $%.2f.";
    public static final String GENERATE_TAX_FILE_NO_RECORDS_FOUND_MESSAGE = "No records were found with Payment Dates on or within the specified date";
    public static final String[] CUSTOM_CLAIM_REPORT_HEADERS = {"Payee", "Claim Interest", "Interest Withheld", "Total Paid","Date of Payment"};
    public static final String ARITHMATIC_EXCEPTION = "Arithmetic overflow error converting numeric to data type numeric";
}
