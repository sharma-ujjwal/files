package com.sunlife.us.cic.common.util;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.ClaimDTO;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.service.CicClaimService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * RequestUtil utility class implementaion
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Component("RequestUtil")
@Slf4j
public class RequestUtil {

    /**
     * Method to validate page number and page size for null or empty input parameter of API
     * Description Method to validate page number and page size cannot be less than or equal to 0 for input parameter of API
     * @param pageNumber
     * @param pageSize
     * @return ErrorsList
     */
    public static List<Errors> validate(int pageNumber, int pageSize) {
        log.info("validate function call under RequestUtil class");
        List<Errors> errorMessage = new ArrayList<>();
        if(pageNumber <= 0 ){
            log.debug("Page number cannot be less than 0" + pageNumber);
            setErrors(CicConstants.PAGENUMBERERROR, CicConstants.PAGENUMBER, errorMessage);
        }
        if(pageSize <= 0){
            log.debug("Page size cannot be less than 0" + pageSize);
            setErrors(CicConstants.PAGESIZEERROR, CicConstants.PAGESIZE, errorMessage);
        }
        log.info("validate function call ended");
        return errorMessage;
    }

    /**
     * Method to validate string input parameter of API for null or empty
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Method to validate string input parameter of API for null or empty
     * @param fieldName
     * @param input
     * @param errorMessage
     * @return ErrorsList
     */
    public static List<Errors> validateStringInput(String fieldName, String input, List<Errors> errorMessage) {
        if(input == null || StringUtils.isEmpty(input.trim())) {
            log.debug("Field "+ fieldName +" cannot be null or empty");
            setErrors(CicConstants.INPUT_CANNOT_BE_NULL, fieldName, errorMessage);
        }
        return errorMessage;
    }

    /**
     * Method to set error message in case of null or empty input parameter of API
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Method to set error message in case of null or empty input parameter of API
     * @param inputCannotBeNull
     * @param fieldName
     * @param errorMessage
     */
    private static void setErrors(String inputCannotBeNull, String fieldName, List<Errors> errorMessage) {
        Errors errors = Errors.getInstance();
        errors.setErrorMessage(inputCannotBeNull);
        errors.setFieldName(fieldName);
        errorMessage.add(errors);
    }

    /**
     * Method to validate integer input parameter of API for null or empty
     * @author <a href="mailto:rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Method to validate integer input parameter of API for greater than 0
     * @param fieldName
     * @param input
     * @param errorMessage
     * @return ErrorsList
     */
    public static List<Errors> validateIntegerInput(String fieldName, int input, List<Errors> errorMessage) {
        if(input <= 0) {
            log.debug("Input cannot be null or empty" + input);
            setErrors(CicConstants.INPUT_CANNOT_BE_ZERO, fieldName, errorMessage);
        }
        return errorMessage;
    }

    /**
     * Description : Method to check for special characters in request parameters
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param request
     * @throws InvalidRequestException
     */
    public static void checkForSpecialCharacters(HttpServletRequest request){
        request.getParameterMap().forEach((key, value) -> {
                if( !value[0].isEmpty() && value.length >= 1 && (!value[0].matches(CicConstants.ALPHA_NUMERIC_REGEX)))
            {
                throw new InvalidRequestException("Invalid Request: Should not contain special characters");
            }
        });
    }

    /**
     * Description Method to check for special characters in request parameters for Path param only
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param request
     * @throws InvalidRequestException
     */

    public static void checkForSpecialCharactersInPathParam(HttpServletRequest request) {

        Pattern digit = Pattern.compile("[0-9]+");
        Pattern alpha = Pattern.compile("[a-zA-Z]+");

        String value = request.getRequestURI().substring(request.getRequestURI().lastIndexOf('/') + 1);
        if(!digit.matcher(value).matches() && !alpha.matcher(value).matches()) {
            throw new InvalidRequestException("Invalid Request: Should not contain special characters");
        }
    }

    /**
     * Description Method to validate policy number based on admin system code
     *
     * @param claimDTO COLI
     *                 min -9, max-9
     *                 <p>
     *                 GROUP
     *                 min -5, max-6
     *                 <p>
     *                 LEVERAGE
     *                 min -7, max-10
     *                 <p>
     *                 SOLAR
     *                 min -7, max-9
     * @param admin
     * @throws InvalidRequestException
     */
    public static void validatePolicyNumber(ClaimDTO claimDTO, List<Errors> errorsList, Optional<Admin> admin) {
        if(admin.isEmpty()) {
            setErrors(CicConstants.INVALID_ADMIN_SYSTEM_CODE, CicConstants.ADMNSYSTCD, errorsList);
        } else {
            Admin adminData = admin.get();
            if (claimDTO.getClmPolNum().length() < Integer.parseInt(adminData.getAdmnSystIdMinLgthNum()) || claimDTO.getClmPolNum().length() > Integer.parseInt(adminData.getAdmnSystIdMaxLgthNum())) {
                setErrors("For " + adminData.getAdmnSystDsc() + " admin system, " + CicConstants.POLICY_NUMBER_LENGTH +
                                (Integer.parseInt(adminData.getAdmnSystIdMinLgthNum()) == Integer.parseInt(adminData.getAdmnSystIdMaxLgthNum())?
                                Integer.parseInt(adminData.getAdmnSystIdMinLgthNum()) : adminData.getAdmnSystIdMinLgthNum() + " to " + adminData.getAdmnSystIdMaxLgthNum()) + " characters"
                        , CicConstants.CLMPOLNUM, errorsList);
            }
        }
    }

}
