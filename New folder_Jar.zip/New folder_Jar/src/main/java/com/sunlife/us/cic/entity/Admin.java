package com.sunlife.us.cic.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

/**
 *
 * Admin entity Class for admin_system_t DB table.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Entity
@Getter
@Setter
@Table(name = "admin_system_t")
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "admn_syst_cd")
    private Integer admnSystCd;
    @Column(name = "lob_cd")
    private String lobCd;
    @Column(name = "admn_syst_dsc")
    private String admnSystDsc;
    @Column(name = "lst_updt_dtm")
    private Date lstUpdtDtm;
    @Column(name = "lst_updt_user_id")
    private String lstUpdtUserId;
    @Column(name = "admn_syst_id_min_lgth_num")
    private String admnSystIdMinLgthNum;
    @Column(name = "admn_syst_id_max_lgth_num")
    private String admnSystIdMaxLgthNum;
    @Column(name = "dflt_pyco_typ_cd")
    private String dfltPycoTypCd;
    @Column(name = "admn_syst_tax_rptg_ind")
    private String admnSystTaxRptgInd;

}
