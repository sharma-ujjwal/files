package com.sunlife.us.cic.config;

import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.config.MapConfig;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

/**
 * CacheConfig class to configure cache for the application
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description: This class is used to configure cache for the application
 */
@Configuration
@EnableCaching
public class CacheConfig {

    /**
     * Method to create Hazelcast instance
     * Description Method to create Hazelcast instance
     * @return HazelcastInstance
     */
    @Bean
    public HazelcastInstance hazelcastInstance() {
        HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance();
        hazelcastInstance.getConfig().addMapConfig(new MapConfig("searchCache").setTimeToLiveSeconds(0));
        hazelcastInstance.getConfig().addMapConfig(new MapConfig("taxCache").setTimeToLiveSeconds(0));
        return hazelcastInstance;
    }

    /**
     * Method to create client configuration
     * Description Method to create client configuration
     * @return ClientConfig
     */
    @Bean
    public ClientConfig clientConfig() {
        ClientConfig cfg = new ClientConfig();
        cfg.setClusterName("searchCluster");
        return cfg;
    }

}
