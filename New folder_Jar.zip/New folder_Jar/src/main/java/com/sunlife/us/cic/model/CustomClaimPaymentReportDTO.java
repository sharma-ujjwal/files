package com.sunlife.us.cic.model;

import java.math.BigDecimal;
import java.util.Date;

public interface CustomClaimPaymentReportDTO {
    Integer getClmId();
    String getInsuredName();
    String getLstUpdUserId();
    String getPayeFullNm();
    BigDecimal getPayeClmIntAmt();
    BigDecimal getPayeClmPdAmt();
    BigDecimal getPayeWthldAmt();
    Date getPayePmtDt();
    BigDecimal getTotalClaimInterest();
    BigDecimal getTotalInterestWithheld();
    BigDecimal getTotalPaid();
}
