package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 * LoanRateNotProvidedException is a custom exception class that extends RuntimeException.
 * This exception is thrown when the loan rate is not provided.
 */
public class LoanRateNotProvidedException extends RuntimeException{

    public LoanRateNotProvidedException() {
        super(CustomErrors.LOAN_RATE_NOT_PROVIDED_EXCEPTION.getDescription());
    }
    public LoanRateNotProvidedException(String message) {
        super(message);
    }
    public LoanRateNotProvidedException(String message, Throwable cause) {
        super(message, cause);
    }
    public LoanRateNotProvidedException(Throwable cause) {
        super(cause);
    }
}
