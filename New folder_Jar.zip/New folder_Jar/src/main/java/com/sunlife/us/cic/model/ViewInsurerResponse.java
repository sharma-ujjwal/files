package com.sunlife.us.cic.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Response class for viewInsurer API
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Getter
@Setter
@NotNull
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ViewInsurerResponse implements Serializable {

    private String returnCode;
    private String code = "";
    private String message = "";
    private String errorType = "";
    private List<Errors> errorDetails = new ArrayList<>();

    List<ClaimDTO> claimsList;
    List<AdminDTO> adminList;
    List<PayeeDTO> payeeList;
    List<PayorDTO> payorList;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    long totalCount;
}
