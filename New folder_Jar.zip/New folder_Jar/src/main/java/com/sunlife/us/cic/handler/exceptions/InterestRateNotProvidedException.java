package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

public class InterestRateNotProvidedException extends RuntimeException{

    public InterestRateNotProvidedException() {
        super(CustomErrors.INTEREST_RATE_NOT_PROVIDED_EXCEPTION.getDescription());
    }
    public InterestRateNotProvidedException(String message) {
        super(message);
    }
    public InterestRateNotProvidedException(String message, Throwable cause) {
        super(message, cause);
    }
    public InterestRateNotProvidedException(Throwable cause) {
        super(cause);
    }
}
