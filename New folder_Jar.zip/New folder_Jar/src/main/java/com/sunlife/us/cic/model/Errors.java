package com.sunlife.us.cic.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Errors Class for GlobalExceptionHandler
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@Getter
@Setter
@AllArgsConstructor
public class Errors {
    String fieldName;
    String errorMessage;

    public Errors() {

    }

    public static Errors getInstance(){
        return new Errors();
    }

}
