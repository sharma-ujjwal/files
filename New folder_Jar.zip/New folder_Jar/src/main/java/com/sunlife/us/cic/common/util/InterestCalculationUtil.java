package com.sunlife.us.cic.common.util;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.InterestCalculationConstants;
import com.sunlife.us.cic.entity.*;
import com.sunlife.us.cic.handler.exceptions.CompactDateException;
import com.sunlife.us.cic.handler.exceptions.UserInterestRateNotProvidedException;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.model.PayeeDTO;
import com.sunlife.us.cic.repo.CicStateRuleRepo;
import com.sunlife.us.cic.repo.CicStateRuleTierRepo;
import com.sunlife.us.cic.service.CicPayeeService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

/**
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * InterestCalculationUtil class is used to calculate the interest amount for the payee.
 * This class contains the methods to calculate the interest amount based on the interest rate and the number of days.
 */
@Component
@Slf4j
public class InterestCalculationUtil {
    public static PayeeDTO payeeDTO;
    public static StateRule stateRule;
    public static Claim claim;
    public static CurrentRate currentRate;
    public static Admin admin;

    @Autowired
    CicStateRuleRepo cicStateRuleRepo;

    @Autowired
    CicStateRuleTierRepo cicStateRuleTierRepo;

    /**
     * Method to calculate the claim interest for the payee.
     * @param errorList
     * @return PayeeDTO
     */
    public PayeeDTO CalcClaimInterest(List<Errors> errorList) throws InvocationTargetException, IllegalAccessException {
        PayeeDTO currentCalculationPayeeDTO = new PayeeDTO();
        PayeeDTO insuredResidencePayeeDTO = new PayeeDTO();
        PayeeDTO payeePayeeDTO = new PayeeDTO();
        PayeeDTO issueStatePayeeDTO = new PayeeDTO();
        PayeeDTO compactStatePayeeDTO = new PayeeDTO();
        BeanUtils.copyProperties(insuredResidencePayeeDTO, payeeDTO);
        BeanUtils.copyProperties(payeePayeeDTO, payeeDTO);
        BeanUtils.copyProperties(issueStatePayeeDTO, payeeDTO);
        BeanUtils.copyProperties(compactStatePayeeDTO, payeeDTO);

        if(payeeDTO.getPayeDfltOvrdInd()){
            calcForOverrideSate(errorList);
            currentCalculationPayeeDTO = payeeDTO;
        } else {
            currentCalculationPayeeDTO = calcForNonOverrideState(errorList, insuredResidencePayeeDTO, payeePayeeDTO, compactStatePayeeDTO, issueStatePayeeDTO);
        }
        checkForAnomolyState(currentCalculationPayeeDTO);
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to calculate the interest amount for the payee when the state is not an override state.
     * @param errorList
     * @param insuredResidencePayeeDTO
     * @param payeePayeeDTO
     * @param compactStatePayeeDTO
     * @return PayeeDTO
     */
    private PayeeDTO calcForNonOverrideState(List<Errors> errorList, PayeeDTO insuredResidencePayeeDTO, PayeeDTO payeePayeeDTO, PayeeDTO compactStatePayeeDTO, PayeeDTO issueStatePayeeDTO) {
        PayeeDTO currentCalculationPayeeDTO;
        if (claim.getClmForResDthInd().equalsIgnoreCase(InterestCalculationConstants.N_INDICATOR)) {
            String lob = fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), claim.getInsdDthResStCd(), payeeDTO.getPayePmtDt());
            StateRule residenceStateRule = getStateRuleData(lob, claim.getInsdDthResStCd(), payeeDTO.getPayePmtDt());
            if(residenceStateRule == null) {
                residenceStateRule = getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getInsdDthResStCd(), payeeDTO.getPayePmtDt());
            }
            insuredResidencePayeeDTO = InterestCalculationUtil.calculateInterest(errorList,residenceStateRule, InterestCalculationConstants.INSURED_RESIDENCE_STATE, insuredResidencePayeeDTO);

            payeePayeeDTO = calcForPayeeState(errorList, payeePayeeDTO);
            issueStatePayeeDTO = calcForIssueState(errorList, issueStatePayeeDTO);
        } else {
            payeePayeeDTO = calcForPayeeState(errorList, payeePayeeDTO);
            issueStatePayeeDTO = calcForIssueState(errorList, issueStatePayeeDTO);
        }
        if(claim.getClmCompactClcnInd().equalsIgnoreCase(InterestCalculationConstants.T_INDICATOR)) {
            StateRule compactState = new StateRule();
            compactState = getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, InterestCalculationConstants.YY_STATE_CODE, payeeDTO.getPayePmtDt());
            if(compactState == null) {
               throw new CompactDateException(String.format(CustomErrors.COMPACT_DATE_EXCEPTION.getDescription(), formatDate(payeeDTO.getPayePmtDt())));
            }
            compactState.setStCd(InterestCalculationConstants.YY_STATE_CODE);
            compactStatePayeeDTO = InterestCalculationUtil.calculateInterest(errorList,compactState, InterestCalculationConstants.COMPACT_CALCULATION, compactStatePayeeDTO);
        }

        currentCalculationPayeeDTO = determineCurrentCalcPayee(insuredResidencePayeeDTO, payeePayeeDTO, issueStatePayeeDTO, compactStatePayeeDTO);
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to fetch the state information based on the claim, payee and the payment date.
     * @param claim
     * @param payeeDTO
     * @param lobCd
     * @param insdDthResStCd
     * @param payePmtDt
     * @return String
     */
    public String fetchStateInfo(Claim claim, PayeeDTO payeeDTO, String lobCd, String insdDthResStCd, Date payePmtDt) {
        String strLOBIn = lobCd;
        StateRuleTier rstTierTemp = cicStateRuleTierRepo.findTopByStCdOrderByStrlEffDtDesc(lobCd, insdDthResStCd, payePmtDt);
        if (rstTierTemp != null) {
            if (claim != null) {
                String mcstrStrltIdtypCd = rstTierTemp.getStrlt_idtyp_cd().trim();
                Date DtProofDate = claim.getClmProofDt();
                Date DtDeathDate = claim.getClmInsdDthDt();
                BigDecimal dblAmount = claim.getClmTotClmPdAmt();
                long DtDthProofDifference;
                Date DtResultDate;

                double DblCompareVal;
                if (rstTierTemp.getStrlt_calc_value() < 0) {
                    DblCompareVal = rstTierTemp.getStrlt_calc_value() * -1;
                } else {
                    DblCompareVal = rstTierTemp.getStrlt_calc_value();
                }

                if (mcstrStrltIdtypCd.equals(InterestCalculationConstants.PROOFDTH)) {
                    DtDthProofDifference = ChronoUnit.DAYS.between(DtDeathDate.toInstant(), DtProofDate.toInstant());
                    if (rstTierTemp.getStrlt_calc_value() < 0) {
                        if (DtDthProofDifference <= DblCompareVal) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    } else {
                        if (DtDthProofDifference > DblCompareVal) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    }
                } else if (mcstrStrltIdtypCd.equals(InterestCalculationConstants.PROOF)) {
                    DtResultDate = Date.from(DtProofDate.toInstant().plus((long)DblCompareVal, ChronoUnit.DAYS));
                    if (rstTierTemp.getStrlt_calc_value() < 0) {
                        if (!payePmtDt.after(DtResultDate)) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    } else {
                        if (payePmtDt.after(DtResultDate)) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    }
                } else if (mcstrStrltIdtypCd.equals(InterestCalculationConstants.DEATH)) {
                    DtResultDate = Date.from(DtDeathDate.toInstant().plus((long)DblCompareVal, ChronoUnit.DAYS));
                    if (rstTierTemp.getStrlt_calc_value() < 0) {
                        if (!payePmtDt.after(DtResultDate)) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    } else {
                        if (payePmtDt.after(DtResultDate)) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    }
                } else if (mcstrStrltIdtypCd.equals(InterestCalculationConstants.AMOUNT)) {
                    if (rstTierTemp.getStrlt_calc_value() < 0) {
                        if (payeeDTO.getPayeDthbPmtAmt().compareTo(BigDecimal.valueOf(DblCompareVal)) > 0) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    } else {
                        if (payeeDTO.getPayeDthbPmtAmt().compareTo(BigDecimal.valueOf(DblCompareVal)) <= 0) {
                            strLOBIn = strLOBIn.equals(InterestCalculationConstants.MCSTR_GROUP_LOB) ? InterestCalculationConstants.MCSTR_GROUP_TIER_2_LOB : InterestCalculationConstants.MCSTR_INDIVIDUAL_TIER_2_LOB;
                        }
                    }
                }
            }
        }
        return strLOBIn;
    }



    /**
     * Method to calculate the interest amount for the payee when the state is an override state.
     * @param errorList
     */
    private void calcForOverrideSate(List<Errors> errorList) {
        String lob = fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt());
        StateRule overrideStateRule = getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt());
        if(overrideStateRule == null) {
            overrideStateRule = getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt());
        }
        payeeDTO = InterestCalculationUtil.calculateInterest(errorList, overrideStateRule, InterestCalculationConstants.CALC_STATE, payeeDTO);
    }

    /**
     * Method to calculate the interest amount for the payee when the state is an issue state.
     * @param errorList
     * @return PayeeDTO
     */
    private PayeeDTO calcForIssueState(List<Errors> errorList, PayeeDTO issueStatePayeeDTO) {
        String lob = fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), claim.getIssStCd(), payeeDTO.getPayePmtDt());
        StateRule issueStateRule = getStateRuleData(lob, claim.getIssStCd(), payeeDTO.getPayePmtDt());
        if(issueStateRule == null) {
            issueStateRule = getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getIssStCd(), payeeDTO.getPayePmtDt());
        }
        issueStatePayeeDTO = InterestCalculationUtil.calculateInterest(errorList,issueStateRule, InterestCalculationConstants.ISSUE_STATE, issueStatePayeeDTO);
        return issueStatePayeeDTO;
    }

    /**
     * Method to calculate the interest amount for the payee when the state is a payee state.
     * @param errorList
     * @param payeePayeeDTO
     * @return PayeeDTO
     */
    private PayeeDTO calcForPayeeState(List<Errors> errorList, PayeeDTO payeePayeeDTO) {
        if(!payeeDTO.getPayeStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE)) {
            String lob = fetchStateInfo(claim, payeeDTO, claim.getAdmin().getLobCd(), payeeDTO.getPayeStCd(), payeeDTO.getPayePmtDt());
            StateRule payeeStateRule = getStateRuleData(lob, payeeDTO.getPayeStCd(), payeeDTO.getPayePmtDt());
            if(payeeStateRule == null) {
                payeeStateRule = getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, payeeDTO.getPayeStCd(), payeeDTO.getPayePmtDt());
            }
            payeePayeeDTO = InterestCalculationUtil.calculateInterest(errorList,payeeStateRule, InterestCalculationConstants.PAYEE_STATE, payeePayeeDTO);
        }
        return payeePayeeDTO;
    }

    /**
     * Method to determine the current calculation payee based on the interest amount.
     * @param insuredResidencePayeeDTO
     * @param payeePayeeDTO
     * @param issueStatePayeeDTO
     * @param compactStatePayeeDTO
     * @return PayeeDTO
     */
   private PayeeDTO determineCurrentCalcPayee(PayeeDTO insuredResidencePayeeDTO, PayeeDTO payeePayeeDTO, PayeeDTO issueStatePayeeDTO, PayeeDTO compactStatePayeeDTO) {
        PayeeDTO currentCalculationPayeeDTO = payeeDTO.getPayeStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE) ? issueStatePayeeDTO : payeePayeeDTO;
        currentCalculationPayeeDTO.setCalcStCd(payeeDTO.getPayeStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE) ? claim.getIssStCd() : payeeDTO.getPayeStCd());

        if(admin.getAdmnSystDsc().trim().equalsIgnoreCase(CicConstants.LINEOFBUSINESS_GROUP)) {
            currentCalculationPayeeDTO = getPayeeDTOForAdminSystem(insuredResidencePayeeDTO, payeePayeeDTO, issueStatePayeeDTO, compactStatePayeeDTO, currentCalculationPayeeDTO);
        } else {
            currentCalculationPayeeDTO = getPayeeDTOForNonAdminSystem(insuredResidencePayeeDTO, issueStatePayeeDTO, compactStatePayeeDTO, currentCalculationPayeeDTO);
        }
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to determine the current calculation payee based on the interest amount for the admin system.
     * @param insuredResidencePayeeDTO
     * @param payeePayeeDTO
     * @param issueStatePayeeDTO
     * @param compactStatePayeeDTO
     * @param currentCalculationPayeeDTO
     * @return PayeeDTO
     */
    private PayeeDTO getPayeeDTOForAdminSystem(PayeeDTO insuredResidencePayeeDTO, PayeeDTO payeePayeeDTO, PayeeDTO issueStatePayeeDTO, PayeeDTO compactStatePayeeDTO, PayeeDTO currentCalculationPayeeDTO) {
        if(!isAnomolyState(payeeDTO.getCalcStCd()) && !payeeDTO.getPayeStCd().equalsIgnoreCase(InterestCalculationConstants.ZZ_STATE_CODE)) {
            currentCalculationPayeeDTO = payeePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(payeeDTO.getPayeStCd());
        } else if (!isAnomolyState(claim.getInsdDthResStCd()) ) {
            currentCalculationPayeeDTO = insuredResidencePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(claim.getInsdDthResStCd());
        } else {
            currentCalculationPayeeDTO = issueStatePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(claim.getIssStCd());
        }

        currentCalculationPayeeDTO = getPayeeDTOWithHighestInterestAmount(insuredResidencePayeeDTO, payeePayeeDTO, issueStatePayeeDTO, compactStatePayeeDTO, currentCalculationPayeeDTO);
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to determine the current calculation payee based on the interest amount for the non admin system.
     * @param insuredResidencePayeeDTO
     * @param issueStatePayeeDTO
     * @param compactStatePayeeDTO
     * @param currentCalculationPayeeDTO
     * @return PayeeDTO
     */
    private PayeeDTO getPayeeDTOForNonAdminSystem(PayeeDTO insuredResidencePayeeDTO, PayeeDTO issueStatePayeeDTO, PayeeDTO compactStatePayeeDTO, PayeeDTO currentCalculationPayeeDTO) {
        currentCalculationPayeeDTO = getPayeeDTOWithHighestInterestAmount(insuredResidencePayeeDTO, null, issueStatePayeeDTO, compactStatePayeeDTO, currentCalculationPayeeDTO);
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to determine the payee with the highest interest amount.
     * @param insuredResidencePayeeDTO
     * @param payeePayeeDTO
     * @param issueStatePayeeDTO
     * @param compactStatePayeeDTO
     * @param currentCalculationPayeeDTO
     * @return PayeeDTO
     */
    private PayeeDTO getPayeeDTOWithHighestInterestAmount(PayeeDTO insuredResidencePayeeDTO, PayeeDTO payeePayeeDTO, PayeeDTO issueStatePayeeDTO, PayeeDTO compactStatePayeeDTO, PayeeDTO currentCalculationPayeeDTO) {
        if(issueStatePayeeDTO.getPayeClmIntAmt().compareTo(currentCalculationPayeeDTO.getPayeClmIntAmt()) > 0) {
            currentCalculationPayeeDTO = issueStatePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(claim.getIssStCd());
        }
        if(insuredResidencePayeeDTO.getPayeClmIntAmt().compareTo(currentCalculationPayeeDTO.getPayeClmIntAmt()) > 0) {
            currentCalculationPayeeDTO = insuredResidencePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(claim.getInsdDthResStCd());
        }
        if(payeePayeeDTO != null && payeePayeeDTO.getPayeClmIntAmt().compareTo(currentCalculationPayeeDTO.getPayeClmIntAmt()) > 0) {
            currentCalculationPayeeDTO = payeePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(payeeDTO.getPayeStCd());
        }
        if(claim.getClmCompactClcnInd().equalsIgnoreCase(InterestCalculationConstants.T_INDICATOR) && compactStatePayeeDTO.getPayeClmIntAmt().compareTo(currentCalculationPayeeDTO.getPayeClmIntAmt()) > 0) {
            currentCalculationPayeeDTO = compactStatePayeeDTO;
            currentCalculationPayeeDTO.setCalcStCd(InterestCalculationConstants.YY_STATE_CODE);
        }
        return currentCalculationPayeeDTO;
    }

    /**
     * Method to check for the anomoly state and set the payee amount to 0.
     * @param currentCalculationPayeeDTO
     */
    private void checkForAnomolyState(PayeeDTO currentCalculationPayeeDTO) {
        if(isAnomolyState(currentCalculationPayeeDTO.getCalcStCd()) && claim.getAdmnSystCd() == 10) {
            currentCalculationPayeeDTO.setPayeClmIntAmt(BigDecimal.valueOf(0.0));
            currentCalculationPayeeDTO.setPayeWthldAmt(BigDecimal.valueOf(0.0));
            currentCalculationPayeeDTO.setPayeIntDaysPdNum(0);
            currentCalculationPayeeDTO.setPayeClmIntRt(BigDecimal.valueOf(0.0));
            currentCalculationPayeeDTO.setPayeClmPdAmt(payeeDTO.getPayeDthbPmtAmt());
            currentCalculationPayeeDTO.setInterestCalculationMessage("Note: This is a group policy - an interest rate of 0% applies.");
        }
    }

    /**
     * Method to check if the state is an anomoly state
     * @param stateCode
     * @return boolean
     */
    public Boolean isAnomolyState(String stateCode) {
        return InterestCalculationConstants.isAnomolyState(stateCode);
    }


    /**
     * calculateInterest
     * Describes the steps to calculate the interest amount for the payee.
     * @param errorList
     * @return
     */
    public static PayeeDTO calculateInterest(List<Errors> errorList, StateRule stateRule, String interestFor, PayeeDTO payeeDTO) {
        BigDecimal interestRate = BigDecimal.valueOf(0.0);
        payeeDTO.setCalcStateMsg(stateRule != null?stateRule.getStrlSpclInstrTxt():InterestCalculationConstants.NONE);

        // Step 1 : If Calculation Date Type Code is NONE , no interest will be paid and jump to step 8.
        boolean noInterestFlag = step1Call(stateRule, errorList, payeeDTO, interestFor);

        if (!noInterestFlag) {
            // Step 2 : If Required Date Type Code is NONE , no interest will be paid and jump to step 8.
            noInterestFlag = step2Call(stateRule, errorList, payeeDTO, interestFor);
        }

        // If no interest is to be paid, jump to step 8.
        if (!noInterestFlag) {
            // Step 3 : Set Payable Period End Date
            step3SetPayablePeriodEndDate(stateRule, claim, payeeDTO);
            // Step 4 : No interest will be paid if the claim is being  paid on or before the Payable Period End Date and jump to step 8.
            if (payeeDTO.getPayePmtDt().compareTo(payeeDTO.getPayablePeriodEndDate()) <= 0) {
                errorList.add(new Errors(InterestCalculationConstants.CLAIM_INTEREST_RATE, InterestCalculationConstants.NO_INTEREST_PAID_MESSAGE));
                payeeDTO.setPayeIntDaysPdNum(0);
                payeeDTO.setPayeClmIntRt(BigDecimal.valueOf(0.0));
                payeeDTO.setInterestCalculationMessage(InterestCalculationConstants.INTEREST_CALCULATION_MESSAGE + interestFor + ". No Interest was paid due to the Date of Payment being within the Payable Period.");
                interestRate = BigDecimal.valueOf(0.0);
            }
            else {
                // Step 5 : Set Figured From Date
                step5SetFiguredFromDate(stateRule, claim, payeeDTO);
                // Step 6 : Calculate Interest Days
                step6CalculateInterestDays(payeeDTO);
                // Step 7 : Determine Interest Rate
                interestRate = step7DetermineInterestRate(payeeDTO, stateRule, currentRate, interestFor);
            }
        }


        // Step 8 : Calculate Claims Interest Amount
        step8CalculateClaimsInterestAmount(interestRate, payeeDTO, stateRule, interestFor);

        // Step 9 : Calculate Withheld Amount
        step9CalculateWithheldAmount(payeeDTO);

        // Step 10 : Calculate Total Amount
        step10CalculateTotalAmount(payeeDTO);

        return payeeDTO;
    }


    /**
     * Step 1 : If Calculation Date Type Code is NONE , no interest will be paid and jump to step 8.
     * Method to isNoInterest
     * Determines if interest should be paid or not based on the state rule.
     *
     * @param stateRule
     * @param errorList
     * @param payeeDTO
     * @param interestFor
     * @return boolean
     */
    public static boolean step1Call(StateRule stateRule, List<Errors> errorList, PayeeDTO payeeDTO, String interestFor) {
        if (!stateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE) && stateRule.getCalcIdtypCd().trim().equalsIgnoreCase(InterestCalculationConstants.NONE)) {
            errorList.add(new Errors(InterestCalculationConstants.CLAIM_INTEREST_RATE, "No interest was paid due as Calculation Date Type Code is NONE."));
            payeeDTO.setPayeIntDaysPdNum(0);
            if(!payeeDTO.getPayeDfltOvrdInd())
            {
                payeeDTO.setPayeClmIntRt(BigDecimal.valueOf(0.0));
            }
            payeeDTO.setInterestCalculationMessage("The claim interest rate was calculated based on the rates for the "+interestFor+". No interest was paid due to that state's Calculation Interest Date Type Code Specification.");
            return true;
        }
        return false;
    }

    /**
     * Step 2 : If Required Date Type Code is NONE , no interest will be paid and jump to step 8.
     * Method to isNoInterest
     * Determines if interest should be paid or not based on the state rule.
     *
     * @param stateRule
     * @param errorList
     * @param payeeDTO
     * @param interestFor
     * @return boolean
     */
    public static boolean step2Call(StateRule stateRule, List<Errors> errorList, PayeeDTO payeeDTO, String interestFor) {
        if (!stateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE) && stateRule.getReqdIdtypCd().trim().equalsIgnoreCase(InterestCalculationConstants.NONE)) {
            errorList.add(new Errors(InterestCalculationConstants.CLAIM_INTEREST_RATE,"No interest was paid due as Required Date Type Code is NONE."));
            payeeDTO.setPayeIntDaysPdNum(0);
            if(!payeeDTO.getPayeDfltOvrdInd())
            {
                payeeDTO.setPayeClmIntRt(BigDecimal.valueOf(0.0));
            }
            payeeDTO.setInterestCalculationMessage("The claim interest rate was calculated based on the rates for the "+interestFor+". No interest was paid due to that state's Required Interest Date Type Code Specification.");
            return true;
        }
        return false;
    }

    /**
     * Step 3 : Set Payable Period End Date
     * Method to setPayablePeriodEndDate
     * Determines the Payable Period End Date based on the state rule and the claim.
     * @param stateRule
     * @param claim
     * @param payeeDTO
     */
    public static void step3SetPayablePeriodEndDate(StateRule stateRule, Claim claim, PayeeDTO payeeDTO) {
        if(!stateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE)) {
            Date baseDate = stateRule.getReqdIdtypCd().trim().equalsIgnoreCase(InterestCalculationConstants.REQUIRED_ID_TYPE_CODE_PROOF) ? claim.getClmProofDt() : claim.getClmInsdDthDt();
            payeeDTO.setPayablePeriodEndDate(DateUtils.addDays(baseDate, stateRule.getStrlIntReqdOfstNum()));
        } else {
            payeeDTO.setPayablePeriodEndDate(claim.getClmInsdDthDt());
        }
    }

    /**
     * Step 5 : Set Figured From Date
     * Method to setFiguredFromDate
     * Determines the Figured From Date based on the state rule and the claim.
     * @param stateRule
     * @param claim
     * @param payeeDTO
     */
    private static void step5SetFiguredFromDate(StateRule stateRule, Claim claim, PayeeDTO payeeDTO) {
        Date baseDate = stateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE) ? claim.getClmInsdDthDt() : stateRule.getCalcIdtypCd().trim().equalsIgnoreCase(InterestCalculationConstants.REQUIRED_ID_TYPE_CODE_PROOF) ? claim.getClmProofDt() : claim.getClmInsdDthDt();
        payeeDTO.setFiguredFromDate(DateUtils.addDays(baseDate, stateRule.getStrlIntCalcOfstNum()));
    }


    /**
     * Step 6 : Calculate Interest Days
     * Method to calculateInterestDays
     * Determines the number of days between the Figured From Date and the Payment Date.
     * @param payeeDTO
     */
    private static void step6CalculateInterestDays(PayeeDTO payeeDTO) {
        Date figuredDate = payeeDTO.getFiguredFromDate();
        Date paymentDate = payeeDTO.getPayePmtDt();

        LocalDate figuredDateLocal = figuredDate.toInstant().atZone(ZoneId.of("America/New_York")).toLocalDate();
        LocalDate paymentDateLocal = paymentDate.toInstant().atZone(ZoneId.of("America/New_York")).toLocalDate();
        log.info("Figured local Date : "+figuredDateLocal);
        log.info("Payment local Date : "+paymentDateLocal);

        long daysInBetween = ChronoUnit.DAYS.between(figuredDateLocal, paymentDateLocal);
        log.info("Difference in Days using ChronoUnit : "+daysInBetween);

        payeeDTO.setPayeIntDaysPdNum((int) Math.max(daysInBetween, 0));
    }

    /**
     * Step 7 : Determine Interest Rate
     * Method to determineInterestRate
     * Determines the interest rate to be used based on the payee's default override indicator and the number of days.
     * @param payeeDTO
     * @param stateRule
     * @param currentRate
     * @return interestRate
     */
    private static BigDecimal step7DetermineInterestRate(PayeeDTO payeeDTO, StateRule stateRule, CurrentRate currentRate, String interestFor) {
        BigDecimal interestRate = BigDecimal.valueOf(0.0);
        if(stateRule.getStCd().equalsIgnoreCase(InterestCalculationConstants.YY_STATE_CODE) && !payeeDTO.getPayeDfltOvrdInd()) {
            interestRate = payeeDTO.getCompactInterestRate();
        }
        else if (payeeDTO.getPayeDfltOvrdInd()) {
            interestRate = payeeDTO.getPayeClmIntRt();
            String interestCalculationMessage = String.format(
                    InterestCalculationConstants.INTEREST_CALCULATION_MESSAGE_TEMPLATE,
                    interestFor,
                    payeeDTO.getPayeIntDaysPdNum(),
                    formatDate(payeeDTO.getFiguredFromDate()),
                    formatDate(payeeDTO.getPayePmtDt())
            );

            payeeDTO.setInterestCalculationMessage(interestCalculationMessage);
        } else if (payeeDTO.getPayeIntDaysPdNum() > 0) {
            interestRate = fetchInterestRate(stateRule, stateRule.getStCd(), payeeDTO, currentRate, interestFor);
        }
        payeeDTO.setCalcStCd(stateRule.getStCd());
        payeeDTO.setPayeClmIntRt(interestRate);
        return interestRate;
    }

    /**
     * Part of step 7
     * Method to fetchInterestRate
     * @return interest
     */
    public static BigDecimal fetchInterestRate(StateRule stateRule, String stCd, PayeeDTO payeeDTO, CurrentRate currentRate, String interestFor) {
        BigDecimal rateToUse = BigDecimal.valueOf(0.0);
        BigDecimal currentLoanRate = BigDecimal.valueOf(0.0);
        BigDecimal currentInterestRate = BigDecimal.valueOf(0.0);

        String interestCalculationMessage = String.format(
                InterestCalculationConstants.INTEREST_CALCULATION_MESSAGE_TEMPLATE,
                interestFor,
                payeeDTO.getPayeIntDaysPdNum(),
                formatDate(payeeDTO.getFiguredFromDate()),
                formatDate(payeeDTO.getPayePmtDt())
        );

        payeeDTO.setInterestCalculationMessage(interestCalculationMessage);

        switch (stateRule.getIruleCd().trim()) {
            case InterestCalculationConstants.CURLN:
                rateToUse = getRespectiveInterestRate(payeeDTO, interestFor);
                break;
            case InterestCalculationConstants.CURLN_PLUS_X:
                currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                rateToUse = currentLoanRate.add(stateRule.getStrlIntRuleAmt());
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentLoanRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, "");
                break;
            case InterestCalculationConstants.CURLN_MINUS_X:
                currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                rateToUse = currentLoanRate.subtract(stateRule.getStrlIntRuleAmt());
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentLoanRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X,"");
                break;
            case InterestCalculationConstants.CLNW_MAX:
                    currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                if (currentLoanRate.compareTo(stateRule.getStrlIntRuleAmt()) >0) {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                } else {
                    rateToUse = currentLoanRate;
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentLoanRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_MAX_OF);
                break;
            case InterestCalculationConstants.CLNW_MIN:
                    currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                if (currentLoanRate.compareTo( stateRule.getStrlIntRuleAmt()) <0) {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                } else {
                    rateToUse = currentLoanRate;
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentLoanRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_MIN_OF);
                break;
            case InterestCalculationConstants.CURRT:
                currentInterestRate = currentRate.getCurrIntRt();
                rateToUse = currentInterestRate;
                break;
            case InterestCalculationConstants.CURRT_PLUS_X:
                currentInterestRate = currentRate.getCurrIntRt();
                rateToUse = currentInterestRate.add(stateRule.getStrlIntRuleAmt());
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, "");
                break;
            case InterestCalculationConstants.CURRT_MINUS_X:
                currentInterestRate = currentRate.getCurrIntRt();
                rateToUse = currentInterestRate.subtract(stateRule.getStrlIntRuleAmt());
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, "");
                break;
            case InterestCalculationConstants.CRTW_MAX:
                currentInterestRate = currentRate.getCurrIntRt();
                if (currentInterestRate.compareTo(stateRule.getStrlIntRuleAmt()) > 0) {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                } else {
                    rateToUse = currentInterestRate;
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_MAX_OF);
                break;
            case InterestCalculationConstants.CRTW_MIN:
                currentInterestRate = currentRate.getCurrIntRt();

                if (currentInterestRate.compareTo(stateRule.getStrlIntRuleAmt()) < 0) {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                } else {
                    rateToUse = currentInterestRate;
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_MIN_OF);
                break;
            case InterestCalculationConstants.GTCLN_X:
                    currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                if (currentLoanRate.compareTo(stateRule.getStrlIntRuleAmt()) >0) {
                    rateToUse = currentLoanRate;
                } else {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentLoanRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_GREATER_OF);
                break;
            case InterestCalculationConstants.GTCRT_LN:
                currentInterestRate = currentRate.getCurrIntRt();
                    currentLoanRate = getRespectiveInterestRate(payeeDTO, interestFor);
                if (currentInterestRate.compareTo(currentLoanRate) >0) {
                    rateToUse = currentInterestRate;
                } else {
                    rateToUse = currentLoanRate;
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, currentLoanRate, InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.CURRENT_LOAN_RATE_X, InterestCalculationConstants.THE_GREATER_OF);
                break;
            case InterestCalculationConstants.GTCRT_AND_X:
                currentInterestRate = currentRate.getCurrIntRt();
                if (currentInterestRate.compareTo(stateRule.getStrlIntRuleAmt()) >0) {
                    rateToUse = currentInterestRate;
                } else {
                    rateToUse = stateRule.getStrlIntRuleAmt();
                }
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, currentInterestRate, stateRule.getStrlIntRuleAmt(), InterestCalculationConstants.CURRENT_RATE_X, InterestCalculationConstants.STATE_RULE_AMOUNT_X, InterestCalculationConstants.THE_GREATER_OF);
                break;
            case InterestCalculationConstants.SPECAMT:
                rateToUse = stateRule.getStrlIntRuleAmt();
                rateToUse = checkRateToUse(stateRule, payeeDTO, rateToUse, stateRule.getStrlIntRuleAmt(), BigDecimal.valueOf(0), InterestCalculationConstants.STATE_RULE_AMOUNT_X, null, "");
                break;
            case InterestCalculationConstants.PROMPT:
                    rateToUse = getRespectiveInterestRate(payeeDTO, interestFor);
                break;

            default:
                // Handle unexpected value
                throw new IllegalArgumentException("Unexpected value: " + stateRule.getIruleCd());

        }
        return rateToUse;
    }

    private static BigDecimal getRespectiveInterestRate(PayeeDTO payeeDTO, String interestFor) {
        return interestFor.equalsIgnoreCase(InterestCalculationConstants.ISSUE_STATE) ? payeeDTO.getIssueInterestRate() : interestFor.equalsIgnoreCase(InterestCalculationConstants.PAYEE_STATE) ? payeeDTO.getPayeeInterestRate() : payeeDTO.getResidenceInterestRate();
    }

    /**
     * Part of step 7
     * Method to checkRateToUse
     * @return rateToUse
     */
    private static BigDecimal checkRateToUse(StateRule stateRule, PayeeDTO payeeDTO, BigDecimal rateToUse, BigDecimal firstRate, BigDecimal secondRate,
                                         String firstMsg, String secondMsg, String thirdMsg) {
        if (rateToUse.compareTo(BigDecimal.valueOf(0.0)) < 0) {
            if(payeeDTO.getCurrentInterestRateProvided()) {
                rateToUse = payeeDTO.getCurrentInterestRate();
            } else {
                String exceptionMsg = InterestCalculationConstants.DERIVED_RATE_BASED_ON + thirdMsg + firstMsg + firstRate + InterestCalculationConstants.CLOSE_PAREN
                        + (secondMsg != null?InterestCalculationConstants.AND:"") + secondMsg + (secondMsg != null?secondRate:"") + (secondMsg != null?InterestCalculationConstants.CLOSE_PAREN:"")
                        + InterestCalculationConstants.IS_NEGATIVE_NUMBER_SUPPLY_RATE_TO_USE
                        + InterestCalculationConstants.FOR_THE + stateRule.getStCd();
                throw new UserInterestRateNotProvidedException(exceptionMsg);
            }
        }
        return rateToUse;
    }

    /**
     * Step 8 : Calculate Claims Interest Amount
     * Method to calculateClaimsInterestAmount
     * Calculates the interest amount, withheld amount, and paid amount for the payee.
     * @param interestRate
     * @param payeeDTO
     */
    private static void step8CalculateClaimsInterestAmount(BigDecimal interestRate, PayeeDTO payeeDTO, StateRule stateRule, String interestFor) {
        BigDecimal claimInterestAmount = BigDecimal.ZERO;
        if(interestRate.compareTo(BigDecimal.valueOf(0.0)) > 0){
            String interestCalculationMessage = String.format(
                    InterestCalculationConstants.INTEREST_CALCULATION_MESSAGE_TEMPLATE,
                    interestFor,
                    payeeDTO.getPayeIntDaysPdNum(),
                    formatDate(payeeDTO.getFiguredFromDate()),
                    formatDate(payeeDTO.getPayePmtDt())
            );

            payeeDTO.setInterestCalculationMessage(interestCalculationMessage);
            // Step 8: Calculate the interest amount
            claimInterestAmount = payeeDTO.getPayeDthbPmtAmt().multiply(interestRate.divide(BigDecimal.valueOf(100))).multiply(BigDecimal.valueOf(payeeDTO.getPayeIntDaysPdNum() / 365.0));
            claimInterestAmount = claimInterestAmount.setScale(2, RoundingMode.HALF_UP);
        }
        payeeDTO.setPayeClmIntAmt(claimInterestAmount);
    }

    public static String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(date);
    }

    /**
     * Step 9 : Calculate Withheld Amount
     * Method to calculateWithheldAmount
     * Calculates the withheld amount for the payee.
     * @param payeeDTO
     */
    private static void step9CalculateWithheldAmount(PayeeDTO payeeDTO) {
        BigDecimal withheldAmount = BigDecimal.ZERO;
        withheldAmount = payeeDTO.getPayeClmIntAmt().multiply(payeeDTO.getPayeWthldRt().divide(BigDecimal.valueOf(100) ));
        withheldAmount = withheldAmount.setScale(2, RoundingMode.HALF_UP);

        payeeDTO.setPayeWthldAmt(withheldAmount);
    }

    /**
     * Step 10 : Calculate Total Amount
     * Method to calculateTotalAmount
     * Calculates the total amount for the payee.
     * @param payeeDTO
     */
    private static void step10CalculateTotalAmount(PayeeDTO payeeDTO) {
        BigDecimal claimPaidAmount = (payeeDTO.getPayeDthbPmtAmt().add(payeeDTO.getPayeClmIntAmt())).subtract(payeeDTO.getPayeWthldAmt());
        payeeDTO.setPayeClmPdAmt(claimPaidAmount.setScale(2, RoundingMode.HALF_UP));
    }

    public StateRule getStateRuleData(String lobCd, String stCd, Date payePmtDt) {
        return cicStateRuleRepo.findTopByStCdOrderByStrlEffDtDesc(lobCd, stCd, payePmtDt);
    }

    public static PayeeDTO getPayeeDTO() {
        return payeeDTO;
    }

    public static void setPayeeDTO(PayeeDTO payeeDTO) {
        InterestCalculationUtil.payeeDTO = payeeDTO;
    }

    public static StateRule getStateRule() {
        return stateRule;
    }

    public static void setStateRule(StateRule stateRule) {
        InterestCalculationUtil.stateRule = stateRule;
    }

    public static Claim getClaim() {
        return claim;
    }

    public static void setClaim(Claim claim) {
        InterestCalculationUtil.claim = claim;
    }

    public static CurrentRate getCurrentRate() {
        return currentRate;
    }

    public static void setCurrentRate(CurrentRate currentRate) {
        InterestCalculationUtil.currentRate = currentRate;
    }

    public void setAdmin(Admin admin) {
        InterestCalculationUtil.admin = admin;
    }
}
