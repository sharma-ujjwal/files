package com.sunlife.us.cic;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;

/**
 *
 * CicApplication main Class of springboot project.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Swagger Implementation
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 *
 */
@SpringBootApplication
@EnableEncryptableProperties
@OpenAPIDefinition(
		info = @Info(
				title = "CIC Application",
				description = "Claims Interest Calculator Application",
				version = "v1"
		),
		servers = @Server(
				url = "${DOMAIN_NAME}:" + "${server.port}",
				description = "CIC API"
		)
)
@EnableCaching
public class CicApplication {
	public static void main(String[] args) {
		SpringApplication.run(CicApplication.class, args);
	}
}
