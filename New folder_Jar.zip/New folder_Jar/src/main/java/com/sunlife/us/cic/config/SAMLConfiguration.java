package com.sunlife.us.cic.config;

import org.opensaml.core.config.InitializationException;
import org.opensaml.saml.saml2.core.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.saml2.core.Saml2X509Credential;
import org.springframework.security.saml2.provider.service.authentication.OpenSaml4AuthenticationProvider;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticationToken;
import org.springframework.security.saml2.provider.service.registration.InMemoryRelyingPartyRegistrationRepository;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistration;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;


/**
 * SAML configuration
 */
@Configuration
public class SAMLConfiguration {


    @Value("${saml2.sp.registration-id}")
    private String registrationId;

    @Value("${saml2.sp.entity-id}")
    private String spEntityId;

    @Value("${saml2.sp.acs}")
    private String spAcsUrl;

    @Value("${saml2.idp.entity-id}")
    private String idpEntityId;

    @Value("${saml2.idp.sso}")
    private String idpSso;

    @Value("${saml2.idp.certs-file}")
    private String idpCertsFile;


    @Bean
    public RelyingPartyRegistrationRepository relyingPartyRegistrationRepository() throws CertificateException, IOException, ParserConfigurationException, InitializationException, SAXException {
        Saml2X509Credential credential= Saml2X509Credential.verification(getX509Certificate());
        RelyingPartyRegistration registration = RelyingPartyRegistration.withRegistrationId(registrationId)
                .entityId(spEntityId)
                .assertionConsumerServiceLocation(spAcsUrl)
                .assertingPartyDetails(party -> party
                        .entityId(idpEntityId)
                        .singleSignOnServiceLocation(idpSso)
                        .verificationX509Credentials(c -> c.add(credential))
                        .wantAuthnRequestsSigned(false)).build();
        return new InMemoryRelyingPartyRegistrationRepository(registration);
    }


    /**
     * Description: converts the .cer file into X509Certificate
     * @return
     * @throws CertificateException
     * @throws IOException
     */
    X509Certificate getX509Certificate() throws CertificateException, IOException {
        ClassPathResource resource = new ClassPathResource(idpCertsFile);
        InputStream inputStream = resource.getInputStream();
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        return (X509Certificate) cf.generateCertificate(inputStream);
    }

}
