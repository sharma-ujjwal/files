package com.sunlife.us.cic.entity;

public class StateRuleTierCompositeKey implements java.io.Serializable{
    String st_cd;
    String lob_cd;
    String strlt_eff_dt;
}
