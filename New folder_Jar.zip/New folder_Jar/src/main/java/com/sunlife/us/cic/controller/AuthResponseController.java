package com.sunlife.us.cic.controller;


import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;



/**
 * Rest Controller to MAP the Assertion Consumer Service URL.
 */
@RestController
@RequestMapping("/login/cic/sso/saml/acs")
public class AuthResponseController {


    /**
     * Description:: This redirect method is required due to custom acs url configured on Azure AD.
     *      The response from Aure AD will be redirected to default SAML assertion url for validation
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
        @PostMapping
        public void redirectTheURl(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            RequestDispatcher dispatcher = request.getRequestDispatcher("/login/saml2/sso/azure");
            dispatcher.forward(request, response);
        }
}
