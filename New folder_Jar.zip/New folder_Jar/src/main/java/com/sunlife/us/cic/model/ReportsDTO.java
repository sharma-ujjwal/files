package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.web.util.HtmlUtils;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

@Getter
@Setter
public class ReportsDTO implements Serializable {
    private Date fromDate;
    private Date toDate;
    private String reportType;
    private String lineOfBusiness;

    public void setReportType(String reportType) {
        this.reportType = HtmlUtils.htmlEscape(reportType);
    }

    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = HtmlUtils.htmlEscape(lineOfBusiness);
    }
}
