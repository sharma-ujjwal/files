package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.handler.exceptions.JwtTokenInvalidException;
import com.sunlife.us.cic.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

import java.lang.reflect.Array;
import java.security.Key;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;

import static com.sunlife.us.cic.common.SecurityConstants.*;


/**
 * This service class helps to deal with the claim related data for the JWT token (Creation & Validation of the token)
 *
 */
@Service
public class JwtService {
    @Value("${security.jwt.secret-key}")
    private String secretKey;

    @Value("${security.jwt.expiration-time}")
    private long jwtExpiration;

    @Value("${ad-groups-std-user}")
    private String adGroupsStdUser;

    @Value("${ad-groups-admin-user}")
    private String adGroupsAdmUser;

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    public String generateToken(User userDetails) {
        return generateToken(new HashMap<>(), userDetails);
    }

    public String generateToken(Map<String, Object> extraClaims, User userDetails) {
        return buildToken(extraClaims, userDetails, jwtExpiration);
    }

    public long getExpirationTime() {
        return jwtExpiration;
    }

    public String[] getAdminAdGroups() {
        return Arrays.stream(adGroupsAdmUser.split(",")).map(String::trim).toArray(String[]::new);
    }

    public String[] getStdGroups() {
        return  Arrays.stream(adGroupsStdUser.split(",")).map(String::trim).toArray(String[]::new);
    }

    /**
     * Description: Return a signed token
     * @param extraClaims
     * @param userDetails
     * @param expiration
     * @return
     */
    private String buildToken(
            Map<String, Object> extraClaims,
            User userDetails,
            long expiration
    ) {
        return Jwts
                .builder()
                .setClaims(extraClaims)
                .setSubject(userDetails.getUsername())
                .claim(EMAIL, userDetails.getEmail())
                .claim(ROLE, userDetails.getRole())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSignInKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * Description: Validates the token
     * @param token
     * @param userDetails
     * @return
     */
    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        if (username.equals(userDetails.getUsername()) && !isTokenExpired(token)) return true;
        return false;
    }

    /**
     * Description: Checks if the token  has been expired ot not
     * @param token
     * @return
     */
    boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /**
     * Description: Checks for the expiration time set for the token
     * @param token
     * @return
     */
    Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    /**
     * Description: Method helps to get all the claim details from the JWT token
     * @param token
     * @return
     */
    public Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith((SecretKey) getSignInKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /**
     * Description: Get the key decoded
     * @return key
     */

    private Key getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }


    /**
     * Description: This method helps to get the role of current logged in user post SAML assertion
     * @param adGroupName
     * @return
     */
    public String getTheLoggedInUserRole(String adGroupName) {
        String[] adGroupsData = adGroupName.split(",");
        for (String adGroup: adGroupsData) {
            if (Arrays.asList(getAdminAdGroups()).contains(adGroup.trim())) return ROLE_ADMIN_USER;
        }
        for (String adGroup: adGroupsData) {
            if (Arrays.asList(getStdGroups()).contains(adGroup.trim())) return ROLE_STD_USER;
        }
        return null;
    }


    /**
     * Description: This is required due to Azure returing the claims wrapped in '[]' at the start and ending of attributes
     * @param str
     * @return
     */
    public String removeFirstAndLastChar(String str) {
        if (str != null && str.length() > 2) {
            return str.substring(1, str.length() - 1);
        }
        return str;
    }
}