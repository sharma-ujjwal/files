package com.sunlife.us.cic.service;

import com.sunlife.us.cic.model.GenerateTaxFileReportsDTO;
import com.sunlife.us.cic.model.ReportsDTO;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.IOException;

@Component
public interface CicReportService {
    InputStreamResource generatePdfReport();
    InputStreamResource printReport(ReportsDTO reportsDTO);

    String generateTaxFile(GenerateTaxFileReportsDTO generateTaxFileReportsDTO);

    String getTaxFiles(boolean viewNonPR, boolean viewPR);

    InputStreamResource printIndividualReports(String html, Integer claimId) throws IOException;
}

