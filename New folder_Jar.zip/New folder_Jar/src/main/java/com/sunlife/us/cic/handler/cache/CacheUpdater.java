package com.sunlife.us.cic.handler.cache;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.regex.Pattern;

/**
 * CacheUpdater Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * This class is responsible for updating the cache when a claim is updated or deleted.
 * It uses the hazelcast instance to get the cache and then deletes the cache if the claim is deleted or updates the cache if the claim is updated.
 */
@Component
public class CacheUpdater {

    @Autowired
    private HazelcastInstance hazelcastInstance;

    /**
     * Method to delete cache
     * @param claim
     */
    public void deleteCache(Claim claim) {
        processCache(claim, null);
    }

    /**
     * Method to delete Cache in case of update insurer call
     * @param newClaim
     * @param oldClaim
     */
    public void updateCache(Claim newClaim, Claim oldClaim) {
        processCache(newClaim, oldClaim);
    }

    /**
     *
     * Description: Method to process the cache
     * @param newClaim
     * @param oldClaim
     */
    private void processCache(Claim newClaim, Claim oldClaim) {
        IMap<String, ViewInsurerResponse> map = hazelcastInstance.getMap("searchCache");

        map.keySet().stream()
                .filter(key -> {
                    String searchInputKey = key.split("-")[0].toLowerCase();
                    Pattern pattern = Pattern.compile(Pattern.quote(searchInputKey));
                    return isMatch(pattern, newClaim) || (oldClaim != null && isMatch(pattern, oldClaim));
                })
                .forEach(map::delete);
    }

    /**
     *
     * Description: Method to check if the claim matches the search input
     * @param pattern
     * @param claim
     * @return
     */
    private boolean isMatch(Pattern pattern, Claim claim) {
        String name = claim.getClmInsdFirstNm().toLowerCase() + " " + claim.getClmInsdLastNm().toLowerCase();
        return pattern.matcher(name).find() || pattern.matcher(claim.getClmPolNum().toLowerCase()).find() || pattern.matcher(claim.getClmInsdSsnNum()).find();
    }

    public List<Object[]> getTaxCache(String acf2Id) {
        IMap<String, List<Object[]>> map = hazelcastInstance.getMap("taxCache");
        return map.get(acf2Id);
    }

}