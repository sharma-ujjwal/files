package com.sunlife.us.cic.common.util;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.model.Errors;
import com.sunlife.us.cic.model.ReportsDTO;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;
import java.util.Date;

/**
 * ReportsUtil class
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 * Description: This is a generic utility class to generate PDF reports
 */

@Component("ReportsUtil")
@Slf4j
@Getter
@Setter
public class ReportsUtil {

    private String[] headers;
    private Image imagePath;
    private float imageScaleWidth;
    private float imageScaleHeight;
    private float imagePositionX;
    private float imagePositionY;
    private String headerTitle;
    private String subHeaderTitle;
    private PdfFont headerFont;
    private PdfFont subHeaderFont;
    private int headerAlignment;
    private int indentationRight;
    private int indentationLeft;
    private int spacingBefore;
    private int subHeaderAlignment;
    private int subHeaderIndentationLeft;
    private int spacingAfter;

    private ReportsUtil() {
        // private constructor to enforce object creation through builder
    }

    public static class Builder {
        private String[] headers;
        private Image imagePath;
        private float imageScaleWidth;
        private float imageScaleHeight;
        private float imagePositionX;
        private float imagePositionY;
        private String headerTitle;
        private String subHeaderTitle;
        private PdfFont headerFontFamily;
        private int headerFontSize;
        private int headerFontStyle;
        private PdfFont subHeaderFontFamily;
        private int subHeaderFontSize;
        private int subHeaderFontStyle;
        private int headerAlignment;
        private int indentationRight;
        private int indentationLeft;
        private int spacingBefore;
        private int subHeaderAlignment;
        private int spacingAfter;

        public Builder withHeaders(String[] headers) {
            this.headers = headers;
            return this;
        }

        public Builder withImage(Image imagePath, float scaleWidth, float scaleHeight, float positionX, float positionY) {
            this.imagePath = imagePath;
            this.imageScaleWidth = scaleWidth;
            this.imageScaleHeight = scaleHeight;
            this.imagePositionX = positionX;
            this.imagePositionY = positionY;
            return this;
        }

        public Builder withHeaderTitle(String headerTitle, PdfFont fontFamily, int fontSize, int alignment, int indentationLeft, int indentationRight, int spacingBefore) {
            this.headerTitle = headerTitle;
            this.headerFontFamily = fontFamily;
            this.headerFontSize = fontSize;
            this.headerAlignment = alignment;
            this.indentationRight = indentationRight;
            this.indentationLeft= indentationLeft;
            this.spacingBefore = spacingBefore;
            return this;
        }

        public Builder withSubHeaderTitle(String subHeaderTitle, PdfFont fontFamily, int fontSize, int alignment, int indentationLeft, int indentationRight, int spacingAfter) {
            this.subHeaderTitle = subHeaderTitle;
            this.subHeaderFontFamily = fontFamily;
            this.subHeaderFontSize = fontSize;
            this.subHeaderAlignment = alignment;
            this.indentationLeft = indentationLeft;
            this.indentationRight = indentationRight;
            this.spacingAfter = spacingAfter;
            return this;
        }

        public Builder withHeaderFont(String fontPath) {
            try {
                this.headerFontFamily = PdfFontFactory.createFont(fontPath);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this;
        }

        public ReportsUtil build() {
            ReportsUtil reportsUtil = new ReportsUtil();
            reportsUtil.imagePath = this.imagePath;
            reportsUtil.imageScaleWidth = this.imageScaleWidth;
            reportsUtil.imageScaleHeight = this.imageScaleHeight;
            reportsUtil.imagePositionX = this.imagePositionX;
            reportsUtil.imagePositionY = this.imagePositionY;
            reportsUtil.headers = this.headers;
            reportsUtil.headerTitle = this.headerTitle;
            reportsUtil.subHeaderTitle = this.subHeaderTitle;
            reportsUtil.headerFont = this.headerFontFamily;
            reportsUtil.subHeaderFont = this.subHeaderFontFamily;
            reportsUtil.indentationLeft = this.indentationLeft;
            reportsUtil.indentationRight = this.indentationRight;
            reportsUtil.spacingBefore = this.spacingBefore;
            reportsUtil.spacingAfter = this.spacingAfter;
            reportsUtil.headerAlignment = this.headerAlignment;
            reportsUtil.subHeaderAlignment = this.subHeaderAlignment;
            return reportsUtil;
        }
    }

    /**
     * Description: This method is used to generate a generic PDF report template
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return InputStreamResource
     * @param out ByteArrayOutputStream
     */
    public Document generatePdfReport(ByteArrayOutputStream out) throws  IOException {

        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdfDocument = new PdfDocument(writer);
        Document document = new Document(pdfDocument);

        //get the image from resources images
        ClassPathResource classPathResource = new ClassPathResource("Images/Sunlifelogo.png");
        Image img = new Image(ImageDataFactory.create(classPathResource.getURL()));

        float scaledWidth =  img.getImageWidth() * imageScaleWidth;
        float scaledHeight = img.getImageHeight() * imageScaleHeight;
        img.scaleAbsolute(scaledWidth, scaledHeight);
        float rightMargin = document.getRightMargin();
        float topMargin = document.getTopMargin();
        float xPos = document.getPdfDocument().getDefaultPageSize().getWidth() - img.getImageScaledWidth() - rightMargin;
        float yPos = document.getPdfDocument().getDefaultPageSize().getHeight() - img.getImageScaledHeight() - topMargin;
        img.setFixedPosition(xPos,yPos);
        document.add(img);

        Paragraph paragraph = new Paragraph(headerTitle).setFont(headerFont);
        paragraph.setTextAlignment(convertAlignment(headerAlignment));
        paragraph.setMarginRight(indentationRight);
        paragraph.setMarginTop(spacingBefore);
        document.add(paragraph);

        Paragraph paragraph1 = new Paragraph(subHeaderTitle).setFont(subHeaderFont).setFontSize(8);
        paragraph1.setMarginLeft(indentationLeft);
        paragraph1.setMarginBottom(spacingAfter);
        document.add(paragraph1);

        Table table = createTableWithHeaders(headers);
        document.add(table);

        return document;
    }

    /**
     * Description: This method is used to create a table with headers in PDF report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return PdfPTable
     * @param headers String[]
     */
    public Table createTableWithHeaders(String[] headers) {
        // Create a table with the specified number of columns
        float[] columnWidths = new float[]{35f, 20f, 20f, 20f, 20f};
        Table table = new Table(UnitValue.createPercentArray(columnWidths));
        try {
            // Set relative widths of the columns
            table.setWidth(UnitValue.createPercentValue(100));
        } catch (Exception e) {
            e.printStackTrace();
        }
        AtomicReference<Boolean> firstHeader = new AtomicReference<>(true);

        // Add table headers
        Stream.of(headers).forEach(headerTitle -> {
            Cell header = new Cell();
            PdfFont headFont = null;
            try {
                headFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);
            } catch (IOException e) {
                e.printStackTrace();
            }
            header.setBorderTop(solidBorder(2));
            header.setBorderBottom(solidBorder(1)); // Use solidBorder method or directly set style

            if(firstHeader.get()) {
                firstHeader.set(false);
                header.setTextAlignment(TextAlignment.LEFT);
            }
            else
                header.setTextAlignment(TextAlignment.RIGHT);
            if (headFont != null) {
                header.setFont(headFont).setFontSize(8).setBorder(Border.NO_BORDER);
            }
            header.add(new Paragraph(headerTitle));
            table.addCell(header);
        });

        return table;
    }
    private static Border solidBorder(float width) {
        return new SolidBorder(width);
    }

    /**
     * Description: This method is used to create a table with footers in PDF report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return PdfPTable
     * @param footers String[]
     */
    public static List<Cell> createTotalRow(String[] footers) {
        List<Cell> firstRowCells = new ArrayList<>();
        Stream.of(footers).forEach(footerTitle -> {
            Cell cell = new Cell();
            PdfFont font = null;
            try {
                font = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);
            } catch (IOException e) {
                e.printStackTrace();
            }
            cell.setBorderTop(new SolidBorder(1));
            cell.setTextAlignment(TextAlignment.RIGHT);

            if (footers[0].equals(footerTitle)) {
                cell.setTextAlignment(TextAlignment.CENTER);
            }
            if (font != null) {
                cell.setFont(font).setFontSize(8);
            }
            cell.add(new Paragraph(footerTitle));
            firstRowCells.add(cell);
        });
        return firstRowCells;
    }

    /**
     * Description: This method is used to validate the report dates before generating the report
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param reportsDTO
     * @return List<Errors>
     */
    public static List<Errors> validateReportDates(ReportsDTO reportsDTO) {
        List<Errors> errorMessages = new ArrayList<>();

        Date currentDate = new Date();

        Calendar toDateCalendar = Calendar.getInstance();
        Date toDateLimit = toDateCalendar.getTime();
        toDateCalendar.add(Calendar.DATE, 5);

        if (reportsDTO.getFromDate().after(currentDate)) {
            setErrors("The From Date (%s) cannot be in the future.", "fromDate", errorMessages, reportsDTO.getFromDate(), reportsDTO.getToDate());
        }

        if (reportsDTO.getToDate().after(toDateLimit)) {
            setErrors("The To Date (%s) cannot be more than 5 days in the future.", "toDate", errorMessages, reportsDTO.getFromDate(), reportsDTO.getToDate());
        }

        if (reportsDTO.getToDate().before(reportsDTO.getFromDate())) {
            setErrors("The To Date (%s) must be on or after the From Date (%s).", "toDate", errorMessages, reportsDTO.getFromDate(), reportsDTO.getToDate());
        }

        return errorMessages;
    }

    /**
     * Description: This method is used to set the error messages for the report dates validation errors found in the report DTO object
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param errorMessage
     * @param fieldName
     * @param errorMessages
     */
    private static void setErrors(String errorMessage, String fieldName, List<Errors> errorMessages, Date fromDate, Date toDate) {
        Errors error = new Errors();
        String mainError = CicConstants.CROSS_FIELD_VALIDATIONS;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String formattedFromDate = sdf.format(fromDate);
        String formattedToDate = sdf.format(toDate);

        String finalErrorMessage = String.format(errorMessage, formattedFromDate, formattedToDate);
        String finalMainError1 = mainError;
        boolean fullErrorMessageExists = errorMessages.stream().anyMatch(e -> e.getErrorMessage().startsWith(finalMainError1));

        if (fullErrorMessageExists) {
            mainError = finalErrorMessage;
        } else {
            mainError = mainError + finalErrorMessage;
        }

        String finalMainError2 = mainError;
        boolean errorExists = errorMessages.stream().anyMatch(e -> e.getErrorMessage().equals(finalMainError2) && e.getFieldName().equals(fieldName));
        if (!errorExists) {
            error.setErrorMessage(mainError);
            error.setFieldName(fieldName);
            errorMessages.add(error);
        }
    }

    TextAlignment convertAlignment(int alignment) {
        switch (alignment) {
            case 0: return TextAlignment.LEFT;
            case 1: return TextAlignment.CENTER;
            case 2: return TextAlignment.RIGHT;
            default: return TextAlignment.LEFT; // Default to LEFT if unknown
        }
    }
}