package com.sunlife.us.cic.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.Id;

@Entity
@Getter
@Setter
@Table(name = "state_rule_tier_t")
@IdClass(StateRuleTierCompositeKey.class)
public class StateRuleTier {

    @Id
    String st_cd;
    @Id
    String lob_cd;
    @Id
    String strlt_eff_dt;
    String strlt_idtyp_cd;
    Integer strlt_calc_value;
    String strlt_end_dt;
    String lst_updt_dtm;
    String lst_updt_user_id;

}
