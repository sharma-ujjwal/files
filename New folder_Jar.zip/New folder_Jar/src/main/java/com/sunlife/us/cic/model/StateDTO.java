package com.sunlife.us.cic.model;

import lombok.Getter;
import lombok.Setter;

/**
 * StateDTO Class for mapping to State entity.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * */
@Getter
@Setter
public class StateDTO {
    private String stateCd;
    private String stDsc;
    private Boolean stCompactClcnAllowInd;

}
