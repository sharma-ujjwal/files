package com.sunlife.us.cic.controller;


import com.sunlife.us.cic.handler.exceptions.AuthorizationServiceException;
import com.sunlife.us.cic.model.LoginResponse;
import com.sunlife.us.cic.model.User;
import com.sunlife.us.cic.service.impl.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
import org.springframework.web.bind.annotation.*;
import static com.sunlife.us.cic.common.SecurityConstants.*;


/**
 * This controller is responsible for generating the JWT token once the SAML Assertion is successful.
 */
@RestController
@RequestMapping("/getToken")
@Slf4j
public class VerifyAndGenerateJWTController {
    private final JwtService jwtService;

    @Value("${saml2.sp.success.redirect-url}")
    private String redirectUrl;

    @Value("${saml2.sp.failure.redirect-url}")
    private String errorRedirectUrl;

    public VerifyAndGenerateJWTController(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    /**
     * Description: Principal will have all the details from SAML token.
     * The token will be validated and attributes are extracted and used to sign a JWT token and is sent back to FrontEnd url.
     * @param request
     * @param principal
     * @return
     */
    @PostMapping()
    public void getCredentials(HttpServletRequest request, @AuthenticationPrincipal Saml2AuthenticatedPrincipal principal, HttpServletResponse response) throws Exception {
        if (principal == null){
            log.error("SSO Error : The SSO login request has been failed. The principal is empty");
            throw new IllegalArgumentException();
        }
        User user = new User();
        if (principal.getAttribute(AD_GROUPS_ATTRIBUTE) == null) {
            handleException(response, UN_AUTHORIZED, request);
            return;
        }

        String role = jwtService.getTheLoggedInUserRole(jwtService.removeFirstAndLastChar(principal.getAttribute(AD_GROUPS_ATTRIBUTE).toString()));
        if (role == null) {
            handleException(response, UN_AUTHORIZED, request);
            return;
        }
        user.setEmail(jwtService.removeFirstAndLastChar(principal.getAttribute(EMAIL_ATTRIBUTE).toString()));
        user.setUserName(jwtService.removeFirstAndLastChar(principal.getAttribute(ACF2ID_ATTRIBUTE).toString()));
        user.setRole(role);
        String jwtToken = jwtService.generateToken(user);
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setToken(jwtToken);
        loginResponse.setExpiresIn(jwtService.getExpirationTime());
        /**
         * Post successful auth, redirect to FE application with the token and expiry details.
         */
        log.info("SSO : Redirecting to FrontEnd for user " + user.getUsername());
        response.setStatus(HttpStatus.OK.value());
        response.sendRedirect(redirectUrl + "?token=" + loginResponse.getToken() + "&expiresIn=" + loginResponse.getExpiresIn());
    }


    private void handleException(HttpServletResponse response, String error, HttpServletRequest request) throws Exception {
        log.error("SSO Error : Role based failure post SAML Assertion. User is being redirected to Error page");
        request.getSession().invalidate();
        response.setStatus(HttpStatus.OK.value());
        response.sendRedirect(errorRedirectUrl + "?Error=" + UN_AUTHORIZED);
    }
}
