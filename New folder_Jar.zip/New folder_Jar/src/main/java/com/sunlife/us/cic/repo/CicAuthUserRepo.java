package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.model.User;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * This Repository doesn't connect to DB to fetch user details.
 * This will get the details from SAML to populate the data.
 */
@Component
public class CicAuthUserRepo {

    /**
     * Description: This will set the user credentials required for Jwt Subject.
     * @param userName
     * @return
     */
    public Optional<User> findByEmail(String userName) {
       User user = new User();
       user.setUserName(userName);
       return Optional.of(user);
    }
}
