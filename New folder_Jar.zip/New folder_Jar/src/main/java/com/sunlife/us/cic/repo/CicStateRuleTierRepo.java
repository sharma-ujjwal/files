package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.StateRuleTier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface CicStateRuleTierRepo extends JpaRepository<StateRuleTier, String> {

    @Query(value = "SELECT srt.* FROM state_rule_tier_t srt INNER JOIN (SELECT lob_cd, st_cd, MAX(strlt_eff_dt) as max_date FROM state_rule_tier_t WHERE lob_cd = ?1 AND st_cd = ?2 AND strlt_eff_dt <= ?3 GROUP BY lob_cd, st_cd) subq ON srt.lob_cd = subq.lob_cd AND srt.st_cd = subq.st_cd AND srt.strlt_eff_dt = subq.max_date", nativeQuery = true)
    StateRuleTier findTopByStCdOrderByStrlEffDtDesc(String lobCd, String stCd, Date payePmtDt);
}
