package com.sunlife.us.cic.handler;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import java.io.IOException;

import static com.sunlife.us.cic.common.SecurityConstants.GET_TOKEN;

/**
 * Custom Success Handler post successfull SAML AUthentication
 */
public class CustomSuccessHandler implements AuthenticationSuccessHandler {


    /**
     * Description: Post successful SAML assertion, this controller will redirect to /getToken to generate the JWT.
     * @param request the request which caused the successful authentication
     * @param response the response
     * @param authentication the <tt>Authentication</tt> object which was created during
     * the authentication process.
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(GET_TOKEN);
        dispatcher.forward(request, response);
    }
}
