package com.sunlife.us.cic.repo;

import com.sunlife.us.cic.entity.Payee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 *
 * CicPayeeRepo interface as DAO layer for payee_t table.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This interface is used to interact with the payee_t table in the database.
 */
@Repository
public interface CicPayeeRepo extends JpaRepository<Payee, Integer> {

    /**
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description This method is used to find the payee by clmId.
     * @param clmId
     * @return List of Payee
     */
    @Query(value = "select * from payee_t t where t.clm_id = :clmId order by lst_updt_dtm DESC ", nativeQuery = true)
    List<Payee> findByClmId(Integer clmId);
    @Query(value = "select * from payee_t t where t.clm_id = :clmId and t.paye_full_nm = :fullName", nativeQuery = true)
    Optional<Payee> findByPayeFullNm(@Param("fullName") String payeFullNm, @Param("clmId") Integer clmId);

    Optional<Payee> findByPayeFullNmAndClmId(String payeFullNm, Integer clmId);

    @Query(value ="SELECT SUM(p.paye_clm_int_amt) FROM payee_t p WHERE p.clm_id = ?1", nativeQuery = true)
    BigDecimal sumPayeClmIntAmtByClmId(Integer clmId);

    @Query(value ="SELECT SUM(p.paye_wthld_amt) FROM payee_t p WHERE p.clm_id = ?1", nativeQuery = true)
    BigDecimal sumPayeWthldAmtByClmId(Integer clmId);

    @Query(value = "SELECT SUM(p.paye_clm_pd_amt) FROM payee_t p WHERE p.clm_id = ?1", nativeQuery = true)
    BigDecimal sumPayeClmPdAmtByClmId(Integer clmId);

    @Query(value ="SELECT SUM(p.paye_dthb_pmt_amt) FROM payee_t p WHERE p.clm_id = ?1", nativeQuery = true)
    BigDecimal sumPayeDthbPmtAmtByClmId(Integer clmId);
}
