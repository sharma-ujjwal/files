package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 * CompactRateNotProvidedException is a custom exception class that extends RuntimeException.
 * This exception is thrown when the compact rate is not provided.
 */
public class CompactRateNotProvidedException extends RuntimeException {
    public CompactRateNotProvidedException() {
        super(CustomErrors.COMPACT_RATE_NOT_PROVIDED_EXCEPTION.getDescription());
    }
    public CompactRateNotProvidedException(String message) {
        super(message);
    }
    public CompactRateNotProvidedException(String message, Throwable cause) {
        super(message, cause);
    }
    public CompactRateNotProvidedException(Throwable cause) {
        super(cause);
    }

}
