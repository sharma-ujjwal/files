package com.sunlife.us.cic.handler.exceptions;


import com.sunlife.us.cic.common.util.CustomErrors;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *
 * DataNotFoundException Class.
 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class DataNotFoundException extends RuntimeException {

    public DataNotFoundException() {
        super(CustomErrors.DATA_NOT_FOUND_EXCEPTION.getDescription());
    }
    public DataNotFoundException(final String message) {
        super(message);
    }

    public DataNotFoundException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public DataNotFoundException(final Throwable cause) {
        super(cause);
    }

}
