package com.sunlife.us.cic.config;

import com.sunlife.us.cic.config.filter.JwtAuthenticationFilter;
import com.sunlife.us.cic.handler.CustomFailureHandler;
import com.sunlife.us.cic.handler.CustomSuccessHandler;
import org.springframework.boot.autoconfigure.session.DefaultCookieSerializerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.saml2.provider.service.registration.RelyingPartyRegistrationRepository;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import static com.sunlife.us.cic.common.SecurityConstants.AUTH_WHITELIST;

/**
 * All the security related to the application goes here!!
 */
@Configuration
@EnableWebSecurity
public class WebSecurity {

    private final AuthenticationProvider authenticationProvider;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    private final RelyingPartyRegistrationRepository relyingPartyRegistrationRepository;

    public WebSecurity(AuthenticationProvider authenticationProvider, JwtAuthenticationFilter jwtAuthenticationFilter, RelyingPartyRegistrationRepository relyingPartyRegistrationRepository) {
        this.authenticationProvider = authenticationProvider;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.relyingPartyRegistrationRepository = relyingPartyRegistrationRepository;
    }


    /**
     * Description: Security Filter for Auth using SAML2 and JWT
     * @param http
     * @return
     * @throws Exception
     */
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http  ) throws Exception {

            http
                    .sessionManagement((sessionManagement) -> sessionManagement
                            .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                    .csrf((csrf) -> csrf.disable())
                    .authorizeHttpRequests((authorize) -> authorize
                            .requestMatchers(AUTH_WHITELIST).permitAll()
                            .anyRequest().authenticated()
                    )
                    .authenticationProvider(authenticationProvider)
                    .saml2Login(saml2 -> saml2.relyingPartyRegistrationRepository(relyingPartyRegistrationRepository)
                                        .successHandler(customSuccessHandler()).failureHandler(customFailureHandler()))
                    .addFilterBefore( jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

            return http.build();
    }

    /**
     * Description:: Registering a custom Success Handler for processing post SAML Assertion
     * @return
     */
    @Bean
    public CustomSuccessHandler customSuccessHandler() {
        return new CustomSuccessHandler();
    }


    /**
     * Description:: Registering a custom Failure Handler for processing post SAML Assertion
     * @return
     */
    @Bean
    public CustomFailureHandler customFailureHandler() {
        return new CustomFailureHandler();
    }



}
