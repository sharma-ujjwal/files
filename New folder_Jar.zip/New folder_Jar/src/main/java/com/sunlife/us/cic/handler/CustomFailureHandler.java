package com.sunlife.us.cic.handler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

import java.io.IOException;
import java.net.CookieStore;

@Slf4j
public class CustomFailureHandler implements AuthenticationFailureHandler {

    @Value("${saml2.sp.failure.redirect-url}")
    private String redirectUrl;
    /**
     * Description: Post failed SAML assertion, this controller will redirect to configured FE url.
     * @param request the request which caused the successful authentication
     * @param response the response
     * @param exception the <tt>Authentication</tt> object which was created during
     * the authentication process.
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        log.error("SSO Error : The SSO login request has been failed and redirected to FE. The exception is : " + exception.getMessage());
        request.getSession().invalidate();
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        response.sendRedirect(redirectUrl);
    }
}
