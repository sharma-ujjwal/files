package com.sunlife.us.cic.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NotNull
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ViewPayeeResponse extends GenericResponseDTO {
    List<PayeeDTO> payeeList;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    long totalCount;
}
