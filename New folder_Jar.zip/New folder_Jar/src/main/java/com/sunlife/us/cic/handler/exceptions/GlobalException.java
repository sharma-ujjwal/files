package com.sunlife.us.cic.handler.exceptions;

import com.sunlife.us.cic.common.util.CustomErrors;

/**
 *
 * GlobalException Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 */
public class GlobalException extends RuntimeException {

    public GlobalException() {
        super(CustomErrors.GLOBAL_EXCEPTION.getDescription(), new Throwable(CustomErrors.GLOBAL_EXCEPTION.getCode()));
    }
    public GlobalException(final String message) {
        super(message);
    }

    public GlobalException(final String message, final Throwable cause) {
        super(message, cause);
    }

    public GlobalException(final Throwable cause) {
        super(cause);
    }

}
