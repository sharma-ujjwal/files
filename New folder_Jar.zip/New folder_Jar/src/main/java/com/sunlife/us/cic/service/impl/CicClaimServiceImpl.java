package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.InterestCalculationConstants;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.controller.AuthInfoController;
import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.entity.Payee;
import com.sunlife.us.cic.entity.State;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.mapper.CicMapper;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.handler.exceptions.*;
import com.sunlife.us.cic.repo.*;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.sunlife.us.cic.service.CicClaimService;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 *
 * CicClaimsServiceImpl Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description This class is used to implement the service methods for the CicClaimService interface.
 */
@Service
@Slf4j
public class CicClaimServiceImpl implements CicClaimService {

	@Autowired
	private CicClaimRepo cicClaimRepo;

	@Autowired
	private CicPayeeRepo cicPayeeRepo;

	@Autowired
	private CicPayorRepo cicPayorRepo;

	@Autowired
	private CicAdminRepo cicAdminRepo;

	@Autowired
	private CicStateRepo cicStateRepo;

	@Autowired
	CacheUpdater cacheUpdater;

	/**
	 * deleteInsurer API serviceImpl Code implementaion
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: This method is used to delete the insurer details from the claim_t table in database.
	 * @return GenericResponseDTO (message, code and returncode)
	 * @param claimId
	 * @throws DataNotFoundException
	 * @throws InvalidRequestException
	 * @throws GlobalException
	 */
	@Override
	public GenericResponseDTO deleteInsurer(int claimId) {
		log.info("deleteInsurer Implementation called : " + claimId);
		GenericResponseDTO genericResponse = new GenericResponseDTO();
		try {
			Claim claim = cicClaimRepo.findById(claimId).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + claimId));
			List<Payee> payees = cicPayeeRepo.findByClmId(claimId);
			if (!payees.isEmpty()) {
				log.info("Payee data is present for claim Id : " + claimId);
				throw new InvalidRequestException(CicConstants.CLAIM_PAYEE_PRESENT + claimId);
			}

			CompletableFuture.runAsync(() -> cacheUpdater.deleteCache(claim));
			cicClaimRepo.deleteById(claimId);
			genericResponse.setMessage(CicConstants.CLAIMDELETEDSUCCESSFULLY + claimId);
			genericResponse.setReturnCode(HttpStatus.OK.toString());
			genericResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
		}
		catch (DataNotFoundException e){
			log.error("DataNotFoundException thrown : " + e.getMessage());
			throw new DataNotFoundException(e.getMessage());
		}
		catch (InvalidRequestException e){
			log.error("InvalidRequestException thrown : " + e.getMessage());
			throw new InvalidRequestException(e.getMessage());
		}
		catch (Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(e.getMessage());
		}
		log.info("deleteInsurer Implementation ended : " + claimId);
		return genericResponse;
	}

	/**
	 * Description viewInsurer API serviceImpl Code implementation
	 * viewInsurer API serviceImpl Code implementaion
	 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
	 * Description This method is used to view the insurer details from the database.
	 * @return string
	 * @param pageNumber
	 * @param pageSize
	 * @throws DataNotFoundException
	 * @throws GlobalException
	 */
	@Override
	public ViewInsurerResponse viewInsurer(int pageNumber, int pageSize) {
		log.info("viewInsurer Implementation called");
		ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
		List<ClaimDTO> claimDTOList = new ArrayList<>();

		try {
			Page<Claim> claimList = cicClaimRepo.findAll(PageRequest.of(pageNumber-1, pageSize, Sort.by(CicConstants.LAST_UPDATED_DATE_WITHOUT_UNDERSCORE).descending()));
			log.debug("Page Number: " + pageNumber + " and " + "Page Size: " + pageSize);
			if(claimList.getTotalPages() <= 0){
				log.info("Invalid Request");
				log.debug("Total Pages: " + claimList.getTotalPages());
				throw new DataNotFoundException(CicConstants.CLAIMNOTFOUND);
			}

			log.debug("Claim List: " + claimList.getContent());
			List<Claim> claims = claimList.getContent();
 			claims.forEach(claim -> {
				ClaimDTO claimDTO = CicMapper.INSTANCE.mapclaim(claim);
				AdminDTO adminDTO = CicMapper.INSTANCE.mapAdmin(claim.getAdmin());
				claimDTO.setDeleteActive(claim.getPayee().size() > 0 ? false : true);
				claimDTO.setAdmnSystDsc(adminDTO.getAdmnSystDsc());
				claimDTOList.add(claimDTO);
			});

			viewInsurerResponse.setTotalCount(cicClaimRepo.count());
			viewInsurerResponse.setClaimsList(claimDTOList);
			viewInsurerResponse.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
			viewInsurerResponse.setReturnCode(HttpStatus.OK.toString());
		}
		catch (DataNotFoundException e){
			log.error("DataNotFoundException thrown : " + e.getMessage());
			throw new DataNotFoundException(CustomErrors.DATA_NOT_FOUND_EXCEPTION.getDescription());
		}
		catch(Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(CustomErrors.GLOBAL_EXCEPTION.getDescription());
		}
		log.info("viewInsurer Implementation ended");
		return viewInsurerResponse;
	}

	/**
	 * Description getInsurer API serviceImpl Code implementation
	 * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
	 * @return string
	 * @param claimId
	 * @throws DataNotFoundException
	 * @throws GlobalException
	 */
	@Override
	public ViewInsurerResponse getInsurer(int claimId) {
		log.info("getInsurer Implementation called : " + claimId);
		ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();

		try{
			cicClaimRepo.findById(claimId).orElseThrow(() -> new DataNotFoundException(CicConstants.CLAIMNOTFOUND + claimId));
			List<Claim> claimList = cicClaimRepo.findAllById(Collections.singleton(claimId));

			List<ClaimDTO> claimDTOList = new ArrayList<>();
			List<AdminDTO> adminDTOList = new ArrayList<>();
			List<PayeeDTO> payeeDTOList = new ArrayList<>();
			List<PayorDTO> payorDTOList = new ArrayList<>();

			claimList.forEach(claim -> {
				log.debug("ClaimId: " + claimId);
				ClaimDTO claimDTO = CicMapper.INSTANCE.mapclaim(claim);
				AdminDTO adminDTO = CicMapper.INSTANCE.mapAdmin(claim.getAdmin());
				List<PayeeDTO> payeeDTO = CicMapper.INSTANCE.mapPayee(claim.getPayee());
				claimDTO.setClmTotClmPdAmt(BigDecimal.valueOf(0.00));
				claimDTO.setClmTotDthbPmtAmt(BigDecimal.valueOf(0.00));
				claimDTO.setClmTotIntAmt(BigDecimal.valueOf(0.00));
				claimDTO.setClmTotWthldAmt(BigDecimal.valueOf(0.00));
				for(PayeeDTO payee:payeeDTO){
					claimDTO.setClmTotDthbPmtAmt(claimDTO.getClmTotDthbPmtAmt().add(payee.getPayeDthbPmtAmt()));
					claimDTO.setClmTotIntAmt(claimDTO.getClmTotIntAmt().add(payee.getPayeClmIntAmt()));
					claimDTO.setClmTotWthldAmt(claimDTO.getClmTotWthldAmt().add(payee.getPayeWthldAmt()));
					claimDTO.setClmTotClmPdAmt(claimDTO.getClmTotClmPdAmt().add(payee.getPayeClmPdAmt()));
				}
				Collections.sort(payeeDTO, new Comparator<PayeeDTO>() {
					@Override
					public int compare(PayeeDTO p1, PayeeDTO p2) {
						return p2.getLstUpdtDtm().compareTo(p1.getLstUpdtDtm());
					}
				});
				PayorDTO payorDTO = CicMapper.INSTANCE.mapPayor(claim.getPayor());
				claimDTOList.add(claimDTO);
				adminDTOList.add(adminDTO);
				payeeDTOList.addAll(payeeDTO);
				payorDTOList.add(payorDTO);
			});

			viewInsurerResponse.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
			viewInsurerResponse.setReturnCode(HttpStatus.OK.toString());
			viewInsurerResponse.setClaimsList(claimDTOList);
			viewInsurerResponse.setAdminList(adminDTOList);
			viewInsurerResponse.setPayeeList(payeeDTOList);
			viewInsurerResponse.setPayorList(payorDTOList);

	}
		catch (DataNotFoundException e){
			log.error("DataNotFoundException thrown : " + e.getMessage());
			throw new DataNotFoundException(e.getMessage());
		}
		catch (Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(e.getMessage());
		}
		log.info("getInsurer Implementation ended : " + claimId);
		return viewInsurerResponse;
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description getClaimFormData API serviceImpl Code implementation
	 * getClaimFormData API serviceImpl Code implementaion
	 * @return string
	 * @throws GlobalException
	 */
	@Override
	public ClaimFormDataDTO getClaimFormData(Integer claimId) {
		ClaimFormDataDTO claimFormDataDTO = new ClaimFormDataDTO();
		try {
			log.info("getClaimFormData Implementation called");
			List<AdminDTO> adminDTOList = cicAdminRepo.findAllByOrderByAdmnSystDscAsc().stream().map(admin -> CicMapper.INSTANCE.mapAdmin(admin)).toList();
			List<PayorDTO> payorDTOList = cicPayorRepo.findAllByOrderByPycoTypDscAsc().stream().map(payor -> CicMapper.INSTANCE.mapPayor(payor)).toList();
			List<StateDTO> stateDTOList = cicStateRepo.findAll().stream().map(state -> CicMapper.INSTANCE.mapState(state)).toList();

			if (claimId != null) {
				Claim claim = cicClaimRepo.findById(claimId).orElseThrow(() -> new DataNotFoundException("Claim not found for id: " + claimId));
				ClaimDTO claimDTO = CicMapper.INSTANCE.mapclaim(claim);

				String insdDthResStCd = claimDTO.getInsdDthResStCd();
				String issStCd = claimDTO.getIssStCd();
				String clmPolNum = claimDTO.getClmPolNum();

				claimFormDataDTO.setTinSsnList(List.of(CicConstants.TIN_TYPE_CODE_P, CicConstants.TIN_TYPE_CODE_B));
				claimFormDataDTO.setAdminList(adminDTOList);
				claimFormDataDTO.setPayorList(payorDTOList);
				claimFormDataDTO.setStateList(stateDTOList);
				claimFormDataDTO.setClmPolNum(clmPolNum);
				claimFormDataDTO.setInsdDthResStCd(insdDthResStCd);
				claimFormDataDTO.setIssStCd(issStCd);
				claimFormDataDTO.setAdminSystemDesc(claim.getAdmin().getAdmnSystDsc());
				claimFormDataDTO.setClmForResDthInd(claimDTO.getClmForResDthInd());
				claimFormDataDTO.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
				claimFormDataDTO.setReturnCode(HttpStatus.OK.toString());
				claimFormDataDTO.setInsProofDate(claimDTO.getClmProofDt());
				claimFormDataDTO.setInsDeathDate(claimDTO.getClmInsdDthDt());
			} else {
				claimFormDataDTO.setTinSsnList(List.of(CicConstants.TIN_TYPE_CODE_P, CicConstants.TIN_TYPE_CODE_B));
				claimFormDataDTO.setAdminList(adminDTOList);
				claimFormDataDTO.setPayorList(payorDTOList);
				claimFormDataDTO.setStateList(stateDTOList);
				claimFormDataDTO.setCode(String.valueOf(CustomErrors.POSITIVE_CASE.getCode()));
				claimFormDataDTO.setReturnCode(HttpStatus.OK.toString());
			}
		}
		catch (DataNotFoundException e){
			log.error("DataNotFoundException thrown : " + e.getMessage());
			throw new DataNotFoundException(e.getMessage());
		}
		catch (Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(e.getMessage());
		}
		log.info("getClaimFormData Implementation ended");
		return claimFormDataDTO;
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description addInsurer API serviceImpl Code implementation
	 * addInsurer API serviceImpl Code implementaion
	 * @return string
	 * @param claimDTO
	 * @throws InvalidRequestException
	 * @throws GlobalException
	 */
	@Override
	public GenericResponseDTO addInsurer(ClaimDTO claimDTO, Admin admin) {
		log.info("addInsurer Implementation called");
		GenericResponseDTO genericResponse = new GenericResponseDTO();
		try {
			if(claimDTO.getClmInsdDthDt().after(claimDTO.getClmProofDt()))
				throw new InvalidRequestException(CicConstants.DEATH_DATE_GREATER_THAN_PROOF_DATE);

			if(!admin.getAdmnSystDsc().trim().equalsIgnoreCase(CicConstants.LINEOFBUSINESS_GROUP)) {
				checkForExistingClaimWithPolicyNo(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum()), CicConstants.CLAIM_ALREADY_PRESENT + CicConstants.COLON_SPACING + claimDTO.getClmPolNum());
			} else {
				checkForExistingPolicyWithPolicyAndSSN(claimDTO);
			}
			Claim claim = CicMapper.INSTANCE.mapClaimDTO(claimDTO);

			State state = addInsurerInputDataDBValiadtion(claimDTO);
			foreignStateCodecheck(claimDTO, claim);
			compactFilingCheck(claimDTO, claim, state);

			claim.setClmNum(!admin.getAdmnSystDsc().trim().equalsIgnoreCase(CicConstants.LINEOFBUSINESS_GROUP)? claimDTO.getClmPolNum() : claimDTO.getClmPolNum()+CicConstants.ADMIN_SYSTEM_GROUP_G+claimDTO.getClmInsdSsnNum());
			claim.setLstUpdtDtm(new Date());
			claim.setLstUpdtUserId(getLoggedInUserAcf2Id());

			Claim generatedClaim = cicClaimRepo.save(claim);
			CompletableFuture.runAsync(() -> cacheUpdater.deleteCache(claim));
			genericResponse.setMessage(CicConstants.CLAIM_ADDED + " : " + generatedClaim.getClmId());
			genericResponse.setReturnCode(HttpStatus.OK.toString());
			genericResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
		}
		catch (InvalidRequestException e) {
			log.error("InvalidRequestException thrown : "+ e.getMessage());
			throw new InvalidRequestException(e.getMessage());
		}
		catch (Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(e.getMessage());
		}
		return genericResponse;
	}

	private void checkForExistingPolicyWithPolicyAndSSN(ClaimDTO claimDTO) {
		String errorMessage = String.format(
				CicConstants.CLAIM_ALREADY_PRESENT_POLICY_SSN,
				claimDTO.getClmPolNum() + "G" + claimDTO.getClmInsdSsnNum()
		);
		checkForExistingClaimWithPolicyNo(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum()), errorMessage);
	}

	private void checkForExistingClaimWithPolicyNo(Optional<List<Claim>> cicClaimRepo, String CLAIM_ALREADY_PRESENT) {
		cicClaimRepo.get().stream().findAny().ifPresent(claim -> {
			throw new InvalidRequestException(CLAIM_ALREADY_PRESENT);
		});
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: This method is used to validate the admin system code, payor type code and state code from DB.
	 */
	private State addInsurerInputDataDBValiadtion(ClaimDTO claimDTO) {
		cicAdminRepo.findById(claimDTO.getAdmnSystCd()).orElseThrow(() -> new InvalidRequestException(CicConstants.INVALID_ADMIN_SYSTEM_CODE + CicConstants.COLON_SPACING + claimDTO.getAdmnSystCd()));
		cicPayorRepo.findById(claimDTO.getPycoTypCd()).orElseThrow(() -> new InvalidRequestException(CicConstants.INVALID_PAYOR_CODE + CicConstants.COLON_SPACING + claimDTO.getPycoTypCd()));
		State state = cicStateRepo.findById(claimDTO.getIssStCd()).orElseThrow(() -> new InvalidRequestException(CicConstants.STATE_NOT_FOUND + CicConstants.COLON_SPACING + claimDTO.getIssStCd()));
		return state;
	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: This method is used to set the compact filing based on the state and admin system code.
	 */
	private static void compactFilingCheck(ClaimDTO claimDTO, Claim claim, State state) {
		if((claimDTO.getAdmnSystCd() == CicConstants.ADMIN_SOLAR_SYSTEM_CODE) && state.getStCompactClcnAllowInd().equalsIgnoreCase(CicConstants.TRUE_T)) {
			claim.setClmCompactClcnInd(claimDTO.getClmCompactClcnInd() ? CicConstants.TRUE_T : CicConstants.FALSE_F);
		} else {
			claim.setClmCompactClcnInd(CicConstants.FALSE_F);
		}
	}

	/**
	 * Description getLoggedInUserAcf2Id is used to get the logged in user acf2 id.
	 * @author <a href="ankit.kumar2@sunlife.com">Ankit Kumar(BV26)</a>
	 * @return
	 */
	private String getLoggedInUserAcf2Id(){
		return ((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

	}

	/**
	 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
	 * Description: checking for foreign state code, if it is present then it will be checked in the state table.
	 */
	private void foreignStateCodecheck(ClaimDTO claimDTO, Claim claim) {
		if(!claimDTO.getClmForResDthInd()) {
			if (claimDTO.getInsdDthResStCd() == null)
				throw new InvalidRequestException(CicConstants.RESIDENCE_STATE_NULL_MSG);
			cicStateRepo.findById(claimDTO.getInsdDthResStCd()).orElseThrow(() -> new InvalidRequestException(CicConstants.STATE_NOT_FOUND + CicConstants.COLON_SPACING + claimDTO.getInsdDthResStCd()));
			claim.setClmForResDthInd(CicConstants.NO_N);
		} else {
			claim.setInsdDthResStCd(null);
			claim.setClmForResDthInd(CicConstants.YES_Y);
		}
	}


	/**
	 * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
	 * Description editInsurer API serviceImpl Code implementation
	 * editInsurer API serviceImpl Code implementaion
	 * @return string
	 * @param claimDTO
	 * @throws InvalidRequestException
	 * @throws GlobalException
	 */
	@Override
	public GenericResponseDTO editInsurer(ClaimDTO claimDTO, Admin admin) {
		log.info("editInsurer Implementation called");
		GenericResponseDTO genericResponse = new GenericResponseDTO();
		try {
			if(claimDTO.getClmInsdDthDt().after(claimDTO.getClmProofDt()))
				throw new InvalidRequestException(CicConstants.DEATH_DATE_GREATER_THAN_PROOF_DATE);

			Claim claim = CicMapper.INSTANCE.mapClaimDTO(claimDTO);
			Claim oldClaim = cicClaimRepo.findById(claimDTO.getClmId()).orElseThrow(() -> new InvalidRequestException(CicConstants.CLAIMNOTFOUND+CicConstants.COLON_SPACING+claimDTO.getClmId()));
			if(!admin.getAdmnSystDsc().trim().equalsIgnoreCase(CicConstants.LINEOFBUSINESS_GROUP) && !oldClaim.getClmPolNum().trim().equalsIgnoreCase(claim.getClmPolNum().trim())) {
				checkForExistingClaimWithPolicyNo(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum()), CicConstants.CLAIM_ALREADY_PRESENT + CicConstants.COLON_SPACING + claimDTO.getClmPolNum());
			} else if(!oldClaim.getClmPolNum().trim().equalsIgnoreCase(claim.getClmPolNum().trim()) || (oldClaim.getClmInsdSsnNum() == null || !oldClaim.getClmInsdSsnNum().trim().equalsIgnoreCase(claim.getClmInsdSsnNum().trim()))) {
				checkForExistingPolicyWithPolicyAndSSN(claimDTO);
			}

			State state = addInsurerInputDataDBValiadtion(claimDTO);
			foreignStateCodecheck(claimDTO, claim);
			compactFilingCheck(claimDTO, claim, state);

			claim.setClmNum(!admin.getAdmnSystDsc().trim().equalsIgnoreCase(CicConstants.LINEOFBUSINESS_GROUP)? claimDTO.getClmPolNum() : claimDTO.getClmPolNum()+CicConstants.ADMIN_SYSTEM_GROUP_G+claimDTO.getClmInsdSsnNum());
			claim.setLstUpdtDtm(new Date());

			claim.setLstUpdtUserId(getLoggedInUserAcf2Id());

			CompletableFuture.runAsync(() -> cacheUpdater.updateCache(claim, oldClaim));
			Claim generatedClaim = cicClaimRepo.save(claim);

			genericResponse.setMessage(CicConstants.CLAIM_UPDATED+ " : " + generatedClaim.getClmId());
			genericResponse.setReturnCode(HttpStatus.OK.toString());
			genericResponse.setCode(CustomErrors.POSITIVE_CASE.getCode());
		}
		catch (InvalidRequestException e) {
			log.error("InvalidRequestException thrown : "+ e.getMessage());
			throw new InvalidRequestException(e.getMessage());
		}
		catch (Exception e){
			log.error("Exception thrown : " + e.getMessage());
			throw new GlobalException(e.getMessage());
		}

		return genericResponse;
	}

	@Override
	public Optional<Admin> findAdminById(Integer admnSystCd) {
		return cicAdminRepo.findById(admnSystCd);
	}

}
