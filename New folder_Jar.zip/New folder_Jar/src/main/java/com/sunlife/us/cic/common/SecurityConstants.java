package com.sunlife.us.cic.common;

/**
 * This class have te constants for security related for CIC
 */
public class SecurityConstants {


    /**
     * The list of urls to be whitelisted from auth
     */
    public static final String[] AUTH_WHITELIST = {
            "/swagger-resources",
            "/swagger-resources/**",
            "/error",
            "login/**",
            "/getToken",
            "/test",
            "/customLogin",
            "/actuator/**"
    };


    public static final String ROLE_ADMIN_USER = "ADMIN_USER";

    public static final String ROLE_STD_USER = "STD_USER";

    public static final String AUTH_HEADER = "Authorization";

    public static final String BEARER_TOKEN = "Bearer ";

    public static final String GET_TOKEN = "/getToken";

    public static final String AD_GROUPS_ATTRIBUTE = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groups";

    public  static final String EMAIL_ATTRIBUTE = "Email";

    public  static  final  String ACF2ID_ATTRIBUTE = "ACF2ID";

    public  static  final  String EMAIL = "email";

    public  static  final  String ROLE = "role";

    public  static final String UN_AUTHORIZED = "UN_AUTHORIZED";



}
