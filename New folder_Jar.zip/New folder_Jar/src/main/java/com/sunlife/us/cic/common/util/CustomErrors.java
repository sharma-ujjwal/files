package com.sunlife.us.cic.common.util;

/**
 *
 * CustomErrors enum.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Description Enum class for custom error codes and messages
 */
public enum CustomErrors {

    POSITIVE_CASE("1000","PositiveCase","Successfully executed"),
    GLOBAL_EXCEPTION("1003","InternalServerError","Internal Server error occurred"),
    JSON_EXCEPTION("1001","JsonException","Validation has failed for one or more fields."),
    API_NOT_FOUND_EXCEPTION("1004","ApiNotFoundException","The requested API endpoint was not found."),
    UNAUTHORIZED_EXCEPTION("1005","UnauthorizedException","invalid access token. please pass a valid access token"),
    DATA_NOT_FOUND_EXCEPTION("1008","DataNotFoundException", "Required data does not exist."),
    DATABASE_EXCEPTION("1009","DataBaseException","Exception thrown from DB {}"),
    INVALID_REQUEST_EXCEPTION("10010","InvalidRequestException","Invalid request data. Please check data and try again later."),
    ILLEGAL_STATE_EXCEPTION("10011","IllegalStateException","Please check the state(request, url etc.) of the object before calling this method."),
    USER_INTEREST_RATE_NOT_PROVIDED_EXCEPTION("10012","UserInterestRateNotProvidedException","Please provide the user interest rate."),
    LOAN_RATE_NOT_PROVIDED_EXCEPTION("10013","LoanRateNotProvidedException","Please provide the loan rate."),
    INTEREST_RATE_NOT_PROVIDED_EXCEPTION("10015","InterestRateNotProvidedException","Please provide the interest rate."),
    RESI_INTEREST_RATE_NOT_PROVIDED_EXCEPTION("10016","ResiInterestRateNotProvidedException","Please provide the interest rate."),
    PAYEE_INTEREST_RATE_NOT_PROVIDED_EXCEPTION("10017","PayeeInterestRateNotProvidedException","Please provide the interest rate."),

    COMPACT_RATE_NOT_PROVIDED_EXCEPTION("10019","CompactRateNotProvidedException","Please provide the compact rate."),
    PAYEE_COMPACT_RATE_NOT_PROVIDED_EXCEPTION("10020","PayeeCompactRateNotProvidedException","Please provide the compact rate."),
    USER_NOT_FOUND_EXCEPTION("1012", "UserNotFoundException", "user not found/doesn't have sufficient permissions!!" ),
    JWT_TOKEN_INVALID_EXCEPTION("1013", "JwtTokenInvalidException", "Token is Invalid/Expired" ),
    COMPACT_DATE_EXCEPTION("10018","CompactDateException","Individual rates were not found for the state of Compact Calc(YY) as of %s. The Calculations cannot be done."),
    SQL_GRAMMAR_EXCEPTION("10024","SQLGrammarException","One or more numeric fields are too large to be stored in database. Your changes cannot be saved."),;


    CustomErrors(String code, String errorType, String description) {
        this.code = code;
        this.description = description;
        this.errorType = errorType;
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    private String code;
    private  String description;
    private String errorType;

}
