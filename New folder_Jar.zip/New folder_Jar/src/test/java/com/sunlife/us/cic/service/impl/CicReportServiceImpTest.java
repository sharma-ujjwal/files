package com.sunlife.us.cic.service.impl;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.handler.exceptions.GlobalException;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.service.impl.CicReportServiceImpl;
import com.sunlife.us.cic.repo.CicClaimRepo;
import com.sunlife.us.cic.common.util.ReportsUtil;
import com.sunlife.us.cic.mapper.CicMapper;
import com.sunlife.us.cic.entity.Claim;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CicReportServiceImplTest {

    @Mock
    private CicClaimRepo claimRepository;
    @MockBean
    private ReportsUtil reportsUtil;
    @Mock
    private CicMapper cicMapper;
    @Mock
    private CacheUpdater cacheUpdater;
    @InjectMocks
    private CicReportServiceImpl cicReportService;
    @Mock
    private HazelcastInstance hazelcastInstance;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        cicReportService = new CicReportServiceImpl(claimRepository, reportsUtil, cicMapper, cacheUpdater, hazelcastInstance);
        ReflectionTestUtils.setField(cicReportService, "hazelcastInstance", hazelcastInstance);
    }

    // Test case for generatePdfReport method

    /**
     * testGeneratePdfReport_isOk is unit test case from serviceImple generatePdfReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generatePdfReport API: postive case
     * @return void
     */
    @Test
    public void testGeneratePdfReport_isOk() {
        Claim claim = new Claim();
        List<Claim> claims = List.of(claim);
        Page<Claim> claimsPage = new PageImpl<>(claims, PageRequest.of(0, 10), claims.size());
        when(claimRepository.findAll(PageRequest.of(0, 10))).thenReturn(claimsPage);

        ClaimDTO claimDTO = new ClaimDTO();
        List<ClaimDTO> claimDTOS = List.of(claimDTO);
        when(cicMapper.mapclaim(claim)).thenReturn(claimDTO);

        InputStreamResource result = cicReportService.generatePdfReport();

        assertNotNull(result);
    }

    /**
     * testGeneratePdfReport_withMultipleClaims is unit test case from serviceImple generatePdfReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generatePdfReport API: postive case with multiple claims
     * @return void
     */

    @Test
    public void testGeneratePdfReport_withMultipleClaims() {

        Claim claim1 = new Claim();
        Claim claim2 = new Claim();
        List<Claim> claims = List.of(claim1, claim2);
        Page<Claim> claimsPage = new PageImpl<>(claims, PageRequest.of(0, 10), claims.size());
        when(claimRepository.findAll(PageRequest.of(0, 10))).thenReturn(claimsPage);

        ClaimDTO claimDTO1 = new ClaimDTO();
        claimDTO1.setClmId(819);
        claimDTO1.setClmNum("123");
        claimDTO1.setClmPolNum("456");
        claimDTO1.setClmInsdFirstNm("John");
        claimDTO1.setClmInsdLastNm("Doe");

        ClaimDTO claimDTO2 = new ClaimDTO();
        claimDTO2.setClmId(81);
        claimDTO2.setClmNum("789");
        claimDTO2.setClmPolNum("012");
        claimDTO2.setClmInsdFirstNm("Jane");
        claimDTO2.setClmInsdLastNm("Doe");

        List<ClaimDTO> claimDTOS = List.of(claimDTO1, claimDTO2);
        when(cicMapper.mapclaim(claim1)).thenReturn(claimDTO1);
        when(cicMapper.mapclaim(claim2)).thenReturn(claimDTO2);
        InputStreamResource result = cicReportService.generatePdfReport();

        assertNotNull(result);
    }

    // Test case for generateStateInterestReport method

    /**
     * testGenerateStateInterestReport is unit test case from serviceImple generateStateInterestReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generateStateInterestReport API: postive case
     * @return void
     */
    @Test
    void testGenerateStateInterestReport() {
        StateInterestReportDTO report1 = mock(StateInterestReportDTO.class);
        when(report1.getInterestAmount()).thenReturn(BigDecimal.valueOf(100.0));
        when(report1.getTotalPaid()).thenReturn(BigDecimal.valueOf(200.0));
        when(report1.getNumberOfClaims()).thenReturn(BigDecimal.valueOf(10));
        when(report1.getClaimNumber()).thenReturn("1234567");
        when(report1.getClaimInterest()).thenReturn("100.0");
        when(report1.getDateOfPayment()).thenReturn(Date.valueOf("2024-02-23"));
        when(report1.getPayeeName()).thenReturn("TEST");
        when(report1.getPayeStCd()).thenReturn("ACF2");
        when(report1.getTotals()).thenReturn(BigDecimal.valueOf(100.0));

        StateInterestReportDTO report2 = mock(StateInterestReportDTO.class);
        when(report2.getPayeStCd()).thenReturn("NY");
        when(report2.getInterestAmount()).thenReturn(BigDecimal.valueOf(200.0));
        when(report2.getTotalPaid()).thenReturn(BigDecimal.valueOf(300.0));
        when(report2.getNumberOfClaims()).thenReturn(BigDecimal.valueOf(20));
        when(report2.getClaimNumber()).thenReturn("1234568");
        when(report2.getClaimInterest()).thenReturn("200.0");
        when(report2.getDateOfPayment()).thenReturn(Date.valueOf("2024-02-24"));
        when(report2.getPayeeName()).thenReturn("TEST2");
        when(report2.getTotals()).thenReturn(BigDecimal.valueOf(200.0));

        List<StateInterestReportDTO> reports = List.of(report1, report2);
        when(claimRepository.getStateInterestDetails(any(), any(), anyList())).thenReturn(reports);

        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        InputStreamResource result = cicReportService.generateStateInterestReport(reportsDTO);

        assertNotNull(result);
    }


    /**
     * testGenerateStateInterestReport_lineOfBusiness is unit test case from serviceImple generateStateInterestReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generateStateInterestReport API: postive case with different line of business
     * @return void
     */
    @Test
    void testGenerateStateInterestReport_lineOfBusiness() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));

        // Test with "I"
        reportsDTO.setLineOfBusiness("I");
        assertNotNull(cicReportService.generateStateInterestReport(reportsDTO));

        // Test with "G"
        reportsDTO.setLineOfBusiness("G");
        assertNotNull(cicReportService.generateStateInterestReport(reportsDTO));

        // Test with "All"
        reportsDTO.setLineOfBusiness(CicConstants.LINEOFBUSINESS_ALL);
        assertNotNull(cicReportService.generateStateInterestReport(reportsDTO));
    }

    /**
     * testGenerateStateInterestReport_exception is unit test case from serviceImple generateStateInterestReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generateStateInterestReport API: negative case
     * @return void
     */
    @Test
    void testGenerateStateInterestReport_exception() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        when(claimRepository.getStateInterestDetails(any(), any(), anyList()))
                .thenThrow(new RuntimeException("Test exception"));

        assertDoesNotThrow(() -> cicReportService.generateStateInterestReport(reportsDTO));
    }

    /**
     * testGenerateStateInterestReport_exception is unit test case from serviceImple generateStateInterestReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service generateStateInterestReport API: negative case
     * @return void
     */
    @Test
    void testPrintReport_ThrowsInvalidRequestException() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("State_Interest_Report");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 30); // 30 days from the current date
        java.util.Date fromdate = cal.getTime();

        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DATE, 60);// 60 days from the current date
        java.util.Date toDate = cal2.getTime();
        reportsDTO.setFromDate(fromdate);
        reportsDTO.setToDate(toDate);

        assertThrows(InvalidRequestException.class, () -> cicReportService.printReport(reportsDTO));

    }

    /**
     * testPrintReport_ifStateInterestReportSelected is unit test case from serviceImple printReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service printReport API: postive case
     * @return void
     */
    @Test
    void testPrintReport_ifStateInterestReportSelected(){
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("State_Interest_Report");
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));

        InputStreamResource result = cicReportService.printReport(reportsDTO);

        assertNotNull(result);

    }

    /**
     * testPrintReport_InvalidReport is unit test case from serviceImple printReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service printReport API: negative case
     * @return void
     */
    @Test
    void testPrintReport_InvalidReport(){
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("Invalid report type");
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));

        assertThrows(InvalidRequestException.class, () -> cicReportService.printReport(reportsDTO));
    }

    // Test case for generateTaxFile method

    /**
     * Description: testGetAcf2Id is unit test case from serviceImple getAcf2Id API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGetAcf2Id() {
        Authentication authentication = mock(Authentication.class);
        User user = mock(User.class);
        when(user.getUsername()).thenReturn("username");
        when(authentication.getPrincipal()).thenReturn(user);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        AuthInfoDTO result = cicReportService.getAcf2Id();

        assertNotNull(result);
        assertEquals("username", result.getAcf2Id());
    }

    /**
     * Description: testGetTaxFileReports is unit test case from serviceImple getTaxFileReports API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGetTaxFileReports() {
        GenerateTaxFileReportsDTO generateTaxFileReportsDTO = new GenerateTaxFileReportsDTO();
        generateTaxFileReportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        generateTaxFileReportsDTO.setToDate(Date.valueOf("2023-04-30"));

        IMap<String,List<Object[]>> map = mock(IMap.class);
        when(hazelcastInstance.<String, List<Object[]>>getMap(anyString())).thenReturn(map);
        when(map.get("bk45")).thenReturn(new ArrayList<>());
        List<Object[]> expected = Arrays.asList(new Object[22], new Object[22]);
        when(claimRepository.proc_tax_file_layout_generate(any(), any())).thenReturn(expected);

        List<Object[]> result = cicReportService.getTaxFileReports(generateTaxFileReportsDTO, "bk45");

        assertNotNull(result);
        assertEquals(expected, result);
    }

    /**
     * Description: testGenerateTaxFile_isOk is unit test case from serviceImple generateTaxFile API
     * Description: Unit test case for service generateTaxFile API: postive case
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGenerateTaxFile_isOk() {

        IMap<String, List<Object[]>> map = mock(IMap.class);
        when(hazelcastInstance.<String, List<Object[]>>getMap(anyString())).thenReturn(map);
        when(map.get("bk45")).thenReturn(new ArrayList<>());

        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);

        GenerateTaxFileReportsDTO generateTaxFileReportsDTO = new GenerateTaxFileReportsDTO();
        generateTaxFileReportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        generateTaxFileReportsDTO.setToDate(Date.valueOf("2023-04-30"));

        Object[] report1 = new Object[22];
        report1[8] = CicConstants.TAXFILE_PR;
        report1[18] = "100.0";
        report1[21] = "50.0";

        Object[] report2 = new Object[22];
        report2[8] = "NonPR";
        report2[18] = "200.0";
        report2[21] = "100.0";

        List<Object[]> taxReports = Arrays.asList(report1, report2);
        when(claimRepository.proc_tax_file_layout_generate(any(), any())).thenReturn(taxReports);

        when(cicReportService.getTaxFileReports(generateTaxFileReportsDTO, "bk45")).thenReturn(taxReports);

        String result = cicReportService.generateTaxFile(generateTaxFileReportsDTO);

        String expected = "1 record(s) were written to the  TAXFILE_PR.TXT tax file. The total interest (Box 1) amount was $1.00 and the total Interest Withheld (Box 4) amount was $0.50.\n" +
                "1 record(s) were written to the  TAXFILE.TXT  tax file. The total interest (Box 1) amount was $2.00 and the total Interest Withheld (Box 4) amount was $1.00.";
        assertEquals(expected, result);

    }


    /**
     * Description: testThrowDataNotFoundExceptionWhenNoRecordsFound when no records found in the database for the given date range
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testThrowDataNotFoundExceptionWhenNoRecordsFound() {
        GenerateTaxFileReportsDTO generateTaxFileReportsDTO = new GenerateTaxFileReportsDTO();
        generateTaxFileReportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        generateTaxFileReportsDTO.setToDate(Date.valueOf("2023-04-30"));

        IMap<String,List<Object[]>> map = mock(IMap.class);
        when(hazelcastInstance.<String, List<Object[]>>getMap(anyString())).thenReturn(map);
        when(map.get("bk45")).thenReturn(new ArrayList<>());

        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);

        when(cicReportService.getTaxFileReports(generateTaxFileReportsDTO, "bk45")).thenReturn(Collections.emptyList());

        assertThrows(DataNotFoundException.class, () -> cicReportService.generateTaxFile(generateTaxFileReportsDTO));
    }


    /**
     * Description: setupSecurityContext method is used to setup the security context with the given acf2Id
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @param acf2Id
     */
    private void setupSecurityContext(String acf2Id) {
        Authentication authentication = mock(Authentication.class);
        User user = mock(User.class);
        when(user.getUsername()).thenReturn(acf2Id);
        when(authentication.getPrincipal()).thenReturn(user);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }
    /**
     * Description: testGetTaxFilesForNonPr is unit test case from serviceImple getTaxFiles API
     * Description: Unit test case for service getTaxFiles API: postive case for NonPR tax files
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGetTaxFilesForNonPr() {
        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);

        Object[] nonPrReport = new Object[22];
        nonPrReport[8] = "NonPR";
        nonPrReport[18] = "200.0";
        nonPrReport[21] = "100.0";

        List<Object[]> taxReports = Collections.singletonList(nonPrReport);
        when(cacheUpdater.getTaxCache(acf2Id)).thenReturn(taxReports);

        String result = cicReportService.getTaxFiles(true, false);

        assertNotNull(result);
        assertTrue(result.contains("200.0100.0"));
    }

    /**
     * Description: testGetTaxFilesForPr is unit test case from serviceImple getTaxFiles API
     * Description: Unit test case for service getTaxFiles API: postive case for NonPR tax files
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGetTaxFilesForPr() {
        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);

        Object[] prReport = new Object[22];
        prReport[8] = CicConstants.TAXFILE_PR;
        prReport[18] = "100.0";
        prReport[21] = "50.0";

        List<Object[]> taxReports = Collections.singletonList(prReport);
        when(cacheUpdater.getTaxCache(acf2Id)).thenReturn(taxReports);

        String result = cicReportService.getTaxFiles(false, true);

        assertNotNull(result);
        assertTrue(result.contains("100.0"));
    }

    /**
     * Description: testReturnNullWhenNeitherNonPrNorPrSelected is unit test case from serviceImple getTaxFiles API
     * Description: Unit test case for service getTaxFiles API: negative case when neither NonPR nor PR selected in the request parameters
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testReturnNullWhenNeitherNonPrNorPrSelected() {
        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);

        Object[] report = new Object[22];
        report[8] = "NonPR";
        report[18] = "200.0";
        report[21] = "100.0";

        List<Object[]> taxReports = Collections.singletonList(report);
        when(cacheUpdater.getTaxCache(acf2Id)).thenReturn(taxReports);

        String result = cicReportService.getTaxFiles(false, false);

        assertNull(result);
    }

    /**
     * Description: testReturnEmptyStringWhenNoReportsFound is unit test case from serviceImple getTaxFiles API
     * Description: Unit test case for service getTaxFiles API: negative case when no reports found in the cache for the given acf2Id
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testReturnEmptyStringWhenNoReportsFound() {
        String acf2Id = "bk45";
        setupSecurityContext(acf2Id);
        when(cacheUpdater.getTaxCache(acf2Id)).thenReturn(Collections.emptyList());
        String result = cicReportService.getTaxFiles(true, true);
        assertEquals("", result);
    }


    /**
     * testGenerateCustomClaimPaymentReport is unit test case from serviceImple generateCustomClaimPaymentReport API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service generateCustomClaimPaymentReport API: postive case
     * @return void
     */
    @Test
    void testGenerateCustomClaimPaymentReport() {
        CustomClaimPaymentReportDTO report1 = mock(CustomClaimPaymentReportDTO.class);
        when(report1.getPayeClmIntAmt()).thenReturn(BigDecimal.valueOf(100.0));
        when(report1.getTotalPaid()).thenReturn(BigDecimal.valueOf(200.0));
        when(report1.getPayeWthldAmt()).thenReturn(BigDecimal.valueOf(10.0));
        when(report1.getClmId()).thenReturn(1234567);
        when(report1.getInsuredName()).thenReturn("This is a very long insured name that is definitely more than thirty characters");
        when(report1.getLstUpdUserId()).thenReturn("ACF2");
        when(report1.getPayePmtDt()).thenReturn(Date.valueOf("2024-02-23"));
        when(report1.getTotalClaimInterest()).thenReturn(BigDecimal.valueOf(100.0));
        when(report1.getTotalInterestWithheld()).thenReturn(BigDecimal.valueOf(10.0));
        when(report1.getPayeFullNm()).thenReturn("TEST");

        CustomClaimPaymentReportDTO report2 = mock(CustomClaimPaymentReportDTO.class);
        when(report2.getClmId()).thenReturn(2);
        when(report2.getInsuredName()).thenReturn("Short name");
        when(report2.getPayeClmIntAmt()).thenReturn(BigDecimal.valueOf(200.00));
        when(report2.getTotalPaid()).thenReturn(BigDecimal.valueOf(300.0));
        when(report2.getPayeWthldAmt()).thenReturn(BigDecimal.valueOf(20.0));
        when(report2.getPayePmtDt()).thenReturn(Date.valueOf("2024-02-24"));
        when(report2.getTotalClaimInterest()).thenReturn(BigDecimal.valueOf(200.00));
        when(report2.getTotalInterestWithheld()).thenReturn(BigDecimal.valueOf(20.0));
        when(report2.getPayeFullNm()).thenReturn("TEST2");
        when(report1.getLstUpdUserId()).thenReturn("ACF2");

        List<CustomClaimPaymentReportDTO> reports = List.of(report1, report2);
        when(claimRepository.getCustomClaimPaymentDetails(any(), any(), anyList())).thenReturn(reports);

        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        InputStreamResource result = cicReportService.generateCustomClaimReport(reportsDTO);

        assertNotNull(result);
    }

    /**
     * testGenerateCustomClaimPaymentReport_nullValue is unit test case from serviceImple generateCustomClaimPaymentReport API
     * Description: Unit test case for service generateCustomClaimPaymentReport API: postive case with null values in the report object
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGenerateCustomClaimPaymentReport_nullValue() {
        CustomClaimPaymentReportDTO report1 = mock(CustomClaimPaymentReportDTO.class);
        when(report1.getPayeClmIntAmt()).thenReturn(null);
        when(report1.getTotalPaid()).thenReturn(null);
        when(report1.getPayeWthldAmt()).thenReturn(null);
        when(report1.getClmId()).thenReturn(1234567);
        when(report1.getInsuredName()).thenReturn("TEST");
        when(report1.getLstUpdUserId()).thenReturn("ACF2");
        when(report1.getPayePmtDt()).thenReturn(Date.valueOf("2024-02-23"));
        when(report1.getTotalClaimInterest()).thenReturn(null);
        when(report1.getTotalInterestWithheld()).thenReturn(null);
        when(report1.getPayeFullNm()).thenReturn("TEST");

        CustomClaimPaymentReportDTO report2 = mock(CustomClaimPaymentReportDTO.class);
        when(report2.getClmId()).thenReturn(2);
        when(report2.getInsuredName()).thenReturn("TEST2");
        when(report2.getPayeClmIntAmt()).thenReturn(null);
        when(report2.getTotalPaid()).thenReturn(null);
        when(report2.getPayeWthldAmt()).thenReturn(null);
        when(report2.getPayePmtDt()).thenReturn(Date.valueOf("2024-02-24"));
        when(report2.getTotalClaimInterest()).thenReturn(null);
        when(report2.getTotalInterestWithheld()).thenReturn(null);
        when(report2.getPayeFullNm()).thenReturn("TEST2");
        when(report1.getLstUpdUserId()).thenReturn("ACF2");

        List<CustomClaimPaymentReportDTO> reports = List.of(report1, report2);
        when(claimRepository.getCustomClaimPaymentDetails(any(), any(), anyList())).thenReturn(reports);

        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        InputStreamResource result = cicReportService.generateCustomClaimReport(reportsDTO);

        assertNotNull(result);
    }

    /**
     * testGenerateCustomClaimPaymentReport_lineOfBusiness is unit test case from serviceImple generateCustomClaimPaymentReport API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service generateCustomClaimPaymentReport API: postive case with different line of business
     * @return void
     */
    @Test
    void testGenerateCustomClaimPaymentReport_lineOfBusiness() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));

        // Test with "I"
        reportsDTO.setLineOfBusiness("I");
        assertNotNull(cicReportService.generateCustomClaimReport(reportsDTO));

        // Test with "G"
        reportsDTO.setLineOfBusiness("G");
        assertNotNull(cicReportService.generateCustomClaimReport(reportsDTO));

        // Test with "All"
        reportsDTO.setLineOfBusiness(CicConstants.LINEOFBUSINESS_ALL);
        assertNotNull(cicReportService.generateCustomClaimReport(reportsDTO));
    }

    /**
     * testGenerateCustomClaimPaymentReport_exception is unit test case from serviceImple generateCustomClaimPaymentReport API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service generateCustomClaimPaymentReport API: negative case
     * @return void
     */
    @Test
    void testGenerateCustomClaimPaymentReport_exception() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        when(claimRepository.getCustomClaimPaymentDetails(any(), any(), anyList()))
                .thenThrow(new RuntimeException("Test exception"));

        assertThrows(RuntimeException.class,() -> cicReportService.generateCustomClaimReport(reportsDTO));
    }

    /**
     * testPrintReportCustomClaimPayment_ThrowsInvalidRequestException is unit test case from serviceImpl generateCustomClaimPaymentReport API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service generateCustomClaimPaymentReport API: negative case
     * @return void
     */
    @Test
    void testPrintReportCustomClaimPayment_ThrowsInvalidRequestException() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("Custom_Claim_Report");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 30); // 30 days from the current date
        java.util.Date fromdate = cal.getTime();

        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DATE, 60);// 60 days from the current date
        java.util.Date toDate = cal2.getTime();
        reportsDTO.setFromDate(fromdate);
        reportsDTO.setToDate(toDate);

        assertThrows(InvalidRequestException.class, () -> cicReportService.printReport(reportsDTO));

    }

    /**
     * testPrintReport_ifCustomClaimPaymentSelected is unit test case from serviceImpl printReport API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service printReport API: postive case
     * @return void
     */
    @Test
    void testPrintReport_ifCustomClaimPaymentReportSelected(){
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("Custom_Claim_Report");
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("ALL");

        InputStreamResource result = cicReportService.printReport(reportsDTO);

        assertNotNull(result);

    }

    // Test case for printIndividualReports method

    /**
     * testPrintIndividualReports is unit test case from serviceImple printIndividualReports API
     * Description: Unit test case for service printIndividualReports API: postive case
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testPrintIndividualReports() throws IOException {
        Integer claimId = 1;
        String html = "<html></html>";
        List<IndividualReportDTO> individualReports = IntStream.range(0, 6)
                .mapToObj(i -> {
                    IndividualReportDTO report = mock(IndividualReportDTO.class);
                    when(report.getPaye_full_nm()).thenReturn("Payee " + i);
                    return report;
                })
                .collect(Collectors.toList());
        when(individualReports.get(0).getClm_pol_num()).thenReturn(String.valueOf(claimId));
        when(individualReports.get(0).getCalcInsuredFullName()).thenReturn("John");
        when(individualReports.get(0).getClm_insd_dth_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(individualReports.get(0).getClm_proof_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(individualReports.get(0).getClm_tot_dthb_pmt_amt()).thenReturn(100.0);
        when(individualReports.get(0).getClm_tot_int_amt()).thenReturn(200.0);
        when(individualReports.get(0).getCalcInsdDthResStCd()).thenReturn("NY");
        when(individualReports.get(0).getIss_st_cd()).thenReturn("NY");
        when(individualReports.get(0).getClm_insd_ssn_num()).thenReturn("123456789");
        when(individualReports.get(0).getAdmn_syst_dsc()).thenReturn("Type");
        when(individualReports.get(0).getPaye_full_nm()).thenReturn("John");
        when(individualReports.get(0).getPaye_addr_ln1_txt()).thenReturn("123 Main St");
        when(individualReports.get(0).getPaye_addr_ln2_txt()).thenReturn("Apt 1");
        when(individualReports.get(0).getPaye_city_nm_txt()).thenReturn("New York");
        when(individualReports.get(0).getPaye_st_cd()).thenReturn("NY");
        when(individualReports.get(0).getCalc_st_cd()).thenReturn("NY");
        when(individualReports.get(0).getCalcPayeZipCd()).thenReturn("12345");
        when(individualReports.get(0).getPaye_care_of_txt()).thenReturn("John");
        when(individualReports.get(0).getPaye_ssn_tin_num()).thenReturn("123456789");
        when(individualReports.get(0).getPaye_clm_int_amt()).thenReturn(100.0);
        when(individualReports.get(0).getPaye_dthb_pmt_amt()).thenReturn(300.0);
        when(individualReports.get(0).getPaye_clm_int_rt()).thenReturn(10.0);
        when(individualReports.get(0).getPyco_typ_dsc()).thenReturn("NY");
        when(individualReports.get(0).getPaye_wthld_rt()).thenReturn(20.0);
        when(individualReports.get(0).getPaye_wthld_amt()).thenReturn(400.0);
        when(individualReports.get(0).getPaye_pmt_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(individualReports.get(0).getPaye_int_days_pd_num()).thenReturn(10);

        when(claimRepository.getIndividualReport(any(Integer.class))).thenReturn(individualReports);

        InputStreamResource result = cicReportService.printIndividualReports(html, claimId);

        assertNotNull(result);
    }

    /**
     * testAddRowsForCustomClaimPaymentReport is unit test case from serviceImple CustomClaimPaymentReport API
     * Description: Unit test case for service CustomClaimPaymentReport API: postive case
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @throws IOException
     */
    @Test
    void testAddRowsForCustomClaimPaymentReport() throws IOException {

        CicClaimRepo claimRepository = mock(CicClaimRepo.class);
        ReportsUtil reportsUtil = mock(ReportsUtil.class);
        CicMapper cicMapper = mock(CicMapper.class);
        CacheUpdater cacheUpdater = mock(CacheUpdater.class);
        HazelcastInstance hazelcastInstance = mock(HazelcastInstance.class);
        CicReportServiceImpl cicReportService = new CicReportServiceImpl(claimRepository, reportsUtil, cicMapper, cacheUpdater, hazelcastInstance);

        Table table = new Table(UnitValue.createPointArray(new float[]{35f, 20f, 20f, 20f, 20f}));
        List<CustomClaimPaymentReportDTO> customClaimPaymentReportDTOs = new ArrayList<>();
        CustomClaimPaymentReportDTO customClaimPaymentReportDTO = mock(CustomClaimPaymentReportDTO.class);
        when(customClaimPaymentReportDTO.getClmId()).thenReturn(1);
        when(customClaimPaymentReportDTO.getPayeClmIntAmt()).thenReturn(BigDecimal.valueOf(100));
        when(customClaimPaymentReportDTO.getPayeClmPdAmt()).thenReturn(BigDecimal.valueOf(200));
        when(customClaimPaymentReportDTO.getPayeWthldAmt()).thenReturn(BigDecimal.valueOf(50));
        when(customClaimPaymentReportDTO.getTotalClaimInterest()).thenReturn(BigDecimal.valueOf(100));
        when(customClaimPaymentReportDTO.getTotalInterestWithheld()).thenReturn(BigDecimal.valueOf(50));
        when(customClaimPaymentReportDTO.getTotalPaid()).thenReturn(BigDecimal.valueOf(200));
        when(customClaimPaymentReportDTO.getPayePmtDt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(customClaimPaymentReportDTO.getPayeFullNm()).thenReturn("John Doe");
        when(customClaimPaymentReportDTO.getLstUpdUserId()).thenReturn("ACF2");
        when(customClaimPaymentReportDTO.getInsuredName()).thenReturn("John Doe");

        customClaimPaymentReportDTOs.add(customClaimPaymentReportDTO);

        BigDecimal[] result = cicReportService.addRowsForCustomClaimPaymentReport(table, customClaimPaymentReportDTOs, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);

        assertEquals(BigDecimal.valueOf(100), result[0]);
        assertEquals(BigDecimal.valueOf(50), result[1]);
        assertEquals(BigDecimal.valueOf(200), result[2]);
    }

    /**
     * testPrintIndividualReports_NullValues is unit test case from serviceImple printIndividualReports API
     * Description: Unit test case for service printIndividualReports API: negative case with null values in the report data
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testPrintIndividualReports_NullValues() throws IOException {
        Integer claimId = 1;
        String html = "<html></html>";
        List<IndividualReportDTO> individualReports = new ArrayList<>();
        IndividualReportDTO firstReport = mock(IndividualReportDTO.class);
        when(firstReport.getClm_pol_num()).thenReturn(String.valueOf(claimId));
        when(firstReport.getCalcInsuredFullName()).thenReturn("John");
        when(firstReport.getClm_insd_dth_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(firstReport.getClm_proof_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(firstReport.getClm_tot_dthb_pmt_amt()).thenReturn(null);
        when(firstReport.getClm_tot_int_amt()).thenReturn(null);
        when(firstReport.getClm_tot_wthld_amt()).thenReturn(null);
        when(firstReport.getClm_tot_clm_pd_amt()).thenReturn(null);
        when(firstReport.getCalcInsdDthResStCd()).thenReturn("NY");
        when(firstReport.getIss_st_cd()).thenReturn("NY");
        when(firstReport.getClm_insd_ssn_num()).thenReturn(null);
        when(firstReport.getAdmn_syst_dsc()).thenReturn("Type");
        when(firstReport.getPaye_full_nm()).thenReturn(null);
        when(firstReport.getPaye_addr_ln1_txt()).thenReturn("123 Main St");
        when(firstReport.getPaye_addr_ln2_txt()).thenReturn("Apt 1");
        when(firstReport.getPaye_city_nm_txt()).thenReturn("New York");
        when(firstReport.getPaye_st_cd()).thenReturn("NY");
        when(firstReport.getCalc_st_cd()).thenReturn("NY");
        when(firstReport.getCalcPayeZipCd()).thenReturn("12345");
        when(firstReport.getPaye_care_of_txt()).thenReturn("John");
        when(firstReport.getPaye_ssn_tin_num()).thenReturn("123456789");
        when(firstReport.getPaye_clm_int_amt()).thenReturn(null);
        when(firstReport.getPaye_dthb_pmt_amt()).thenReturn(null);
        when(firstReport.getPaye_clm_int_rt()).thenReturn(null);
        when(firstReport.getPyco_typ_dsc()).thenReturn("NY");
        when(firstReport.getPaye_wthld_rt()).thenReturn(null);
        when(firstReport.getPaye_wthld_amt()).thenReturn(null);
        when(firstReport.getPaye_pmt_dt()).thenReturn(Date.valueOf(LocalDate.now()));
        when(firstReport.getPaye_int_days_pd_num()).thenReturn(null);
        when(firstReport.getPaye_clm_pd_amt()).thenReturn(null);

        individualReports.add(firstReport);
        when(claimRepository.getIndividualReport(claimId)).thenReturn(individualReports);

        InputStreamResource result = cicReportService.printIndividualReports(html, claimId);

        assertNotNull(result);
    }
    /**
     * testGenerateStateInterestReport_SameState is unit test case from serviceImple generateStateInterestReport API
     * Description: Unit test case for service generateStateInterestReport API: postive case with same state in the report data
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGenerateStateInterestReport_SameState() {
        StateInterestReportDTO report1 = mock(StateInterestReportDTO.class);
        when(report1.getPayeStCd()).thenReturn("NY");
        when(report1.getClaimNumber()).thenReturn("1234567");
        when(report1.getClaimInterest()).thenReturn("100.0");
        when(report1.getDateOfPayment()).thenReturn(Date.valueOf("2024-02-23"));
        when(report1.getPayeeName()).thenReturn("TEST");
        when(report1.getTotals()).thenReturn(BigDecimal.valueOf(100.0));
        when(report1.getNumberOfClaims()).thenReturn(BigDecimal.valueOf(10));
        when(report1.getTotalPaid()).thenReturn(BigDecimal.valueOf(200.0));
        when(report1.getInterestAmount()).thenReturn(BigDecimal.valueOf(100.0));

        StateInterestReportDTO report2 = mock(StateInterestReportDTO.class);
        when(report2.getPayeStCd()).thenReturn("NY");
        when(report2.getClaimNumber()).thenReturn("1234568");
        when(report2.getClaimInterest()).thenReturn("200.0");
        when(report2.getDateOfPayment()).thenReturn(Date.valueOf("2024-02-24"));
        when(report2.getPayeeName()).thenReturn("TEST2");
        when(report2.getTotals()).thenReturn(BigDecimal.valueOf(200.0));

        List<StateInterestReportDTO> reports = List.of(report1, report2);
        when(claimRepository.getStateInterestDetails(any(), any(), anyList())).thenReturn(reports);

        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        InputStreamResource result = cicReportService.generateStateInterestReport(reportsDTO);

        assertNotNull(result);
    }
    /**
     * testGetTaxFiles_PR_OR_NONPR is unit test case from serviceImple getTaxFiles API
     * Description: Unit test case for service getTaxFiles API: postive case for PR and NonPR tax files
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testGetTaxFiles_PR_OR_NONPR() {
        String acf2Id = "testId";
        setupSecurityContext(acf2Id);
        Object[][] taxReportsData = {
                {null, "value2", "value3", "!", "value5", "value6", "value7", "value8", "value9"},
                {"value1", "value2", "value3", "value4", "value5", "value6", "value7", "value8", "value9"}
        };
        List<Object[]> taxReports = Arrays.asList(taxReportsData);

        when(cacheUpdater.getTaxCache(acf2Id)).thenReturn(taxReports);

        String result = cicReportService.getTaxFiles(true, true);

        assertNotNull(result);
        assertFalse(result.contains("null"));
        assertFalse(result.contains("!"));
    }

}
