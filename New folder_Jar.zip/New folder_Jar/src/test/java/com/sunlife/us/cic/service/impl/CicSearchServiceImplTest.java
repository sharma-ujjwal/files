package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.entity.Payee;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import com.sunlife.us.cic.repo.CicClaimRepo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * CicSearchServiceImplTest Class.
 * Unit test class for CicSearchServiceImpl class
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 */
@ExtendWith(MockitoExtension.class)
class CicSearchServiceImplTest {

    @Mock
    private CicClaimRepo cicClaimRepo;

    @InjectMocks
    private CicSearchServiceImpl cicSearchService;

    /**
     * searchInsurer_test is unit test case from serviceImple searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: policyNumber search postive case
     * @return void
     */
    @Test
    void searchInsurer_policyNumber_test() {
        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");
        Claim claim =Mockito.spy(Claim.class);
        claim.setClmInsdFirstNm("John");
        claim.setPayee(new ArrayList<>());
        claim.getPayee();
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(admin);
        Mockito.verify(claim, Mockito.times(1)).getPayee();

        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(2, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()), 0);
        when(   cicClaimRepo.findByPolicyNumberRegex("123", PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(claimList);

        ViewInsurerResponse viewInsurerResponse =  cicSearchService.searchInsurer("123", "policyNumber", 2, 5);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * searchInsurer_test is unit test case from serviceImple searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: name search postive case
     * @return void
     */
    @Test
    void searchInsurer_name_test() {
        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");
        Claim claim = new Claim();
        claim.setClmInsdFirstNm("John");
        claim.setPayee(new ArrayList<>());
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(admin);

        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(2, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()), 0);
        when(cicClaimRepo.findByClmInsdFirstNmRegexOrClmInsdLastNmRegex("John",  PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(claimList);

        ViewInsurerResponse viewInsurerResponse =  cicSearchService.searchInsurer("John", "name", 2, 5);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * searchInsurer_test is unit test case from serviceImple searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: SSN search postive case
     * @return void
     */
    @Test
    void searchInsurer_SSN_test() {
        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");
        Claim claim = new Claim();
        claim.setClmInsdFirstNm("John");
        claim.setPayee(new ArrayList<>());
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(admin);
        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(2, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()), 0);
        when(cicClaimRepo.findByClmInsdSsnNumRegex("123", PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(claimList);

        ViewInsurerResponse viewInsurerResponse =  cicSearchService.searchInsurer("123", "SSN", 2, 5);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * searchInsurer_test is unit test case from serviceImple searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: Data not found negative case
     * @return void
     */
    @Test
    void searchInsurer_Data_Not_found_test() {
        Page<Claim> claimList = new PageImpl<>(List.of(), PageRequest.of(2, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()), 0);
        when(cicClaimRepo.findByClmInsdSsnNumRegex("123", PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(claimList);
        assertThrows(DataNotFoundException.class, ()->cicSearchService.searchInsurer("123", "SSN", 2, 5));
    }

    @Test
    void searchInsurer_Data_Not_found_test2() {
        when(cicClaimRepo.findByClmInsdSsnNumRegex("123", PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(null);
        assertThrows(DataNotFoundException.class, ()->cicSearchService.searchInsurer("123", "SSN", 2, 5));
    }

    /**
     * searchInsurer_test is unit test case from serviceImple searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: Invalid searchField negative case
     * @return void
     */
    @Test
    void searchInsurer_Invalid_searchfield_test() {
        assertThrows(InvalidRequestException.class, ()->cicSearchService.searchInsurer("123", "SSN1", 2, 5));
    }

    /**
     * searchInsurer_test is unit test case from serviceImpl searchInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service searchInsurer API: Ternary search postive case
     * @return void
     */
    @Test
    void searchInsurer_ternary_switch_test() {
        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");
        String searchInput = "123";
        String searchField = "policyNumber";
        Payee payee = new Payee();
        payee.setClmId(123);
        Claim claim =Mockito.spy(Claim.class);
        claim.setClmInsdFirstNm("John");
        claim.setPayee(List.of(payee));
        claim.getPayee();
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(admin);
        Mockito.verify(claim, Mockito.times(1)).getPayee();

        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(2, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()), 0);
        when(cicClaimRepo.findByPolicyNumberRegex("123", PageRequest.of(1, 5, Sort.by(CicConstants.LAST_UPDATED_DATE).descending()))).thenReturn(claimList);

        ViewInsurerResponse viewInsurerResponse =  cicSearchService.searchInsurer(searchInput, searchField, 2, 5);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();    }


}
