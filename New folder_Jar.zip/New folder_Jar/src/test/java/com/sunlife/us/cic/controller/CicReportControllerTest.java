package com.sunlife.us.cic.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.ReportsUtil;
import com.sunlife.us.cic.controller.CicReportController;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.GlobalException;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.handler.exceptions.JsonException;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.repo.CicClaimRepo;
import com.sunlife.us.cic.service.CicReportService;
import com.sunlife.us.cic.service.impl.CicReportServiceImpl;
import com.sunlife.us.cic.service.impl.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.core.io.Resource;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.opensaml.security.crypto.SigningUtil.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = CicReportController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
public class CicReportControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private CicReportService reportService;
    @MockBean
    private ReportsUtil reportsUtil;

    @MockBean
    JwtService jwtService;

    @MockBean
    UserDetailsService userDetailsService;

    @InjectMocks
    private CicReportController cicReportController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // Test case for generatePdfReport method

    /**
     * testGeneratePdfReport_isOk is unit test case from controller generatePdfReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller generatePdfReport API: postive case
     * @return void
     */

    @Test
    public void testGeneratePdfReport() throws Exception {
        // Arrange
        InputStreamResource mockResource = new InputStreamResource(new ByteArrayInputStream(new byte[0]));
        when(reportService.generatePdfReport()).thenReturn(mockResource);

        // Act
        mockMvc.perform(get("/v1/interestcalculator/report/pdf")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(header().string(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE))
                .andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"filename\"; filename=\"reports.pdf\""))
                .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "must-revalidate, post-check=0, pre-check=0"));

        // Verify
//        verify(reportService, times(1)).generatePdfReport();
    }

    @Test
    public void testPrintReport() throws Exception {
        // Arrange
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("State_Interest_Report");
        reportsDTO.setFromDate(Date.valueOf("2021-04-01"));
        reportsDTO.setToDate(Date.valueOf("2024-04-30"));
        reportsDTO.setLineOfBusiness("All");

        InputStreamResource mockResource = new InputStreamResource(new ByteArrayInputStream(new byte[0]));
        when(reportService.printReport(any(ReportsDTO.class))).thenReturn(mockResource);

        // Act and Assert
        mockMvc.perform(post("/v1/interestcalculator/report/printReport")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(reportsDTO))) // You need to convert reportsDTO to JSON string
                .andExpect(status().isOk())
                .andExpect(header().string(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE))
                .andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"filename\"; filename=\"reports.pdf\""))
                .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "must-revalidate, post-check=0, pre-check=0"));
    }

    @Test
    public void testGenerateTaxFile() throws Exception {
        // Arrange
        GenerateTaxFileReportsDTO generateTaxFileReportsDTO = new GenerateTaxFileReportsDTO();
        // Set the properties of generateTaxFileReportsDTO as per your requirements

        String expectedTaxFile = "Expected Tax File";
        when(reportService.generateTaxFile(any(GenerateTaxFileReportsDTO.class))).thenReturn(expectedTaxFile);

        // Act
        MockHttpServletResponse response = mockMvc.perform(post("/v1/interestcalculator/report/generateTaxFile")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(generateTaxFileReportsDTO))) // You need to convert generateTaxFileReportsDTO to JSON string
                .andExpect(status().isOk())
                .andReturn().getResponse();

        // Assert
        assertEquals(expectedTaxFile, response.getContentAsString());
    }

    @Test
    public void testPrintIndividualReports() throws Exception {
        // Arrange
        int claimId = 1;
        InputStreamResource mockResource = new InputStreamResource(new ByteArrayInputStream(new byte[0]));
        when(reportService.printIndividualReports(null, claimId)).thenReturn(mockResource);

        // Act and Assert
        mockMvc.perform(get("/v1/interestcalculator/report/printIndividualReport")
                        .param("claimId", String.valueOf(claimId))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(header().string(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE))
                .andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"filename\"; filename=\"reports.pdf\""))
                .andExpect(header().string(HttpHeaders.CACHE_CONTROL, "must-revalidate, post-check=0, pre-check=0"));
    }

    // Method to convert Object to JSON string
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Description: testPrintReport_InvalidReportDates is unit test case from controller printReport API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    void testPrintReport_ThrowsInvalidRequestException() {
        ReportsDTO reportsDTO = new ReportsDTO();
        reportsDTO.setReportType("State_Interest_Report");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 30); // 30 days from the current date
        java.util.Date fromdate = cal.getTime();

        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DATE, 60);// 60 days from the current date
        java.util.Date toDate = cal2.getTime();
        reportsDTO.setFromDate(fromdate);
        reportsDTO.setToDate(toDate);

    assertThrows(InvalidRequestException.class, () -> cicReportController.printReport(reportsDTO));

    }
    

    @Test
    public void testReturnNonPRTaxFilesWhenViewNonPRIsNotNull1() throws Exception {
        String taxFiles = "Expected viewPR Tax Files";
        when(reportService.getTaxFiles(false, true)).thenReturn(taxFiles);

        mockMvc.perform(get("/v1/interestcalculator/report/taxFiles?viewPR=viewPR")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(taxFiles));
    }

    @Test
    public void testReturnNonPRTaxFilesWhenViewNonPRIsNotNull2() throws Exception {
        String expectedTaxFiles = "Expected viewNonPR Tax Files";
        when(reportService.getTaxFiles(true, false)).thenReturn(expectedTaxFiles);

        mockMvc.perform(get("/v1/interestcalculator/report/taxFiles?viewNonPR=viewNonPR&viewPR=null")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(expectedTaxFiles));
    }

    /**
     * Description: testThrowInvalidRequestExceptionWhenBothViewNonPRAndViewPRAreNull is unit test case from controller generateTaxFile API
     * Description: Unit test case for controller generateTaxFile API: negative case
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * @return void
     */
    @Test
    public void testThrowInvalidRequestExceptionWhenBothViewNonPRAndViewPRAreNull() {
        assertThrows(InvalidRequestException.class, () -> cicReportController.getTaxFiles(null, null));
    }

}
