package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.security.SignatureException;
import org.apache.el.util.ReflectionUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.commons.util.ReflectionUtils;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class JwtServiceTest {
    @InjectMocks
    private JwtService jwtService;

    @Mock
    private User user;

    @Mock
    private UserDetails userDetails;

    private String token;

    /**
     * Initial test set up
     */
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        when(user.getUsername()).thenReturn("testUser");
        when(user.getEmail()).thenReturn("testEmail");
        when(user.getRole()).thenReturn("testRole");
        ReflectionTestUtils.setField(jwtService, "secretKey", "3cfj76ef14937c1e0ea519f8fc057t80wcd04a7420f8e8bcd0a7277c272e007b");
        ReflectionTestUtils.setField(jwtService, "jwtExpiration", 3600000L);
        token = jwtService.generateToken(new HashMap<>(), user);
    }


    /**
     * Test if the username is correct
     */
    @Test
    public void testExtractUsername_test_is_ok() {
        String username = jwtService.extractUsername(token);
        assertEquals("testUser", username);
    }

    /**
     * Test for correct token is generated
     */
    @Test
    public void testGenerateToken_test_token() {
        Map<String, Object> claims = new HashMap<>();
        String token = jwtService.generateToken(claims, user);
        when(userDetails.getUsername()).thenReturn("testUser");
        assertTrue(jwtService.isTokenValid(token, userDetails));
    }

    /**
     * Test for checking the token is a valid one
     */
    @Test
    public void testIsTokenValid_is_not_valid() {
        when(userDetails.getUsername()).thenReturn(null);
        assertFalse(jwtService.isTokenValid(token, userDetails));
    }

    /**
     * Check the token generated is valid
     */
    @Test
    public void testIsTokenValid_is_true() {
        JwtService jwtService = new JwtService();
        UserDetails userDetails = mock(UserDetails.class);
        User user = new User();
        user.setUserName("testUser");
        ReflectionTestUtils.setField(jwtService, "secretKey", "3cfj76ef14937c1e0ea519f8fc057t80wcd04a7420f8e8bcd0a7277c272e007b");
        ReflectionTestUtils.setField(jwtService, "jwtExpiration", 3600000L);
        String token = jwtService.generateToken(user);

        // Test case for true branch
        when(userDetails.getUsername()).thenReturn("testUser");
        assertTrue(jwtService.isTokenValid(token, userDetails));

        // Test case for false branch
        when(userDetails.getUsername()).thenReturn("wrongUser");
        assertFalse(jwtService.isTokenValid(token, userDetails));
    }


    /**
     * Verify the behaviour when the token is null
     */
    @Test
    public void testExtractUsername_test_with_null_token() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            jwtService.extractUsername(null);
        });
    }

    /**
     * Verify the behaviour when the token is empty
     */
    @Test
    public void testExtractUsername_test_with_empty_token() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            jwtService.extractUsername("");
        });
    }

    /**
     * Verify the behaviour when the token is being expired
     */
    @Test
    public void testIsTokenValid_test_with_expired_token() {
        String expiredToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0ZXN0VXNlciIsImV4cCI6MTYxNzY5MzYwMH0.5dVJv_2HKvu9qkcXJ6YPb6PibCbXZ2C1Z6ZGM8JiHKg";
        Assertions.assertThrows(SignatureException.class, () -> {
            jwtService.isTokenValid(expiredToken, userDetails);
        });
    }

    /**
     * Verify the token with a different username rather than used for signing the token
     */
    @Test
    public void testIsTokenValid_with_different_username() {
        when(userDetails.getUsername()).thenReturn("differentUser");
        Assertions.assertFalse(jwtService.isTokenValid(token, userDetails));
    }

    /**
     * Check for null case
     */
    @Test
    public void testRemoveFirstAndLastChar_null() {
        JwtService jwtService = new JwtService();
        String result = jwtService.removeFirstAndLastChar(null);
        assertNull(result);
    }

    /**
     * test for ADMIN_USER
     */
    @Test
    public void testGetTheLoggedInUserRole_for_admin() {
        JwtService jwtService = mock(JwtService.class);
        when(jwtService.getAdminAdGroups()).thenReturn(new String[]{"adminGroup1", "adminGroup2"});
        when(jwtService.getTheLoggedInUserRole("adminGroup1,adminGroup2")).thenCallRealMethod();
        String role = jwtService.getTheLoggedInUserRole("adminGroup1,adminGroup2");
        assertEquals("ADMIN_USER", role);
    }

    /**
     * Test for STD_USER
     */

    @Test
    public void testGetTheLoggedInUserRole_for_std_user() {
        JwtService jwtService = mock(JwtService.class);
        when(jwtService.getAdminAdGroups()).thenReturn(new String[]{"", ""});
        when(jwtService.getStdGroups()).thenReturn(new String[]{"stdUserGroup1", "stdUserGroup2"});
        when(jwtService.getTheLoggedInUserRole("stdUserGroup1,stdUserGroup2")).thenCallRealMethod();
        String role = jwtService.getTheLoggedInUserRole("stdUserGroup1,stdUserGroup2");
        assertEquals("STD_USER", role);
    }

    /**
     * NUll check for unknown groups
     */
    @Test
    public void testGetTheLoggedInUserRole_for_unknown_group() {
        JwtService jwtService = mock(JwtService.class);
        when(jwtService.getAdminAdGroups()).thenReturn(new String[]{"adminGroup1", "adminGroup2"});
        when(jwtService.getStdGroups()).thenReturn(new String[]{"stdGroup1", "stdGroup2"});
        when(jwtService.getTheLoggedInUserRole("unknownGroup1,unknownGroup2")).thenCallRealMethod();
        String role = jwtService.getTheLoggedInUserRole("unknownGroup1,unknownGroup2");
        assertEquals(null, role);
    }

    /**
     * Test if claim can be extracted from token
     */
    @Test
    public void testExtractClaim_is_ok() {
        String token = jwtService.generateToken(new HashMap<>(), user);
        String username = jwtService.extractClaim(token, Claims::getSubject);
        assertEquals("testUser", username);
    }

    /**
     * Test for expiration time for the token
     */
    @Test
    public void testGetExpirationTime_is_ok() {
        long expirationTime = jwtService.getExpirationTime();
        assertEquals(3600000L, expirationTime);
    }

    /**
     * test if the expiration time is not null
     */
    @Test
    public void testExtractExpiration_not_null() {
        String token = jwtService.generateToken(new HashMap<>(), user);
        Date expiration = jwtService.extractExpiration(token);
        assertNotNull(expiration);
    }

    /**
     * Check if the extracted claims is not null
     */
    @Test
    public void testExtractAllClaims_not_null() {
        String token = jwtService.generateToken(new HashMap<>(), user);
        Claims claims = jwtService.extractAllClaims(token);
        assertNotNull(claims);
    }

    /**
     * Test if token is being created
     */
    @Test
    public void testGenerateToken_is_true() {
        User testUser = mock(User.class);
        when(testUser.getUsername()).thenReturn("testUser");
        when(testUser.getEmail()).thenReturn("testEmail");
        when(testUser.getRole()).thenReturn("testRole");

        String token = jwtService.generateToken(testUser);

        assertNotNull(token);
        assertTrue(jwtService.isTokenValid(token, testUser));
    }

    /**
     * test for ADMIN_USER groups
     */
    @Test
    public void testGetAdminAdGroups_is_ok() {
        JwtService jwtService = new JwtService();
        String adGroups = "adminGroup1, adminGroup2, adminGroup3";
        ReflectionTestUtils.setField(jwtService, "adGroupsAdmUser", adGroups);

        String[] expected = {"adminGroup1", "adminGroup2", "adminGroup3"};
        String[] actual = jwtService.getAdminAdGroups();

        assertArrayEquals(expected, actual);
    }


    /**
     * Test for STD_USER groups
     */
    @Test
    public void testGetStdGroups_is_ok() {
        JwtService jwtService = new JwtService();
        String adGroups = "stdGroup1, stdGroup2, stdGroup3";
        ReflectionTestUtils.setField(jwtService, "adGroupsStdUser", adGroups);

        String[] expected = {"stdGroup1", "stdGroup2", "stdGroup3"};
        String[] actual = jwtService.getStdGroups();

        assertArrayEquals(expected, actual);
    }

    /**
     * Test for removing the first and last character from SAML assertion attributes
     */
    @Test
    public void testRemoveFirstAndLastChar_is_ok() {
        JwtService jwtService = new JwtService();

        String input1 = "[test]";
        String expected1 = "test";
        String actual1 = jwtService.removeFirstAndLastChar(input1);
        assertEquals(expected1, actual1);

        String input2 = null;
        String expected2 = null;
        String actual2 = jwtService.removeFirstAndLastChar(input2);
        assertEquals(expected2, actual2);

        String input3 = "t";
        String expected3 = "t";
        String actual3 = jwtService.removeFirstAndLastChar(input3);
        assertEquals(expected3, actual3);
    }
}
