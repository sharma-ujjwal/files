package com.sunlife.us.cic.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.common.util.RequestUtil;
import com.sunlife.us.cic.entity.Admin;
import com.sunlife.us.cic.handler.exceptions.JsonException;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.repo.CicAdminRepo;
import com.sunlife.us.cic.model.ClaimDTO;
import com.sunlife.us.cic.model.ClaimFormDataDTO;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import com.sunlife.us.cic.service.CicClaimService;
import com.sunlife.us.cic.service.impl.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.*;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

/**
 *
 * CicClaimsControllerTests Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Unit test class for CicClaimController class
 */
@WebMvcTest(controllers = CicClaimController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class CicClaimsControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RequestUtil requestUtil;

    @MockBean
    private CicClaimService cicClaimsService;

    @MockBean
    private CicAdminRepo cicAdminRepo;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private JwtService jwtService;

    @MockBean
    private UserDetailsService userDetailsService;
    
    Admin adminData;
    
    //beforeeach
    @BeforeEach
    void setUp() {
        adminData = new Admin();
        adminData.setAdmnSystCd(20);
        adminData.setAdmnSystDsc("Group");
        adminData.setAdmnSystIdMaxLgthNum("10");
        adminData.setAdmnSystIdMinLgthNum("6");
    }

    /* Delete Insurer Test Cases */

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: postive case
     */
    @Test
    void deleteInsurer_test_isok() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/insured?claimId=122881")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: parameter is 0
     */
    @Test
    void deleteInsurer_test_isBadRequest_0() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/insured?claimId=0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: parameter is null
     */
    @Test
    void deleteInsurer_test_isBadRequest_null() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/insured?claimId=null")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: parameter is empty
     */
    @Test
    void deleteInsurer_test_isBadRequest_empty() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/insured?claimId=")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: API not found
     */
    @Test
    void deleteInsurer_test_isNotFound() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v2/interestcalculator/insured?claimId=0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * deleteInsurer_test method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for controller deleteInsurer API: InternalServerError
     */
    @Test
    void deleteInsurer_test_isInternalServerError() throws Exception {
        when(cicClaimsService.deleteInsurer(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /* View Insurer Test Cases */

    /**
     * viewInsurer_test method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: postive case
     */
    @Test
    void getViewInsurer_test_isOk() throws Exception {
        int pageNumber = 1;
        int pageSize = 5;
        when(cicClaimsService.viewInsurer(pageNumber, pageSize)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured?pageNumber=1&pageSize=3")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * viewInsurer_test method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: Bad Request
     */
    @Test
    void getViewInsurer_test_BadRequest_0() throws Exception {
        int pageNumber = 0;
        int pageSize = 0;
        when(cicClaimsService.viewInsurer(pageNumber, pageSize)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured?pageNumber=0&pageSize=0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());

    }

    /**
     * viewInsurer_test method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: When PageSize is notpresent
     */
    @Test
    void getViewInsurer_test_whenPageSize_notpresent() throws Exception {
        int pageNumber=1;
        when(cicClaimsService.viewInsurer(pageNumber,0)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured?pageNumber=1&pageSize=0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * viewInsurer_test method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: When PageNumber is notpresent
     */
    @Test
    void getViewInsurer_test_whenPageNumber_notpresent() throws Exception {
        int pageSize=5;
        when(cicClaimsService.viewInsurer(0,pageSize)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured?pageNumber=0&pageSize=1")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * viewInsurer_test method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: URL is wrong
     */
    @Test
    void getViewInsurer_test_isNotFound() throws Exception {
        int pageNumber = 1;
        int pageSize = 5;
        when(cicClaimsService.viewInsurer(pageNumber, pageSize)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v2/interestcalculator/insured?pageNumber=1&pageSize=5")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: Positive case
     */
    @Test
    void getInsurer_test_isOk() throws Exception {
        int claimId = 819;
        when(cicClaimsService.getInsurer(claimId)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured/819")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: Claim not found(not present in db)
     */
    @Test
    void getInsurer_test_isNotFound() throws Exception {
        when(cicClaimsService.getInsurer(0)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured/0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: API not found
     */
    @Test
    void getInsurer_test_isInvalidData() throws Exception {
        when(cicClaimsService.getInsurer(81)).thenReturn(new ViewInsurerResponse());
        ResultActions response = mockMvc.perform(get("/v2/interestcalculator/insured/81")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * getClaimFormData method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller getClaimFormData API: positive case
     */
    @Test
    void getClaimFormData_test_isOk() throws Exception {
        int claimId = 819;
        when(cicClaimsService.getClaimFormData(claimId)).thenReturn(new ClaimFormDataDTO());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured/formdata?claimId=819")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * getClaimFormData method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller getClaimFormData API: API not found
     */
    @Test
    void getClaimFormData_test_isNotFound() throws Exception {
        int claimId = 819;
        when(cicClaimsService.getClaimFormData(claimId)).thenReturn(new ClaimFormDataDTO());
        ResultActions response = mockMvc.perform(get("/v22/interestcalculator/insured/formdata")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * getClaimFormData method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller getClaimFormData API: method not allowed
     */
    @Test
    void getClaimFormData_test_isInternalServerError() throws Exception {
        int claimId = 819;
        when(cicClaimsService.getClaimFormData(claimId)).thenReturn(new ClaimFormDataDTO());
        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/insured/formdata")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isMethodNotAllowed());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: positive case
     */
    @Test
    void addInsurer_test_isOk() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Admin adminData = new Admin();
        adminData.setAdmnSystCd(20);
        adminData.setAdmnSystDsc("Group");
        adminData.setAdmnSystIdMaxLgthNum("10");
        adminData.setAdmnSystIdMinLgthNum("6");
        Optional<Admin> admin = Optional.of(adminData);
        List<Errors> errorsList = new ArrayList<>();
        when(cicClaimsService.findAdminById(20)).thenReturn(admin);
        when(cicClaimsService.addInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        RequestUtil.validatePolicyNumber(claimDTO, errorsList, admin);
        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));
        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: ClaimDTO is null
     */
    @Test
    void addInsurer_test_isBadRequest() throws Exception {
        ClaimDTO claimDTO = null;
        Admin adminData = new Admin();
        adminData.setAdmnSystCd(20);
        adminData.setAdmnSystDsc("Group");
        adminData.setAdmnSystIdMaxLgthNum("10");
        adminData.setAdmnSystIdMinLgthNum("6");
        when(cicClaimsService.addInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: policynumber is invalid
     */
    @Test
    void addInsurer_test_isInvalidRequest() throws Exception {
        List<Errors> errorsList = new ArrayList<>();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Admin admin = new Admin();
        admin.setAdmnSystCd(20);
        admin.setAdmnSystIdMaxLgthNum("7");
        admin.setAdmnSystIdMinLgthNum("6");

        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: API not found
     */
    @Test
    void addInsurer_test_isNotFound() throws Exception {
        
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        when(cicClaimsService.addInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(post("/v2/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: InternalServerError
     */
    @Test
    void addInsurer_test_isInternalServerError() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        when(cicClaimsService.addInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /**
     * addInsurer method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for controller addInsurer API: InternalServerError
     */
    @Test
    void addInsurer_test_isInternalServerError_2() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.00"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        when(cicClaimsService.addInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /**
     * editInsurer method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar (BV26</a>
     * Description: Unit test case for controller editInsurer API: positive case
     */
    @Test
    void editInsurer_test_isOk() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(149966, "UT1233G123","UT124357", new BigDecimal("100.00"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "123456987", "MN", true, true, true, 20, "I1","GROUP");
        when(cicClaimsService.findAdminById(20)).thenReturn(Optional.of(adminData));
        when(cicClaimsService.editInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(patch("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void editInsurer_test_isInvalidRequest() throws Exception {
        List<Errors> errorsList = new ArrayList<>();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Admin admin = new Admin();
        admin.setAdmnSystCd(20);
        admin.setAdmnSystIdMaxLgthNum("7");
        admin.setAdmnSystIdMinLgthNum("6");

        ResultActions response = mockMvc.perform(patch("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * editInsurer method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for controller editInsurer API: ClaimDTO is null
     */
    @Test
    void editInsurer_test_isBadRequest() throws Exception {
        ClaimDTO claimDTO = null;
        when(cicClaimsService.editInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(patch("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * editInsurer method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for controller editInsurer API: API not found
     */
    @Test
    void editInsurer_test_isNotFound() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.00"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        when(cicClaimsService.editInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(patch("/v2/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDTO)));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * editInsurer method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for controller editInsurer API: InternalServerError
     */
    @Test
    void editInsurer_test_isInternalServerError() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.00"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        when(cicClaimsService.editInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /**
     * editInsurer method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for controller editInsurer API: InternalServerError
     */
    @Test
    void editInsurer_test_isInternalServerError_2() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.00"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        when(cicClaimsService.editInsurer(claimDTO, adminData)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/insured")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

}
