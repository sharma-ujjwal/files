package com.sunlife.us.cic.controller;

import com.sunlife.us.cic.model.ClaimDTO;
import com.sunlife.us.cic.model.ViewInsurerResponse;
import com.sunlife.us.cic.service.CicSearchService;
import com.sunlife.us.cic.service.impl.JwtService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import java.util.List;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

/**
 *
 * CicSearchControllerTest Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Unit test class for CicsearchController class
 */
@WebMvcTest(controllers = CicSearchController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class CicSearchControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CicSearchService cicSearchService;

    @MockBean
    private JwtService jwtService;

    @MockBean
    private UserDetailsService userDetailsService;


    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: postive case
     */
    @Test
    void searchInsurerTest() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClmInsdFirstNm("DJ");
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        viewInsurerResponse.setClaimsList(List.of(claimDTO));
        when(cicSearchService.searchInsurer("abc","abc",1,2)).thenReturn(viewInsurerResponse);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void searchInsurerTest2() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClmInsdFirstNm("DJ");
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        viewInsurerResponse.setClaimsList(List.of(claimDTO));
        when(cicSearchService.searchInsurer("name","name",1,2)).thenReturn(viewInsurerResponse);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=name&searchField=name&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void searchInsurerTest3() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClmInsdFirstNm("DJ");
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        viewInsurerResponse.setClaimsList(List.of(claimDTO));
        when(cicSearchService.searchInsurer("namee","name",1,2)).thenReturn(viewInsurerResponse);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=namee&searchField=name&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void searchInsurerTest4() throws Exception {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClmInsdFirstNm("DJ");
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        viewInsurerResponse.setClaimsList(List.of(claimDTO));
        when(cicSearchService.searchInsurer("name","name",1,2)).thenReturn(viewInsurerResponse);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=name&searchField=&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }


    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: searchInput null
     */
    @Test
    void searchInsurerTest_searchInput_null() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchField=abc&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: searchInput empty
     */
    @Test
    void searchInsurerTest_searchInput_empty() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=&searchField=abc&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: searchField null
     */
    @Test
    void searchInsurerTest_searchField_null() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: searchField empty
     */
    @Test
    void searchInsurerTest_searchField_empty() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: pageNumber null
     */
    @Test
    void searchInsurerTest_pageNumber_null() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: searchInput empty
     */
    @Test
    void searchInsurerTest_pageNumber_zero() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageNumber=0&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: pageSize null
     */
    @Test
    void searchInsurerTest_pageSize_null() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageNumber=1")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isInternalServerError());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: pageSize empty
     */
    @Test
    void searchInsurerTest_pageSize_zero() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageNumber=1&pageSize=0")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: special char check
     */
    @Test
    void searchInsurerTest_pageSize_special_char() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=ab@c&searchField=name&pageNumber=1&pageSize=5")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    void searchInsurerTest_pageSize_special_char2() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=&searchField=name&pageNumber=1&pageSize=5")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * searchInsurerTest method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for controller searchInsurer API: nocontent
     */
    @Test
    void searchInsurerTest_No_content() throws Exception {
        ViewInsurerResponse viewInsurerResponse = new ViewInsurerResponse();
        viewInsurerResponse.setClaimsList(List.of());
        when(cicSearchService.searchInsurer("abc","abc",1,2)).thenReturn(viewInsurerResponse);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/search?searchInput=abc&searchField=abc&pageNumber=1&pageSize=2")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isNoContent());
    }
}
