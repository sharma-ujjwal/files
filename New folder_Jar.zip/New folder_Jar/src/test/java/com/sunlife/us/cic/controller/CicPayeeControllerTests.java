package com.sunlife.us.cic.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.common.util.CustomErrors;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.InstructionsDTO;
import com.sunlife.us.cic.model.PayeeDTO;
import com.sunlife.us.cic.model.ViewPayeeResponse;
import com.sunlife.us.cic.service.CicClaimService;
import com.sunlife.us.cic.service.CicPayeeService;
import org.json.JSONObject;
import com.sunlife.us.cic.service.impl.JwtService;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigDecimal;
import java.util.Date;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@WebMvcTest(controllers = CicPayeeController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class CicPayeeControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CicPayeeService cicPayeeService;

    @Autowired
    private ObjectMapper objectMapper;


    @MockBean
    private JwtService jwtService;

    @MockBean
    private UserDetailsService userDetailsService;

    /*Delete Payee Test Cases*/

    /**
     * deletePayee_test_isok method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller deletePayee API: postive case
     */
    @Test
    void deletePayee_test_isok() throws Exception {
        when(cicPayeeService.deletePayee(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/payee/123")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * deletePayee_test_isBadRequest_0 method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller deletePayee API: parameter is 0
     */
    @Test
    void deletePayee_test_isBadRequest_0() throws Exception {
        when(cicPayeeService.deletePayee(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/payee/0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deletePayee_test_isBadRequest_null method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller deletePayee API: parameter is null
     */
    @Test
    void deletePayee_test_isBadRequest_null() throws Exception {
        when(cicPayeeService.deletePayee(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/payee/null")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deletePayee_test_isBadRequest_empty method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller deletePayee API: parameter is empty
     */
    @Test
    void deletePayee_test_isBadRequest_empty() throws Exception {
        when(cicPayeeService.deletePayee(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v1/interestcalculator/payee/8*")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * deletePayee_test_isNotFound method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for controller deletePayee API: API not found
     */
    @Test
    void deletePayee_test_isNotFound() throws Exception {
        when(cicPayeeService.deletePayee(123)).thenReturn(new GenericResponseDTO());
        ResultActions response = mockMvc.perform(delete("/v2/interestcalculator/payee/0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /*Add Payee Test Cases*/

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_test_isOk method.
     * Description: Unit test case for controller addPayee API: postive case
     */

    @Test
    void addPayee_test_isOk() throws Exception {
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg", BigDecimal.valueOf(0.00));
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/payee")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payeeDTO)));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_test_isBadRequest method.
     * Description: Unit test case for controller addPayee API: payeeDTO is null
     */
    @Test
    void addPayee_test_isBadRequest() throws Exception {
        PayeeDTO payeeDTO = null;
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        ResultActions response = mockMvc.perform(post("/v1/interestcalculator/payee")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payeeDTO)));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_test_isNotFound method.
     * Description: Unit test case for controller addPayee API: API not found
     */
    @Test
    void addPayee_test_isNotFound() throws Exception {
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg", BigDecimal.valueOf(0.00));
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        when(cicPayeeService.addPayee(payeeDTO)).thenReturn(new PayeeDTO());
        ResultActions response = mockMvc.perform(post("/v2/interestcalculator/payee")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(payeeDTO)));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /*View Payee Test Cases*/

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_test_isOk method.
     * Description: Unit test case for controller viewPayee API: postive case
     */
    @Test
    void viewPayee_WhenClaimIdIsValid() throws Exception {
        int claimId = 123;
        ViewPayeeResponse responseDTO = new ViewPayeeResponse();
        when(cicPayeeService.viewPayee(claimId)).thenReturn(responseDTO);

        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.get("/v1/interestcalculator/payee?claimId=123")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenClaimIdIsZero method.
     * Description: Unit test case for controller viewPayee API: claimId is 0
     */
    @Test
    void viewPayee_WhenClaimIdIsZero() throws Exception {

        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.get("/v1/interestcalculator/payee?claimId=0")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenClaimIdIsNull method.
     * Description: Unit test case for controller viewPayee API: claimId is null
     */
    @Test
    void viewPayee_WhenClaimIdIsNull() throws Exception {

        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.get("/v1/interestcalculator/payee?claimId=null")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenClaimIdIsEmpty method.
     * Description: Unit test case for controller viewPayee API: claimId is empty
     */
    @Test
    void viewPayee_WhenClaimIdIsEmpty() throws Exception {

        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.get("/v1/interestcalculator/payee?claimId=")
                .contentType(MediaType.APPLICATION_JSON));
        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenAPIIsNotFound method.
     * Description: Unit test case for controller viewPayee API: API not found
     */
    @Test
    void viewPayee_WhenAPIIsNotFound() throws Exception {
        int claimId = 123;
        ViewPayeeResponse responseDTO = new ViewPayeeResponse();
        when(cicPayeeService.viewPayee(claimId)).thenReturn(responseDTO);

        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.get("/v2/interestcalculator/payee?claimId=123")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isNotFound());
    }

    /**
     * editPayee_test_isok method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for controller editPayee API: postive case
     */
    @Test
    void editPayee_test_isok() throws Exception {
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg", BigDecimal.valueOf(0.00));
        when(cicPayeeService.editPayee(payeeDTO)).thenReturn(new PayeeDTO());
        ResultActions response = mockMvc.perform(patch("/v1/interestcalculator/payee")
                        .content(objectMapper.writeValueAsString(payeeDTO))
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * editPayee_test_isBadRequest method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for controller editPayee API: negative case
     */
    @Test
    void editPayee_test_isBadRequest() throws Exception {
        String json = "{ \"payeFullNm\": \"PAUL NEWELY\", \"payeCareOfTxt\": \".\", \"payeAddrLn1Txt\": \".\", \"payeAddrLn2Txt\": \".\", \"payeCityNmTxt\": \".\", \"payeStCd\": \"CA\", \"payeZipCd\": \"00000\", \"payeZip4Cd\": \"00\", \"calcStCd\": \"CA\", \"payePmtDt\": \"2016-06-27\", \"payeSsnTinNum\": \"190404590\", \"payeSsnTinTypCd\": \"P\", \"payeDfltOvrdInd\": false, \"payeClmIntAmt\": \"41.89\", \"payeClmPdAmt\": \"2041.89\", \"payeDthbPmtAmt\": \"2000.00\", \"payeClmIntRt\": \"2.75000\", \"payeWthldRt\": \"0.00000\", \"payeWthldAmt\": \"0.00\", \"paye1099IntInd\": false, \"payeIntDaysPdNum\":10 }";
        ObjectMapper mapper = new ObjectMapper();
        PayeeDTO payeeDTO = mapper.readValue(json, PayeeDTO.class);
        when(cicPayeeService.editPayee(payeeDTO)).thenReturn(new PayeeDTO());
        ResultActions response = mockMvc.perform(patch("/v1/interestcalculator/payee")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    /**
     * editPayee_test_isNotFound method.
     * @throws Exception
     */
    @Test
    void getInstructionByStcd_WhenParametersAreValid() throws Exception {
        // Arrange
        int clmId = 123;
        String payeStCd = "MD";
        String payeResStCd = "MD";
        String calcStCd = "MD";
        String issueStCd = "MD";
        BigDecimal bdData = BigDecimal.valueOf(5);
        Date payePmtDt = new Date();
        InstructionsDTO instructionsDTO = new InstructionsDTO();
        when(cicPayeeService.getInstructionsFromStCd(clmId, payeStCd, payeResStCd, calcStCd, issueStCd, payePmtDt,bdData)).thenReturn(instructionsDTO);
        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/payee/123?payeStCd=MD&payeResStCd=MD&calcStCd=MD&issueStCd=MD&payePmtDt=2021-06-27&paymentAmount=5")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * getInstructionByStcd_WhenClmIdIsZero method.
     * @throws Exception
     */
    @Test
    void getInstructionByStcd_WhenClmIdIsZero() throws Exception {

        int clmId = 0;
        String payeStCd = "MD";
        String payeResStCd = "MD";
        String calcStCd = "MD";
        String issueStCd = "MD";
        Date payePmtDt = new Date();
        BigDecimal bdData = BigDecimal.valueOf(5);
        InstructionsDTO instructionsDTO = new InstructionsDTO();
        when(cicPayeeService.getInstructionsFromStCd(clmId, payeStCd, payeResStCd, calcStCd, issueStCd, payePmtDt, bdData)).thenReturn(instructionsDTO);

        ResultActions response = mockMvc.perform(get("/v1/interestcalculator/payee/0?payeStCd=MD&payeResStCd=MD&calcStCd=MD&issueStCd=MD&payePmtDt=2021-06-27")
                .contentType(MediaType.APPLICATION_JSON));

        response.andExpect(MockMvcResultMatchers.status().isBadRequest());
    }
}
