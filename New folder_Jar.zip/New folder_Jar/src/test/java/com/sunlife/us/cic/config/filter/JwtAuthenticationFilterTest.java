package com.sunlife.us.cic.config.filter;

import com.sunlife.us.cic.config.filter.JwtAuthenticationFilter;
import com.sunlife.us.cic.service.impl.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.servlet.HandlerExceptionResolver;

import static com.sunlife.us.cic.common.SecurityConstants.*;
import static org.mockito.Mockito.*;


public class JwtAuthenticationFilterTest {

    @Mock
    private JwtService jwtService;

    @Mock
    private UserDetailsService userDetailsService;

    @Mock
    private HandlerExceptionResolver handlerExceptionResolver;

    @InjectMocks
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Basic filter working test with header set
     * @throws Exception
     */
    @Test
    public void testDoFilterInternal_test_filter() throws Exception {
        when(request.getHeader(AUTH_HEADER)).thenReturn(BEARER_TOKEN + " jwtToken");

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        verify(filterChain, times(1)).doFilter(request, response);
    }

    /**
     * Basic filter working test with no Bearer token
     * @throws Exception
     */
    @Test
    public void testDoFilterInternal_test_withnull_authHeader() throws Exception {
        when(request.getHeader(AUTH_HEADER)).thenReturn(null);

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        verify(filterChain, times(1)).doFilter(request, response);
    }

    /**
     * Basic filter workiong test with invalid bearer token
     * @throws Exception
     */
    @Test
    public void testDoFilterInternal_test_with_invalid_bearertoken() throws Exception {
        when(request.getHeader(AUTH_HEADER)).thenReturn("Invalid Bearer Token");

        jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

        verify(filterChain, times(1)).doFilter(request, response);
    }

}