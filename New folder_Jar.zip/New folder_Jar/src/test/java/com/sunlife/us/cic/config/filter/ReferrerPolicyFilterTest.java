package com.sunlife.us.cic.config.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.IOException;

import static org.mockito.Mockito.verify;

/**
 * ReferrerPolicyFilterTest Class.
 */
public class ReferrerPolicyFilterTest {

    @Mock
    ServletRequest request;

    @Mock
    ServletResponse response;

    @Mock
    FilterChain chain;

    @InjectMocks
    ReferrerPolicyFilter referrerPolicyFilter;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    public void testDoFilter_isOk() throws IOException, ServletException {
        HttpServletResponse responseSpy = Mockito.spy(HttpServletResponse.class);
        referrerPolicyFilter.doFilter(request, responseSpy, chain);

        verify(responseSpy).setHeader("Referrer-Policy", "no-referrer");
        verify(chain).doFilter(request, responseSpy);
    }
}