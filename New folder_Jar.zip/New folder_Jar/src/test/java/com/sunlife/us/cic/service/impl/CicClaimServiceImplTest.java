package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.*;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.handler.exceptions.GlobalException;
import com.sunlife.us.cic.repo.*;
import org.apache.commons.beanutils.BeanUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 *
 * CicClaimServiceImplTest Class.
 * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
 * Unit test class for CicClaimServiceImpl class
 */
@ExtendWith(MockitoExtension.class)
class CicClaimServiceImplTest {

    @Mock
    private CicClaimRepo cicClaimRepo;

    @Mock
    private CicPayeeRepo cicPayeeRepo;

    @Mock
    private CicStateRepo cicStateRepo;

    @Mock
    private CicPayorRepo cicPayorRepo;

    @Mock
    private CicAdminRepo cicAdminRepo;

    @Mock
    private CacheUpdater cacheUpdater;
    @Mock
    private Authentication authentication;
    @Mock
    private User principal;



    @InjectMocks
    private CicClaimServiceImpl cicClaimService;
    Admin adminData;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        adminData = new Admin();
        adminData.setAdmnSystCd(20);
        adminData.setAdmnSystDsc("Coli");
        adminData.setAdmnSystIdMaxLgthNum("10");
        adminData.setAdmnSystIdMinLgthNum("6");
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    /* deleteInsurer method test cases */

    /**
     * deleteInsurer_test is unit test case from serviceImple deleteInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for service deleteInsurer API: positive case
     * @return void
     */
    @Test
    void deleteInsurer_test() {
        int claimId = 123;
        Claim claim = new Claim();
        claim.setClmInsdFirstNm("John");
        claim.setClmInsdLastNm("Doe RG");
        claim.setClmNum("U123");

        new  Thread(() -> cacheUpdater.deleteCache(claim)).start();
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.ofNullable(claim));
        when(cicPayeeRepo.findByClmId(claimId)).thenReturn(List.of());
        doNothing().when(cicClaimRepo).deleteById(claimId);
        cicClaimService.deleteInsurer(claimId);
        assertAll(() -> cicClaimService.deleteInsurer(claimId));
    }

    /**
     * deleteInsurer_test_when_no_data method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for service deleteInsurer API: data from DB is null
     */
    @Test
    void deleteInsurer_test_when_null() {
        int claimId = 123;
        when(cicClaimRepo.findById(claimId)).thenReturn(null);
        assertThrows(GlobalException.class, ()->cicClaimService.deleteInsurer(claimId));
    }

    /**
     * deleteInsurer_test_when_no_data method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for service deleteInsurer API: payee data is present
     */
    @Test
    void deleteInsurer_test_when_payee_presnt() {
        int claimId = 123;
        Claim claim = new Claim();
        claim.setClmInsdFirstNm("John");
        claim.setClmInsdLastNm("Doe RG");
        claim.setClmNum("U123");
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.ofNullable(claim));
        when(cicPayeeRepo.findByClmId(claimId)).thenReturn(List.of(new Payee()));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.deleteInsurer(claimId));
    }

    /**
     * deleteInsurer_test_when_no_data method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Unit test case for service deleteInsurer API: no data from DB
     */
    @Test
    void deleteInsurer_test_when_no_data() {
        int claimId = 123;
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class, ()->cicClaimService.deleteInsurer(claimId));
    }

    /* viewInsurer method test cases */

    /**
     * viewInsurer_test is unit test case from serviceImple viewInsurer API
     * * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for service viewInsurer API: positive case
     * @return void
     */
    @Test
    void viewInsurer_test() {
        Claim claim = new Claim();
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setDeleteActive(true);
        claim.setClmNum("U123");
        claim.setPayee(new ArrayList<>());
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(new Admin());
        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(1, 5, Sort.by("clmInsdDthDt").descending()), 0);
        int pageNumber = 1;
        int pageSize = 5;
        when(cicClaimRepo.findAll(Mockito.any(Pageable.class))).thenReturn(claimList);
        ViewInsurerResponse viewInsurerResponse = cicClaimService.viewInsurer(pageNumber, pageSize);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * viewInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: DB data is empty
     */
    @Test
    void viewInsurer_dataEmpty() {
        Claim claim = new Claim();
        claim.setClmNum("U123");
        claim.setPayee(new ArrayList<>());
        claim.getPayee().size();
        int pageNumber = 1;
        int pageSize = 5;
        when(cicClaimRepo.findAll(mock(Pageable.class))).thenReturn(Page.empty());
        when(mock(Page.class).getTotalPages()).thenReturn(0);
        assertThrows(GlobalException.class, ()->cicClaimService.viewInsurer(pageNumber, pageSize));
    }

    /**
     * viewInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller viewInsurer API: Data not found
     */
    @Test
    void viewInsurer_dataisNotFound() {
        int pageNumber = 2;
        int pageSize = 5;
        Page<Claim> claimList = new PageImpl<>(List.of(), PageRequest.of(2, 5, Sort.by("clm_insd_dth_dt").descending()), 0);
        when(cicClaimRepo.findAll(Mockito.any(Pageable.class))).thenReturn(claimList);
        assertThrows(DataNotFoundException.class, ()->cicClaimService.viewInsurer(pageNumber, pageSize));
    }

    /**
     * viewInsurer_test is unit test case from serviceImpl viewInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service viewInsurer API: Ternary positive case
     * @return void
     */
    @Test
    void viewInsurer_ternary_switch_test() {
        int pageNumber = 1;
        int pageSize = 5;
        Payee payee = new Payee();
        payee.setClmId(123);
        Claim claim =Mockito.spy(Claim.class);
        claim.setClmInsdFirstNm("John");
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setPayee(List.of(payee));
        claim.getPayee();
        claim.setAdmin(new Admin());
        Mockito.verify(claim, Mockito.times(1)).getPayee();

        Page<Claim> claimList = new PageImpl<>(List.of(claim), PageRequest.of(2, 5, Sort.by(CicConstants.CLAIM_INSD_DTH_DT).descending()), 0);
        when(cicClaimRepo.findAll(Mockito.any(Pageable.class))).thenReturn(claimList);
        ViewInsurerResponse viewInsurerResponse = cicClaimService.viewInsurer(pageNumber, pageSize);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: Positive case
     */

    @Test
    void getInsurer_test_ok() throws InvocationTargetException, IllegalAccessException {
        Payee payee1 = new Payee();
        Payee payee2 = new Payee();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg", BigDecimal.valueOf(10.00));
        BeanUtils.copyProperties(payee1, payeeDTO);
        BeanUtils.copyProperties(payee2, payeeDTO);
        List<Payee> payeeDTOList = Arrays.asList(payee1, payee2);
        int claimId = 819;
        Claim claim = new Claim();
        claim.setClmInsdFirstNm("John");
        claim.setClmInsdLastNm("Doe RG");
        claim.setClmNum("U123");
        claim.setClmForResDthInd("Y");
        claim.getClmForResDthInd();
        claim.setClmCompactClcnInd("T");
        claim.getClmCompactClcnInd();
        claim.setAdmin(new Admin());
        claim.setPayor(new Payor());
        claim.setPayee(payeeDTOList);
        List<Claim> claimList = new ArrayList<>();
        claimList.add(claim);
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.ofNullable(claim));
        when(cicClaimRepo.findAllById(Collections.singleton(claimId))).thenReturn(claimList);
        ViewInsurerResponse viewInsurerResponse = cicClaimService.getInsurer(claimId);
        org.assertj.core.api.Assertions.assertThat(viewInsurerResponse).isNotNull();
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: Data not found
     */
    @Test
    void getInsurer_test_when_no_data() {
        int claimId = 0;
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class, ()->cicClaimService.getInsurer(claimId));
    }

    /**
     * getInsurer method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Unit test case for controller getInsurer API: DB is null
     */
    @Test
    void getInsurer_test_when_dataisNull() {
        int claimId = 819;
        when(cicClaimRepo.findById(claimId)).thenReturn(null);
        assertThrows(GlobalException.class, ()->cicClaimService.getInsurer(claimId));
    }

    /**
     * getClaimFormData_test is unit test case from serviceImpl getClaimFormData API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description Unit test case for service getClaimFormData API: positive case
     * @return void
     */
    @Test
    void getClaimFormData_test() {
        int claimId = 819;
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();

        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");


        Claim claim = new Claim();
        claim.setInsdDthResStCd("NY");
        claim.setIssStCd("NY");
        claim.setClmForResDthInd("Y");
        claim.setClmCompactClcnInd("T");
        claim.setAdmin(admin);
        when(cicAdminRepo.findAllByOrderByAdmnSystDscAsc()).thenReturn(List.of(admin));
        when(cicPayorRepo.findAllByOrderByPycoTypDscAsc()).thenReturn(List.of(new Payor()));
        when(cicStateRepo.findAll()).thenReturn(List.of(state));
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.of(claim));

        ClaimFormDataDTO claimFormDataDTO = cicClaimService.getClaimFormData(claimId);
        org.assertj.core.api.Assertions.assertThat(claimFormDataDTO).isNotNull();
    }

    @Test
    void getClaimFormData_test_Data_not_Found() {
        int claimId = 819;
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        Admin admin = new Admin();
        admin.setAdmnSystDsc("dj");
        Claim claim = new Claim();
        claim.setInsdDthResStCd("NY");
        claim.setIssStCd("NY");
        claim.setClmForResDthInd("Y");
        claim.setClmCompactClcnInd("T");
        claim.setAdmin(admin);
        when(cicAdminRepo.findAllByOrderByAdmnSystDscAsc()).thenReturn(List.of(admin));
        when(cicPayorRepo.findAllByOrderByPycoTypDscAsc()).thenReturn(List.of(new Payor()));
        when(cicStateRepo.findAll()).thenReturn(List.of(state));
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.empty());

        assertThrows(DataNotFoundException.class, ()->cicClaimService.getClaimFormData(claimId));
    }

    /**
     * getClaimFormData_test_when_claimisNull method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getClaimFormData API: claim is null
     */
    @Test
    void getClaimFormData_testClaimisNull() {

        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();

        when(cicAdminRepo.findAllByOrderByAdmnSystDscAsc()).thenReturn(List.of(new Admin()));
        when(cicPayorRepo.findAllByOrderByPycoTypDscAsc()).thenReturn(List.of(new Payor()));
        when(cicStateRepo.findAll()).thenReturn(List.of(state));

        ClaimFormDataDTO claimFormDataDTO = cicClaimService.getClaimFormData(null);
        org.assertj.core.api.Assertions.assertThat(claimFormDataDTO).isNotNull();
    }

    /**
     * getClaimFormData_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service getClaimFormData API: DB data is empty
     */
    @Test
    void getClaimFormData_test_when_dataEmpty() {
        int claimId = 819;
        when(cicAdminRepo.findAllByOrderByAdmnSystDscAsc()).thenReturn(null);
        assertThrows(GlobalException.class, ()->cicClaimService.getClaimFormData(claimId));
    }

    /**
     * addInsurer_test is unit test case from serviceImpl addInsurer API
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: positive case
     * @return void
     */
    @Test
    void addInsurer_test() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("T");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 24, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    @Test
    void addInsurer_test2() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("T");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        adminData.setAdmnSystDsc("Group");
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    @Test
    void addInsurer_test3() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("F");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 24, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    @Test
    void addInsurer_test4() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("T");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, false, true, 24, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: DB data is empty
     */
    @Test
    void addInsurer_test_when_dataEmpty() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    @Test
    void addInsurer_test_when_foreign_State_not_present() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", null, false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: insurer with policy already exist
     */
    @Test
    void addInsurer_test_when_insurer_already_exist() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    @Test
    void addInsurer_test_when_insurer_already_exist2() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of()));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: Payor DB data is empty
     */
    @Test
    void addInsurer_test_when_dataEmpty_payor() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: State DB data is empty
     */
    @Test
    void addInsurer_test_when_dataEmpty_State() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: Forign State DB data is empty
     */
    @Test
    void addInsurer_test_when_dataEmpty_FOR_State() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state)).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: negative case, when death date is greater than proof date
     */
    @Test
    void addInsurer_test_when_deathdate_greater_than_proofdate() throws InvocationTargetException, IllegalAccessException {
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(System.currentTimeMillis()-24*60*60*1000), "ssn123456", "MN", true, true, true, 20, "I1","GROUP");
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }


    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: compact filing false
     */
    @Test
    void addInsurer_test_when_compact_filing_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: admin system is not solar
     */
    @Test
    void addInsurer_test_when_ad_sys_not_solar() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }



    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: positive state compact allowed false
     */
    @Test
    void addInsurer_test_when_positive_state_compact_allowed_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.addInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: global null exception
     */
    @Test
    void addInsurer_test_when_null() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(null);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(GlobalException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * Description: Unit test case for service addInsurer API: policy present
     */
    @Test
    void addInsurer_test_when_policy_present() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of(claim)));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * addInsurer_test_when_dataEmpty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addInsurer API: state compact allowed false
     */
    @Test
    void addInsurer_test_when_state_compact_allowed_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("N");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(null);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(GlobalException.class, ()->cicClaimService.addInsurer(claimDTO, adminData));
    }

    /**
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * addInsurer WhenDeathDateIsAfterProofDat method.
     * Description: Unit test case for service addInsurer API: Death date is after proof date
     * @return void
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    @Test
    void addInsurer_test_when_death_date_is_after_proof_date() {
        ClaimDTO claimDTO = new ClaimDTO();
        claimDTO.setClmInsdDthDt(new Date(System.currentTimeMillis() + 10000));
        claimDTO.setClmProofDt(new Date());
        assertThrows(InvalidRequestException.class, () -> cicClaimService.addInsurer(claimDTO, adminData));
    }


    /**
     * editInsurer_test is unit test case from serviceImpl editInsurer API
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: positive case
     * @return void
     */
    @Test
    void editInsurer_test() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim oldClaim = new Claim();
        new  Thread(() -> cacheUpdater.updateCache(new Claim(), new Claim())).start();
        BeanUtils.copyProperties(oldClaim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(oldClaim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * Description: Unit test case for service editInsurer API: lob is group
     */
    @Test
    void editInsurer_test_group() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim oldClaim = new Claim();
        new  Thread(() -> cacheUpdater.updateCache(new Claim(), new Claim())).start();
        BeanUtils.copyProperties(oldClaim, claimDTO);
        oldClaim.setClmPolNum("test123");
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(oldClaim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of()));
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * Description: Unit test case for service editInsurer API: lob is group with null ssn
     */
    @Test
    void editInsurer_test_group_with_null_ssn() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim oldClaim = new Claim();
        new  Thread(() -> cacheUpdater.updateCache(new Claim(), new Claim())).start();
        BeanUtils.copyProperties(oldClaim, claimDTO);
        oldClaim.setClmInsdSsnNum(null);
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(oldClaim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of()));
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * Description: Unit test case for service editInsurer API: lob is group with diff ssn
     */
    @Test
    void editInsurer_test_group_with_ssn() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim oldClaim = new Claim();
        new  Thread(() -> cacheUpdater.updateCache(new Claim(), new Claim())).start();
        BeanUtils.copyProperties(oldClaim, claimDTO);
        oldClaim.setClmInsdSsnNum("123");
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(oldClaim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of()));
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    @Test
    void editInsurer_test_group_admin() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "ssn123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim oldClaim = new Claim();
        new  Thread(() -> cacheUpdater.updateCache(new Claim(), new Claim())).start();
        BeanUtils.copyProperties(oldClaim, claimDTO);
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(oldClaim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * Description: Unit test case for service editInsurer API: DB data is empty
     */
    @Test
    void shouldNotThrowExceptionWhenClaimFound() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(149966, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "999123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim oldClaim = new Claim();
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        BeanUtils.copyProperties(oldClaim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(oldClaim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertDoesNotThrow(() -> cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: DB data is empty
     */
    @Test
    void editInsurer_test_when_claim_dataEmpty() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146996, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "876123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: DB data is empty
     */
    @Test
    void editInsurer_test_when_dataEmpty() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146996, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "876123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: Payor DB data is empty
     */
    @Test
    void editInsurer_test_when_dataEmpty_payor() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146996, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "234123456", "MN", true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: State DB data is empty
     */
    @Test
    void editInsurer_test_when_dataEmpty_State() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146996, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "877123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: Forign State DB data is empty
     */
    @Test
    void editInsurer_test_when_dataEmpty_FOR_State() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state)).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    @Test
    void editInsurer_test_when_old_claim_present() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        Claim claim2 = new Claim();
        BeanUtils.copyProperties(claim2, claimDTO);
        BeanUtils.copyProperties(claim, claimDTO);
        claimDTO.setClmPolNum("UT12sd");
        claim2.setClmPolNum("UT12sd");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of(claim2)));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    @Test
    void editInsurer_test_when_old_claim_present2() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        Claim claim2 = new Claim();
        BeanUtils.copyProperties(claim2, claimDTO);
        BeanUtils.copyProperties(claim, claimDTO);
        claimDTO.setClmPolNum("UT123sd");
        claim2.setClmPolNum("UT12sd");
        adminData.setAdmnSystDsc("Group");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicClaimRepo.findByClmPolNumAndClmInsdSsnNum(claimDTO.getClmPolNum(), claimDTO.getClmInsdSsnNum())).thenReturn(Optional.of(List.of(claim2)));
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    @Test
    void editInsurer_test_when_old_claim_empty() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        Claim claim2 = new Claim();
        BeanUtils.copyProperties(claim2, claimDTO);
        BeanUtils.copyProperties(claim, claimDTO);
        claimDTO.setClmPolNum("UT12sd");
        claim2.setClmPolNum("UT12sd");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.empty());
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicClaimRepo.findByClmPolNum(claimDTO.getClmPolNum())).thenReturn(Optional.of(List.of()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state)).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: negative case, when death date is greater than proof date
     */
    @Test
    void editInsurer_test_when_deathdate_greater_than_proofdate() throws InvocationTargetException, IllegalAccessException {
        ClaimDTO claimDTO = new ClaimDTO(176889, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(System.currentTimeMillis()-24*60*60*1000), "987123456", "MN", true, true, true, 20, "I1","GROUP");
        assertThrows(InvalidRequestException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: Foreign residence false
     */
    @Test
    void editInsurer_test_when_foreign_State_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: compact filing false
     */
    @Test
    void editInsurer_test_when_compact_filing_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(null, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "876123456", "MN", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: admin system is not solar
     */
    @Test
    void editInsurer_test_when_ad_sys_not_solar() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(147889, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: positive state compact allowed false
     */
    @Test
    void editInsurer_test_when_positive_state_compact_allowed_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(187998, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(claim);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        GenericResponseDTO response = cicClaimService.editInsurer(claimDTO, adminData);
        Assertions.assertThat(response).isNotNull();
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service addInsurer API: global null exception
     */
    @Test
    void editInsurer_test_when_null() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("Y");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(146996, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(null);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(GlobalException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * editInsurer_test_when_dataEmpty method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service editInsurer API: state compact allowed false
     */
    @Test
    void editInsurer_test_when_state_compact_allowed_false() throws InvocationTargetException, IllegalAccessException {
        State state = new State();
        state.setStateCd("NY");
        state.setStCompactClcnAllowInd("N");
        state.getStCompactClcnAllowInd();
        ClaimDTO claimDTO = new ClaimDTO(178667, "UT1233G123","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "UT",new Date(),new Date(), "987123456", "MN", false, false, true, 10, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(new Admin()));
        when(cicPayorRepo.findById(Mockito.any())).thenReturn(Optional.of(new Payor()));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(cicClaimRepo.save(Mockito.any())).thenReturn(null);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(GlobalException.class, ()->cicClaimService.editInsurer(claimDTO, adminData));
    }

    /**
     * findAdminById_tes.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Description: Unit test case for service findAdminById API: positive case
     */
    @Test
    void findAdminById_test() {
        Admin admin = new Admin();
        admin.setAdmnSystCd(20);
        admin.setAdmnSystDsc("Solar");
        admin.setAdmnSystIdMaxLgthNum("10");
        admin.setAdmnSystIdMinLgthNum("5");
        when(cicAdminRepo.findById(Mockito.any())).thenReturn(Optional.of(admin));
        Optional<Admin> adminDTO = cicClaimService.findAdminById(20);
        Assertions.assertThat(adminDTO).isNotNull();
    }

}
