package com.sunlife.us.cic.controller;

import com.sunlife.us.cic.model.AuthInfoDTO;
import com.sunlife.us.cic.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class AuthInfoControllerTest {

    @InjectMocks
    private AuthInfoController authInfoController;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private Authentication authentication;

    @Mock
    private User user;

    @BeforeEach
    public void setUp() {
        securityContext = Mockito.mock(SecurityContext.class);
        authentication = Mockito.mock(Authentication.class);
        user = Mockito.mock(User.class);
        SecurityContextHolder.setContext(securityContext);
        authInfoController = new AuthInfoController();
    }

    /**
     * Description: This test verifies the required logged in user details are sent back as response
     */
    @Test
    public void testGetLoggedInUserInfo() {
        try (MockedStatic<SecurityContextHolder> mocked = Mockito.mockStatic(SecurityContextHolder.class)) {
            mocked.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(user);
            when(user.getRole()).thenReturn("role");
            when(user.getEmail()).thenReturn("email");
            when(user.getUsername()).thenReturn("username");

            ResponseEntity<AuthInfoDTO> response = authInfoController.getLoggedInUserInfo();
            AuthInfoDTO authInfoDTO = response.getBody();

            assertEquals("role", authInfoDTO.getRole());
            assertEquals("email", authInfoDTO.getEmail());
            assertEquals("username", authInfoDTO.getAcf2Id());
        }
    }
}