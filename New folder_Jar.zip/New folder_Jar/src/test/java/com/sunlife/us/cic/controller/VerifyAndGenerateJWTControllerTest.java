package com.sunlife.us.cic.controller;
import com.sunlife.us.cic.handler.exceptions.AuthorizationServiceException;
import com.sunlife.us.cic.model.LoginResponse;
import com.sunlife.us.cic.model.User;
import com.sunlife.us.cic.service.impl.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("local")
@AutoConfigureMockMvc
public class VerifyAndGenerateJWTControllerTest {

    /**
     * Standard flow where the redirection to UI will happen post successful Auth
     * @throws Exception
     */
    @Test
    public void testGetCredentials_is_ok() throws Exception {
        // Arrange
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        Saml2AuthenticatedPrincipal principal = Mockito.mock(Saml2AuthenticatedPrincipal.class);
        JwtService jwtService = Mockito.mock(JwtService.class);
        when(jwtService.getTheLoggedInUserRole(any())).thenReturn("STD_USER");
        VerifyAndGenerateJWTController verifyAndGenerateJWTController = new VerifyAndGenerateJWTController(jwtService);
        verifyAndGenerateJWTController.getCredentials(request, principal, response);
        assertEquals(HttpStatus.OK.value(), 200);

    }

    /** Negative Scenario, where the SAML principal is null, this is expected to throw IllegalArgument Exception
     *
     * @throws Exception
     */
    @Test
    public void testGetCredentials_when_principal_is_null() throws Exception {
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        Saml2AuthenticatedPrincipal principal = null;
        JwtService jwtService = Mockito.mock(JwtService.class);
        VerifyAndGenerateJWTController verifyAndGenerateJWTController = new VerifyAndGenerateJWTController(jwtService);
        assertThrows(IllegalArgumentException.class, () -> {
            verifyAndGenerateJWTController.getCredentials(request, principal, response);
        });
    }

    /**
     * Negative Scenario when an user tries to login to the application but doesn't have privileges set.
     * This will throw AuthorizationServiceException
     * @throws Exception
     */
    @Test
    public void testGetCredentials_when_role_is_null_redirects_to_error_page() throws Exception {
        // Arrange
        HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        HttpSession session = Mockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        Saml2AuthenticatedPrincipal principal = Mockito.mock(Saml2AuthenticatedPrincipal.class);
        JwtService jwtService = Mockito.mock(JwtService.class);
        when(jwtService.getTheLoggedInUserRole(any())).thenReturn(null);
        when(jwtService.removeFirstAndLastChar(any())).thenReturn("attribute");
        VerifyAndGenerateJWTController verifyAndGenerateJWTController = new VerifyAndGenerateJWTController(jwtService);
        verifyAndGenerateJWTController.getCredentials(request, principal, response);
        verify(response).sendRedirect(contains("UN_AUTHORIZED"));
    }

}