package com.sunlife.us.cic.service.impl;

import com.sunlife.us.cic.common.InterestCalculationConstants;
import com.sunlife.us.cic.common.util.InterestCalculationUtil;
import com.sunlife.us.cic.entity.*;
import com.sunlife.us.cic.handler.cache.CacheUpdater;
import com.sunlife.us.cic.handler.exceptions.*;
import com.sunlife.us.cic.model.*;
import com.sunlife.us.cic.common.CicConstants;
import com.sunlife.us.cic.entity.Claim;
import com.sunlife.us.cic.entity.Payee;
import com.sunlife.us.cic.entity.State;
import com.sunlife.us.cic.handler.exceptions.DataNotFoundException;
import com.sunlife.us.cic.handler.exceptions.GlobalException;
import com.sunlife.us.cic.handler.exceptions.InvalidRequestException;
import com.sunlife.us.cic.repo.*;
import com.sunlife.us.cic.model.GenericResponseDTO;
import com.sunlife.us.cic.model.PayeeDTO;
import com.sunlife.us.cic.model.User;
import com.sunlife.us.cic.model.ViewPayeeResponse;
import com.sunlife.us.cic.repo.CicClaimRepo;
import com.sunlife.us.cic.repo.CicPayeeRepo;
import com.sunlife.us.cic.repo.CicStateRepo;
import org.apache.commons.beanutils.BeanUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;


import com.hazelcast.client.HazelcastClient;
import com.hazelcast.core.DistributedObject;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

@ExtendWith(MockitoExtension.class)
class CicPayeeServiceImplTests {

    @Mock
    private CicPayeeRepo cicPayeeRepo;
    @Mock
    private CicStateRepo cicStateRepo;
    @Mock
    private CicClaimRepo cicClaimRepo;
    @Mock
    private Authentication authentication;
    @Mock
    private User principal;

    @Mock
    private CicStateRuleRepo cicStateRuleRepo;

    @Mock
    private CicStateRuleTierRepo cicStateRuleTierRepo;

    @Mock
    private CicCurrentRateRepo cicCurrentRateRepo;

    @Mock
    private CicAdminRepo cicAdminRepo;

    @Mock
    private InterestCalculationUtil interestCalculationUtil;

    @InjectMocks
    private CicPayeeServiceImpl cicPayeeService;

    CurrentRate currentRate;

    Admin adminData;

    @Mock
    private CacheUpdater cacheUpdater;

    @BeforeEach
    void setUp() throws InvocationTargetException, IllegalAccessException {
        currentRate = new CurrentRate();
        currentRate.setCurrIntRt(BigDecimal.valueOf(10.0));
        currentRate.setCurrRtEffDt("01/01/2021");
        currentRate.setCurrRtEndDt("01/01/2022");

        adminData = new Admin();
        adminData.setAdmnSystCd(20);
        adminData.setAdmnSystDsc("Coli");
        adminData.setAdmnSystIdMaxLgthNum("10");
        adminData.setAdmnSystIdMinLgthNum("6");

        Map<String, String> responseCodes = Map.of(
                "Issue State", "10015",
                "Insurer Residence State", "10016",
                "Payee State", "10017"
        );

    }
    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }


    /* deletePayee method test cases */

    /**
     * deletePayee_test is unit test case from serviceImple deletePayee API
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service deletePayee API: postive case
     * @return void
     */
    @Test
    void deletePayee_test() throws InvocationTargetException, IllegalAccessException {
        int payeId = 123;
        Payee payee = new Payee();
        payee.setPayeFullNm("John");
        payee.setPayeCareOfTxt("U123");
        payee.setClmId(146895);

        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);

        when(cicPayeeRepo.findById(payeId)).thenReturn(Optional.ofNullable(payee));
        when(cicClaimRepo.findById(payee.getClmId())).thenReturn(Optional.of(claim));
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        doNothing().when(cicPayeeRepo).deleteById(payeId);
        cicPayeeService.deletePayee(payeId);
        assertAll(() -> cicPayeeService.deletePayee(payeId));
    }

    @Test
    void deletePayee_test_when_sum_null() throws InvocationTargetException, IllegalAccessException {
        int payeId = 123;
        Payee payee = new Payee();
        payee.setPayeFullNm("John");
        payee.setPayeCareOfTxt("U123");
        payee.setClmId(146895);

        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);

        when(cicPayeeRepo.findById(payeId)).thenReturn(Optional.ofNullable(payee));
        when(cicClaimRepo.findById(payee.getClmId())).thenReturn(Optional.of(claim));
        updateClaimDataMapWhenNull(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        doNothing().when(cicPayeeRepo).deleteById(payeId);
        cicPayeeService.deletePayee(payeId);
        assertAll(() -> cicPayeeService.deletePayee(payeId));
    }

    @Test
    void deletePayee_ShouldDeletePayeeAndUpdateClaimData_WhenPayeeExists() {
        int payeId = 1;
        Payee payee = new Payee();
        payee.setClmId(2);
        Claim claim = new Claim();

        when(cicPayeeRepo.findById(payeId)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(payee.getClmId())).thenReturn(Optional.of(claim));
        updateClaimDataMap(Mockito.any());
        cicPayeeService.deletePayee(payeId);

        verify(cicPayeeRepo, times(1)).deleteById(payeId);
    }

    @Test
    void deletePayee_ShouldThrowDataNotFoundException_WhenPayeeDoesNotExist() {
        int payeId = 1;

        when(cicPayeeRepo.findById(payeId)).thenReturn(Optional.empty());

        assertThrows(DataNotFoundException.class, () -> cicPayeeService.deletePayee(payeId));
    }


    /**
     * deletePayee_test_when_null method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service deletePayee API: data from DB is null
     */
    @Test
    void deletePayee_test_when_null() {
        int payeId = 123;
        when(cicPayeeRepo.findById(payeId)).thenReturn(null);
        assertThrows(GlobalException.class, ()->cicPayeeService.deletePayee(payeId));
    }

    /**
     * deletePayee_test_when_no_data method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service deletePayee API: no data from DB
     */
    @Test
    void deletePayee_test_when_no_data() {
        int payeId = 123;
        when(cicPayeeRepo.findById(payeId)).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class, ()->cicPayeeService.deletePayee(payeId));
    }

    /* addPayee method test cases */

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_test is unit test case from serviceImple addPayee API
     * Description: Unit test case for service addPayee API: postive case
     */
    @Test
    void addPayee_test() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }

    @Test
    void addPayee_test_noInterestFlag_true() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("NONE");
        stateRule.setReqdIdtypCd("NONE");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        List<Errors> errorList = new ArrayList<>();
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }
    @Test
    void addPayee_test_noInterestFlag_false() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("None");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }


    @Test
    void addPayee_test_without_currt_int() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }
    @Test
    void addPayee_test_without_current_int_data() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }

    @Test
    void addPayee_test2() throws Exception {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(true); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        String  lob = "I";
        state.setStateCd("NY");
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.addPayee(payeeDTO);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getMessage()).contains("Payee added successfully");
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_WhenStateNotFound method.
     * Description: Unit test case for service addPayee API: State not found
     */
    @Test
    void addPayee_WhenStateNotFound() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        String lob = "I";
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.empty());

        assertThrows(InvalidRequestException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Inv_req_data() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.empty());
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(InvalidRequestException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_CompactDate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "YY",new Date(),new Date(), "987123456", "YY", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        String lob = "I";
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"YY","TEST","X","X","X","X","YY","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.empty());
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenThrow(new CompactDateException());
        assertThrows(CompactDateException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_StateRule_data_not_present() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "YY",new Date(),new Date(), "987123456", "YY", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        String lob = "I";
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"YY","TEST","X","X","X","X","YY","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.empty());
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Inv_req() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.of(new Payee()));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        assertThrows(InvalidRequestException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Global() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_WhenSaveFails method.
     * Description: Unit test case for service addPayee API: DB data is empty
     */
    @Test
    void addPayee_WhenDataEmpty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenThrow(new RuntimeException("Database error"));
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(state));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * addPayee_When_Current_Rate_empty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addPayee API: Current Rate is empty
     */
    @Test
    void addPayee_When_Current_Rate_empty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(01-01-2021), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());

        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Current_Rate_empty2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());

        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Current_Rate_empty3() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),true,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());

        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * addPayee_When_compact_Rate_empty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addPayee API: compact Rate is negative
     */
    @Test
    void addPayee_When_Current_Rate_negative() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        currentRate.setCurrIntRt(BigDecimal.valueOf(-10.0));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_Current_Rate_negative2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),true,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        currentRate.setCurrIntRt(BigDecimal.valueOf(-10.0));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * addPayee_When_compact_Rate_empty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addPayee API: compact Rate is empty
     */
    @Test
    void addPayee_When_compact_Rate_empty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.setClmCompactClcnInd("T");
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
//        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(CompactRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * addPayee_When_loan_rate_empty method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service addPayee API: loan rate is empty
     */
    @Test
    void addPayee_When_loan_rate_empty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(LoanRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty10() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), true,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty9() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), true,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty8() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty5() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), true,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty6() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), true,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty7() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(LoanRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empty2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), true,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empt11() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_loan_rate_empt12() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURLN");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(LoanRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * addPayee_When_interst_rate_empty method.
     * Description: Unit test case for service addPayee API: interest rate is empty
     */
    @Test
    void addPayee_When_interst_rate_empty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("WV");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);

        assertThrows(InterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    @Test
    void addPayee_When_interst_rate_empty_Map() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(InterestRateNotProvidedException.class, ()->cicPayeeService.addPayee(payeeDTO));
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_WhenPayeDfltOvrdIndIsTrue method.
     * Description: Unit test case for service addPayee API: payeDfltOvrdInd is true
     */
    @Test
    void addPayee_WhenPayeDfltOvrdIndIsTrue() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(new State()));
        when(authentication.getPrincipal()).thenReturn(principal);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.addPayee(payeeDTO);
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * addPayee_WhenPaye1099IntIndIsFalse method.
     * Description: Unit test case for service addPayee API: paye1099IntInd is false
     */
    @Test
    void addPayee_WhenPaye1099IntIndIsFalse() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        claim.setClmForResDthInd("N");
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.save(Mockito.any())).thenReturn(payee);
        when(cicStateRepo.findById(Mockito.any())).thenReturn(Optional.of(new State()));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(authentication.getPrincipal()).thenReturn(principal);
        updateClaimDataMap(Mockito.any());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        cicPayeeService.addPayee(payeeDTO);
    }

    private void updateClaimDataMap(Integer any) {
        when(cicPayeeRepo.sumPayeClmIntAmtByClmId(any)).thenReturn(BigDecimal.valueOf(10));
        when(cicPayeeRepo.sumPayeWthldAmtByClmId(Mockito.any())).thenReturn(BigDecimal.valueOf(10));
        when(cicPayeeRepo.sumPayeClmPdAmtByClmId(Mockito.any())).thenReturn(BigDecimal.valueOf(10));
        when(cicPayeeRepo.sumPayeDthbPmtAmtByClmId(Mockito.any())).thenReturn(BigDecimal.valueOf(10));
    }

    private void updateClaimDataMapWhenNull(Integer any) {
        when(cicPayeeRepo.sumPayeClmIntAmtByClmId(any)).thenReturn(null);
        when(cicPayeeRepo.sumPayeWthldAmtByClmId(Mockito.any())).thenReturn(null);
        when(cicPayeeRepo.sumPayeClmPdAmtByClmId(Mockito.any())).thenReturn(null);
        when(cicPayeeRepo.sumPayeDthbPmtAmtByClmId(Mockito.any())).thenReturn(null);
    }

    /* viewPayee method test cases */

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenPayeesExist method.
     * Description: Unit test case for service viewPayee API: positive case
     */
    @Test
    void viewPayee_WhenPayeesExist() throws InvocationTargetException, IllegalAccessException {
        int claimId = 123;
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();

        BeanUtils.copyProperties(payee, payeeDTO);
        List<Payee> payees = new ArrayList<>();
        payees.add(payee);
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.of(new Claim()));
        when(cicPayeeRepo.findByClmId(claimId)).thenReturn(payees);
        when(cicPayeeRepo.count()).thenReturn(1L);

        ViewPayeeResponse response = cicPayeeService.viewPayee(claimId);

        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getTotalCount()).isEqualTo(1);
        Assertions.assertThat(HttpStatus.OK.toString()).isEqualTo(response.getReturnCode());
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenClaimDoesNotExist method.
     * Description: Unit test case for service viewPayee API: no claim exist
     */
    @Test
    void viewPayee_WhenClaimDoesNotExist() {
        int claimId = 123;

        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.empty());

        assertThrows(DataNotFoundException.class, () -> cicPayeeService.viewPayee(claimId));
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenNoPayeesExist method.
     * Description: Unit test case for service viewPayee API: no payees exist
     */
    @Test
    void viewPayee_WhenNoPayeesExist() {
        int claimId = 123;
        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.of(new Claim()));
        when(cicPayeeRepo.findByClmId(claimId)).thenReturn(new ArrayList<>());

        assertThrows(DataNotFoundException.class, () -> cicPayeeService.viewPayee(claimId));
    }

    /**
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * viewPayee_WhenExceptionOccurs method.
     * Description: Unit test case for service viewPayee API: exception occurs
     */
    @Test
    void viewPayee_WhenExceptionOccurs() {
        int claimId = 123;
        when(cicClaimRepo.findById(claimId)).thenThrow(new RuntimeException());

        assertThrows(GlobalException.class, () -> cicPayeeService.viewPayee(claimId));
    }

    /**
     * testEditPayeeSuccess method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API
     */
    @Test
    void testEditPayeeSuccess() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicStateRepo.findById("WV")).thenReturn(Optional.of(new State()));
        when(cicPayeeRepo.save(any(Payee.class))).thenReturn(payee);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.editPayee(payeeDTO);

        assertEquals(HttpStatus.OK.toString(), response.getReturnCode());
        assertEquals(CicConstants.PAYEE_UPDATED, response.getMessage());
    }

    @Test
    void testEditPayeeSuccess_ZZ() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", null, true, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicStateRepo.findById("WV")).thenReturn(Optional.of(new State()));
        when(cicPayeeRepo.save(any(Payee.class))).thenReturn(payee);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.editPayee(payeeDTO);

        assertEquals(HttpStatus.OK.toString(), response.getReturnCode());
        assertEquals(CicConstants.PAYEE_UPDATED, response.getMessage());
    }

    @Test
    void testEditPayeeSuccess_no_currt_int_rate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicStateRepo.findById("WV")).thenReturn(Optional.of(new State()));
        when(cicPayeeRepo.save(any(Payee.class))).thenReturn(payee);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.editPayee(payeeDTO);

        assertEquals(HttpStatus.OK.toString(), response.getReturnCode());
        assertEquals(CicConstants.PAYEE_UPDATED, response.getMessage());
    }

    @Test
    void testEditPayeeSuccess2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(true); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicStateRepo.findById("WV")).thenReturn(Optional.of(new State()));
        when(cicPayeeRepo.save(any(Payee.class))).thenReturn(payee);
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        updateClaimDataMap(Mockito.any());
        cicPayeeService.updateClaimData(payee.getClmId(), claim);
        cacheUpdater.deleteCache(claim);
        GenericResponseDTO response = cicPayeeService.editPayee(payeeDTO);

        assertEquals(HttpStatus.OK.toString(), response.getReturnCode());
        assertEquals(CicConstants.PAYEE_UPDATED, response.getMessage());
    }

    @Test
    void testEditPayeeCompact2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","YY","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("YY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
//        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(CompactRateNotProvidedException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeCompact4() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("YY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeCompact5() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, false, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("YY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeCompact3() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("YY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.setClmCompactClcnInd("T");
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","YY","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("YY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
//        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(CompactRateNotProvidedException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }


    @Test
    void testEditPayeeInvaild4() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.empty());
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(DataNotFoundException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeInvaild2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "ZZ", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeInvaild3() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "ZZ",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void testEditPayeeInvaild_over3() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"ZZ","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),true,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";

        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeDataNotFoundException method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API data not found
     */
    @Test
    void testEditPayeeDataNotFoundException() {
        PayeeDTO payeeDTO = new PayeeDTO();
        payeeDTO.setPayeId(187654);

        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.empty());

        assertThrows(DataNotFoundException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeInvalidRequestException method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API Invalid Request Exception
     */
    @Test
    void testEditPayeeInvalidRequestException() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);

        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicStateRepo.findById("WV")).thenReturn(Optional.empty());

        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    @Test
    void testEditPayeeCompactDate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenThrow(new CompactDateException());
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));

        assertThrows(CompactDateException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeCurrentRate Exception method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service editPayee API Current rate Exception
     */
    @Test
    void testEditPayeecurrentrate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());

        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeLoanRate Exception method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service editPayee API Loan rate Exception
     */
    @Test
    void testEditLoanRate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenThrow(new LoanRateNotProvidedException());

        assertThrows(LoanRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditInterestRate Exception method.
     * Description: Unit test case for service editPayee API Interest rate Exception
     */
    @Test
    void testEditInterestRate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenThrow(new InterestRateNotProvidedException());
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);

        assertThrows(InterestRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    @Test
    void testEditInterestRate_MAP() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("PROMPT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);

        assertThrows(InterestRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeCompactRate Exception method.
     * @author <a href="rohit.r.gupta@sunlife.com" >Rohit Gupta(BK87)</a>
     * Description: Unit test case for service editPayee API Compact rate Exception
     */
    @Test
    void testEditPayeecompactrate() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), BigDecimal.valueOf(100.0), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.setClmCompactClcnInd("T");
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));

        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
//        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));

        assertThrows(CompactRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    @Test
    void testEditPayeeInvalidRequestException3() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        payeeDTO.setPayeFullNm("DJ");
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.of(new Payee()));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));

        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    @Test
    void testEditPayeeInvalidRequestException2() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        payeeDTO.setPayeFullNm("DJ");
        when(cicPayeeRepo.findByPayeFullNmAndClmId(Mockito.any(),Mockito.any())).thenReturn(Optional.empty());
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));

        assertThrows(GlobalException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }


    /**
     * testEditPayeeInvalidRequestExceptionIfSSNTypeNotMatched method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API Invalid Request Exception SSN Type not matching
     */
    @Test
    void testEditPayeeInvalidRequestExceptionIfSSNTypeNotMatched() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(new CurrentRate()));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeInvalidRequestExceptionIfNameAlreadyExists method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API Invalid Request Exception for Name already exists
     */
    @Test
    void testEditPayeeInvalidRequestExceptionIfNameAlreadyExists() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        when(cicAdminRepo.findById(claim.getAdmnSystCd())).thenReturn(Optional.of(adminData));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);

        assertThrows(InvalidRequestException.class, () -> cicPayeeService.editPayee(payeeDTO));
    }

    /**
     * testEditPayeeGlobalException method.
     * @author <a href="ankit.kumar2@sunlife.com" >Ankit Kumar(BV26)</a>
     * Unit test case for service editPayee API Global Exception
     */
    @Test
    void testEditPayeeGlobalException() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(null,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",false,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(true);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicStateRuleRepo.findTopByStCdOrderByStrlEffDtDesc(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(stateRule);
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(new CurrentRate()));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(interestCalculationUtil.CalcClaimInterest(Mockito.any())).thenReturn(payeeDTO);

        when(cicStateRepo.findById("Test State Code")).thenReturn(Optional.of(new State()));
        when(cicPayeeRepo.save(any(Payee.class))).thenThrow(new GlobalException());
        when(authentication.getPrincipal()).thenReturn(principal);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        assertThrows(GlobalException.class, () -> cicPayeeService.editPayee(payeeDTO));

    }

    @Test
    void editPayee_When_Current_Rate_negative() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date("09/31/2025"),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),false,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        currentRate.setCurrIntRt(BigDecimal.valueOf(-10.0));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.of(currentRate));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(UserInterestRateNotProvidedException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    @Test
    void editPayee_When_Current_Rate_empty() throws InvocationTargetException, IllegalAccessException {
        StateRule stateRule = new StateRule();
        stateRule.setCalcIdtypCd("PROOF");
        stateRule.setReqdIdtypCd("PROOF");
        stateRule.setIruleCd("CURRT");
        stateRule.setStrlIntCalcOfstNum(1);
        stateRule.setStrlIntReqdOfstNum(1);
        stateRule.setStCd("NY");

        Admin admin = new Admin();
        admin.setLobCd("I");
        ClaimDTO claimDTO = new ClaimDTO(146895, "UT1233G","UT124357", new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), new BigDecimal("100.0"), "Rohit", "Gupta", "WV",new Date(),new Date(), "987123456", "WV", false, true, true, 20, "I1","GROUP");
        Claim claim = new Claim();
        BeanUtils.copyProperties(claim, claimDTO);
        claim.setAdmin(admin);
        claim.getAdmin();
        claim.getAdmin().getLobCd();
        PayeeDTO payeeDTO = new PayeeDTO(187654,149853,"WV","TEST","X","X","X","X","WV","11111","1111","111111111","P",BigDecimal.valueOf(0.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(555555.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),BigDecimal.valueOf(0.00),5,new Date(),false,new Date(),"bk45",true,new Date(), new Date(), false,BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "AK", BigDecimal.valueOf(10.00),true,BigDecimal.valueOf(10.00), "test",true,BigDecimal.valueOf(10.00), "msg",BigDecimal.valueOf(0.00));
        Payee payee = new Payee();
        payeeDTO.setPayeDfltOvrdInd(false);
        payeeDTO.setPaye1099IntInd(false); // set a value for paye1099IntInd
        BeanUtils.copyProperties(payee, payeeDTO);
        State state = new State();
        state.setStateCd("NY");
        String lob = "I";
        currentRate.setCurrIntRt(BigDecimal.valueOf(-10.0));
        when(cicPayeeRepo.findById(187654)).thenReturn(Optional.of(payee));
        when(cicClaimRepo.findById(Mockito.any())).thenReturn(Optional.of(claim));
        when(cicCurrentRateRepo.findCurrentRate(Mockito.any())).thenReturn(Optional.empty());
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(lob);
        when(interestCalculationUtil.getStateRuleData(claim.getAdmin().getLobCd(), payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule).thenReturn(stateRule);
        when(interestCalculationUtil.getStateRuleData(lob, payeeDTO.getCalcStCd(), payeeDTO.getPayePmtDt())).thenReturn(stateRule);
        assertThrows(GlobalException.class, ()->cicPayeeService.editPayee(payeeDTO));
    }

    // Test cases for getInstructionsFromStCd

    /**
     * getInstructionsFromStCd_testOk method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getInstructionsFromStCd API: positive case
     */
    @Test
    void getInstructionsFromStCd_testOk() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(stateRule);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));

        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk4() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));

        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk3() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));

        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk_compact_calc() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("YY");
        claim.setIssStCd("YY");
        Date payePmtDt = new Date();
        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.fetchStateInfo(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB);
        when(interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, "YY", payePmtDt)).thenReturn(stateRule);
        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "YY", claim.getInsdDthResStCd(), "YY", "YY", payePmtDt, BigDecimal.valueOf(5));
        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk_calc_state() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(stateRule);

        assertThrows(CompactDateException.class, () -> cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "YY", "CO", payePmtDt, BigDecimal.valueOf(5)));

    }

    @Test
    void getInstructionsFromStCd_testOk_2() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);
        when(interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(stateRule);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));

        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk_3() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("N");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);
        when(interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(stateRule);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));
        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk_5() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("N");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);
        when(interestCalculationUtil.getStateRuleData(InterestCalculationConstants.MCSTR_INDIVIDUAL_LOB, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(null);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));
        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    @Test
    void getInstructionsFromStCd_testOk_4() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), null, null, payePmtDt, BigDecimal.valueOf(5));
        Assertions.assertThat(instructionsDTO).isNotNull();
    }

    /**
     * getInstructionsFromStCd_testClaimNotFound method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getInstructionsFromStCd API: claim not found
     */
    @Test
    void getInstructionsFromStCd_ClaimNotFound() {
        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(DataNotFoundException.class, () -> cicPayeeService.getInstructionsFromStCd(1, "NY", "NY", "NY", "NY", new Date(), BigDecimal.valueOf(5)));
    }

    /**
     * getInstructionsFromStCd_testGlobalException method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getInstructionsFromStCd API: Global Exception
     */
    @Test
    void getInstructionsFromStCd_GlobalException() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("Y");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenThrow(new GlobalException());

        assertThrows(GlobalException.class, () -> cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5)));
    }

    /**
     * getInstructionsFromStCd_testInvalidRequestException method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getInstructionsFromStCd API: Invalid Request Exception
     */
    @Test
    void getInstructionsFromStCd_StateRuleNotFound() {
        Claim claim = new Claim();
        claim.setClmForResDthInd("N");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setInsdDthResStCd("CO");
        claim.setIssStCd("CO");
        Date payePmtDt = new Date();

        StateRule stateRule = new StateRule();
        stateRule.setStrlSpclInstrTxt("Test Instruction");

        when(cicClaimRepo.findById(anyInt())).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenReturn(stateRule);

        InstructionsDTO instructionsDTO = cicPayeeService.getInstructionsFromStCd(1, "CO", claim.getInsdDthResStCd(), "CO", "CO", payePmtDt, BigDecimal.valueOf(5));

        Assertions.assertThat(instructionsDTO).isNotNull();
    }
    /**
     * getInstructionsFromStCd_testInvalidRequestException method.
     * @author <a href="megha.gupta@sunlife.com" >Megha Gupta(BK45)</a>
     * Description: Unit test case for service getInstructionsFromStCd API: Invalid Request Exception
     */
    @Test
    void getInstructionsFromStCd_ThrowsInvalidRequestException_WhenInvalidRequestOccurs() {
        int claimId = 1;
        String payeStCd = "NY";
        String payeResStCd = "NY";
        String calcStCd = "NY";
        String issueStCd = "NY";
        Date payePmtDt = new Date();

        Claim claim = new Claim();
        claim.setClmForResDthInd("N");
        claim.setAdmin(new Admin());
        claim.getAdmin().setLobCd("I");
        claim.setIssStCd("CO");
        claim.setInsdDthResStCd("CO");

        when(cicClaimRepo.findById(claimId)).thenReturn(Optional.of(claim));
        when(interestCalculationUtil.getStateRuleData(null, claim.getInsdDthResStCd(), payePmtDt)).thenThrow(new InvalidRequestException("Invalid request"));

        assertThrows(InvalidRequestException.class, () -> cicPayeeService.getInstructionsFromStCd(claimId, payeStCd, claim.getInsdDthResStCd(), calcStCd, issueStCd, payePmtDt, BigDecimal.valueOf(5)));
    }

}
