jte {
    pipeline_template = "sunlife-us-gradle-applications-ci-template"
}
libraries {
    gradle {
        java_version = "JDK 17.0.9"
        static_code_analysis {
          run_sonarqube_scan = false
          enforce_sonarqube_gate = false
          java_version = "JDK 17.0.9"
        }
      	sca_scan {
          run_snyk_scan = false
          enforce_snyk_gate = false
     	}
    	publish {
    		artifactory_instance_id = "Artifactory"
    	}
    }
  	checkmarx {
    	run_checkmarx_scan = false
      	enforce_checkmarx_gate = false
  	}
    quay {
    	registry_credentials_id = "artifactorydockerpoc"
        build {
            build_container_image = true
            docker_file_name = "Dockerfile"
          	scm_credentials_id = "4e8ffdd4-9eb7-4d5e-ae30-1b0e20d645e0"
          	scm_repo_url = "https://bitbucket.us.sunlife/scm/clinca/claims-interest-calculator.git"
          	artifactory_read_access_token_id = "artifactorytoken"
        }
    }
}